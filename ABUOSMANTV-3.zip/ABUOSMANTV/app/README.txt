ABUOSMAN TV
1) Android Studio > Open > ABUOSMANTV folder > Gradle sync > Run
2) Channel links: app/src/main/assets/channels.json
   har channel ka "url" (m3u8) aur chahein to "logo" (image link) yahan bharein.
   logo khali ho to rang-birangi initials wala tile nazar aata hai.
