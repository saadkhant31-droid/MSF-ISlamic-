package com.abuosman.tv

import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

@Composable
fun PillButton(text: String, modifier: Modifier = Modifier, color: Color = C.blue, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(color).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White, fontSize = 13.sp) }
}

@Composable
fun EditDialog(ch: Channel, st: AppState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var url by remember { mutableStateOf(st.urls[ch.id] ?: "") }
    var logo by remember { mutableStateOf(st.logos[ch.id] ?: "") }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) {
            try {
                val f = File(ctx.filesDir, "logo_" + System.currentTimeMillis() + ".img")
                ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                logo = f.absolutePath
            } catch (e: Exception) {
                Toast.makeText(ctx, "Could not load image", Toast.LENGTH_SHORT).show()
            }
        }
    }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = C.card, titleContentColor = Color.White, textContentColor = Color.White,
        title = { Text(ch.name) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Direct stream link (m3u8)  |  اسٹریم لنک", fontSize = 12.sp, color = C.sub)
                OutlinedTextField(url, { url = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("https://...") })
                Text("Logo  |  لوگو", fontSize = 12.sp, color = C.sub)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    LogoTile(ch.copy(logo = logo), Modifier.size(56.dp))
                    Spacer(Modifier.width(10.dp))
                    PillButton("Choose from gallery", Modifier.weight(1f)) {
                        picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                    }
                }
                OutlinedTextField(logo, { logo = it }, singleLine = true, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("or paste image link") })
            }
        },
        confirmButton = { TextButton(onClick = { st.setOverride(ch.id, url, logo); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun ImportDialog(channels: List<Channel>, st: AppState, onClose: () -> Unit) {
    val ctx = LocalContext.current
    var text by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = C.card, titleContentColor = Color.White, textContentColor = Color.White,
        title = { Text("Paste links list") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Geo News = https://...\nARY News = https://...", fontSize = 12.sp, color = C.sub)
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().height(180.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = {
                var n = 0
                text.lines().forEach { line ->
                    val k = line.indexOfFirst { it == '=' || it == '|' }
                    if (k > 0) {
                        val name = line.substring(0, k).trim()
                        val u = line.substring(k + 1).trim()
                        val c = channels.find { it.name.equals(name, true) }
                        if (c != null && u.isNotBlank()) { st.setUrl(c.id, u); n++ }
                    }
                }
                Toast.makeText(ctx, "$n links saved", Toast.LENGTH_SHORT).show()
                onClose()
            }) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}

@Composable
fun PlaylistDialog(st: AppState, onClose: () -> Unit) {
    var text by remember { mutableStateOf(st.playlistUrl) }
    AlertDialog(
        onDismissRequest = onClose,
        containerColor = C.card, titleContentColor = Color.White, textContentColor = Color.White,
        title = { Text("Playlist links (M3U) - one per line") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth())
                TextButton(onClick = { text = DEFAULT_PLAYLIST }) { Text("Reset to default") }
            }
        },
        confirmButton = { TextButton(onClick = { st.setPlaylist(text); onClose() }) { Text("Save") } },
        dismissButton = { TextButton(onClick = onClose) { Text("Cancel") } }
    )
}
