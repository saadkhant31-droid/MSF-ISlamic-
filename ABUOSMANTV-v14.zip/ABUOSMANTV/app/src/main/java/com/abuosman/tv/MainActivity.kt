package com.abuosman.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = 0xFF071226.toInt()
        window.navigationBarColor = 0xFF0E1F3F.toInt()
        val st = AppState(this)
        val channels = loadChannels(this)
        st.baseNames = channels.map { it.name }
        st.refreshPlaylist()
        setContent { AppTheme { Root(st, channels) } }
    }
}

@Composable
fun Root(st: AppState, baseChannels: List<Channel>) {
    val all = (baseChannels + st.extraChannels()).map { st.eff(it) }
    val live = all.filter { !it.offline }
    val channels = if (st.hideOffline && live.size >= 3) live else all
    var tab by remember { mutableStateOf(0) }
    var liveCat by remember { mutableStateOf("all") }
    var playingId by remember { mutableStateOf<String?>(null) }
    var switched by remember { mutableStateOf(false) }
    val cur = channels.find { it.id == playingId }

    BackHandler(enabled = cur != null) { playingId = null; switched = false }

    if (cur != null) {
        val sib = channels.filter { it.category == cur.category }
        key(cur.id + (st.urls[cur.id] ?: "")) {
            PlayerScreen(
                cur, st, if (switched) st.delaySec * 1000L else 0L,
                onPrev = { val i = sib.indexOf(cur); playingId = sib[(i - 1 + sib.size) % sib.size].id; switched = true },
                onNext = { val i = sib.indexOf(cur); playingId = sib[(i + 1) % sib.size].id; switched = true },
                onBack = { playingId = null; switched = false }
            )
        }
        return
    }

    Scaffold(
        containerColor = C.bg,
        topBar = { TopBar(st, { liveCat = "all"; tab = 1 }, { tab = 2 }, { tab = 4 }) },
        bottomBar = { BottomBar(st, tab) { tab = it } }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(st, channels, { t, c -> liveCat = c; tab = t }) { playingId = it.id }
                1 -> LiveScreen(st, channels, liveCat) { playingId = it.id }
                2 -> FavoritesScreen(st, channels) { playingId = it.id }
                3 -> HistoryScreen(st, channels) { playingId = it.id }
                else -> SettingsScreen(st, channels)
            }
        }
    }
}

@Composable
fun TopBar(st: AppState, onSearch: () -> Unit, onFav: () -> Unit, onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(C.bg).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(40.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Row {
                Text("ABUOSMAN ", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
                Text("TV", color = C.gold, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold)
            }
            Text("Live TV | News | Sports | Islamic", color = C.sub, fontSize = 9.sp, maxLines = 1)
        }
        Icon(Icons.Filled.Search, null, tint = Color.White, modifier = Modifier.size(34.dp).clickable { onSearch() }.padding(5.dp))
        Icon(Icons.Filled.Star, null, tint = Color.White, modifier = Modifier.size(34.dp).clickable { onFav() }.padding(5.dp))
        Icon(Icons.Filled.Settings, null, tint = Color.White, modifier = Modifier.size(34.dp).clickable { onSettings() }.padding(5.dp))
    }
}

@Composable
fun BottomBar(st: AppState, tab: Int, onTab: (Int) -> Unit) {
    val items = listOf(
        Triple(Icons.Filled.Home, "Home", "ہوم"),
        Triple(Icons.Filled.LiveTv, "Live TV", "لائیو ٹی وی"),
        Triple(Icons.Filled.Favorite, "Favorites", "پسندیدہ"),
        Triple(Icons.Filled.History, "History", "تاریخ"),
        Triple(Icons.Filled.Settings, "Settings", "ترتیبات")
    )
    NavigationBar(containerColor = C.card) {
        items.forEachIndexed { i, (icon, en, ur) ->
            val sel = tab == i
            NavigationBarItem(
                selected = sel, onClick = { onTab(i) },
                icon = { Icon(icon, null) },
                label = {
                    Bi(en, ur, st, size = 10.sp, align = Alignment.CenterHorizontally,
                        color = if (sel) C.blue else Color.White, urColor = if (sel) C.blue else C.sub)
                },
                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = C.blue, unselectedIconColor = Color.White,
                    selectedTextColor = C.blue, unselectedTextColor = Color.White,
                    indicatorColor = Color(0xFF16305F)
                )
            )
        }
    }
}
