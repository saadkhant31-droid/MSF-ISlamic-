package com.abuosman.tv

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage

object C {
    val bg = Color(0xFF071226)
    val card = Color(0xFF0E1F3F)
    val border = Color(0xFF1E3A6B)
    val blue = Color(0xFF1E6BFF)
    val gold = Color(0xFFFFC107)
    val green = Color(0xFF1B8A3C)
    val purple = Color(0xFF6A2BD9)
    val orange = Color(0xFFF57C00)
    val red = Color(0xFFE53935)
    val sub = Color(0xFFA9B8D6)
}

fun catColor(c: String): Color = when (c) {
    "news" -> C.green; "sports" -> C.blue; "islamic" -> C.purple; "regional" -> C.orange; else -> C.blue
}
fun catEmoji(c: String) = when (c) { "news" -> "📰"; "sports" -> "⚽"; "islamic" -> "🕌"; "regional" -> "🌐"; else -> "📺" }
fun catEn(c: String) = when (c) {
    "news" -> "News"; "sports" -> "Sports"; "islamic" -> "Islamic"; "regional" -> "Regional"; else -> "All"
}
fun catUr(c: String) = when (c) {
    "news" -> "خبریں"; "sports" -> "کھیل"; "islamic" -> "اسلامی"; "regional" -> "علاقائی"; else -> "سب"
}
fun secEn(c: String) = when (c) {
    "news" -> "Pakistani News Channels"; "sports" -> "Sports Channels"
    "islamic" -> "Islamic Channels"; else -> "Regional Channels"
}
fun secUr(c: String) = when (c) {
    "news" -> "پاکستانی نیوز چینلز"; "sports" -> "اسپورٹس چینلز"
    "islamic" -> "اسلامی چینلز"; else -> "علاقائی چینلز"
}

@Composable
fun AppTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = C.blue, background = C.bg, surface = C.bg,
            onSurface = Color.White, onBackground = Color.White
        )
    ) { Surface(Modifier.fillMaxSize(), color = C.bg, content = content) }
}

/** انگلش + اردو دونوں لائنیں (سیٹنگز کے مطابق) */
@Composable
fun Bi(
    en: String, ur: String, st: AppState, modifier: Modifier = Modifier,
    size: TextUnit = 14.sp, color: Color = Color.White, bold: Boolean = false,
    align: Alignment.Horizontal = Alignment.Start, urColor: Color = C.sub
) {
    val ta = if (align == Alignment.CenterHorizontally) TextAlign.Center else TextAlign.Start
    Column(modifier, horizontalAlignment = align) {
        Text(en, fontSize = size, color = color, textAlign = ta, maxLines = 1, overflow = TextOverflow.Ellipsis,
            fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        if (st.bilingual && ur.isNotBlank()) {
            Text(ur, fontSize = (size.value * 0.9f).sp, color = urColor, textAlign = ta,
                maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
    }
}

@Composable
fun LogoTile(ch: Channel, modifier: Modifier = Modifier) {
    val cols = listOf(Color(0xFF1565C0), Color(0xFFC62828), Color(0xFF2E7D32),
        Color(0xFF6A1B9A), Color(0xFFEF6C00), Color(0xFF00838F))
    val col = cols[(ch.name.hashCode() and 0x7fffffff) % cols.size]
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(if (ch.logo.isBlank()) col else Color.White),
        contentAlignment = Alignment.Center
    ) {
        if (ch.logo.isBlank()) {
            val ini = ch.name.split(" ").filter { it.isNotBlank() }.take(2).joinToString("") { it.take(1).uppercase() }
            Text(ini, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        } else {
            AsyncImage(model = ch.logo, contentDescription = ch.name, modifier = Modifier.fillMaxSize().padding(4.dp))
        }
    }
}

@Composable
fun ChannelCard(ch: Channel, st: AppState, modifier: Modifier = Modifier, editMode: Boolean = false, onClick: () -> Unit) {
    val fav = ch.id in st.favorites
    val shape = RoundedCornerShape(12.dp)
    Box(
        modifier.clip(shape).background(C.card).border(1.dp, C.border, shape)
            .clickable { if (editMode) st.toggleFav(ch.id) else onClick() }.padding(8.dp)
    ) {
        Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
            LogoTile(ch, Modifier.fillMaxWidth().height(62.dp))
            Spacer(Modifier.height(5.dp))
            Bi(ch.name, ch.nameUr, st, size = 12.sp, align = Alignment.CenterHorizontally)
            Spacer(Modifier.height(2.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (ch.offline) C.sub else C.red))
                Spacer(Modifier.width(4.dp))
                Text(if (ch.offline) "OFFLINE" else "LIVE", color = if (ch.offline) C.sub else C.red, fontSize = 10.sp, fontWeight = FontWeight.Bold)
            }
        }
        Icon(
            if (editMode) Icons.Filled.Close else if (fav) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = null,
            tint = if (editMode || fav) C.red else Color.White,
            modifier = Modifier.align(Alignment.TopEnd).size(20.dp).clickable { st.toggleFav(ch.id) }
        )
    }
}
