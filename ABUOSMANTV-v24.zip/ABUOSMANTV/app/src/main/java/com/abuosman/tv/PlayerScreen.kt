package com.abuosman.tv

import android.app.Activity
import android.content.pm.ActivityInfo
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

@Composable
fun PlayerScreen(
    ch: Channel, st: AppState, delayMs: Long,
    onPrev: () -> Unit, onNext: () -> Unit, onBack: () -> Unit
) {
    val ctx = LocalContext.current
    val activity = ctx as Activity
    var buffering by remember { mutableStateOf(true) }
    var full by remember { mutableStateOf(false) }
    var retries by remember { mutableStateOf(0) }
    var srcIdx by remember { mutableStateOf(0) }
    var edit by remember { mutableStateOf(false) }
    val isOpen = ch.url.startsWith("open:")
    val isWeb = ch.url.isNotBlank() && !isOpen && !isStreamUrl(ch.url)
    var noLive by remember { mutableStateOf(false) }
    var ytFailed by remember { mutableStateOf(false) }
    var pageUrl by remember { mutableStateOf(if (isWeb && !ch.url.startsWith("yt:")) ch.url else "") }
    LaunchedEffect(ch.url) {
        if (ch.url.startsWith("yt:")) {
            val u = withContext(Dispatchers.IO) { ytPageUrl(ch.url.removePrefix("yt:")) }
            if (u.isNotBlank()) pageUrl = u
            else if (ch.web.isNotBlank()) pageUrl = ch.web
            else ytFailed = true
        }
    }
    val sources = remember { if (ch.url.isBlank() || isWeb) emptyList() else listOf(ch.url) + ch.alts }
    val handler = remember { Handler(Looper.getMainLooper()) }
    val startTime = remember { System.currentTimeMillis() }
    val startElapsed = remember { SystemClock.elapsedRealtime() }

    val exo = remember {
        val lc = DefaultLoadControl.Builder().setBufferDurationsMs(10_000, 40_000, 1_500, 3_000).build()
        ExoPlayer.Builder(ctx).setLoadControl(lc).build()
    }

    // ویب پلیئر کی فل سکرین
    val fsHolder = remember { arrayOfNulls<Any>(2) }
    var inFs by remember { mutableStateOf(false) }
    val exitFs: () -> Unit = {
        val v = fsHolder[0] as? android.view.View
        (v?.parent as? android.view.ViewGroup)?.removeView(v)
        (fsHolder[1] as? android.webkit.WebChromeClient.CustomViewCallback)?.onCustomViewHidden()
        fsHolder[0] = null; fsHolder[1] = null
        inFs = false
        activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        WindowCompat.getInsetsController(activity.window, activity.window.decorView).show(WindowInsetsCompat.Type.systemBars())
    }
    BackHandler(enabled = inFs) { exitFs() }
    BackHandler(enabled = full) { full = false }
    if (edit) EditDialog(ch, st) { edit = false }

    LaunchedEffect(Unit) { st.addHistory(ch.id, startTime) }
    // خودکار پلے: پہلا کام نہ کرے تو اگلا ذریعہ آزماتا ہے
    LaunchedEffect(srcIdx) {
        val u = sources.getOrNull(srcIdx) ?: ""
        if (u.isNotBlank()) {
            if (delayMs > 0 && srcIdx == 0) delay(delayMs)
            exo.setMediaItem(MediaItem.fromUri(u)); exo.prepare(); exo.playWhenReady = true
        }
    }
    LaunchedEffect(st.quality, st.dataMode) {
        exo.trackSelectionParameters = exo.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, st.maxHeight()).build()
    }
    LaunchedEffect(full) {
        activity.requestedOrientation =
            if (full) ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        val c = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
        if (full) {
            c.hide(WindowInsetsCompat.Type.systemBars())
            c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        } else c.show(WindowInsetsCompat.Type.systemBars())
    }
    DisposableEffect(exo) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                buffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_READY) retries = 0
            }
            override fun onPlayerError(error: PlaybackException) {
                if (st.autoRetry && retries < 2) {
                    retries++
                    handler.postDelayed({ exo.prepare() }, 1500L)
                } else if (srcIdx + 1 < sources.size) {
                    retries = 0
                    srcIdx = srcIdx + 1
                } else {
                    Toast.makeText(ctx, "Channel is offline right now | چینل ابھی بند ہے", Toast.LENGTH_LONG).show()
                }
            }
        }
        exo.addListener(l)
        onDispose {
            handler.removeCallbacksAndMessages(null)
            exo.removeListener(l)
            exo.release()
            st.addDuration(startTime, (SystemClock.elapsedRealtime() - startElapsed) / 1000)
            activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
            WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                .show(WindowInsetsCompat.Type.systemBars())
        }
    }

    Column(Modifier.fillMaxSize().background(C.bg)) {
        if (!full) {
            Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.clip(RoundedCornerShape(8.dp)).background(C.card).clickable { onBack() }.padding(horizontal = 12.dp, vertical = 8.dp)) {
                    Text("←", color = Color.White, fontSize = 18.sp)
                }
                Spacer(Modifier.width(10.dp))
                Bi(ch.name, ch.nameUr, st, Modifier.weight(1f), size = 17.sp, bold = true)
                Text(if (ch.id in st.favorites) "❤️" else "🤍", fontSize = 26.sp,
                    modifier = Modifier.clickable { st.toggleFav(ch.id) }.padding(6.dp))
            }
        }
        Box(
            if (full) Modifier.fillMaxSize().background(Color.Black)
            else Modifier.fillMaxWidth().aspectRatio(16f / 9f).background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            if (isOpen) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(12.dp)) {
                    Text("یہ چینل سرکاری ایپ میں چلتا ہے\nThis channel plays in its official app", color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    PillButton("Open official app  |  سرکاری ایپ کھولیں") {
                        try {
                            ctx.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW,
                                android.net.Uri.parse(ch.url.removePrefix("open:"))))
                        } catch (e: Exception) { Toast.makeText(ctx, "Cannot open link", Toast.LENGTH_SHORT).show() }
                    }
                }
            } else if (isWeb) {
                AndroidView(
                    factory = { c ->
                        android.webkit.WebView(c).apply {
                            setBackgroundColor(android.graphics.Color.BLACK)
                            setLayerType(android.view.View.LAYER_TYPE_HARDWARE, null)
                            settings.javaScriptEnabled = true
                            settings.domStorageEnabled = true
                            settings.mediaPlaybackRequiresUserGesture = false
                            settings.loadWithOverviewMode = true
                            settings.useWideViewPort = true
                            settings.userAgentString = "Mozilla/5.0 (Linux; Android 13; Pixel 7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36"
                            addJavascriptInterface(object {
                                @android.webkit.JavascriptInterface fun onLive() { android.os.Handler(android.os.Looper.getMainLooper()).post { noLive = false } }
                                @android.webkit.JavascriptInterface fun onNoLive() { android.os.Handler(android.os.Looper.getMainLooper()).post { noLive = true } }
                            }, "AbuApp")
                            webViewClient = object : android.webkit.WebViewClient() {
                                override fun onPageFinished(view: android.webkit.WebView, url: String?) {
                                    if ((url ?: "").contains("youtube.com")) view.evaluateJavascript(YT_ONLY_VIDEO_JS, null)
                                }
                                override fun doUpdateVisitedHistory(view: android.webkit.WebView, url: String?, isReload: Boolean) {
                                    if ((url ?: "").contains("youtube.com")) view.evaluateJavascript(YT_ONLY_VIDEO_JS, null)
                                }
                            }
                            webChromeClient = object : android.webkit.WebChromeClient() {
                                override fun onShowCustomView(v: android.view.View, cb: android.webkit.WebChromeClient.CustomViewCallback) {
                                    if (fsHolder[0] != null) { cb.onCustomViewHidden(); return }
                                    fsHolder[0] = v; fsHolder[1] = cb; inFs = true
                                    (activity.window.decorView as android.view.ViewGroup).addView(v,
                                        android.view.ViewGroup.LayoutParams(android.view.ViewGroup.LayoutParams.MATCH_PARENT, android.view.ViewGroup.LayoutParams.MATCH_PARENT))
                                    activity.requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
                                    val ic = WindowCompat.getInsetsController(activity.window, activity.window.decorView)
                                    ic.hide(WindowInsetsCompat.Type.systemBars())
                                    ic.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
                                }
                                override fun onHideCustomView() { exitFs() }
                            }
                            keepScreenOn = st.keepOn
                        }
                    },
                    update = { w ->
                        if (pageUrl.isNotBlank() && w.tag != pageUrl) {
                            w.tag = pageUrl
                            w.loadUrl(pageUrl)
                        }
                    },
                    onRelease = { it.destroy() },
                    modifier = Modifier.fillMaxSize()
                )
                if (noLive && ch.url.startsWith("yt:")) Box(Modifier.fillMaxSize().background(Color.Black), contentAlignment = Alignment.Center) {
                    Text("لائیو ابھی شروع نہیں ہے\nLive has not started yet", color = Color.White, fontSize = 15.sp, textAlign = androidx.compose.ui.text.style.TextAlign.Center)
                }
                Box(Modifier.align(Alignment.BottomEnd).padding(8.dp).clip(RoundedCornerShape(8.dp))
                    .background(Color(0x99000000)).clickable { full = !full }.padding(horizontal = 10.dp, vertical = 6.dp)) {
                    Text(if (full) "✕" else "⛶", color = Color.White, fontSize = 20.sp)
                }
                if (ytFailed) Text("Live stream not available right now\nلائیو ابھی دستیاب نہیں", color = Color.White, fontSize = 14.sp)
                else if (pageUrl.isBlank()) CircularProgressIndicator(color = C.blue)
            } else if (sources.isEmpty()) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, modifier = Modifier.padding(12.dp)) {
                    Text("Stream not available right now\nاس چینل کی اسٹریم ابھی دستیاب نہیں", color = Color.White, fontSize = 14.sp)
                    Spacer(Modifier.height(10.dp))
                    PillButton("Add stream link  |  لنک ڈالیں") { edit = true }
                }
            } else {
                AndroidView(
                    factory = {
                        PlayerView(it).apply {
                            this.player = exo
                            useController = true
                            keepScreenOn = st.keepOn
                            setFullscreenButtonClickListener { f -> full = f }
                        }
                    },
                    modifier = Modifier.fillMaxSize()
                )
                if (buffering) CircularProgressIndicator(color = C.blue)
            }
        }
        if (!full) {
            Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(10.dp)).clickable { onPrev() }.padding(12.dp),
                        contentAlignment = Alignment.Center) { Text("⏮  Previous", color = Color.White) }
                    Box(Modifier.weight(1f).clip(RoundedCornerShape(10.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(10.dp)).clickable { onNext() }.padding(12.dp),
                        contentAlignment = Alignment.Center) { Text("Next  ⏭", color = Color.White) }
                }
                Bi("Video Quality", "ویڈیو کوالٹی", st, size = 14.sp, bold = true)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(0 to "Auto", 240 to "240p", 360 to "360p", 480 to "480p", 720 to "720p", 1080 to "1080p").forEach { (v, label) ->
                        val sel = st.quality == v
                        Box(
                            Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (sel) C.blue else C.card)
                                .border(1.dp, if (sel) Color(0xFF5B9BFF) else C.border, RoundedCornerShape(8.dp))
                                .clickable { st.updateQuality(v) }.padding(vertical = 8.dp),
                            contentAlignment = Alignment.Center
                        ) { Text(label, color = Color.White, fontSize = 11.sp) }
                    }
                }
                PillButton("✏  Edit link / logo", Modifier.fillMaxWidth(), C.card) { edit = true }
            }
        }
    }
}
