package com.abuosman.tv

import android.content.Context
import androidx.compose.runtime.*
import org.json.JSONObject

data class Channel(val name: String, val nameUr: String, val category: String, val url: String, val logo: String) {
    val id: String get() = name
}

data class HistoryItem(val id: String, val time: Long, val dur: Long)

fun loadChannels(ctx: Context): List<Channel> {
    val text = ctx.assets.open("channels.json").bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("channels")
    return List(arr.length()) {
        val o = arr.getJSONObject(it)
        Channel(o.getString("name"), o.optString("nameUr", ""), o.getString("category"),
            o.optString("url", ""), o.optString("logo", ""))
    }
}

class AppState(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("abuosman", Context.MODE_PRIVATE)

    var bilingual by mutableStateOf(p.getBoolean("bi", true))
        private set
    var quality by mutableStateOf(p.getInt("quality", 0))      // 0 = Auto
        private set
    var dataMode by mutableStateOf(p.getInt("data", 1))        // 0 Standard, 1 Saver, 2 Low
        private set
    var autoRetry by mutableStateOf(p.getBoolean("retry", true))
        private set
    var continueWatching by mutableStateOf(p.getBoolean("cont", true))
        private set
    var delaySec by mutableStateOf(p.getInt("delay", 2))
        private set
    var keepOn by mutableStateOf(p.getBoolean("keepon", true))
        private set

    val favorites = mutableStateListOf<String>().apply { addAll(p.getStringSet("fav", emptySet())!!) }
    val history = mutableStateListOf<HistoryItem>().apply {
        addAll((p.getString("hist", "") ?: "").split("|").mapNotNull {
            val a = it.split("~")
            if (a.size == 3) HistoryItem(a[0], a[1].toLongOrNull() ?: 0L, a[2].toLongOrNull() ?: 0L) else null
        })
    }

    fun updateBilingual(v: Boolean) { bilingual = v; p.edit().putBoolean("bi", v).apply() }
    fun updateQuality(v: Int) { quality = v; p.edit().putInt("quality", v).apply() }
    fun updateDataMode(v: Int) { dataMode = v; p.edit().putInt("data", v).apply() }
    fun updateAutoRetry(v: Boolean) { autoRetry = v; p.edit().putBoolean("retry", v).apply() }
    fun updateContinueWatching(v: Boolean) { continueWatching = v; p.edit().putBoolean("cont", v).apply() }
    fun setDelay(v: Int) { delaySec = v; p.edit().putInt("delay", v).apply() }
    fun updateKeepOn(v: Boolean) { keepOn = v; p.edit().putBoolean("keepon", v).apply() }

    fun resetSettings() {
        updateBilingual(true); updateQuality(0); updateDataMode(1); updateAutoRetry(true)
        updateContinueWatching(true); setDelay(2); updateKeepOn(true)
    }

    fun toggleFav(id: String) {
        if (!favorites.remove(id)) favorites.add(id)
        p.edit().putStringSet("fav", favorites.toSet()).apply()
    }

    private fun saveHistory() {
        p.edit().putString("hist", history.joinToString("|") { "${it.id}~${it.time}~${it.dur}" }).apply()
    }
    fun addHistory(id: String, time: Long) {
        history.removeAll { it.id == id }
        history.add(0, HistoryItem(id, time, 0L))
        while (history.size > 50) history.removeAt(history.size - 1)
        saveHistory()
    }
    fun addDuration(time: Long, secs: Long) {
        val i = history.indexOfFirst { it.time == time }
        if (i >= 0) { history[i] = history[i].copy(dur = history[i].dur + secs); saveHistory() }
    }
    fun deleteHistory(item: HistoryItem) { history.remove(item); saveHistory() }
    fun clearHistory() { history.clear(); saveHistory() }

    /** پلیئر کے لیے زیادہ سے زیادہ ویڈیو اونچائی */
    fun maxHeight(): Int {
        val q = if (quality == 0) Int.MAX_VALUE else quality
        val d = when (dataMode) { 1 -> 480; 2 -> 360; else -> Int.MAX_VALUE }
        return minOf(q, d)
    }
}
