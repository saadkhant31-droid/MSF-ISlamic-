package com.abuosman.tv

import android.widget.Toast
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// ───────────────────────── HOME ─────────────────────────
@Composable
fun HomeScreen(st: AppState, channels: List<Channel>, go: (Int, String) -> Unit, play: (Channel) -> Unit) {
    val last = st.history.firstOrNull()?.let { h -> channels.find { it.id == h.id } }
    LazyColumn(
        Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item { Banner() }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                CatTile("📰", "Pak News", "پاکستانی خبریں", C.green, st, Modifier.weight(1f)) { go(1, "news") }
                CatTile("⚽", "Sports", "کھیل", C.blue, st, Modifier.weight(1f)) { go(1, "sports") }
                CatTile("🕌", "Islamic TV", "اسلامی چینلز", C.purple, st, Modifier.weight(1f)) { go(1, "islamic") }
            }
        }
        item {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                QuickTile("❤️", "Favorites", "پسندیدہ", st, Modifier.weight(1f)) { go(2, "all") }
                QuickTile("🕘", "Recent", "حال ہی میں", st, Modifier.weight(1f)) { go(3, "all") }
                QuickTile("📋", "All Channels", "تمام چینلز", st, Modifier.weight(1f)) { go(1, "all") }
                QuickTile("🔍", "Search", "تلاش کریں", st, Modifier.weight(1f)) { go(1, "all") }
            }
        }
        if (st.continueWatching && last != null) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(12.dp)).clickable { play(last) }.padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LogoTile(last, Modifier.size(52.dp))
                    Spacer(Modifier.width(10.dp))
                    Bi("Continue Watching", "جہاں سے دیکھا تھا وہیں سے چلائیں", st, Modifier.weight(1f), size = 13.sp, bold = true)
                    Text("▶", color = C.blue, fontSize = 22.sp)
                }
            }
        }
        for (c in listOf("news", "sports", "islamic")) {
            val list = channels.filter { it.category == c }.take(8)
            if (list.isNotEmpty()) item {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(catEmoji(c), fontSize = 20.sp)
                        Spacer(Modifier.width(8.dp))
                        Bi(secEn(c), secUr(c), st, Modifier.weight(1f), size = 16.sp, bold = true)
                        Text("See All ›", color = C.blue, fontSize = 13.sp, modifier = Modifier.clickable { go(1, c) })
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list) { ch -> ChannelCard(ch, st, Modifier.width(104.dp)) { play(ch) } }
                    }
                }
            }
        }
        item { InfoStrip(st) }
    }
}

@Composable
fun Banner() {
    val msgs = listOf(
        Triple("پاکستان کی تمام", "نیوز چینلز اب ایک جگہ", "All Pakistani News Channels"),
        Triple("پاکستان کی تمام", "ٹی وی چینلز اب ایک جگہ", "Pakistani Channels | Live TV"),
        Triple("کھیل، خبریں اور", "اسلامی چینلز لائیو", "Sports | News | Islamic")
    )
    var i by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(4000); i = (i + 1) % msgs.size } }
    val m = msgs[i]
    Box(
        Modifier.fillMaxWidth().height(150.dp).clip(RoundedCornerShape(14.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF0B4A32), Color(0xFF0A1F4D))))
            .border(1.dp, C.border, RoundedCornerShape(14.dp)).padding(14.dp)
    ) {
        Text("📺", fontSize = 70.sp, modifier = Modifier.align(Alignment.CenterEnd))
        Column(Modifier.align(Alignment.CenterStart)) {
            Box(Modifier.clip(RoundedCornerShape(6.dp)).background(C.red).padding(horizontal = 8.dp, vertical = 3.dp)) {
                Text("● LIVE", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(8.dp))
            Text(m.first, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            Text(m.second, color = C.gold, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(6.dp))
            Text(m.third, color = Color.White, fontSize = 12.sp)
        }
        Row(Modifier.align(Alignment.BottomCenter), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            msgs.indices.forEach { k ->
                Box(Modifier.size(7.dp).clip(CircleShape).background(if (k == i) C.blue else Color(0xFF3B4C73)))
            }
        }
    }
}

@Composable
fun CatTile(emoji: String, en: String, ur: String, color: Color, st: AppState, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(color).clickable { onClick() }.padding(10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 26.sp)
        Bi(en, ur, st, size = 13.sp, bold = true, urColor = Color.White, align = Alignment.CenterHorizontally)
    }
}

@Composable
fun QuickTile(emoji: String, en: String, ur: String, st: AppState, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(C.card).border(1.dp, C.border, RoundedCornerShape(12.dp))
            .clickable { onClick() }.padding(vertical = 10.dp, horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(emoji, fontSize = 20.sp)
        Bi(en, ur, st, size = 10.sp, align = Alignment.CenterHorizontally)
    }
}

@Composable
fun InfoStrip(st: AppState) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card)
            .border(1.dp, C.border, RoundedCornerShape(12.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Bi("✅ Low Data Mode", "کم ڈیٹا استعمال کریں", st, size = 11.sp, color = Color(0xFF5CE08A))
            Bi("📶 Auto Quality", "خودکار کوالٹی", st, size = 11.sp, color = Color(0xFF5CE08A))
            Bi("📱 All SIMs", "تمام SIM پر", st, size = 11.sp, color = Color(0xFF5CE08A))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("Jazz" to Color(0xFFD32F2F), "ZONG" to Color(0xFF2E7D32), "ufone" to Color(0xFFEF6C00), "telenor" to Color(0xFF0288D1))
                .forEach { (n, c) ->
                    Box(Modifier.clip(RoundedCornerShape(6.dp)).background(c).padding(horizontal = 10.dp, vertical = 4.dp)) {
                        Text(n, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
        }
    }
}

// ───────────────────────── LIVE TV ─────────────────────────
@Composable
fun LiveScreen(st: AppState, channels: List<Channel>, initialCat: String, play: (Channel) -> Unit) {
    var cat by remember(initialCat) { mutableStateOf(initialCat) }
    var q by remember { mutableStateOf("") }
    val shown = channels.filter { (cat == "all" || it.category == cat) && it.name.contains(q, true) }
    LazyVerticalGrid(
        GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Bi("Live TV", "لائیو ٹی وی", st, size = 20.sp, bold = true)
                BasicTextField(
                    value = q, onValueChange = { q = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(12.dp)).padding(14.dp),
                    decorationBox = { inner ->
                        Box {
                            if (q.isEmpty()) Text("🔍  Search channels  |  چینل تلاش کریں", color = C.sub, fontSize = 14.sp)
                            inner()
                        }
                    }
                )
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(listOf("all", "news", "regional", "sports", "islamic")) { c ->
                        val sel = cat == c
                        Box(
                            Modifier.clip(RoundedCornerShape(20.dp))
                                .background(if (sel) catColor(c) else C.card)
                                .border(1.dp, if (sel) Color.White else C.border, RoundedCornerShape(20.dp))
                                .clickable { cat = c }.padding(horizontal = 14.dp, vertical = 8.dp)
                        ) { Text(catEn(c) + "  " + catUr(c), color = Color.White, fontSize = 13.sp) }
                    }
                }
            }
        }
        items(shown) { ch -> ChannelCard(ch, st) { play(ch) } }
    }
}

// ───────────────────────── FAVORITES ─────────────────────────
@Composable
fun FavoritesScreen(st: AppState, channels: List<Channel>, play: (Channel) -> Unit) {
    var edit by remember { mutableStateOf(false) }
    val favs = channels.filter { it.id in st.favorites }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("❤️", fontSize = 28.sp)
                Spacer(Modifier.width(8.dp))
                Bi("My Favorites", "میرے پسندیدہ چینلز", st, Modifier.weight(1f), size = 20.sp, bold = true)
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp)).background(if (edit) C.green else C.blue)
                        .clickable { edit = !edit }.padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    Bi(if (edit) "✔ Done" else "✏ Edit", if (edit) "مکمل" else "تبدیلی", st, size = 12.sp, bold = true, urColor = Color.White,
                        align = Alignment.CenterHorizontally)
                }
            }
        }
        if (favs.isEmpty()) {
            item {
                Text(st.run { if (bilingual) "ابھی کوئی پسندیدہ چینل نہیں / No favorites yet" else "No favorites yet" },
                    color = C.sub, modifier = Modifier.padding(16.dp))
            }
        }
        for (c in listOf("news", "sports", "islamic", "regional")) {
            val list = favs.filter { it.category == c }
            if (list.isNotEmpty()) item {
                Column {
                    Row(
                        Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(catColor(c)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(catEmoji(c), fontSize = 18.sp)
                        Spacer(Modifier.width(8.dp))
                        Bi(secEn(c), secUr(c), st, Modifier.weight(1f), size = 14.sp, bold = true, urColor = Color.White)
                        Text("${list.size} Channels", color = Color.White, fontSize = 12.sp)
                    }
                    Spacer(Modifier.height(8.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(list) { ch -> ChannelCard(ch, st, Modifier.width(104.dp), editMode = edit) { play(ch) } }
                    }
                }
            }
        }
        item {
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card)
                    .border(1.dp, C.border, RoundedCornerShape(12.dp)).padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("⭐", fontSize = 34.sp)
                Spacer(Modifier.width(12.dp))
                Column {
                    Bi("Your Favorite Channels", "آپ کے پسندیدہ چینلز", st, size = 15.sp, bold = true)
                    Text("Quick access to your favorite TV channels", color = C.sub, fontSize = 11.sp)
                }
            }
        }
    }
}

// ───────────────────────── HISTORY ─────────────────────────
@Composable
fun HistoryScreen(st: AppState, channels: List<Channel>, play: (Channel) -> Unit) {
    val fmt = remember { SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.getDefault()) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("🕘", fontSize = 28.sp)
                Spacer(Modifier.width(8.dp))
                Bi("Watch History", "دیکھنے کی تاریخ", st, Modifier.weight(1f), size = 20.sp, bold = true)
                Box(
                    Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, C.blue, RoundedCornerShape(10.dp))
                        .clickable { st.clearHistory() }.padding(horizontal = 10.dp, vertical = 8.dp)
                ) { Bi("🗑 Clear All", "تاریخ حذف کریں", st, size = 11.sp, align = Alignment.CenterHorizontally) }
            }
        }
        if (st.history.isEmpty()) item { Text("Nothing here yet  |  ابھی کچھ نہیں", color = C.sub, modifier = Modifier.padding(16.dp)) }
        items(st.history.toList()) { h ->
            val ch = channels.find { it.id == h.id }
            if (ch != null) {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(C.card)
                        .border(1.dp, C.border, RoundedCornerShape(12.dp)).padding(10.dp)
                ) {
                    Box(Modifier.width(96.dp).height(64.dp)) {
                        LogoTile(ch, Modifier.fillMaxSize())
                        Box(Modifier.align(Alignment.TopStart).padding(3.dp).clip(RoundedCornerShape(4.dp)).background(C.red).padding(horizontal = 4.dp)) {
                            Text("LIVE", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Bi(ch.name, ch.nameUr, st, size = 14.sp, bold = true)
                        Text(catEn(ch.category) + " | " + catUr(ch.category), color = C.sub, fontSize = 11.sp)
                        val s = h.dur
                        Text(
                            "📅 " + fmt.format(Date(h.time)) + "   ⏱ " +
                                String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60),
                            color = Color.White, fontSize = 10.sp
                        )
                        Spacer(Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                Modifier.clip(RoundedCornerShape(8.dp)).background(C.blue)
                                    .clickable { play(ch) }.padding(horizontal = 12.dp, vertical = 6.dp)
                            ) { Text("▶ Watch Again  دوبارہ دیکھیں", color = Color.White, fontSize = 11.sp) }
                            Box(
                                Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, C.border, RoundedCornerShape(8.dp))
                                    .clickable { st.deleteHistory(h) }.padding(horizontal = 10.dp, vertical = 6.dp)
                            ) { Text("🗑", fontSize = 13.sp) }
                        }
                    }
                }
            }
        }
    }
}

// ───────────────────────── SETTINGS ─────────────────────────
@Composable
fun SettingCard(emoji: String, en: String, ur: String, st: AppState, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(C.card)
            .border(1.dp, C.border, RoundedCornerShape(14.dp)).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(emoji, fontSize = 22.sp)
            Spacer(Modifier.width(8.dp))
            Bi(en, ur, st, size = 16.sp, bold = true)
        }
        Spacer(Modifier.height(10.dp))
        content()
    }
}

@Composable
fun OptionBox(en: String, ur: String, selected: Boolean, st: AppState, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.clip(RoundedCornerShape(10.dp)).background(if (selected) C.blue else Color(0xFF0A1830))
            .border(1.dp, if (selected) Color(0xFF5B9BFF) else C.border, RoundedCornerShape(10.dp))
            .clickable { onClick() }.padding(vertical = 8.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) { Bi(en, ur, st, size = 12.sp, bold = true, align = Alignment.CenterHorizontally, urColor = Color.White) }
}

@Composable
fun SwitchRow(en: String, ur: String, checked: Boolean, st: AppState, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Bi(en, ur, st, Modifier.weight(1f), size = 14.sp)
        Switch(checked = checked, onCheckedChange = onChange)
    }
}

@Composable
fun SettingsScreen(st: AppState) {
    val ctx = LocalContext.current
    val qOpts = listOf(
        Triple(240, "240p", "کم کوالٹی"), Triple(320, "320p", "کم ڈیٹا"), Triple(480, "480p", "معیاری"),
        Triple(720, "720p", "اچھی"), Triple(1080, "1080p", "اعلیٰ کوالٹی"), Triple(1440, "1440p", "بہت اعلیٰ"),
        Triple(0, "Auto", "خودکار")
    )
    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Bi("Settings", "ترتیبات", st, size = 22.sp, bold = true)

        SettingCard("🎬", "Video Quality", "ویڈیو کوالٹی", st) {
            qOpts.chunked(4).forEach { row ->
                Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { (v, en, ur) -> OptionBox(en, ur, st.quality == v, st, Modifier.weight(1f)) { st.updateQuality(v) } }
                    repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
            Text("Quality changes only if the channel offers it.", color = C.sub, fontSize = 11.sp)
        }

        SettingCard("📶", "Data Usage", "ڈیٹا استعمال", st) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OptionBox("Standard", "معیاری موڈ", st.dataMode == 0, st, Modifier.weight(1f)) { st.updateDataMode(0) }
                OptionBox("Data Saver", "کم ڈیٹا موڈ", st.dataMode == 1, st, Modifier.weight(1f)) { st.updateDataMode(1) }
                OptionBox("Low Data", "بہت کم ڈیٹا", st.dataMode == 2, st, Modifier.weight(1f)) { st.updateDataMode(2) }
            }
            Spacer(Modifier.height(6.dp))
            Text("Data Saver: max 480p  •  Low Data: max 360p", color = C.sub, fontSize = 11.sp)
        }

        SettingCard("▶", "Playback Settings", "پلے بیک ترتیبات", st) {
            SwitchRow("Auto Retry on Error", "خرابی پر خودکار دوبارہ کوشش", st.autoRetry, st) { st.updateAutoRetry(it) }
            SwitchRow("Continue Watching", "جہاں سے دیکھا تھا وہیں سے چلائیں", st.continueWatching, st) { st.updateContinueWatching(it) }
            SwitchRow("Keep Screen On", "پلے کے دوران اسکرین آن رکھیں", st.keepOn, st) { st.updateKeepOn(it) }
            var open by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                Bi("Channel Change Delay", "چینل بدلنے میں تاخیر", st, Modifier.weight(1f), size = 14.sp)
                Box {
                    Box(
                        Modifier.clip(RoundedCornerShape(8.dp)).border(1.dp, C.border, RoundedCornerShape(8.dp))
                            .clickable { open = true }.padding(horizontal = 12.dp, vertical = 8.dp)
                    ) { Text("${st.delaySec} Sec ▾", color = Color.White, fontSize = 13.sp) }
                    DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                        listOf(0, 1, 2, 3, 5).forEach { s ->
                            DropdownMenuItem(text = { Text("$s Sec") }, onClick = { st.setDelay(s); open = false })
                        }
                    }
                }
            }
        }

        SettingCard("🌐", "App Language", "ایپ کی زبان", st) {
            OptionBox("Urdu + English", "انگلش + اردو", st.bilingual, st, Modifier.fillMaxWidth()) { st.updateBilingual(true) }
            Spacer(Modifier.height(8.dp))
            OptionBox("English Only", "صرف انگلش", !st.bilingual, st, Modifier.fillMaxWidth()) { st.updateBilingual(false) }
        }

        SettingCard("⚡", "Quick Actions", "فوری کارروائیاں", st) {
            OptionBox("Clear Cache", "کیش صاف کریں", false, st, Modifier.fillMaxWidth()) {
                ctx.cacheDir.deleteRecursively()
                Toast.makeText(ctx, "Cache cleared", Toast.LENGTH_SHORT).show()
            }
            Spacer(Modifier.height(8.dp))
            OptionBox("Reset Settings", "ترتیبات بحال کریں", false, st, Modifier.fillMaxWidth()) {
                st.resetSettings()
                Toast.makeText(ctx, "Settings reset", Toast.LENGTH_SHORT).show()
            }
        }

        SettingCard("ℹ️", "About App", "ایپ کے بارے میں", st) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("App Name", color = C.sub, fontSize = 11.sp); Text("ABUOSMAN TV", color = Color.White, fontSize = 13.sp) }
                Column { Text("Version", color = C.sub, fontSize = 11.sp); Text("1.0.0", color = Color.White, fontSize = 13.sp) }
                Column { Text("Build", color = C.sub, fontSize = 11.sp); Text("1001", color = Color.White, fontSize = 13.sp) }
            }
        }
        Spacer(Modifier.height(8.dp))
    }
}
