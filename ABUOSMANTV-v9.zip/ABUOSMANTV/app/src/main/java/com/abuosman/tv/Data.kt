package com.abuosman.tv

import android.content.Context
import android.os.Handler
import android.os.Looper
import androidx.compose.runtime.*
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

data class Channel(
    val name: String, val nameUr: String, val category: String, val url: String, val logo: String,
    val offline: Boolean = false, val alts: List<String> = emptyList()
) {
    val id: String get() = name
}

data class HistoryItem(val id: String, val time: Long, val dur: Long)

const val DEFAULT_PLAYLIST = "https://iptv-org.github.io/iptv/countries/pk.m3u\nhttps://iptv-org.github.io/iptv/languages/urd.m3u"

class RemoteEntry(val url: String, val logo: String)

private val reBrackets = Regex("\\(.*?\\)|\\[.*?\\]")
private val reWords = Regex("\\b(hd|tv|news|channel|live)\\b")
private val reJunk = Regex("[^a-z0-9\\u0600-\\u06ff]")

/** چینل کے نام کو موازنے کے لیے سادہ بناتا ہے */
fun normName(s: String): String =
    s.lowercase().replace(reBrackets, "").replace(reWords, "").replace(reJunk, "")

fun parseM3u(t: String): List<Triple<String, String, String>> {
    val out = ArrayList<Triple<String, String, String>>()
    var name = ""
    var logo = ""
    for (raw in t.lines()) {
        val l = raw.trim()
        if (l.startsWith("#EXTINF")) {
            name = l.substringAfterLast(",").trim()
            logo = Regex("tvg-logo=\"([^\"]*)\"").find(l)?.groupValues?.get(1) ?: ""
        } else if (l.isNotEmpty() && !l.startsWith("#") && name.isNotEmpty()) {
            out.add(Triple(name, l, logo)); name = ""; logo = ""
        }
    }
    return out
}

private fun openConn(u: String, timeout: Int): HttpURLConnection? {
    var cur = u
    for (i in 0..4) {
        val c = URL(cur).openConnection() as HttpURLConnection
        c.connectTimeout = timeout
        c.readTimeout = timeout
        c.instanceFollowRedirects = false
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36")
        val code = c.responseCode
        if (code in 300..399) {
            val loc = c.getHeaderField("Location") ?: return null
            cur = URL(URL(cur), loc).toString()
            c.disconnect()
            continue
        }
        return c
    }
    return null
}

private fun fetchText(u: String): String? {
    val c = openConn(u, 20000) ?: return null
    if (c.responseCode !in 200..299) return null
    return c.inputStream.bufferedReader().use { it.readText() }
}

/** چیک کرتا ہے کہ اسٹریم واقعی چل رہی ہے یا نہیں */
private fun probe(u: String): Boolean {
    return try {
        val c = openConn(u, 6000)
        if (c == null) false else {
            var good = false
            if (c.responseCode in 200..299) {
                val ct = (c.contentType ?: "").lowercase()
                val buf = ByteArray(1024)
                val n = c.inputStream.use { it.read(buf) }
                val head = if (n > 0) String(buf, 0, n) else ""
                good = head.startsWith("#EXTM3U") || ct.contains("video") || ct.contains("mpegurl") ||
                    ct.contains("mp2t") || (n > 0 && ct.contains("octet"))
            }
            c.disconnect()
            good
        }
    } catch (e: Exception) { false }
}

fun loadChannels(ctx: Context): List<Channel> {
    val text = ctx.assets.open("channels.json").bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("channels")
    return List(arr.length()) {
        val o = arr.getJSONObject(it)
        Channel(o.getString("name"), o.optString("nameUr", ""), o.getString("category"),
            o.optString("url", ""), o.optString("logo", ""))
    }
}

class AppState(private val ctx: Context) {
    private val p = ctx.getSharedPreferences("abuosman", Context.MODE_PRIVATE)

    var bilingual by mutableStateOf(p.getBoolean("bi", true))
        private set
    var quality by mutableStateOf(p.getInt("quality", 0))
        private set
    var dataMode by mutableStateOf(p.getInt("data", 1))
        private set
    var autoRetry by mutableStateOf(p.getBoolean("retry", true))
        private set
    var continueWatching by mutableStateOf(p.getBoolean("cont", true))
        private set
    var delaySec by mutableStateOf(p.getInt("delay", 0))
        private set
    var keepOn by mutableStateOf(p.getBoolean("keepon", true))
        private set
    var hideOffline by mutableStateOf(p.getBoolean("hide", true))
        private set

    val favorites = mutableStateListOf<String>().apply { addAll(p.getStringSet("fav", emptySet())!!) }
    val history = mutableStateListOf<HistoryItem>().apply {
        addAll((p.getString("hist", "") ?: "").split("|").mapNotNull {
            val a = it.split("~")
            if (a.size == 3) HistoryItem(a[0], a[1].toLongOrNull() ?: 0L, a[2].toLongOrNull() ?: 0L) else null
        })
    }

    val urls = mutableStateMapOf<String, String>().apply { putAll(loadMap("ovr_url")) }
    val logos = mutableStateMapOf<String, String>().apply { putAll(loadMap("ovr_logo")) }

    private fun loadMap(k: String): Map<String, String> {
        val s = p.getString(k, "") ?: ""
        if (s.isBlank()) return emptyMap()
        val o = JSONObject(s)
        val m = HashMap<String, String>()
        o.keys().forEach { m[it] = o.getString(it) }
        return m
    }
    private fun saveMap(k: String, m: Map<String, String>) {
        p.edit().putString(k, JSONObject(m as Map<*, *>).toString()).apply()
    }
    fun setUrl(id: String, url: String) {
        if (url.isBlank()) urls.remove(id) else urls[id] = url.trim()
        saveMap("ovr_url", urls)
    }
    fun setOverride(id: String, url: String, logo: String) {
        setUrl(id, url)
        if (logo.isBlank()) logos.remove(id) else logos[id] = logo.trim()
        saveMap("ovr_logo", logos)
    }

    // ───── خودکار چینلز (پلے لسٹ) ─────
    val remote = mutableStateMapOf<String, List<RemoteEntry>>()
    val status = mutableStateMapOf<String, Boolean>()
    var baseNames: List<String> = emptyList()
    var plStatus by mutableStateOf("")
        private set
    var playlistUrl by mutableStateOf(p.getString("pl2", DEFAULT_PLAYLIST) ?: DEFAULT_PLAYLIST)
        private set

    init {
        (p.getStringSet("good", emptySet()) ?: emptySet()).forEach { status[it] = true }
        (p.getStringSet("bad", emptySet()) ?: emptySet()).forEach { status[it] = false }
        val cached = p.getString("m3u", "") ?: ""
        if (cached.isNotBlank()) applyText(cached)
    }

    private fun applyText(t: String): Int {
        val m = HashMap<String, MutableList<RemoteEntry>>()
        parseM3u(t).forEach { (n, u, lg) ->
            val k = normName(n)
            if (k.isNotEmpty()) m.getOrPut(k) { ArrayList() }.add(RemoteEntry(u, lg))
        }
        remote.clear()
        remote.putAll(m)
        return m.size
    }

    fun working(): Int = baseNames.count { n ->
        val r = remote[normName(n)] ?: emptyList()
        r.any { status[it.url] != false }
    }

    private fun checkStreams() {
        val wanted = baseNames.map { normName(it) }.toSet()
        val list = remote.filterKeys { it in wanted }.values.flatten().map { it.url }.distinct()
        if (list.isEmpty()) { plStatus = "No matching channels found in playlist"; return }
        val total = list.size
        val done = AtomicInteger(0)
        val main = Handler(Looper.getMainLooper())
        val pool = Executors.newFixedThreadPool(8)
        for (u in list) {
            pool.execute {
                val ok = probe(u)
                main.post {
                    status[u] = ok
                    val d = done.incrementAndGet()
                    plStatus = "Testing streams... " + d + " / " + total
                    if (d >= total) {
                        p.edit()
                            .putStringSet("good", status.filter { it.value }.keys.toSet())
                            .putStringSet("bad", status.filter { !it.value }.keys.toSet())
                            .apply()
                        plStatus = "Working channels: " + working() + " / " + baseNames.size
                    }
                }
            }
        }
        pool.shutdown()
    }

    fun refreshPlaylist() {
        val links = playlistUrl.split(Regex("\\s+")).filter { it.startsWith("http") }
        if (links.isEmpty()) { plStatus = "No playlist link"; return }
        plStatus = "Loading..."
        Thread {
            val sb = StringBuilder()
            for (u in links) {
                try { fetchText(u)?.let { sb.append(it).append("\n") } } catch (e: Exception) { }
            }
            val t = sb.toString()
            Handler(Looper.getMainLooper()).post {
                if (t.isNotBlank()) {
                    applyText(t)
                    if (t.length < 1_500_000) p.edit().putString("m3u", t).apply()
                    plStatus = "Testing streams..."
                    checkStreams()
                } else {
                    plStatus = "Could not load playlist (check internet)"
                }
            }
        }.start()
    }

    fun setPlaylist(u: String) {
        playlistUrl = u.trim()
        p.edit().putString("pl2", playlistUrl).apply()
        refreshPlaylist()
    }

    fun eff(c: Channel): Channel {
        val own = urls[c.id]
        val r = remote[normName(c.name)] ?: emptyList()
        val logo = logos[c.id] ?: c.logo.ifBlank { r.firstOrNull { it.logo.isNotBlank() }?.logo ?: "" }
        if (own != null) return c.copy(url = own, logo = logo, offline = false, alts = emptyList())
        if (remote.isEmpty()) return c.copy(logo = logo)
        val all = r.map { it.url }
        if (all.isEmpty()) return c.copy(url = "", logo = logo, offline = true)
        val good = all.filter { status[it] != false }.sortedBy { if (status[it] == true) 0 else 1 }
        if (good.isEmpty()) return c.copy(url = all[0], logo = logo, offline = true, alts = all.drop(1))
        return c.copy(url = good[0], logo = logo, offline = false, alts = good.drop(1))
    }

    fun updateBilingual(v: Boolean) { bilingual = v; p.edit().putBoolean("bi", v).apply() }
    fun updateQuality(v: Int) { quality = v; p.edit().putInt("quality", v).apply() }
    fun updateDataMode(v: Int) { dataMode = v; p.edit().putInt("data", v).apply() }
    fun updateAutoRetry(v: Boolean) { autoRetry = v; p.edit().putBoolean("retry", v).apply() }
    fun updateContinueWatching(v: Boolean) { continueWatching = v; p.edit().putBoolean("cont", v).apply() }
    fun setDelay(v: Int) { delaySec = v; p.edit().putInt("delay", v).apply() }
    fun updateKeepOn(v: Boolean) { keepOn = v; p.edit().putBoolean("keepon", v).apply() }
    fun updateHideOffline(v: Boolean) { hideOffline = v; p.edit().putBoolean("hide", v).apply() }

    fun resetSettings() {
        updateBilingual(true); updateQuality(0); updateDataMode(1); updateAutoRetry(true)
        updateContinueWatching(true); setDelay(0); updateKeepOn(true); updateHideOffline(true)
    }

    fun toggleFav(id: String) {
        if (!favorites.remove(id)) favorites.add(id)
        p.edit().putStringSet("fav", favorites.toSet()).apply()
    }

    private fun saveHistory() {
        p.edit().putString("hist", history.joinToString("|") { "${it.id}~${it.time}~${it.dur}" }).apply()
    }
    fun addHistory(id: String, time: Long) {
        history.removeAll { it.id == id }
        history.add(0, HistoryItem(id, time, 0L))
        while (history.size > 50) history.removeAt(history.size - 1)
        saveHistory()
    }
    fun addDuration(time: Long, secs: Long) {
        val i = history.indexOfFirst { it.time == time }
        if (i >= 0) { history[i] = history[i].copy(dur = history[i].dur + secs); saveHistory() }
    }
    fun deleteHistory(item: HistoryItem) { history.remove(item); saveHistory() }
    fun clearHistory() { history.clear(); saveHistory() }

    fun maxHeight(): Int {
        val q = if (quality == 0) Int.MAX_VALUE else quality
        val d = when (dataMode) { 1 -> 480; 2 -> 360; else -> Int.MAX_VALUE }
        return minOf(q, d)
    }
}
