package com.abuosman.tv

import android.content.Context
import androidx.compose.runtime.*
import org.json.JSONObject

data class Channel(val name: String, val category: String, val url: String)

fun loadChannels(ctx: Context): List<Channel> {
    val text = ctx.assets.open("channels.json").bufferedReader().use { it.readText() }
    val arr = JSONObject(text).getJSONArray("channels")
    return List(arr.length()) {
        val o = arr.getJSONObject(it)
        Channel(o.getString("name"), o.getString("category"), o.optString("url", ""))
    }
}

/** تمام سیٹنگز، پسندیدہ اور ہسٹری یہاں محفوظ ہوتی ہیں */
class AppState(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("abuosman", Context.MODE_PRIVATE)
    var urdu by mutableStateOf(prefs.getBoolean("urdu", true)); private set
    var quality by mutableStateOf(prefs.getInt("quality", 0)); private set   // 0 = Auto
    var lowData by mutableStateOf(prefs.getBoolean("low", false)); private set
    val favorites = mutableStateListOf<String>().apply { addAll(prefs.getStringSet("fav", emptySet())!!) }
    val history = mutableStateListOf<String>().apply {
        addAll((prefs.getString("hist", "") ?: "").split("|").filter { it.isNotBlank() })
    }

    fun t(ur: String, en: String) = if (urdu) ur else en
    fun setUrdu(v: Boolean) { urdu = v; prefs.edit().putBoolean("urdu", v).apply() }
    fun setQuality(v: Int) { quality = v; prefs.edit().putInt("quality", v).apply() }
    fun setLowData(v: Boolean) { lowData = v; prefs.edit().putBoolean("low", v).apply() }
    fun toggleFav(name: String) {
        if (!favorites.remove(name)) favorites.add(name)
        prefs.edit().putStringSet("fav", favorites.toSet()).apply()
    }
    fun addHistory(name: String) {
        history.remove(name); history.add(0, name)
        while (history.size > 30) history.removeAt(history.size - 1)
        prefs.edit().putString("hist", history.joinToString("|")).apply()
    }
    fun clearHistory() { history.clear(); prefs.edit().putString("hist", "").apply() }

    /** زیادہ سے زیادہ ویڈیو اونچائی (Low Data Mode میں 360p سے اوپر نہیں) */
    fun maxHeight(): Int {
        val q = if (quality == 0) Int.MAX_VALUE else quality
        return if (lowData) minOf(q, 360) else q
    }
}
