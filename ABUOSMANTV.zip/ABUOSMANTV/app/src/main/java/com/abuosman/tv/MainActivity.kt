package com.abuosman.tv

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val st = AppState(this)
        val channels = loadChannels(this)
        setContent { MaterialTheme { Surface(Modifier.fillMaxSize()) { Root(st, channels) } } }
    }
}

private val cats = listOf("all" to ("سب" to "All"), "news" to ("🇵🇰 نیوز" to "🇵🇰 News"),
    "regional" to ("🌐 علاقائی" to "🌐 Regional"), "sports" to ("🏏 اسپورٹس" to "🏏 Sports"),
    "islamic" to ("🕌 اسلامی" to "🕌 Islamic"))

@Composable
fun Root(st: AppState, channels: List<Channel>) {
    var tab by remember { mutableStateOf(0) }
    var playing by remember { mutableStateOf<Channel?>(null) }
    BackHandler(enabled = playing != null) { playing = null }

    playing?.let { PlayerScreen(it, st) { playing = null }; return }

    Scaffold(bottomBar = {
        NavigationBar {
            listOf("🏠" to st.t("ہوم", "Home"), "⭐" to st.t("پسندیدہ", "Favorites"),
                "🕘" to st.t("ہسٹری", "History"), "⚙️" to st.t("سیٹنگز", "Settings"))
                .forEachIndexed { i, (icon, label) ->
                    NavigationBarItem(selected = tab == i, onClick = { tab = i },
                        icon = { Text(icon) }, label = { Text(label) })
                }
        }
    }) { pad ->
        Box(Modifier.padding(pad)) {
            when (tab) {
                0 -> HomeTab(st, channels) { playing = it }
                1 -> ListTab(st, channels.filter { it.name in st.favorites }, null) { playing = it }
                2 -> ListTab(st, st.history.mapNotNull { n -> channels.find { it.name == n } },
                    { TextButton(onClick = { st.clearHistory() }) { Text(st.t("صاف کریں", "Clear")) } }) { playing = it }
                else -> SettingsTab(st)
            }
        }
    }
}

@Composable
fun ChannelRow(st: AppState, ch: Channel, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 16.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("📺  " + ch.name, Modifier.weight(1f), style = MaterialTheme.typography.bodyLarge)
        TextButton(onClick = { st.toggleFav(ch.name) }) { Text(if (ch.name in st.favorites) "❤️" else "🤍") }
    }
}

@Composable
fun HomeTab(st: AppState, channels: List<Channel>, onPlay: (Channel) -> Unit) {
    var cat by remember { mutableStateOf("all") }
    var q by remember { mutableStateOf("") }
    val shown = channels.filter { (cat == "all" || it.category == cat) && it.name.contains(q, true) }
    Column {
        Text("ABUOSMAN TV", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
        OutlinedTextField(q, { q = it }, singleLine = true, label = { Text(st.t("چینل تلاش کریں", "Search channels")) },
            modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp))
        LazyRow(contentPadding = PaddingValues(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(cats) { (id, names) ->
                FilterChip(selected = cat == id, onClick = { cat = id },
                    label = { Text(st.t(names.first, names.second)) })
            }
        }
        LazyColumn { items(shown) { ChannelRow(st, it) { onPlay(it) } } }
    }
}

@Composable
fun ListTab(st: AppState, list: List<Channel>, action: (@Composable () -> Unit)?, onPlay: (Channel) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.weight(1f)); action?.invoke()
        }
        if (list.isEmpty()) Text(st.t("ابھی کچھ نہیں ہے", "Nothing here yet"), Modifier.padding(16.dp))
        LazyColumn { items(list) { ChannelRow(st, it) { onPlay(it) } } }
    }
}

@Composable
fun SettingsTab(st: AppState) {
    val qs = listOf(0 to "Auto", 240 to "240p", 360 to "360p", 480 to "480p", 720 to "720p HD", 1080 to "1080p Full HD")
    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(st.t("سیٹنگز", "Settings"), style = MaterialTheme.typography.headlineSmall)
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("اردو / English", Modifier.weight(1f))
            Switch(checked = st.urdu, onCheckedChange = { st.setUrdu(it) })
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⚡ Low Data Mode (360p)", Modifier.weight(1f))
            Switch(checked = st.lowData, onCheckedChange = { st.setLowData(it) })
        }
        Text("🎬 " + st.t("ویڈیو کوالٹی", "Video Quality"), style = MaterialTheme.typography.titleMedium)
        qs.forEach { (v, label) ->
            Row(Modifier.fillMaxWidth().clickable { st.setQuality(v) }, verticalAlignment = Alignment.CenterVertically) {
                RadioButton(selected = st.quality == v, onClick = { st.setQuality(v) })
                Text(label)
            }
        }
        Text(st.t("کوالٹی صرف تب بدلے گی جب چینل وہ ریزولوشن فراہم کرے۔",
            "Quality changes only if the channel offers that resolution."),
            style = MaterialTheme.typography.bodySmall)
    }
}
