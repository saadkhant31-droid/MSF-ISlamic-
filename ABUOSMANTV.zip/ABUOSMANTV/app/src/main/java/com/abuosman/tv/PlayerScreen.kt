package com.abuosman.tv

import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView

@Composable
fun PlayerScreen(ch: Channel, st: AppState, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var buffering by remember { mutableStateOf(true) }
    var retries by remember { mutableStateOf(0) }
    val handler = remember { Handler(Looper.getMainLooper()) }

    val player = remember {
        // Fast Start: کم بفر کے ساتھ جلدی شروع ہو
        val lc = DefaultLoadControl.Builder()
            .setBufferDurationsMs(10_000, 40_000, 1_500, 3_000).build()
        ExoPlayer.Builder(ctx).setLoadControl(lc).build()
    }

    LaunchedEffect(ch.url) {
        st.addHistory(ch.name)
        if (ch.url.isNotBlank()) {
            player.setMediaItem(MediaItem.fromUri(ch.url)); player.prepare(); player.playWhenReady = true
        }
    }
    LaunchedEffect(st.quality, st.lowData) {
        player.trackSelectionParameters = player.trackSelectionParameters.buildUpon()
            .setMaxVideoSize(Int.MAX_VALUE, st.maxHeight()).build()
    }
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onPlaybackStateChanged(s: Int) {
                buffering = s == Player.STATE_BUFFERING
                if (s == Player.STATE_READY) retries = 0
            }
            // Auto Retry: رکنے پر 5 بار دوبارہ کوشش
            override fun onPlayerError(e: PlaybackException) {
                if (retries < 5) {
                    retries++
                    handler.postDelayed({ player.prepare() }, 2000L)
                } else Toast.makeText(ctx, st.t("چینل نہیں چل سکا", "Could not play channel"), Toast.LENGTH_LONG).show()
            }
        }
        player.addListener(l)
        onDispose { handler.removeCallbacksAndMessages(null); player.removeListener(l); player.release() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = onBack) { Text(st.t("← واپس", "← Back")) }
            Text(ch.name, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            IconToggleButton(checked = ch.name in st.favorites, onCheckedChange = { st.toggleFav(ch.name) }) {
                Text(if (ch.name in st.favorites) "❤️" else "🤍")
            }
        }
        Box(Modifier.fillMaxWidth().aspectRatio(16f / 9f), contentAlignment = Alignment.Center) {
            if (ch.url.isBlank()) {
                Text(st.t("اس چینل کا اسٹریم لنک شامل نہیں کیا گیا", "No stream link added for this channel"),
                    modifier = Modifier.padding(16.dp))
            } else {
                AndroidView(factory = { PlayerView(it).apply { this.player = player; useController = true } },
                    modifier = Modifier.fillMaxSize())
                if (buffering) CircularProgressIndicator()
            }
        }
        Text(
            if (st.lowData) st.t("Low Data Mode آن ہے (زیادہ سے زیادہ 360p)", "Low Data Mode is on (max 360p)") else "",
            modifier = Modifier.padding(12.dp)
        )
    }
}
