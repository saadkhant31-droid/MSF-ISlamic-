ABUOSMAN TV — Android Java/XML Project
====================================

یہ پروجیکٹ آپ کی تصویر کو بطور ایپ اسکرین استعمال نہیں کرتا؛ صرف اسی طرز کا نیوی، نیلا/سنہری، کارڈز والا ڈیزائن کوڈ سے بنایا گیا ہے۔

اہم:
- یہ ابتدائی Android پروجیکٹ ہے، مکمل تیار شدہ/ٹیسٹ شدہ APK نہیں۔
- چینلز کی فہرست شامل ہے، مگر Live چلانے کے لیے ہر چینل کا درست، قانونی stream URL درکار ہے۔
- بغیر انٹرنیٹ پیکیج کے مفت ڈیٹا ایپ فراہم نہیں کر سکتی۔
- ویڈیو کوالٹی کے آپشن پلیئر میں صرف تب مؤثر ہوں گے جب اصل stream مختلف qualities دے۔
- build کے لیے Android Studio یا AndroidIDE میں پروجیکٹ کھولیں؛ Gradle sync ہونے دیں، پھر assembleDebug کریں۔
- Android SDK اور Gradle کی مطابقت آپ کے ماحول پر منحصر ہے۔

Stream URL شامل کرنے کا طریقہ:
app/src/main/java/com/abuosman/tv/Channel.java میں ہر چینل کے streamUrl کو اصل مجاز HLS/DASH URL سے بدلیں۔
خالی URL والے چینل پر ایپ “Stream URL not configured” دکھائے گی۔
