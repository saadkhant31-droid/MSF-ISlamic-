package com.abuosman.tv;

public class Channel {
    public final String name, category, urdu;
    public final String streamUrl;
    public Channel(String name, String category, String urdu, String streamUrl) {
        this.name=name; this.category=category; this.urdu=urdu; this.streamUrl=streamUrl;
    }
}
