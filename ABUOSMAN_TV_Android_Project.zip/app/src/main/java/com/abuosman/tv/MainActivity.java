package com.abuosman.tv;

import android.app.*;
import android.os.Bundle;
import android.text.InputType;
import android.widget.*;
import android.view.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.content.SharedPreferences;
import java.util.*;

public class MainActivity extends Activity {
    LinearLayout content;
    TextView title;
    SharedPreferences prefs;
    ArrayList<Channel> channels = new ArrayList<>();
    String currentPage = "Home";
    @Override public void onCreate(Bundle b) {
        super.onCreate(b); setContentView(R.layout.activity_main);
        content=findViewById(R.id.content); title=findViewById(R.id.pageTitle);
        prefs=getSharedPreferences("abuosman_tv", MODE_PRIVATE);
        seedChannels();
        findViewById(R.id.homeBtn).setOnClickListener(v->showPage("Home"));
        findViewById(R.id.liveBtn).setOnClickListener(v->showPage("Live TV"));
        findViewById(R.id.favBtn).setOnClickListener(v->showPage("Favorites"));
        findViewById(R.id.historyBtn).setOnClickListener(v->showPage("History"));
        findViewById(R.id.settingsBtn).setOnClickListener(v->showPage("Settings"));
        findViewById(R.id.searchBtn).setOnClickListener(v->search());
        showPage("Home");
    }
    void seedChannels() {
        String[][] rows={
            {"Geo News","News","جیو نیوز"},{"ARY News","News","اے آر وائی نیوز"},{"Samaa TV","News","سماء ٹی وی"},
            {"Dunya News","News","دنیا نیوز"},{"Express News","News","ایکسپریس نیوز"},{"Hum News","News","ہم نیوز"},
            {"Aaj News","News","آج نیوز"},{"24 News HD","News","24 نیوز"},{"GNN","News","جی این این"},
            {"BOL News","News","بول نیوز"},{"Public News","News","پبلک نیوز"},{"Neo News","News","نیو نیوز"},
            {"Dawn News","News","ڈان نیوز"},{"PTV News","News","پی ٹی وی نیوز"},{"Such TV","News","سچ ٹی وی"},
            {"Din News","News","دن نیوز"},{"Lahore Rang","News","لاہور رنگ"},{"Channel 5","News","چینل 5"},
            {"K21 News","News","کے 21 نیوز"},{"City 42","News","سٹی 42"},{"Roze News","News","روز نیوز"},
            {"Abb Takk News","News","اب تک نیوز"},{"Capital TV","News","کیپیٹل ٹی وی"},{"Discover Pakistan","News","ڈسکور پاکستان"},
            {"PTV Sports","Sports","پی ٹی وی اسپورٹس"},{"A Sports HD","Sports","اے اسپورٹس"},{"Geo Super","Sports","جیو سپر"},
            {"Ten Sports","Sports","ٹین اسپورٹس"},{"Green Sports","Sports","گرین اسپورٹس"},
            {"Sindh TV News","Regional","سندھ ٹی وی نیوز"},{"KTN News","Regional","کے ٹی این نیوز"},{"Awaz TV","Regional","آواز ٹی وی"},
            {"Dharti TV","Regional","دھرتی ٹی وی"},{"Mehran TV","Regional","مہران ٹی وی"},{"Khyber News","Regional","خیبر نیوز"},
            {"AVT Khyber","Regional","اے وی ٹی خیبر"},{"Mashriq TV","Regional","مشرق ٹی وی"},{"VSH News","Regional","وی ایس ایچ نیوز"},
            {"Balochistan TV","Regional","بلوچستان ٹی وی"},{"Kashmir News","Regional","کشمیر نیوز"},
            {"Madani Channel","Islamic","مدنی چینل"},{"QTV","Islamic","کیو ٹی وی"},{"Paigham TV","Islamic","پیغام ٹی وی"},
            {"Hadi TV","Islamic","ہادی ٹی وی"},{"Noor TV","Islamic","نور ٹی وی"},{"Peace TV Urdu","Islamic","پیس ٹی وی اردو"},
            {"Ahlulbayt TV","Islamic","اہل بیت ٹی وی"},{"Samaa-e-Madina","Islamic","سماء مدینہ"}
        };
        for(String[] r:rows) channels.add(new Channel(r[0],r[1],r[2],""));
    }
    void showPage(String page) {
        currentPage=page; content.removeAllViews();
        title.setText(page.equals("Home")?"Pakistani Channels | پاکستانی چینلز":page.equals("Live TV")?"Live TV | لائیو ٹی وی":page.equals("Favorites")?"My Favorites | میرے پسندیدہ چینلز":page.equals("History")?"Watch History | دیکھنے کی تاریخ":"Settings | ترتیبات");
        if(page.equals("Settings")) { settings(); return; }
        if(page.equals("History")) { history(); return; }
        if(page.equals("Favorites")) { for(Channel c:channels) if(prefs.getBoolean("fav_"+c.name,false)) addCard(c); if(content.getChildCount()==0) note("ابھی کوئی پسندیدہ چینل نہیں۔ چینل کے ★ بٹن سے شامل کریں۔"); return; }
        String[] cats = page.equals("Home")?new String[]{"News","Sports","Islamic"}:new String[]{"News","Sports","Regional","Islamic"};
        for(String cat:cats) {
            TextView h=new TextView(this); h.setText(cat.equals("News")?"🇵🇰 Pak News / پاکستانی خبریں":cat.equals("Sports")?"🏏 Sports / کھیل":cat.equals("Islamic")?"🕌 Islamic TV / اسلامی چینلز":"🌐 Regional News / علاقائی خبریں");
            h.setTextColor(Color.rgb(255,205,43)); h.setTextSize(18); h.setTypeface(null,Typeface.BOLD); h.setPadding(4,18,4,8); content.addView(h);
            for(Channel c:channels) if(c.category.equals(cat)) addCard(c);
        }
    }
    void addCard(Channel c) {
        LinearLayout card=new LinearLayout(this); card.setOrientation(LinearLayout.VERTICAL); card.setPadding(14,10,14,10);
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2); lp.setMargins(0,4,0,7); card.setLayoutParams(lp); card.setBackgroundResource(R.drawable.bg_card);
        TextView name=new TextView(this); name.setText("● LIVE   "+c.name+"   |   "+c.urdu); name.setTextColor(Color.WHITE); name.setTextSize(16); name.setTypeface(null,Typeface.BOLD); card.addView(name);
        LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        Button play=new Button(this); play.setText("▶ Play"); row.addView(play,new LinearLayout.LayoutParams(0, -2, 1));
        Button fav=new Button(this); fav.setText(prefs.getBoolean("fav_"+c.name,false)?"♥ Saved":"☆ Favorite"); row.addView(fav,new LinearLayout.LayoutParams(0,-2,1));
        card.addView(row); content.addView(card);
        play.setOnClickListener(v->{String old=prefs.getString("history",""); String item=c.name; LinkedHashSet<String> set=new LinkedHashSet<>(); if(!old.isEmpty()) set.addAll(Arrays.asList(old.split("\\|"))); set.remove(item); set.add(item); prefs.edit().putString("history",join(set)).apply(); Intent i=new Intent(this,PlayerActivity.class); i.putExtra("name",c.name); i.putExtra("url",c.streamUrl); startActivity(i);});
        fav.setOnClickListener(v->{boolean value=!prefs.getBoolean("fav_"+c.name,false); prefs.edit().putBoolean("fav_"+c.name,value).apply(); fav.setText(value?"♥ Saved":"☆ Favorite"); if(currentPage.equals("Favorites")) showPage("Favorites");});
    }
    String join(Set<String> s){StringBuilder b=new StringBuilder(); for(String x:s){if(b.length()>0)b.append("|");b.append(x);} return b.toString();}
    void history(){String h=prefs.getString("history",""); if(h.isEmpty()){note("کوئی History موجود نہیں۔");return;} List<String> list=new ArrayList<>(Arrays.asList(h.split("\\|"))); Collections.reverse(list); for(String n:list){Channel found=null;for(Channel c:channels)if(c.name.equals(n)){found=c;break;}if(found!=null){Channel f=found; addCard(f); Button del=new Button(this);del.setText("Delete / حذف");del.setOnClickListener(v->{List<String> cur=new ArrayList<>(Arrays.asList(prefs.getString("history","").split("\\|")));cur.remove(f.name);prefs.edit().putString("history",join(new LinkedHashSet<>(cur))).apply();showPage("History");});content.addView(del);}} Button clear=new Button(this);clear.setText("Clear All History / تمام تاریخ حذف کریں");clear.setOnClickListener(v->{prefs.edit().remove("history").apply();showPage("History");});content.addView(clear);}
    void settings(){
        String[] qualities={"Auto","240p","320p","480p","720p","1080p","1440p"}; Spinner q=new Spinner(this);q.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,qualities));q.setSelection(Arrays.asList(qualities).indexOf(prefs.getString("quality","Auto"))); panel("Video Quality / ویڈیو کوالٹی");content.addView(q);q.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?>p,View v,int pos,long id){prefs.edit().putString("quality",qualities[pos]).apply();}public void onNothingSelected(android.widget.AdapterView<?>p){}});
        toggle("Data Saver Mode / کم ڈیٹا موڈ","dataSaver");toggle("Auto Retry / خودکار دوبارہ کوشش","retry");toggle("Continue Watching / جاری رکھیں","continue");toggle("Dark Mode / ڈارک موڈ","dark");toggle("Channel Updates / چینل اپ ڈیٹس","updates");toggle("App News / ایپ کی خبریں","appNews");toggle("Promotions / تشہیر","promos");
        Button clear=new Button(this);clear.setText("Clear Cache (local app data)");clear.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Temporary app state cleared.").setPositiveButton("OK",(d,w)->{}).show());content.addView(clear);
        Button reset=new Button(this);reset.setText("Reset Settings / ترتیبات بحال کریں");reset.setOnClickListener(v->new AlertDialog.Builder(this).setMessage("Reset settings?").setNegativeButton("Cancel",null).setPositiveButton("Reset",(d,w)->{prefs.edit().clear().apply();showPage("Settings");}).show());content.addView(reset);
        Button lang=new Button(this);lang.setText("Language: Urdu + English / زبان");lang.setOnClickListener(v->new AlertDialog.Builder(this).setItems(new String[]{"Urdu + English","English Only"},(d,w)->prefs.edit().putString("language",w==0?"both":"en").apply()).show());content.addView(lang);
        note("Stream quality depends on each channel's authorized stream. Settings are saved on this phone.");
    }
    void toggle(String label,String key){Switch sw=new Switch(this);sw.setText(label);sw.setTextColor(Color.WHITE);sw.setPadding(8,12,8,12);sw.setChecked(prefs.getBoolean(key,key.equals("retry")||key.equals("continue")||key.equals("dark")||key.equals("dataSaver")));sw.setOnCheckedChangeListener((b,checked)->prefs.edit().putBoolean(key,checked).apply());content.addView(sw);}
    void panel(String text){TextView t=new TextView(this);t.setText(text);t.setTextColor(Color.WHITE);t.setTextSize(17);t.setPadding(4,14,4,6);content.addView(t);}
    void note(String text){TextView t=new TextView(this);t.setText(text);t.setTextColor(Color.LTGRAY);t.setTextSize(15);t.setPadding(12,20,12,20);content.addView(t);}
    void search(){EditText input=new EditText(this);input.setSingleLine(true);input.setHint("Search channel / چینل تلاش کریں");new AlertDialog.Builder(this).setTitle("Search").setView(input).setNegativeButton("Cancel",null).setPositiveButton("Search",(d,w)->{String s=input.getText().toString().toLowerCase(Locale.ROOT);content.removeAllViews();title.setText("Search results");for(Channel c:channels)if(c.name.toLowerCase(Locale.ROOT).contains(s)||c.urdu.contains(s))addCard(c);if(content.getChildCount()==0)note("No channels found.");}).show();}
}
