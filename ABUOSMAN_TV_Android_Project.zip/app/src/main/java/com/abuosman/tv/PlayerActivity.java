package com.abuosman.tv;

import android.app.*;
import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

public class PlayerActivity extends AppCompatActivity {
    ExoPlayer player; PlayerView playerView; TextView message; String url;
    @Override public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_player);
        String name=getIntent().getStringExtra("name");url=getIntent().getStringExtra("url");
        ((TextView)findViewById(R.id.playerTitle)).setText("ABUOSMAN TV • "+name);
        playerView=findViewById(R.id.playerView);message=findViewById(R.id.playerMessage);
        String[] qualities={"Auto","240p","320p","480p","720p","1080p","1440p"};
        Spinner spinner=findViewById(R.id.qualitySpinner);spinner.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_spinner_dropdown_item,qualities));
        if(url==null||url.trim().isEmpty()){message.setText("Stream URL not configured. Add a legal stream URL in Channel.java before playback.");}
        else startPlayback();
        findViewById(R.id.retryBtn).setOnClickListener(v->{if(url==null||url.trim().isEmpty())message.setText("No stream URL configured.");else startPlayback();});
    }
    void startPlayback(){
        if(player!=null){player.release();player=null;}
        player=new ExoPlayer.Builder(this).build();playerView.setPlayer(player);
        player.addListener(new Player.Listener(){@Override public void onPlayerError(PlaybackException e){message.setText("Stream error. Check the URL, network and stream permissions.");}});
        player.setMediaItem(MediaItem.fromUri(url));player.prepare();player.play();message.setText("Connecting to live stream…");
    }
    @Override protected void onStop(){super.onStop();if(player!=null){player.release();player=null;}}
}
