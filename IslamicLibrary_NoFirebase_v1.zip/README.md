# Islamic Library

Firebase کے بغیر Offline Islamic Library Android project.

## موجودہ ورژن
- Kotlin + XML
- Android SDK
- Home Screen
- Search UI
- قرآن، حدیث، تفاسیر، کتب اور علماء کے sections

## اگلا مرحلہ
Local database شامل کر کے:
- آیت نمبر سے search
- حدیث نمبر سے search
- کتاب/مصنف search
- Bookmark
- Offline reading
شامل کیے جائیں گے۔

## AndroidIDE
ZIP extract کریں، project folder AndroidIDE میں کھولیں، Gradle sync کریں اور Run کریں۔
