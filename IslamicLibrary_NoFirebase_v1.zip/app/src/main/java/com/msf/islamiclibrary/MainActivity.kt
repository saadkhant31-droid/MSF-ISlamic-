package com.msf.islamiclibrary

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val searchBox = findViewById<EditText>(R.id.searchBox)
        val searchButton = findViewById<Button>(R.id.searchButton)

        searchButton.setOnClickListener {
            val query = searchBox.text.toString().trim()
            if (query.isEmpty()) {
                Toast.makeText(this, "براہِ کرم کچھ تلاش کریں", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "تلاش: $query", Toast.LENGTH_SHORT).show()
            }
        }
    }
}
