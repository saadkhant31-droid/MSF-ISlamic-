# MSF-Islamic
Firebase-free Kotlin/XML Android Islamic Library starter.
Upload the CONTENTS of this folder to the repository root, not the outer folder.
Then run Actions > Build Android APK > Run workflow.
