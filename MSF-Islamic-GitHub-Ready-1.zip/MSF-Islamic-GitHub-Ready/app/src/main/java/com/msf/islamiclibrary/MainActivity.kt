package com.msf.islamiclibrary

import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        val searchBox = findViewById<EditText>(R.id.searchBox)
        findViewById<Button>(R.id.searchButton).setOnClickListener {
            val query = searchBox.text.toString().trim()
            Toast.makeText(this, if (query.isEmpty()) "کچھ تلاش کریں" else "تلاش: $query", Toast.LENGTH_SHORT).show()
        }
    }
}
