# MSF-Islamic
Firebase کے بغیر Kotlin + XML Android Islamic Library project.

GitHub پر پورا project root میں upload کریں، پھر Actions → Build Android APK → Run workflow کریں۔
APK Artifacts میں `MSF-Islamic-APK` کے نام سے ملے گی۔

اس ابتدائی ورژن میں Home/Search UI موجود ہے۔ قرآن، حدیث اور کتابوں کا مکمل Offline database اگلے مرحلے میں شامل کیا جائے گا۔
