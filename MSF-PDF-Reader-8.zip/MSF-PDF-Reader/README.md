# MSF PDF Reader
Read • Learn • Grow — simple PDF library app (Kotlin + Jetpack Compose).

- Home screen with last-read card, categories, search, sort, grid of books
- Add PDFs from phone storage (no sample books included)
- Built-in PDF viewer (zoom buttons, jump to page, remembers last page)
- Three-dot menu (Home + Viewer): Add/Remove Favorites, Add to Home Screen, Bookmarks (page bookmarks in the viewer),
  Search in PDF, Last Read Page, Night/Day Mode, Share PDF, Remove from Home Screen
- My Files, Bookmarks (favorites), Settings

## Build
Open in Android Studio and press Run, or push to GitHub: Actions builds a debug APK automatically.

## Settings
Reading: reader theme (Light / Sepia / Gray), text size (zoom), night mode, auto page fit, continuous scroll, open last read page.
General: language (English / Urdu for Settings + bottom bar), download location, clear cache, notifications, clear library.
Support: help (e-mail), rate us, privacy policy, about, app information, exit app.
Change SUPPORT_EMAIL in Settings.kt to your real support address.
