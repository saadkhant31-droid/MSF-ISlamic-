package com.msf.pdfreader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.graphics.pdf.PdfDocument
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import androidx.exifinterface.media.ExifInterface
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.DataInputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

fun pdfDir(ctx: Context): File = File(ctx.filesDir, "pdfs").apply { mkdirs() }

/** Converts one photo into a one-page PDF. */
fun imageToPdf(img: File, out: File): Boolean = try {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    BitmapFactory.decodeFile(img.path, bounds)
    var sample = 1
    while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2400) sample *= 2
    var bmp: Bitmap = BitmapFactory.decodeFile(img.path, BitmapFactory.Options().apply { inSampleSize = sample })
        ?: throw IllegalStateException("decode failed")
    val rotation = when (
        ExifInterface(img.path).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    ) {
        ExifInterface.ORIENTATION_ROTATE_90 -> 90f
        ExifInterface.ORIENTATION_ROTATE_180 -> 180f
        ExifInterface.ORIENTATION_ROTATE_270 -> 270f
        else -> 0f
    }
    if (rotation != 0f) {
        val m = Matrix().apply { postRotate(rotation) }
        bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
    }
    val pdf = PdfDocument()
    val page = pdf.startPage(PdfDocument.PageInfo.Builder(bmp.width, bmp.height, 1).create())
    page.canvas.drawBitmap(bmp, 0f, 0f, null)
    pdf.finishPage(page)
    out.outputStream().use { pdf.writeTo(it) }
    pdf.close()
    bmp.recycle()
    true
} catch (e: Exception) {
    false
}

/** Downloads a PDF; returns false if the link is not a real PDF. */
fun downloadPdf(url: String, out: File): Boolean {
    var conn: HttpURLConnection? = null
    return try {
        conn = (URL(url).openConnection() as HttpURLConnection).apply {
            connectTimeout = 15000
            readTimeout = 30000
            instanceFollowRedirects = true
        }
        if (conn.responseCode !in 200..299) {
            false
        } else {
            conn.inputStream.use { ins ->
                val head = ByteArray(5)
                DataInputStream(ins).readFully(head)
                if (String(head, Charsets.ISO_8859_1) != "%PDF-") {
                    false
                } else {
                    out.outputStream().use { o ->
                        o.write(head)
                        ins.copyTo(o)
                    }
                    true
                }
            }
        }
    } catch (e: Exception) {
        false
    } finally {
        conn?.disconnect()
    }
}

fun titleFromUrl(url: String): String {
    val seg = try {
        Uri.parse(url).lastPathSegment
    } catch (e: Exception) {
        null
    }
    val t = (seg ?: "").replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), "").trim()
    return if (t.isBlank()) "Downloaded PDF" else t
}

@Composable
fun AddHeader() {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Navy, Color(0xFF14497E))))
            .padding(horizontal = 14.dp, vertical = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(72.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xFF0F3A68)),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    "PDF", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.background(Red, RoundedCornerShape(5.dp)).padding(horizontal = 6.dp)
                )
                Icon(Icons.Filled.MenuBook, null, tint = Gold, modifier = Modifier.size(34.dp))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("MSF", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold)
            Text("PDF Reader", color = Gold, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            Text("Read  •  Learn  •  Grow", color = Color.White, fontSize = 12.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text(
                "علم روشنی ہے\nاور کتابیں اس کی سبیلیں",
                color = Color.White, fontSize = 13.sp, textAlign = TextAlign.End, lineHeight = 22.sp
            )
            Spacer(Modifier.height(4.dp))
            Box(Modifier.width(100.dp).height(1.dp).background(Gold))
        }
    }
}

@Composable
private fun MethodCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tile: Color,
    bg: Color,
    border: Color,
    onClick: () -> Unit
) {
    Card(
        Modifier.fillMaxWidth().clickable(onClick = onClick),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = bg),
        border = BorderStroke(1.dp, border)
    ) {
        Row(Modifier.padding(horizontal = 14.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(60.dp).background(tile, RoundedCornerShape(16.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(32.dp)) }
            Spacer(Modifier.width(16.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text(subtitle, fontSize = 13.sp, color = Color(0xFF4B5563), lineHeight = 18.sp)
            }
            Icon(Icons.Filled.ChevronRight, null, tint = Blue, modifier = Modifier.size(30.dp))
        }
    }
}

@Composable
fun AddPdfScreen(
    onBack: () -> Unit,
    onPickFiles: () -> Unit,
    onSaved: (File, String) -> Unit,
    onHomeShortcut: () -> Unit
) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var pendingImage by remember { mutableStateOf<File?>(null) }
    var showUrl by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf<String?>(null) }

    val camera = rememberLauncherForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val img = pendingImage
        pendingImage = null
        if (ok && img != null) {
            busy = "Creating PDF…"
            scope.launch {
                val name = "Scan_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
                val out = File(pdfDir(ctx), "$name.pdf")
                val good = withContext(Dispatchers.IO) { imageToPdf(img, out) }
                img.delete()
                busy = null
                if (good) onSaved(out, name) else {
                    out.delete()
                    toast(ctx, "Could not create the PDF")
                }
            }
        } else {
            img?.delete()
        }
    }

    val startScan = {
        try {
            val dir = File(ctx.cacheDir, "scan").apply { mkdirs() }
            val f = File(dir, "scan_${System.currentTimeMillis()}.jpg")
            pendingImage = f
            camera.launch(FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", f))
        } catch (e: Exception) {
            toast(ctx, "No camera app found on this phone")
        }
    }

    Column(Modifier.fillMaxSize().background(Bg).verticalScroll(rememberScrollState())) {
        AddHeader()
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Card(
                Modifier.fillMaxWidth().clickable { onBack() },
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White),
                elevation = CardDefaults.cardElevation(2.dp)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.ArrowBack, "Back", tint = Navy)
                    Spacer(Modifier.width(18.dp))
                    Column {
                        Text("Add PDF", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Navy)
                        Text("Choose a method to add your PDF file", fontSize = 14.sp, color = Gray)
                    }
                }
            }
            MethodCard(
                "From Device", "Select PDF from your phone storage or SD card",
                Icons.Filled.Description, Color(0xFF1E6BF0), Color(0xFFEAF3FF), Color(0xFFCFE2FA)
            ) { onPickFiles() }
            MethodCard(
                "From Google Drive", "Choose PDF from your Google Drive",
                Icons.Filled.AddToDrive, Color(0xFF22A85A), Color(0xFFEAF8EF), Color(0xFFC8EBD4)
            ) {
                toast(ctx, "Tap the ≡ menu and choose Google Drive")
                onPickFiles()
            }
            MethodCard(
                "From Cloud Storage", "OneDrive, Dropbox, etc.",
                Icons.Filled.CloudUpload, Color(0xFF1E6BF0), Color(0xFFF0EEFB), Color(0xFFD9D4F3)
            ) {
                toast(ctx, "Tap the ≡ menu and choose your cloud app")
                onPickFiles()
            }
            MethodCard(
                "Scan Document", "Take a photo and convert to PDF",
                Icons.Filled.PhotoCamera, Color(0xFFFF6D00), Color(0xFFFFF3E6), Color(0xFFF8DDBF)
            ) { startScan() }
            MethodCard(
                "From URL", "Paste a PDF link from the internet",
                Icons.Filled.Link, Color(0xFFF03E5E), Color(0xFFFDEBF0), Color(0xFFF6CBD6)
            ) { showUrl = true }

            Card(
                Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFEAF3FF)),
                border = BorderStroke(1.dp, Color(0xFFCFE2FA))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        Modifier.size(38.dp).background(Blue, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.Lightbulb, null, tint = Color.White, modifier = Modifier.size(22.dp)) }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Tip", color = Blue, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                        Text(
                            "You can also add a PDF to your home screen for quick access.",
                            fontSize = 12.sp, color = Color(0xFF4B5563), lineHeight = 16.sp
                        )
                    }
                    Spacer(Modifier.width(8.dp))
                    Button(
                        onHomeShortcut,
                        shape = RoundedCornerShape(14.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)
                    ) {
                        Icon(Icons.Filled.Home, null, modifier = Modifier.size(18.dp))
                        Spacer(Modifier.width(4.dp))
                        Text("Add to\nHome Screen", fontSize = 11.sp, lineHeight = 13.sp, textAlign = TextAlign.Center)
                    }
                }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (showUrl) {
        var url by remember { mutableStateOf("") }
        val clip = LocalClipboardManager.current
        AlertDialog(
            onDismissRequest = { showUrl = false },
            title = { Text("From URL") },
            text = {
                OutlinedTextField(
                    url, { url = it },
                    singleLine = true,
                    placeholder = { Text("https://example.com/book.pdf") },
                    trailingIcon = {
                        TextButton({ url = clip.getText()?.text ?: url }) { Text("Paste") }
                    },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Uri)
                )
            },
            confirmButton = {
                TextButton({
                    val u = url.trim()
                    if (!(u.startsWith("http://") || u.startsWith("https://"))) {
                        toast(ctx, "Please enter a valid link (https://...)")
                    } else {
                        showUrl = false
                        busy = "Downloading…"
                        scope.launch {
                            val out = File(pdfDir(ctx), "dl_${System.currentTimeMillis()}.pdf")
                            val ok = withContext(Dispatchers.IO) { downloadPdf(u, out) }
                            busy = null
                            if (ok) onSaved(out, titleFromUrl(u)) else {
                                out.delete()
                                toast(ctx, "Could not download a PDF from this link")
                            }
                        }
                    }
                }) { Text("Download") }
            },
            dismissButton = { TextButton({ showUrl = false }) { Text("Cancel") } }
        )
    }

    busy?.let { msg ->
        AlertDialog(
            onDismissRequest = {},
            title = { Text(msg) },
            text = { LinearProgressIndicator(Modifier.fillMaxWidth()) },
            confirmButton = {}
        )
    }
}
