package com.msf.pdfreader

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay

val BM_COLORS = listOf(
    Color(0xFFF03E5E), // red
    Color(0xFF1E6BF0), // blue
    Color(0xFF16A34A), // green
    Color(0xFF7B3FE4), // purple
    Color(0xFFFF9800), // orange
    Color(0xFF00B8B8), // teal
    Color(0xFFFF2D78)  // pink
)

@Composable
fun BookmarksScreen(
    books: List<PdfBook>,
    bookmarks: List<PageBookmark>,
    menuItems: List<MenuEntry>,
    defaultBook: PdfBook?,
    onBack: () -> Unit,
    onOpenAt: (PdfBook, Int) -> Unit,
    onAdd: (PdfBook, Int) -> Boolean,
    onColor: (PageBookmark, Int) -> Unit,
    onRemove: (PageBookmark) -> Unit,
    lastPage: (PdfBook) -> Int
) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var showAdd by remember { mutableStateOf(false) }
    var colorFor by remember { mutableStateOf<PageBookmark?>(null) }
    var removeFor by remember { mutableStateOf<PageBookmark?>(null) }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current

    LaunchedEffect(searching) {
        if (searching) {
            delay(80)
            try {
                focus.requestFocus()
                keyboard?.show()
            } catch (_: Exception) {
            }
        } else {
            query = ""
        }
    }

    // only bookmarks of books that are still in the library
    val byUri = books.associateBy { it.uri }
    val items = bookmarks
        .mapNotNull { m -> byUri[m.uri]?.let { Pair(m, it) } }
        .filter {
            val q = query.trim()
            it.second.title.contains(q, ignoreCase = true) ||
                it.second.shownFileName().contains(q, ignoreCase = true)
        }
        .sortedByDescending { it.first.at }

    Column(Modifier.fillMaxSize()) {
        AppHeader(onBack, { searching = !searching }, menuItems)

        if (searching) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp, 10.dp, 12.dp, 0.dp).focusRequester(focus),
                placeholder = { Text("Search bookmarks...") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = { IconButton({ searching = false }) { Icon(Icons.Filled.Close, "Close search") } },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = Color(0xFFDDE3EE)
                )
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp, 14.dp, 14.dp, 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Bookmark, null, tint = Blue, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(10.dp))
            Column(Modifier.weight(1f)) {
                Text("Bookmarks", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy, maxLines = 1)
                Text(
                    "Your saved pages for quick access", fontSize = 12.sp, color = Gray,
                    lineHeight = 15.sp, maxLines = 2
                )
            }
            Spacer(Modifier.width(8.dp))
            Row(
                Modifier.clip(RoundedCornerShape(26.dp))
                    .background(Color(0xFFF1F6FF))
                    .border(1.5.dp, Color(0xFFCFE2FA), RoundedCornerShape(26.dp))
                    .clickable {
                        if (books.isEmpty()) toast(ctx, "Add a PDF first") else showAdd = true
                    }
                    .padding(horizontal = 14.dp, vertical = 11.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.BookmarkAdd, null, tint = Blue, modifier = Modifier.size(22.dp))
                Spacer(Modifier.width(6.dp))
                Text(
                    "Add Bookmark", fontSize = 14.sp, color = Blue,
                    fontWeight = FontWeight.Medium, maxLines = 1, softWrap = false
                )
            }
        }

        if (items.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (bookmarks.isEmpty()) "No bookmarks yet.\nTap Add Bookmark, or use ⋮ → Bookmarks while reading."
                    else "No bookmarks found.",
                    textAlign = TextAlign.Center, color = Gray, modifier = Modifier.padding(24.dp)
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(items, key = { it.first.uri + "#" + it.first.page }) { (m, b) ->
                    var menu by remember { mutableStateOf(false) }
                    val color = BM_COLORS[m.color % BM_COLORS.size]
                    Card(
                        Modifier.fillMaxWidth().clickable { onOpenAt(b, m.page) },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(2.dp)
                    ) {
                        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Cover(b.uri, Modifier.size(58.dp, 64.dp).clip(RoundedCornerShape(6.dp)))
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    b.title, fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Navy,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    listOfNotNull(b.shownFileName(), if (b.pages > 0) "${b.pages} Pages" else null)
                                        .joinToString("  •  "),
                                    fontSize = 12.sp, color = Color(0xFF3B82F6),
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(5.dp))
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Description, null, tint = Gray, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text("Page ${m.page + 1}", fontSize = 12.sp, color = Color(0xFF374151), maxLines = 1)
                                    Spacer(Modifier.width(8.dp))
                                    Box(Modifier.width(1.dp).height(14.dp).background(Color(0xFFD5DBE6)))
                                    Spacer(Modifier.width(8.dp))
                                    Icon(Icons.Filled.Schedule, null, tint = Gray, modifier = Modifier.size(15.dp))
                                    Spacer(Modifier.width(4.dp))
                                    Text(
                                        fmtDate(m.at), fontSize = 11.sp, color = Gray,
                                        maxLines = 1, overflow = TextOverflow.Ellipsis
                                    )
                                }
                            }
                            IconButton({ colorFor = m }, Modifier.size(40.dp)) {
                                Icon(Icons.Filled.Bookmark, "Change color", tint = color, modifier = Modifier.size(34.dp))
                            }
                            Box {
                                IconButton({ menu = true }, Modifier.size(32.dp)) {
                                    Icon(Icons.Filled.MoreVert, "More", tint = Navy)
                                }
                                AppMenu(
                                    menu, { menu = false },
                                    listOf(
                                        MenuEntry("Go to page ${m.page + 1}", Icons.Filled.MenuBook, Blue) { onOpenAt(b, m.page) },
                                        MenuEntry("Change color", Icons.Filled.Palette, Purple) { colorFor = m },
                                        MenuEntry("Remove bookmark", Icons.Filled.Delete, Red) { removeFor = m }
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    colorFor?.let { m ->
        AlertDialog(
            onDismissRequest = { colorFor = null },
            title = { Text("Bookmark color") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    BM_COLORS.withIndex().toList().chunked(4).forEach { row ->
                        Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            row.forEach { (i, c) ->
                                Box(
                                    Modifier.size(44.dp).clip(CircleShape).background(c)
                                        .then(
                                            if (i == m.color % BM_COLORS.size)
                                                Modifier.border(3.dp, Navy, CircleShape) else Modifier
                                        )
                                        .clickable { onColor(m, i); colorFor = null },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (i == m.color % BM_COLORS.size) {
                                        Icon(Icons.Filled.Check, null, tint = Color.White)
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton({ colorFor = null }) { Text("Cancel") } }
        )
    }

    removeFor?.let { m ->
        AlertDialog(
            onDismissRequest = { removeFor = null },
            title = { Text("Remove bookmark?") },
            text = { Text("Page ${m.page + 1} will be removed from your bookmarks. The PDF is not deleted.") },
            confirmButton = { TextButton({ onRemove(m); removeFor = null }) { Text("Remove") } },
            dismissButton = { TextButton({ removeFor = null }) { Text("Cancel") } }
        )
    }

    if (showAdd) {
        var sel by remember { mutableStateOf(defaultBook ?: books.first()) }
        var pageText by remember { mutableStateOf((lastPage(sel) + 1).toString()) }
        AlertDialog(
            onDismissRequest = { showAdd = false },
            title = { Text("Add Bookmark") },
            text = {
                Column {
                    Text("Choose book", fontSize = 13.sp, color = Gray)
                    LazyColumn(Modifier.heightIn(max = 190.dp)) {
                        items(books, key = { it.uri }) { b ->
                            Row(
                                Modifier.fillMaxWidth()
                                    .clickable { sel = b; pageText = (lastPage(b) + 1).toString() }
                                    .padding(vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                RadioButton(selected = b.uri == sel.uri, onClick = {
                                    sel = b
                                    pageText = (lastPage(b) + 1).toString()
                                })
                                Text(b.title, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                        }
                    }
                    Spacer(Modifier.height(8.dp))
                    OutlinedTextField(
                        pageText, { pageText = it.filter { c -> c.isDigit() } },
                        label = { Text(if (sel.pages > 0) "Page number (1–${sel.pages})" else "Page number") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                    )
                }
            },
            confirmButton = {
                TextButton({
                    val n = pageText.toIntOrNull()
                    when {
                        n == null || n < 1 -> toast(ctx, "Enter a valid page number")
                        sel.pages > 0 && n > sel.pages -> toast(ctx, "This book has only ${sel.pages} pages")
                        onAdd(sel, n - 1) -> {
                            toast(ctx, "Page $n bookmarked")
                            showAdd = false
                        }
                        else -> toast(ctx, "This page is already bookmarked")
                    }
                }) { Text("Add") }
            },
            dismissButton = { TextButton({ showAdd = false }) { Text("Cancel") } }
        )
    }
}
