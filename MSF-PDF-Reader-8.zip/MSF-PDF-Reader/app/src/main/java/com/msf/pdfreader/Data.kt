package com.msf.pdfreader

import android.app.Application
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.provider.OpenableColumns
import androidx.core.content.FileProvider
import java.io.File
import android.util.LruCache
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale

val CATEGORIES = listOf("Islamic", "Quran & Tafsir", "Education", "Others")

data class PdfBook(
    val uri: String,
    val title: String,
    val size: Long,
    val category: String,
    val bookmarked: Boolean,
    val addedAt: Long,
    val pages: Int = 0,
    val fileName: String = ""
)

/** Original file name shown under the title (e.g. Quran.pdf). */
fun PdfBook.shownFileName(): String = fileName.ifBlank { "$title.pdf" }

fun fmtSize(b: Long): String =
    if (b <= 0) "—"
    else if (b >= 1_048_576) String.format(Locale.US, "%.1f MB", b / 1_048_576.0)
    else "${(b / 1024).coerceAtLeast(1)} KB"

fun metaLine(b: PdfBook): String =
    listOfNotNull(fmtSize(b.size), if (b.pages > 0) "${b.pages} Pages" else null).joinToString("  •  ")

fun countPages(ctx: Context, uri: String): Int = try {
    ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")?.use { pfd ->
        PdfRenderer(pfd).use { it.pageCount }
    } ?: 0
} catch (e: Exception) {
    0
}

fun queryMeta(ctx: Context, uri: Uri): Pair<String, Long> {
    var name = "PDF"
    var size = 0L
    try {
        ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val n = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                val s = c.getColumnIndex(OpenableColumns.SIZE)
                if (n >= 0) name = c.getString(n) ?: "PDF"
                if (s >= 0 && !c.isNull(s)) size = c.getLong(s)
            }
        }
    } catch (_: Exception) {
    }
    return Pair(name.replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), ""), size)
}

const val BM_COLOR_COUNT = 7

data class PageBookmark(val uri: String, val page: Int, val color: Int, val at: Long)

class BookStore(ctx: Context) {
    private val prefs = ctx.getSharedPreferences("msf_books", Context.MODE_PRIVATE)

    fun load(): List<PdfBook> = try {
        val arr = JSONArray(prefs.getString("books", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            PdfBook(
                o.getString("uri"), o.getString("title"), o.getLong("size"),
                o.getString("cat"), o.getBoolean("bm"), o.getLong("at"), o.optInt("pages", 0),
                o.optString("fn", "")
            )
        }
    } catch (e: Exception) {
        emptyList()
    }

    fun save(list: List<PdfBook>) {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("uri", it.uri).put("title", it.title).put("size", it.size)
                    .put("cat", it.category).put("bm", it.bookmarked).put("at", it.addedAt)
                    .put("pages", it.pages).put("fn", it.fileName)
            )
        }
        prefs.edit().putString("books", arr.toString()).apply()
    }

    // reading position
    fun delete(uri: String) = save(load().filter { it.uri != uri })

    fun getPage(uri: String): Int = prefs.getInt("page_$uri", 0)
    fun setPage(uri: String, page: Int) = prefs.edit().putInt("page_$uri", page).apply()
    fun getLastRead(uri: String): Long = prefs.getLong("lr_$uri", 0L)
    fun setLastRead(uri: String, t: Long) = prefs.edit().putLong("lr_$uri", t).apply()

    // night mode
    fun isNight(): Boolean = prefs.getBoolean("night", false)
    fun setNight(v: Boolean) = prefs.edit().putBoolean("night", v).apply()

    // home screen shortcut id
    fun getShortcut(uri: String): String? = prefs.getString("sc_$uri", null)
    fun setShortcut(uri: String, id: String?) {
        val e = prefs.edit()
        if (id == null) e.remove("sc_$uri") else e.putString("sc_$uri", id)
        e.apply()
    }

    // page bookmarks (shown on the Bookmarks screen)
    fun allBookmarks(): List<PageBookmark> = try {
        val arr = JSONArray(prefs.getString("bm2", "[]") ?: "[]")
        (0 until arr.length()).map {
            val o = arr.getJSONObject(it)
            PageBookmark(o.getString("u"), o.getInt("p"), o.getInt("c"), o.getLong("t"))
        }
    } catch (e: Exception) {
        emptyList()
    }

    private fun saveBookmarks(l: List<PageBookmark>) {
        val arr = JSONArray()
        l.forEach { arr.put(JSONObject().put("u", it.uri).put("p", it.page).put("c", it.color).put("t", it.at)) }
        prefs.edit().putString("bm2", arr.toString()).apply()
    }

    fun addBookmark(uri: String, page: Int, color: Int = -1): Boolean {
        val l = allBookmarks().toMutableList()
        if (l.any { it.uri == uri && it.page == page }) return false
        val c = if (color >= 0) color else l.size % BM_COLOR_COUNT
        l.add(0, PageBookmark(uri, page, c, System.currentTimeMillis()))
        saveBookmarks(l)
        return true
    }

    fun removeBookmark(uri: String, page: Int) =
        saveBookmarks(allBookmarks().filterNot { it.uri == uri && it.page == page })

    fun setBookmarkColor(uri: String, page: Int, color: Int) =
        saveBookmarks(allBookmarks().map { if (it.uri == uri && it.page == page) it.copy(color = color) else it })

    fun removeBookmarksOf(uri: String) = saveBookmarks(allBookmarks().filter { it.uri != uri })
    fun clearBookmarks() = prefs.edit().remove("bm2").apply()

    // favorites (book level)
    fun isFavorite(uri: String): Boolean = load().any { it.uri == uri && it.bookmarked }

    fun toggleFavorite(uri: String, title: String, pages: Int): Boolean {
        val list = load().toMutableList()
        val i = list.indexOfFirst { it.uri == uri }
        val now: Boolean
        if (i >= 0) {
            now = !list[i].bookmarked
            list[i] = list[i].copy(bookmarked = now)
        } else {
            now = true
            list.add(0, PdfBook(uri, title, 0L, "Others", true, System.currentTimeMillis(), pages))
        }
        save(list)
        return now
    }
}

class LibraryViewModel(app: Application) : AndroidViewModel(app) {
    private val store = BookStore(app)
    val books = mutableStateListOf<PdfBook>()
    val lastRead = mutableStateMapOf<String, Long>()
    val night = mutableStateOf(store.isNight())
    val bookmarks = mutableStateListOf<PageBookmark>()

    fun toggleNight() {
        val v = !night.value
        store.setNight(v)
        night.value = v
    }

    init {
        refresh()
    }

    /** Reload everything from storage (called whenever the app comes to the front). */
    fun refresh() {
        val fresh = store.load()
        books.clear()
        books.addAll(fresh)
        night.value = store.isNight()
        loadBookmarks()
        fresh.forEach { lastRead[it.uri] = store.getLastRead(it.uri) }
        fillPages()
    }

    private fun loadBookmarks() {
        bookmarks.clear()
        bookmarks.addAll(store.allBookmarks())
    }

    fun addBookmark(uri: String, page: Int): Boolean {
        val ok = store.addBookmark(uri, page)
        loadBookmarks()
        return ok
    }

    fun removeBookmark(m: PageBookmark) {
        store.removeBookmark(m.uri, m.page)
        loadBookmarks()
    }

    fun setBookmarkColor(m: PageBookmark, color: Int) {
        store.setBookmarkColor(m.uri, m.page, color)
        loadBookmarks()
    }

    private fun fillPages() {
        val todo = books.filter { it.pages == 0 }
        if (todo.isEmpty()) return
        viewModelScope.launch {
            todo.forEach { b ->
                val n = withContext(Dispatchers.IO) { countPages(getApplication<Application>(), b.uri) }
                if (n > 0) upd(b) { it.copy(pages = n) }
            }
        }
    }

    private fun persist() = store.save(books.toList())

    private fun upd(b: PdfBook, f: (PdfBook) -> PdfBook) {
        val i = books.indexOfFirst { it.uri == b.uri }
        if (i >= 0) {
            books[i] = f(books[i])
            persist()
        }
    }

    fun addPdf(uri: Uri, category: String): Boolean {
        val ctx = getApplication<Application>()
        try {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        if (books.any { it.uri == uri.toString() }) return false
        val (title, size) = queryMeta(ctx, uri)
        val fn = queryName(ctx, uri) ?: "$title.pdf"
        books.add(0, PdfBook(uri.toString(), title, size, category, false, System.currentTimeMillis(), 0, fn))
        persist()
        fillPages()
        return true
    }

    fun toggleBookmark(b: PdfBook) = upd(b) { it.copy(bookmarked = !it.bookmarked) }
    fun setCategory(b: PdfBook, cat: String) = upd(b) { it.copy(category = cat) }
    fun rename(b: PdfBook, title: String) {
        if (title.isNotBlank()) upd(b) { it.copy(title = title.trim()) }
    }

    /** Adds a PDF that the app created itself (scan / download), stored in app storage. */
    fun addLocalPdf(file: File, title: String, category: String = "Others"): Boolean {
        val ctx = getApplication<Application>()
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.fileprovider", file).toString()
        if (books.any { it.uri == uri }) return false
        books.add(0, PdfBook(uri, title, file.length(), category, false, System.currentTimeMillis(), 0, file.name))
        persist()
        fillPages()
        return true
    }

    private fun deleteOwnFile(b: PdfBook) {
        val ctx = getApplication<Application>()
        if (b.uri.contains("${ctx.packageName}.fileprovider")) {
            try {
                Uri.parse(b.uri).lastPathSegment?.let { File(File(ctx.filesDir, "pdfs"), it).delete() }
            } catch (_: Exception) {
            }
        }
    }

    fun remove(b: PdfBook) {
        deleteOwnFile(b)
        store.removeBookmarksOf(b.uri)
        loadBookmarks()
        books.removeAll { it.uri == b.uri }
        persist()
        silentRemoveShortcut(getApplication<Application>(), b.uri)
    }

    fun clear() {
        books.forEach { deleteOwnFile(it) }
        store.clearBookmarks()
        bookmarks.clear()
        books.clear()
        persist()
    }
}

object Thumbs {
    private val cache = LruCache<String, Bitmap>(30)

    fun clear() = cache.evictAll()

    suspend fun get(ctx: Context, uri: String): Bitmap? = withContext(Dispatchers.IO) {
        cache.get(uri) ?: try {
            ctx.contentResolver.openFileDescriptor(Uri.parse(uri), "r")?.use { pfd ->
                PdfRenderer(pfd).use { r ->
                    if (r.pageCount == 0) null
                    else r.openPage(0).use { p ->
                        val w = 300
                        val h = (w * p.height / p.width.toFloat()).toInt().coerceAtLeast(1)
                        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
                        bmp.eraseColor(android.graphics.Color.WHITE)
                        p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                        bmp
                    }
                }
            }?.also { cache.put(uri, it) }
        } catch (e: Exception) {
            null
        }
    }
}
