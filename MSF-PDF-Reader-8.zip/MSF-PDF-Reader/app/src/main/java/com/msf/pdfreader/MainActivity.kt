package com.msf.pdfreader

import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.viewModels
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    private val vm: LibraryViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLang.init(this)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Blue)) { MainScreen(vm) }
        }
    }

    override fun onResume() {
        super.onResume()
        vm.refresh() // pick up changes made in the PDF viewer (favorites, last read, ...)
    }
}

sealed class Dlg {
    class Pick(val uris: List<Uri>) : Dlg()
    class Category(val b: PdfBook) : Dlg()
    class Rename(val b: PdfBook) : Dlg()
    class Remove(val b: PdfBook) : Dlg()
    object Clear : Dlg()
}

@Composable
fun MainScreen(vm: LibraryViewModel = viewModel()) {
    val ctx = LocalContext.current
    var tab by remember { mutableIntStateOf(0) }
    var dialog by remember { mutableStateOf<Dlg?>(null) }

    // system back button: go to Home first, then leave the app
    BackHandler(enabled = tab != 0) { tab = 0 }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) dialog = Dlg.Pick(uris)
    }
    val launchPicker = { picker.launch(arrayOf("application/pdf")) }

    val scope = rememberCoroutineScope()
    val openViewer: (PdfBook, Boolean) -> Unit = { b, search ->
        ctx.startActivity(
            Intent(ctx, PdfViewerActivity::class.java)
                .putExtra("uri", b.uri).putExtra("title", b.title).putExtra("search", search)
        )
    }
    val onOpen: (PdfBook) -> Unit = { b -> openViewer(b, false) }
    val openAt: (PdfBook, Int) -> Unit = { b, page ->
        ctx.startActivity(
            Intent(ctx, PdfViewerActivity::class.java)
                .putExtra("uri", b.uri).putExtra("title", b.title).putExtra("page", page)
        )
    }
    val bookStore = remember { BookStore(ctx) }
    val onBookmarkToggle: (PdfBook) -> Unit = { b ->
        val page = bookStore.getPage(b.uri)
        if (vm.bookmarks.any { it.uri == b.uri && it.page == page }) {
            vm.bookmarks.firstOrNull { it.uri == b.uri && it.page == page }?.let { vm.removeBookmark(it) }
            toast(ctx, "Bookmark removed")
        } else {
            vm.addBookmark(b.uri, page)
            toast(ctx, "Page ${page + 1} bookmarked")
        }
    }
    val onAction: (String, PdfBook) -> Unit = { a, b ->
        when (a) {
            "open" -> onOpen(b)
            "bookmark" -> vm.toggleBookmark(b)
            "category" -> dialog = Dlg.Category(b)
            "rename" -> dialog = Dlg.Rename(b)
            "remove" -> dialog = Dlg.Remove(b)
        }
    }

    // The three-dot menu works on the book you read last
    val current = vm.books.maxByOrNull { vm.lastRead[it.uri] ?: 0L }
    fun withBook(f: (PdfBook) -> Unit) {
        val b = vm.books.maxByOrNull { vm.lastRead[it.uri] ?: 0L }
        if (b == null) toast(ctx, "Add a PDF first") else f(b)
    }

    val night = vm.night.value
    val menuItems = listOf(
        MenuEntry(
            if (current?.bookmarked == true) "Remove from Favorites" else "Add to Favorites",
            Icons.Filled.Star, Blue
        ) {
            withBook {
                vm.toggleBookmark(it)
                toast(ctx, if (it.bookmarked) "Removed from Favorites" else "Added to Favorites")
            }
        },
        MenuEntry("Add to Home Screen", Icons.Filled.AddToHomeScreen, SkyBlue) {
            withBook { b -> scope.launch { addPdfShortcut(ctx, b.uri, b.title) } }
        },
        MenuEntry("Bookmarks", Icons.Filled.Bookmark, Blue) { tab = 3 },
        MenuEntry("Search in PDF", Icons.Filled.Search, SkyBlue) { withBook { openViewer(it, true) } },
        MenuEntry("Last Read Page", Icons.Filled.Schedule, Green) {
            withBook {
                toast(ctx, "Opening page ${BookStore(ctx).getPage(it.uri) + 1}")
                openViewer(it, false)
            }
        },
        MenuEntry(
            if (night) "Day Mode" else "Night Mode",
            if (night) Icons.Filled.LightMode else Icons.Filled.DarkMode, Purple
        ) {
            vm.toggleNight()
            toast(ctx, if (vm.night.value) "Night mode on (PDF reader)" else "Night mode off")
        },
        MenuEntry("Share PDF", Icons.Filled.Share, SkyBlue) { withBook { sharePdf(ctx, it.uri, it.title) } },
        MenuEntry("Remove from Home Screen", Icons.Filled.Delete, Red) {
            withBook { removePdfShortcut(ctx, it.uri) }
        }
    )

    val navItems = listOf(
        Triple("Home", Icons.Filled.Home, 0),
        Triple("My Files", Icons.Filled.Folder, 1),
        Triple("Add PDF", Icons.Filled.AddCircle, 2),
        Triple("Bookmarks", Icons.Filled.Bookmark, 3),
        Triple("Settings", Icons.Filled.Settings, 4)
    )

    Scaffold(
        containerColor = Bg,
        bottomBar = {
            NavigationBar(containerColor = Color.White) {
                navItems.forEach { (label, icon, idx) ->
                    NavigationBarItem(
                        selected = tab == idx,
                        onClick = { tab = idx },
                        icon = { Icon(icon, label) },
                        label = { Text(navLabel(label), fontSize = 11.sp, maxLines = 1) }
                    )
                }
            }
        },
        floatingActionButton = {
            if (tab == 0 || tab == 1) {
                FloatingActionButton(
                    onClick = { tab = 2 },
                    containerColor = Blue,
                    contentColor = Color.White,
                    shape = CircleShape
                ) { Icon(Icons.Filled.Add, "Add PDF") }
            }
        }
    ) { pad ->
        Box(Modifier.padding(pad).fillMaxSize()) {
            when (tab) {
                0 -> HomeScreen(
                    vm.books, current, vm.lastRead[current?.uri ?: ""] ?: 0L, menuItems,
                    onOpen, onAction, { tab = 2 }, { tab = 1 },
                    { (ctx as? Activity)?.finish() }
                )
                1 -> MyFilesScreen(
                    vm.books, vm.bookmarks.map { it.uri }.toSet(), menuItems, onOpen, onAction, onBookmarkToggle
                )
                2 -> AddPdfScreen(
                    onBack = { tab = 0 },
                    onPickFiles = { launchPicker() },
                    onSaved = { f, name ->
                        if (vm.addLocalPdf(f, name)) {
                            var msg = "\"$name\" added to your library"
                            if (AppPrefs(ctx).downloadPublic && saveToDownloads(ctx, f, name)) {
                                msg += "\nCopy saved in Downloads/MSF PDF Reader"
                            }
                            toast(ctx, msg)
                            tab = 1
                        }
                    },
                    onHomeShortcut = {
                        withBook { b -> scope.launch { addPdfShortcut(ctx, b.uri, b.title) } }
                    }
                )
                3 -> BookmarksScreen(
                    books = vm.books,
                    bookmarks = vm.bookmarks,
                    menuItems = menuItems,
                    defaultBook = current,
                    onBack = { tab = 0 },
                    onOpenAt = openAt,
                    onAdd = { b, page -> vm.addBookmark(b.uri, page) },
                    onColor = { m, c -> vm.setBookmarkColor(m, c) },
                    onRemove = { m -> vm.removeBookmark(m) },
                    lastPage = { b -> bookStore.getPage(b.uri) }
                )
                4 -> SettingsScreen(
                    count = vm.books.size,
                    night = vm.night.value,
                    onNight = { vm.toggleNight() },
                    onBack = { tab = 0 },
                    onClear = { dialog = Dlg.Clear }
                )
            }
        }
    }

    when (val d = dialog) {
        is Dlg.Pick -> CategoryDialog("Choose category", null, { dialog = null }) { cat ->
            var n = 0
            d.uris.forEach { if (vm.addPdf(it, cat)) n++ }
            Toast.makeText(ctx, if (n > 0) "$n book(s) added" else "Already in library", Toast.LENGTH_SHORT).show()
            if (n > 0) tab = 1
            dialog = null
        }
        is Dlg.Category -> CategoryDialog("Change category", d.b.category, { dialog = null }) { cat ->
            vm.setCategory(d.b, cat)
            dialog = null
        }
        is Dlg.Rename -> {
            var text by remember { mutableStateOf(d.b.title) }
            AlertDialog(
                onDismissRequest = { dialog = null },
                title = { Text("Rename") },
                text = { OutlinedTextField(text, { text = it }, singleLine = true) },
                confirmButton = { TextButton({ vm.rename(d.b, text); dialog = null }) { Text("Save") } },
                dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } }
            )
        }
        is Dlg.Remove -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Remove from library?") },
            text = { Text("\"${d.b.title}\" will be removed from the list. The PDF file stays on your phone.") },
            confirmButton = { TextButton({ vm.remove(d.b); dialog = null }) { Text("Remove") } },
            dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } }
        )
        Dlg.Clear -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Clear all books?") },
            text = { Text("All books will be removed from the library. Your PDF files are not deleted.") },
            confirmButton = { TextButton({ vm.clear(); dialog = null }) { Text("Clear") } },
            dismissButton = { TextButton({ dialog = null }) { Text("Cancel") } }
        )
        null -> {}
    }
}

@Composable
fun CategoryDialog(title: String, current: String?, onDismiss: () -> Unit, onSelect: (String) -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                CATEGORIES.forEach { c ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onSelect(c) }.padding(vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = c == current, onClick = { onSelect(c) })
                        Text(c)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text("Cancel") } }
    )
}

private class CatMeta(val label: String, val key: String, val icon: ImageVector, val color: Color)

private val catMetas = listOf(
    CatMeta("All Books", "All", Icons.Filled.MenuBook, Color(0xFF22A85A)),
    CatMeta("Islamic", "Islamic", Icons.Filled.Mosque, Color(0xFF1E6BF0)),
    CatMeta("Quran & Tafsir", "Quran & Tafsir", Icons.Filled.AutoStories, Color(0xFF7B3FE4)),
    CatMeta("Education", "Education", Icons.Filled.School, Color(0xFFF59E0B)),
    CatMeta("Others", "Others", Icons.Filled.Description, Color(0xFFE53935))
)

@Composable
fun HomeScreen(
    books: List<PdfBook>,
    current: PdfBook?,
    currentLastRead: Long,
    menuItems: List<MenuEntry>,
    onOpen: (PdfBook) -> Unit,
    onAction: (String, PdfBook) -> Unit,
    onAdd: () -> Unit,
    onViewAll: () -> Unit,
    onBackPress: () -> Unit
) {
    val gridState = rememberLazyGridState()
    val searchFocus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val homeScope = rememberCoroutineScope()
    val goSearch: () -> Unit = {
        homeScope.launch {
            gridState.animateScrollToItem(0)
            delay(80)
            try {
                searchFocus.requestFocus()
                keyboard?.show()
            } catch (_: Exception) {
            }
        }
    }
    var query by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("All") }
    var sort by remember { mutableIntStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }

    val filtered = books.filter {
        (cat == "All" || it.category == cat) && it.title.contains(query, ignoreCase = true)
    }
    val shown = when (sort) {
        0 -> filtered.sortedByDescending { it.addedAt }
        1 -> filtered.sortedBy { it.title.lowercase() }
        else -> filtered.sortedByDescending { it.size }
    }

    Column(Modifier.fillMaxSize()) {
        AppHeader(onBackPress, goSearch, menuItems)
        LazyVerticalGrid(
            state = gridState,
            columns = GridCells.Adaptive(100.dp),
            modifier = Modifier.weight(1f),
            contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 12.dp, bottom = 96.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            if (current != null) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    LastReadCard(current, currentLastRead) { onOpen(current) }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                OutlinedTextField(
                    value = query,
                    onValueChange = { query = it },
                    modifier = Modifier.fillMaxWidth().focusRequester(searchFocus),
                    placeholder = { Text("Search PDF files...") },
                    leadingIcon = { Icon(Icons.Filled.Search, null) },
                    trailingIcon = {
                        Box {
                            IconButton({ sortMenu = true }) { Icon(Icons.Filled.Tune, "Sort") }
                            DropdownMenu(sortMenu, { sortMenu = false }) {
                                listOf("Newest first", "Name A–Z", "Largest first").forEachIndexed { i, t ->
                                    DropdownMenuItem(
                                        text = { Text(t + if (sort == i) "  ✓" else "") },
                                        onClick = { sort = i; sortMenu = false }
                                    )
                                }
                            }
                        }
                    },
                    singleLine = true,
                    shape = RoundedCornerShape(28.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedContainerColor = Color.White,
                        unfocusedContainerColor = Color.White,
                        unfocusedBorderColor = Color(0xFFDDE3EE)
                    )
                )
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    catMetas.forEach { m ->
                        val count = if (m.key == "All") books.size else books.count { it.category == m.key }
                        CatTile(Modifier.weight(1f), m, count, cat == m.key) { cat = m.key }
                    }
                }
            }
            item(span = { GridItemSpan(maxLineSpan) }) {
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.MenuBook, null, tint = Blue, modifier = Modifier.size(28.dp))
                    Spacer(Modifier.width(10.dp))
                    Text("My Books", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.weight(1f))
                    TextButton(onViewAll) { Text("View All  ›", fontWeight = FontWeight.SemiBold) }
                }
            }
            if (shown.isEmpty()) {
                item(span = { GridItemSpan(maxLineSpan) }) {
                    Column(
                        Modifier.fillMaxWidth().padding(vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.LibraryBooks, null, tint = Color(0xFFB0B8C8), modifier = Modifier.size(64.dp))
                        Spacer(Modifier.height(8.dp))
                        Text(
                            if (books.isEmpty()) "No books yet.\nTap + to add your PDF books." else "No books found.",
                            textAlign = TextAlign.Center, color = Gray
                        )
                        if (books.isEmpty()) {
                            Spacer(Modifier.height(12.dp))
                            Button(onAdd) { Text("Add PDF") }
                        }
                    }
                }
            }
            items(shown, key = { it.uri }) { b -> BookCard(b, onOpen, onAction) }
        }
    }
}

@Composable
fun LastReadCard(b: PdfBook, lastRead: Long, onOpen: () -> Unit) {
    Card(
        Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Cover(b.uri, Modifier.size(64.dp, 82.dp).clip(RoundedCornerShape(8.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        b.title, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                        maxLines = 2, overflow = TextOverflow.Ellipsis
                    )
                    Text(metaLine(b), fontSize = 13.sp, color = Gray)
                    Text("Last read: ${fmtDate(lastRead)}", fontSize = 12.sp, color = Gray)
                }
                if (b.bookmarked) {
                    Icon(Icons.Filled.Star, null, tint = Gold, modifier = Modifier.size(22.dp))
                }
            }
            Spacer(Modifier.height(10.dp))
            Button(
                onOpen, Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE3EEFF), contentColor = Blue)
            ) {
                Icon(Icons.Filled.MenuBook, null)
                Spacer(Modifier.width(8.dp))
                Text("Open PDF", fontWeight = FontWeight.SemiBold)
            }
        }
    }
}

@Composable
private fun CatTile(modifier: Modifier, m: CatMeta, count: Int, selected: Boolean, onClick: () -> Unit) {
    Card(
        modifier.clickable(onClick = onClick),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        border = if (selected) BorderStroke(2.dp, Blue) else null,
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(
            Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 2.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box {
                Box(
                    Modifier.size(50.dp).background(m.color, RoundedCornerShape(14.dp)),
                    contentAlignment = Alignment.Center
                ) { Icon(m.icon, null, tint = Color.White, modifier = Modifier.size(28.dp)) }
                Box(
                    Modifier.align(Alignment.BottomEnd).offset(6.dp, 6.dp).size(22.dp)
                        .background(Color(0xFFEFF2F8), CircleShape),
                    contentAlignment = Alignment.Center
                ) { Text("$count", fontSize = 10.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.height(10.dp))
            Text(
                m.label, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center, minLines = 2, maxLines = 2, lineHeight = 13.sp
            )
        }
    }
}

@Composable
fun Cover(uri: String, modifier: Modifier) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri) { value = Thumbs.get(ctx, uri) }
    Box(modifier.background(Color(0xFFE8ECF3)), contentAlignment = Alignment.Center) {
        val b = bmp
        if (b != null) {
            Image(
                b.asImageBitmap(), null, Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop, alignment = Alignment.TopCenter
            )
        } else {
            Icon(Icons.Filled.PictureAsPdf, null, tint = Color(0xFFB0B8C8), modifier = Modifier.size(32.dp))
        }
    }
}

@Composable
fun BookMenu(b: PdfBook, onAction: (String, PdfBook) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Box {
        IconButton({ open = true }, Modifier.size(28.dp)) {
            Icon(Icons.Filled.MoreVert, "More", modifier = Modifier.size(18.dp))
        }
        DropdownMenu(open, { open = false }) {
            listOf(
                "open" to "Open",
                "bookmark" to (if (b.bookmarked) "Remove from Favorites" else "Add to Favorites"),
                "category" to "Change category",
                "rename" to "Rename",
                "remove" to "Remove from library"
            ).forEach { (k, t) ->
                DropdownMenuItem(text = { Text(t) }, onClick = { open = false; onAction(k, b) })
            }
        }
    }
}

@Composable
fun BookCard(b: PdfBook, onOpen: (PdfBook) -> Unit, onAction: (String, PdfBook) -> Unit) {
    Card(
        Modifier.fillMaxWidth().clickable { onOpen(b) },
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(2.dp)
    ) {
        Column(Modifier.padding(6.dp)) {
            Box {
                Cover(b.uri, Modifier.fillMaxWidth().aspectRatio(0.78f).clip(RoundedCornerShape(8.dp)))
                Text(
                    "PDF", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.align(Alignment.BottomStart).padding(4.dp)
                        .background(Color(0xFFE53935), RoundedCornerShape(4.dp))
                        .padding(horizontal = 5.dp, vertical = 1.dp)
                )
                if (b.bookmarked) {
                    Icon(
                        Icons.Filled.Bookmark, null, tint = Gold,
                        modifier = Modifier.align(Alignment.TopEnd).size(22.dp)
                    )
                }
            }
            Text(
                b.title, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                minLines = 2, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.padding(top = 6.dp)
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Description, null, tint = Gray, modifier = Modifier.size(12.dp))
                Spacer(Modifier.width(3.dp))
                Text(fmtSize(b.size), fontSize = 10.sp, color = Gray)
                Spacer(Modifier.weight(1f))
                BookMenu(b, onAction)
            }
        }
    }
}

@Composable
fun TitleBar(text: String) {
    Box(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Navy, Color(0xFF14497E))))
            .padding(horizontal = 20.dp, vertical = 18.dp)
    ) { Text(text, color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun ListScreen(
    title: String,
    books: List<PdfBook>,
    emptyMsg: String,
    onOpen: (PdfBook) -> Unit,
    onAction: (String, PdfBook) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        TitleBar("$title (${books.size})")
        if (books.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(emptyMsg, textAlign = TextAlign.Center, color = Gray)
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(books, key = { it.uri }) { b ->
                    Card(
                        Modifier.fillMaxWidth().clickable { onOpen(b) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White)
                    ) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Cover(b.uri, Modifier.size(56.dp, 72.dp).clip(RoundedCornerShape(8.dp)))
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    b.title, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                                    maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                Text("${metaLine(b)}  •  ${b.category}", fontSize = 12.sp, color = Gray)
                            }
                            if (b.bookmarked) {
                                Icon(Icons.Filled.Bookmark, null, tint = Gold, modifier = Modifier.size(20.dp))
                            }
                            BookMenu(b, onAction)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun MyFilesScreen(
    books: List<PdfBook>,
    bookmarkedUris: Set<String>,
    menuItems: List<MenuEntry>,
    onOpen: (PdfBook) -> Unit,
    onAction: (String, PdfBook) -> Unit,
    onBookmark: (PdfBook) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var searching by remember { mutableStateOf(false) }
    var sort by remember { mutableIntStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val sortNames = listOf("Name", "Date", "Size")

    val filtered = books.filter { it.title.contains(query.trim(), ignoreCase = true) }
    val shown = when (sort) {
        0 -> filtered.sortedBy { it.title.lowercase() }
        1 -> filtered.sortedByDescending { it.addedAt }
        else -> filtered.sortedByDescending { it.size }
    }

    LaunchedEffect(searching) {
        if (searching) {
            delay(80)
            try {
                focus.requestFocus()
                keyboard?.show()
            } catch (_: Exception) {
            }
        } else {
            query = ""
        }
    }

    Column(Modifier.fillMaxSize()) {
        AppHeader(null, { searching = !searching }, menuItems)

        if (searching) {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(12.dp, 10.dp, 12.dp, 0.dp).focusRequester(focus),
                placeholder = { Text("Search my files...") },
                leadingIcon = { Icon(Icons.Filled.Search, null) },
                trailingIcon = {
                    IconButton({ searching = false }) { Icon(Icons.Filled.Close, "Close search") }
                },
                singleLine = true,
                shape = RoundedCornerShape(28.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedContainerColor = Color.White,
                    unfocusedContainerColor = Color.White,
                    unfocusedBorderColor = Color(0xFFDDE3EE)
                )
            )
        }

        Row(
            Modifier.fillMaxWidth().padding(16.dp, 14.dp, 16.dp, 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(44.dp))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("My Files", fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
                Text("All your PDF files are here", fontSize = 13.sp, color = Gray)
            }
            Box {
                Row(
                    Modifier.clip(RoundedCornerShape(24.dp))
                        .background(Color.White)
                        .border(1.dp, Color(0xFFDDE3EE), RoundedCornerShape(24.dp))
                        .clickable { sortMenu = true }
                        .padding(horizontal = 12.dp, vertical = 9.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.Sort, null, tint = Navy, modifier = Modifier.size(20.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("Sort by: ${sortNames[sort]}", fontSize = 13.sp, color = Navy)
                    Icon(Icons.Filled.ArrowDropDown, null, tint = Navy)
                }
                DropdownMenu(sortMenu, { sortMenu = false }) {
                    sortNames.forEachIndexed { i, n ->
                        DropdownMenuItem(
                            text = { Text("Sort by: $n" + if (sort == i) "  ✓" else "") },
                            onClick = { sort = i; sortMenu = false }
                        )
                    }
                }
            }
        }

        if (shown.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    if (books.isEmpty()) "No books yet.\nTap + to import PDFs from your phone."
                    else "No files found.",
                    textAlign = TextAlign.Center, color = Gray
                )
            }
        } else {
            LazyColumn(
                contentPadding = PaddingValues(start = 12.dp, end = 12.dp, top = 6.dp, bottom = 96.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(shown, key = { it.uri }) { b ->
                    Card(
                        Modifier.fillMaxWidth().clickable { onOpen(b) },
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = Color.White),
                        elevation = CardDefaults.cardElevation(1.dp)
                    ) {
                        Row(Modifier.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box {
                                Cover(b.uri, Modifier.size(60.dp, 76.dp).clip(RoundedCornerShape(8.dp)))
                                Text(
                                    "PDF", color = Color.White, fontSize = 9.sp, fontWeight = FontWeight.Bold,
                                    modifier = Modifier.align(Alignment.BottomStart).padding(3.dp)
                                        .background(Red, RoundedCornerShape(4.dp))
                                        .padding(horizontal = 5.dp, vertical = 1.dp)
                                )
                            }
                            Spacer(Modifier.width(14.dp))
                            Column(Modifier.weight(1f)) {
                                Text(
                                    b.title, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                                    color = Navy, maxLines = 2, overflow = TextOverflow.Ellipsis
                                )
                                Spacer(Modifier.height(4.dp))
                                Text(
                                    "${fmtSize(b.size)}  •  ${fmtDate(b.addedAt)}",
                                    fontSize = 12.sp, color = Gray, maxLines = 1
                                )
                            }
                            BookMenu(b, onAction)
                            IconButton({ onBookmark(b) }) {
                                val on = bookmarkedUris.contains(b.uri)
                                Icon(
                                    if (on) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
                                    if (on) "Remove bookmark" else "Bookmark last read page",
                                    tint = if (on) Blue else Navy
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
