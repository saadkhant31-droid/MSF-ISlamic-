package com.msf.pdfreader

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val Blue = Color(0xFF1E6BF0)
val Navy = Color(0xFF0B2A4A)
val Gold = Color(0xFFF5C542)
val Bg = Color(0xFFF4F7FB)
val Gray = Color(0xFF6B7280)
val Green = Color(0xFF22A85A)
val Purple = Color(0xFF7B3FE4)
val Red = Color(0xFFE53935)
val Orange = Color(0xFFF59E0B)
val SkyBlue = Color(0xFF1E88E5)

class MenuEntry(val label: String, val icon: ImageVector, val color: Color, val onClick: () -> Unit)

/** Rounded popup menu with a coloured icon tile in front of every item. */
@Composable
fun AppMenu(expanded: Boolean, onDismiss: () -> Unit, items: List<MenuEntry>) {
    MaterialTheme(
        colorScheme = MaterialTheme.colorScheme,
        typography = MaterialTheme.typography,
        shapes = MaterialTheme.shapes.copy(extraSmall = RoundedCornerShape(18.dp))
    ) {
        DropdownMenu(expanded, onDismiss, modifier = Modifier.width(270.dp).background(Color.White)) {
            items.forEachIndexed { i, m ->
                DropdownMenuItem(
                    text = { Text(m.label, fontWeight = FontWeight.Medium, fontSize = 15.sp) },
                    leadingIcon = {
                        Box(
                            Modifier.size(34.dp).background(m.color, RoundedCornerShape(10.dp)),
                            contentAlignment = Alignment.Center
                        ) { Icon(m.icon, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                    },
                    onClick = { onDismiss(); m.onClick() },
                    modifier = Modifier.height(52.dp)
                )
                if (i < items.lastIndex) {
                    HorizontalDivider(Modifier.padding(horizontal = 12.dp), color = Color(0xFFE6EAF2))
                }
            }
        }
    }
}

/** Blue app header: [back] logo + "MSF PDF Reader", search icon and the three-dot menu. */
@Composable
fun AppHeader(onBack: (() -> Unit)?, onSearch: () -> Unit, menuItems: List<MenuEntry>) {
    var menu by remember { mutableStateOf(false) }
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Navy, Color(0xFF14497E))))
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
        } else {
            Spacer(Modifier.width(12.dp))
        }
        AppLogo()
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White)) { append("MSF ") }
                    withStyle(SpanStyle(color = Gold)) { append("PDF Reader") }
                },
                fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1
            )
            Text("Read  •  Learn  •  Grow", color = Color.White, fontSize = 11.sp)
        }
        IconButton(onSearch) { Icon(Icons.Filled.Search, "Search", tint = Color.White) }
        Box {
            IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menu", tint = Color.White) }
            AppMenu(menu, { menu = false }, menuItems)
        }
    }
}

@Composable
fun AppLogo(size: Dp = 52.dp) {
    Image(
        painterResource(R.drawable.msf_logo), "MSF PDF Reader",
        Modifier.size(size).clip(CircleShape)
    )
}
