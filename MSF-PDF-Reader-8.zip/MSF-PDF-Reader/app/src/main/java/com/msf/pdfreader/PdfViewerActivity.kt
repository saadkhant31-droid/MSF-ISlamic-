package com.msf.pdfreader

import android.content.Context
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.ScrollableDefaults
import androidx.compose.foundation.gestures.snapping.rememberSnapFlingBehavior
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ColorFilter
import androidx.compose.ui.graphics.ColorMatrix
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

class PdfViewerActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val uriStr = intent.getStringExtra("uri") ?: intent.data?.toString()
        val title = intent.getStringExtra("title")
            ?: uriStr?.let { queryName(this, Uri.parse(it)) }?.replace(Regex("\\.pdf$", RegexOption.IGNORE_CASE), "")
            ?: "PDF"
        val openSearch = intent.getBooleanExtra("search", false)
        val startPage = intent.getIntExtra("page", -1)
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Color(0xFF1E6BF0))) {
                ViewerScreen(uriStr, title, openSearch, startPage) { finish() }
            }
        }
    }
}

class PdfDoc(ctx: Context, uri: Uri) {
    private val pfd = ctx.contentResolver.openFileDescriptor(uri, "r")
        ?: throw IllegalStateException("Cannot open file")
    private val renderer = PdfRenderer(pfd)
    private val mutex = Mutex()
    val pageCount: Int get() = renderer.pageCount

    suspend fun render(index: Int, width: Int): Bitmap? = withContext(Dispatchers.IO) {
        mutex.withLock {
            try {
                renderer.openPage(index).use { p ->
                    val h = (width.toFloat() * p.height / p.width).toInt().coerceAtLeast(1)
                    val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
                    bmp.eraseColor(android.graphics.Color.WHITE)
                    p.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    bmp
                }
            } catch (e: Exception) {
                null
            }
        }
    }

    fun close() {
        try {
            renderer.close()
            pfd.close()
        } catch (_: Exception) {
        }
    }
}

@Composable
fun ViewerScreen(uriStr: String?, title: String, openSearch: Boolean, startPage: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val doc = remember(uriStr) {
        try {
            if (uriStr == null) null else PdfDoc(ctx, Uri.parse(uriStr))
        } catch (e: Exception) {
            null
        }
    }
    DisposableEffect(doc) { onDispose { doc?.close() } }

    if (doc == null || uriStr == null) {
        Column(
            Modifier.fillMaxSize().background(Color(0xFF0B2A4A)),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                "Could not open this PDF.\n(File moved, deleted, or password protected)",
                color = Color.White
            )
            Spacer(Modifier.height(16.dp))
            Button(onBack) { Text("Back") }
        }
    } else {
        Reader(doc, uriStr, title, openSearch, startPage, onBack)
    }
}

private val InvertFilter = ColorFilter.colorMatrix(
    ColorMatrix(
        floatArrayOf(
            -1f, 0f, 0f, 0f, 255f,
            0f, -1f, 0f, 0f, 255f,
            0f, 0f, -1f, 0f, 255f,
            0f, 0f, 0f, 1f, 0f
        )
    )
)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Reader(doc: PdfDoc, uriStr: String, title: String, openSearch: Boolean, startPage: Int, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { BookStore(ctx) }
    val prefs = remember { AppPrefs(ctx) }
    val theme = remember { prefs.theme }
    val autoFit = remember { prefs.autoFit }
    val continuous = remember { prefs.continuous }
    val scope = rememberCoroutineScope()
    val count = doc.pageCount
    val savedPage = remember { store.getPage(uriStr).coerceIn(0, (count - 1).coerceAtLeast(0)) }
    val initialPage = when {
        startPage >= 0 -> startPage.coerceIn(0, (count - 1).coerceAtLeast(0))
        prefs.openLast -> savedPage
        else -> 0
    }
    val listState = rememberLazyListState(initialFirstVisibleItemIndex = initialPage)
    var scale by remember { mutableFloatStateOf(prefs.textScale()) }
    var night by remember { mutableStateOf(store.isNight()) }
    var favorite by remember { mutableStateOf(store.isFavorite(uriStr)) }
    var pageMarks by remember { mutableStateOf(store.allBookmarks().filter { it.uri == uriStr }.sortedBy { it.page }) }
    var showJump by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(openSearch) }
    var showMarks by remember { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    val current by remember { derivedStateOf { listState.firstVisibleItemIndex } }
    val fling = if (continuous) ScrollableDefaults.flingBehavior() else rememberSnapFlingBehavior(listState)

    // text index for "Search in PDF" (built on first use, in the background)
    val texts = remember { arrayOfNulls<String>(count) }
    var extracted by remember { mutableIntStateOf(0) }
    var indexState by remember { mutableIntStateOf(0) } // 0 idle, 1 running, 2 done, 3 failed
    LaunchedEffect(showSearch) {
        if (showSearch && indexState == 0) {
            indexState = 1
            scope.launch(Dispatchers.IO) {
                val ok = try {
                    extractText(ctx, Uri.parse(uriStr), count) { i, t ->
                        texts[i] = t
                        if (i % 5 == 0) extracted = i + 1
                    }
                    true
                } catch (e: Exception) {
                    false
                }
                extracted = count
                indexState = if (ok) 2 else 3
            }
        }
    }

    LaunchedEffect(Unit) { store.setLastRead(uriStr, System.currentTimeMillis()) }
    DisposableEffect(Unit) {
        onDispose {
            store.setPage(uriStr, listState.firstVisibleItemIndex)
            store.setLastRead(uriStr, System.currentTimeMillis())
        }
    }

    val screenW = LocalConfiguration.current.screenWidthDp.dp
    val density = LocalDensity.current
    val widthPx = with(density) { (screenW * scale).roundToPx() }.coerceAtMost(2000)
    val hScroll = rememberScrollState()

    val menuItems = listOf(
        MenuEntry(if (favorite) "Remove from Favorites" else "Add to Favorites", Icons.Filled.Star, Blue) {
            favorite = store.toggleFavorite(uriStr, title, count)
            toast(ctx, if (favorite) "Added to Favorites" else "Removed from Favorites")
        },
        MenuEntry("Add to Home Screen", Icons.Filled.AddToHomeScreen, SkyBlue) {
            scope.launch { addPdfShortcut(ctx, uriStr, title) }
        },
        MenuEntry("Bookmarks", Icons.Filled.Bookmark, Blue) { showMarks = true },
        MenuEntry("Search in PDF", Icons.Filled.Search, SkyBlue) { showSearch = true },
        MenuEntry("Last Read Page", Icons.Filled.Schedule, Green) {
            scope.launch { listState.scrollToItem(savedPage) }
            toast(ctx, "Last read: page ${savedPage + 1}")
        },
        MenuEntry(
            if (night) "Day Mode" else "Night Mode",
            if (night) Icons.Filled.LightMode else Icons.Filled.DarkMode, Purple
        ) {
            night = !night
            store.setNight(night)
        },
        MenuEntry("Share PDF", Icons.Filled.Share, SkyBlue) { sharePdf(ctx, uriStr, title) },
        MenuEntry("Remove from Home Screen", Icons.Filled.Delete, Red) { removePdfShortcut(ctx, uriStr) }
    )

    Column(Modifier.fillMaxSize().background(if (night) Color(0xFF121212) else Color(0xFF3A3F4B))) {
        Row(
            Modifier.fillMaxWidth().background(Navy).padding(horizontal = 4.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
            Text(
                title, color = Color.White, fontSize = 16.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Text(
                "${if (count == 0) 0 else current + 1} / $count",
                color = Gold, fontSize = 14.sp,
                modifier = Modifier.clickable { showJump = true }.padding(8.dp)
            )
            IconButton({ showSearch = true }) { Icon(Icons.Filled.Search, "Search", tint = Color.White) }
            Box {
                IconButton({ menu = true }) { Icon(Icons.Filled.MoreVert, "Menu", tint = Color.White) }
                AppMenu(menu, { menu = false }, menuItems)
            }
        }
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Box(Modifier.fillMaxSize().horizontalScroll(hScroll)) {
                Box(
                    Modifier.width(if (scale > 1f) screenW * scale else screenW).fillMaxHeight(),
                    contentAlignment = Alignment.TopCenter
                ) {
                    LazyColumn(
                        state = listState,
                        flingBehavior = fling,
                        modifier = Modifier.width(screenW * scale).fillMaxHeight(),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        items(count) { i ->
                            val itemMod = if (autoFit) Modifier.fillParentMaxHeight(scale) else Modifier
                            PageView(doc, i, widthPx, night, theme, autoFit, itemMod)
                        }
                    }
                }
            }
            Column(
                Modifier.align(Alignment.BottomEnd).padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                SmallFloatingActionButton(
                    onClick = { scale = (scale + 0.25f).coerceAtMost(3f) },
                    containerColor = Color(0xCC0B2A4A), contentColor = Color.White
                ) { Icon(Icons.Filled.ZoomIn, "Zoom in") }
                SmallFloatingActionButton(
                    onClick = { scale = (scale - 0.25f).coerceAtLeast(0.6f) },
                    containerColor = Color(0xCC0B2A4A), contentColor = Color.White
                ) { Icon(Icons.Filled.ZoomOut, "Zoom out") }
            }
        }
    }

    if (showJump) {
        var text by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showJump = false },
            title = { Text("Go to page (1–$count)") },
            text = {
                OutlinedTextField(
                    text, { text = it.filter { c -> c.isDigit() } }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number)
                )
            },
            confirmButton = {
                TextButton({
                    val n = text.toIntOrNull()
                    if (n != null && count > 0) {
                        scope.launch { listState.scrollToItem((n - 1).coerceIn(0, count - 1)) }
                    }
                    showJump = false
                }) { Text("Go") }
            },
            dismissButton = { TextButton({ showJump = false }) { Text("Cancel") } }
        )
    }

    if (showMarks) {
        val cur = current
        val marked = pageMarks.any { it.page == cur }
        AlertDialog(
            onDismissRequest = { showMarks = false },
            title = { Text("Bookmarks") },
            text = {
                Column {
                    Button({
                        if (marked) store.removeBookmark(uriStr, cur) else store.addBookmark(uriStr, cur)
                        pageMarks = store.allBookmarks().filter { it.uri == uriStr }.sortedBy { it.page }
                    }, Modifier.fillMaxWidth()) {
                        Text(if (marked) "Remove bookmark (page ${cur + 1})" else "Bookmark page ${cur + 1}")
                    }
                    Spacer(Modifier.height(8.dp))
                    if (pageMarks.isEmpty()) {
                        Text("No page bookmarks yet.", color = Gray)
                    } else {
                        LazyColumn(Modifier.heightIn(max = 260.dp)) {
                            items(pageMarks) { m ->
                                Row(
                                    Modifier.fillMaxWidth()
                                        .clickable {
                                            scope.launch { listState.scrollToItem(m.page.coerceIn(0, (count - 1).coerceAtLeast(0))) }
                                            showMarks = false
                                        }
                                        .padding(vertical = 4.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(Icons.Filled.Bookmark, null, tint = BM_COLORS[m.color % BM_COLORS.size])
                                    Spacer(Modifier.width(8.dp))
                                    Text("Page ${m.page + 1}", Modifier.weight(1f))
                                    IconButton({
                                        store.removeBookmark(uriStr, m.page)
                                        pageMarks = store.allBookmarks().filter { it.uri == uriStr }.sortedBy { it.page }
                                    }) { Icon(Icons.Filled.Close, "Delete bookmark") }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton({ showMarks = false }) { Text("Close") } }
        )
    }

    if (showSearch) {
        SearchDialog(count, texts, extracted, indexState, onGo = { page ->
            scope.launch { listState.scrollToItem(page.coerceIn(0, (count - 1).coerceAtLeast(0))) }
            showSearch = false
        }, onClose = { showSearch = false })
    }
}

@Composable
fun SearchDialog(
    count: Int,
    texts: Array<String?>,
    extracted: Int,
    state: Int,
    onGo: (Int) -> Unit,
    onClose: () -> Unit
) {
    var q by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    val hits = remember(q, extracted) { findHits(texts, extracted, q) }
    val hasText = remember(state) { state == 2 && texts.any { !it.isNullOrBlank() } }
    LaunchedEffect(Unit) {
        try {
            focus.requestFocus()
        } catch (_: Exception) {
        }
    }
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column(Modifier.fillMaxSize()) {
                Row(
                    Modifier.fillMaxWidth().background(Navy).padding(horizontal = 4.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClose) { Icon(Icons.Filled.ArrowBack, "Close", tint = Color.White) }
                    OutlinedTextField(
                        q, { q = it },
                        modifier = Modifier.weight(1f).focusRequester(focus),
                        placeholder = { Text("Search in PDF...") },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedContainerColor = Color.White,
                            unfocusedContainerColor = Color.White
                        )
                    )
                    Spacer(Modifier.width(8.dp))
                }
                if (state == 1) {
                    LinearProgressIndicator(
                        progress = { if (count == 0) 0f else extracted.toFloat() / count },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Text(
                        "Reading pages… $extracted / $count",
                        color = Gray, fontSize = 12.sp, modifier = Modifier.padding(12.dp, 6.dp)
                    )
                }
                val msg = when {
                    state == 3 -> "Could not read text from this PDF (password protected or unsupported)."
                    state == 2 && !hasText -> "This PDF has no searchable text (it may be scanned images)."
                    q.trim().length < 2 -> "Type at least 2 letters."
                    hits.isEmpty() && state == 2 -> "No results found."
                    else -> null
                }
                if (msg != null) {
                    Text(msg, color = Gray, modifier = Modifier.padding(16.dp))
                }
                LazyColumn(Modifier.fillMaxSize()) {
                    items(hits) { h ->
                        Column(Modifier.fillMaxWidth().clickable { onGo(h.page) }.padding(16.dp, 10.dp)) {
                            Text(
                                "Page ${h.page + 1}  •  ${h.count} match${if (h.count > 1) "es" else ""}",
                                color = Blue, fontWeight = FontWeight.SemiBold, fontSize = 14.sp
                            )
                            Text(h.snippet, fontSize = 13.sp, color = Color(0xFF374151), maxLines = 2, overflow = TextOverflow.Ellipsis)
                        }
                        HorizontalDivider(color = Color(0xFFE6EAF2))
                    }
                }
            }
        }
    }
}

private val SepiaFilter = ColorFilter.tint(Color(0xFFF1E4C3), BlendMode.Multiply)
private val GrayFilter = ColorFilter.colorMatrix(ColorMatrix().apply { setToSaturation(0f) })

@Composable
fun PageView(
    doc: PdfDoc,
    index: Int,
    widthPx: Int,
    night: Boolean,
    theme: Int = 0,
    fit: Boolean = false,
    itemMod: Modifier = Modifier
) {
    val bmp by produceState<Bitmap?>(null, index, widthPx) { value = doc.render(index, widthPx) }
    val b = bmp
    val filter = when {
        night -> InvertFilter
        theme == 1 -> SepiaFilter
        theme == 2 -> GrayFilter
        else -> null
    }
    if (b != null) {
        if (fit) {
            Box(itemMod.fillMaxWidth(), contentAlignment = Alignment.Center) {
                Image(
                    b.asImageBitmap(), null, Modifier.fillMaxSize(),
                    contentScale = ContentScale.Fit, colorFilter = filter
                )
            }
        } else {
            Image(
                b.asImageBitmap(), null, Modifier.fillMaxWidth(),
                contentScale = ContentScale.FillWidth, colorFilter = filter
            )
        }
    } else {
        Box(
            (if (fit) itemMod.fillMaxWidth() else Modifier.fillMaxWidth().aspectRatio(0.707f))
                .background(if (night) Color(0xFF1E1E1E) else Color.White),
            contentAlignment = Alignment.Center
        ) { CircularProgressIndicator() }
    }
}
