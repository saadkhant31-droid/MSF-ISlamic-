package com.msf.pdfreader

import android.content.Context
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.io.MemoryUsageSetting
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

class Hit(val page: Int, val snippet: String, val count: Int)

/** Extracts text page by page (runs on a background thread). */
suspend fun extractText(ctx: Context, uri: Uri, pages: Int, onPage: (Int, String) -> Unit) {
    PDFBoxResourceLoader.init(ctx.applicationContext)
    val input = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Cannot open")
    input.use { ins ->
        PDDocument.load(ins, MemoryUsageSetting.setupTempFileOnly()).use { doc ->
            val stripper = PDFTextStripper()
            val n = minOf(pages, doc.numberOfPages)
            for (p in 1..n) {
                currentCoroutineContext().ensureActive()
                stripper.startPage = p
                stripper.endPage = p
                val t = try {
                    stripper.getText(doc)
                } catch (e: Exception) {
                    ""
                }
                onPage(p - 1, t)
            }
        }
    }
}

fun findHits(texts: Array<String?>, upTo: Int, q: String): List<Hit> {
    val out = ArrayList<Hit>()
    if (q.trim().length < 2) return out
    val query = q.trim()
    for (i in 0 until minOf(upTo, texts.size)) {
        val t = texts[i] ?: continue
        val idx = t.indexOf(query, ignoreCase = true)
        if (idx < 0) continue
        var c = 0
        var from = idx
        while (from >= 0 && c < 99) {
            c++
            from = t.indexOf(query, from + query.length, ignoreCase = true)
        }
        val s = maxOf(0, idx - 30)
        val e = minOf(t.length, idx + query.length + 60)
        out.add(Hit(i, t.substring(s, e).replace(Regex("\\s+"), " ").trim(), c))
        if (out.size >= 300) break
    }
    return out
}
