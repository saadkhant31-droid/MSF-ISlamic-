package com.msf.pdfreader

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** E-mail used by "Help & Support". Change it to your real support address. */
const val SUPPORT_EMAIL = "support@msf.app"

// ---------------------------------------------------------------- saved settings

class AppPrefs(ctx: Context) {
    private val p = ctx.getSharedPreferences("msf_settings", Context.MODE_PRIVATE)

    /** 0 = Light, 1 = Sepia, 2 = Gray */
    var theme: Int
        get() = p.getInt("theme", 0)
        set(v) { p.edit().putInt("theme", v).apply() }

    /** 0 = Small, 1 = Medium, 2 = Large, 3 = Extra Large */
    var textSize: Int
        get() = p.getInt("text", 1)
        set(v) { p.edit().putInt("text", v).apply() }

    var autoFit: Boolean
        get() = p.getBoolean("autofit", false)
        set(v) { p.edit().putBoolean("autofit", v).apply() }

    var continuous: Boolean
        get() = p.getBoolean("continuous", true)
        set(v) { p.edit().putBoolean("continuous", v).apply() }

    var openLast: Boolean
        get() = p.getBoolean("openlast", true)
        set(v) { p.edit().putBoolean("openlast", v).apply() }

    var notifications: Boolean
        get() = p.getBoolean("notif", true)
        set(v) { p.edit().putBoolean("notif", v).apply() }

    var downloadPublic: Boolean
        get() = p.getBoolean("dlpublic", false)
        set(v) { p.edit().putBoolean("dlpublic", v).apply() }

    var lang: String
        get() = p.getString("lang", "en") ?: "en"
        set(v) { p.edit().putString("lang", v).apply() }

    fun textScale(): Float = floatArrayOf(0.8f, 1f, 1.25f, 1.5f)[textSize.coerceIn(0, 3)]
}

object AppLang {
    var urdu by mutableStateOf(false)

    fun init(ctx: Context) {
        urdu = AppPrefs(ctx).lang == "ur"
    }

    fun set(ctx: Context, ur: Boolean) {
        AppPrefs(ctx).lang = if (ur) "ur" else "en"
        urdu = ur
    }
}

/** English / Urdu text picker. */
fun t2(en: String, ur: String): String = if (AppLang.urdu) ur else en

fun navLabel(en: String): String = when (en) {
    "Home" -> t2(en, "ہوم")
    "My Files" -> t2(en, "میری فائلیں")
    "Add PDF" -> t2(en, "پی ڈی ایف")
    "Bookmarks" -> t2(en, "بک مارکس")
    "Settings" -> t2(en, "سیٹنگز")
    else -> en
}

// ---------------------------------------------------------------- helpers

fun dirSize(f: File): Long =
    if (f.isFile) f.length() else (f.listFiles()?.sumOf { dirSize(it) } ?: 0L)

fun fmtCache(b: Long): String = if (b < 1024) "0 KB" else fmtSize(b)

fun clearCacheFiles(ctx: Context) {
    ctx.cacheDir.listFiles()?.forEach { it.deleteRecursively() }
    Thumbs.clear()
}

/** Copies a PDF into the phone's public Downloads folder (Android 10+). */
fun saveToDownloads(ctx: Context, file: File, name: String): Boolean {
    if (Build.VERSION.SDK_INT < 29) return false
    return try {
        val fn = if (name.endsWith(".pdf", ignoreCase = true)) name else "$name.pdf"
        val v = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, fn)
            put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS + "/MSF PDF Reader")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v) ?: return false
        ctx.contentResolver.openOutputStream(uri)?.use { out ->
            file.inputStream().use { it.copyTo(out) }
        }
        true
    } catch (e: Exception) {
        false
    }
}

@SuppressLint("MissingPermission")
fun showTestNotification(ctx: Context) {
    try {
        if (!NotificationManagerCompat.from(ctx).areNotificationsEnabled()) return
        if (Build.VERSION.SDK_INT >= 26) {
            val ch = NotificationChannel("general", "General", NotificationManager.IMPORTANCE_DEFAULT)
            ctx.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
        }
        val pi = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, "general")
            .setSmallIcon(R.drawable.ic_launcher)
            .setContentTitle("MSF PDF Reader")
            .setContentText(t2("Notifications are on. You will hear about new features here.",
                "نوٹیفکیشنز آن ہیں۔ نئے فیچرز کی اطلاع یہاں ملے گی۔"))
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        NotificationManagerCompat.from(ctx).notify(1001, n)
    } catch (_: Exception) {
    }
}

fun rateApp(ctx: Context) {
    try {
        ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=${ctx.packageName}")))
    } catch (e: Exception) {
        try {
            ctx.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=${ctx.packageName}"))
            )
        } catch (e2: Exception) {
            toast(ctx, t2("Could not open the store", "اسٹور نہیں کھل سکا"))
        }
    }
}

fun emailSupport(ctx: Context) {
    try {
        ctx.startActivity(
            Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:$SUPPORT_EMAIL"))
                .putExtra(Intent.EXTRA_SUBJECT, "MSF PDF Reader support")
        )
    } catch (e: Exception) {
        toast(ctx, t2("No e-mail app found. Write to $SUPPORT_EMAIL", "ای میل ایپ نہیں ملی۔ $SUPPORT_EMAIL پر لکھیں"))
    }
}

// ---------------------------------------------------------------- UI pieces

@Composable
private fun SettingsHeader(onBack: () -> Unit) {
    Row(
        Modifier.fillMaxWidth()
            .background(Brush.horizontalGradient(listOf(Color(0xFF0A45B0), Color(0xFF0D5AD0))))
            .padding(horizontal = 4.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        IconButton(onBack) { Icon(Icons.Filled.ArrowBack, "Back", tint = Color.White) }
        AppLogo()
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(
                buildAnnotatedString {
                    withStyle(SpanStyle(color = Color.White)) { append("MSF ") }
                    withStyle(SpanStyle(color = Gold)) { append("PDF Reader") }
                },
                fontSize = 19.sp, fontWeight = FontWeight.ExtraBold, maxLines = 1
            )
            Text("Read  •  Learn  •  Grow", color = Color.White, fontSize = 12.sp, maxLines = 1)
        }
        Column(horizontalAlignment = Alignment.End, modifier = Modifier.padding(end = 10.dp)) {
            Icon(Icons.Filled.MenuBook, null, tint = Color(0xFFBFD6FF), modifier = Modifier.size(22.dp))
            Text("علم روشنی ہے", color = Color.White, fontSize = 12.sp, maxLines = 1, softWrap = false)
            Text("اور کتابیں اس کی سبیلیں", color = Color.White, fontSize = 12.sp, maxLines = 1, softWrap = false)
            Box(Modifier.width(96.dp).height(1.dp).background(Gold))
        }
    }
}

@Composable
private fun SecCard(icon: ImageVector, title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(
        Modifier.fillMaxWidth()
            .shadow(1.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(Color.White)
    ) {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFFE9F1FD)).padding(14.dp, 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(icon, null, tint = Blue, modifier = Modifier.size(26.dp))
            Spacer(Modifier.width(10.dp))
            Text(title, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, color = Navy)
        }
        content()
    }
}

@Composable
private fun SetRow(
    icon: ImageVector,
    tint: Color,
    title: String,
    sub: String,
    value: String? = null,
    switch: Boolean? = null,
    onSwitch: ((Boolean) -> Unit)? = null,
    onClick: (() -> Unit)? = null,
    last: Boolean = false
) {
    val urdu = AppLang.urdu
    Column {
        Row(
            Modifier.fillMaxWidth()
                .clickable { if (switch != null) onSwitch?.invoke(!switch) else onClick?.invoke() }
                .padding(horizontal = 14.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                Modifier.size(44.dp).background(tint, RoundedCornerShape(12.dp)),
                contentAlignment = Alignment.Center
            ) { Icon(icon, null, tint = Color.White, modifier = Modifier.size(26.dp)) }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Medium, color = Navy)
                Text(sub, fontSize = 13.sp, color = Gray, lineHeight = 16.sp)
            }
            if (value != null) {
                Spacer(Modifier.width(6.dp))
                Text(value, fontSize = 13.sp, color = Color(0xFF4B5563), maxLines = 1, overflow = TextOverflow.Ellipsis)
                Spacer(Modifier.width(6.dp))
            }
            if (switch != null) {
                Switch(
                    checked = switch, onCheckedChange = { onSwitch?.invoke(it) },
                    colors = SwitchDefaults.colors(
                        checkedTrackColor = Blue, checkedThumbColor = Color.White,
                        uncheckedTrackColor = Color(0xFFD9DEE8), uncheckedThumbColor = Color.White,
                        uncheckedBorderColor = Color.Transparent
                    )
                )
            } else {
                Icon(
                    Icons.Filled.ChevronRight, null, tint = Color(0xFF4B5563),
                    modifier = Modifier.size(26.dp).graphicsLayer(scaleX = if (urdu) -1f else 1f)
                )
            }
        }
        if (!last) HorizontalDivider(Modifier.padding(start = 72.dp, end = 14.dp), color = Color(0xFFE6EAF2))
    }
}

@Composable
private fun ChoiceDialog(
    title: String,
    options: List<String>,
    selected: Int,
    onPick: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = {
            Column {
                options.forEachIndexed { i, o ->
                    Row(
                        Modifier.fillMaxWidth().clickable { onPick(i) }.padding(vertical = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        RadioButton(selected = i == selected, onClick = { onPick(i) })
                        Text(o, fontSize = 16.sp)
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onDismiss) { Text(t2("Cancel", "منسوخ")) } }
    )
}

@Composable
private fun InfoDialog(
    title: String,
    body: String,
    onDismiss: () -> Unit,
    actionLabel: String? = null,
    onAction: (() -> Unit)? = null
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { Text(body, fontSize = 14.sp, lineHeight = 21.sp, modifier = Modifier.verticalScroll(rememberScrollState())) },
        confirmButton = { TextButton(onDismiss) { Text(t2("Close", "بند کریں")) } },
        dismissButton = {
            if (actionLabel != null && onAction != null) {
                TextButton({ onDismiss(); onAction() }) { Text(actionLabel) }
            }
        }
    )
}

// ---------------------------------------------------------------- Settings screen

@Composable
fun SettingsScreen(
    count: Int,
    night: Boolean,
    onNight: () -> Unit,
    onBack: () -> Unit,
    onClear: () -> Unit
) {
    val ctx = LocalContext.current
    val prefs = remember { AppPrefs(ctx) }
    val urdu = AppLang.urdu

    var theme by remember { mutableIntStateOf(prefs.theme) }
    var textSize by remember { mutableIntStateOf(prefs.textSize) }
    var autoFit by remember { mutableStateOf(prefs.autoFit) }
    var continuous by remember { mutableStateOf(prefs.continuous) }
    var openLast by remember { mutableStateOf(prefs.openLast) }
    var notif by remember { mutableStateOf(prefs.notifications) }
    var dlPublic by remember { mutableStateOf(prefs.downloadPublic) }
    var cache by remember { mutableLongStateOf(0L) }
    var dlg by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(dlg) { cache = withContext(Dispatchers.IO) { dirSize(ctx.cacheDir) } }

    val version = remember {
        try {
            ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0"
        } catch (e: Exception) {
            "1.0.0"
        }
    }

    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) {
            notif = true; prefs.notifications = true
            showTestNotification(ctx)
            toast(ctx, t2("Notifications on", "نوٹیفکیشنز آن ہو گئے"))
        } else {
            notif = false; prefs.notifications = false
            toast(ctx, t2("Notification permission was denied", "نوٹیفکیشن کی اجازت نہیں ملی"))
        }
    }

    fun setNotif(on: Boolean) {
        if (!on) {
            notif = false; prefs.notifications = false
            toast(ctx, t2("Notifications off", "نوٹیفکیشنز بند ہو گئے"))
            return
        }
        val needAsk = Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(ctx, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (needAsk) {
            permLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            notif = true; prefs.notifications = true
            showTestNotification(ctx)
            toast(ctx, t2("Notifications on", "نوٹیفکیشنز آن ہو گئے"))
        }
    }

    val themeNames = listOf(t2("Light", "روشن"), t2("Sepia", "سیپیا"), t2("Gray", "سرمئی"))
    val sizeNames = listOf(
        t2("Small", "چھوٹا"), t2("Medium", "درمیانہ"), t2("Large", "بڑا"), t2("Extra Large", "بہت بڑا")
    )
    val dlNames = listOf(t2("Internal Storage", "اندرونی اسٹوریج"), t2("Downloads Folder", "ڈاؤن لوڈز فولڈر"))

    Column(Modifier.fillMaxSize()) {
        SettingsHeader(onBack)
        CompositionLocalProvider(
            LocalLayoutDirection provides if (urdu) LayoutDirection.Rtl else LayoutDirection.Ltr
        ) {
            Column(Modifier.weight(1f).fillMaxWidth()) {
                Column(
                    Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(12.dp, 12.dp, 12.dp, 4.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    // App information
                    Row(
                        Modifier.fillMaxWidth()
                            .shadow(1.dp, RoundedCornerShape(14.dp))
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .clickable { dlg = "app" }
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        AppLogo(60.dp)
                        Spacer(Modifier.width(12.dp))
                        Box(Modifier.width(1.dp).height(52.dp).background(Color(0xFFE6EAF2)))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(t2("App Information", "ایپ کی معلومات"), fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Navy)
                            Text("MSF PDF Reader v$version", fontSize = 14.sp, color = Color(0xFF4B5563))
                            Text(t2("Developed by MSF", "ایم ایس ایف کی طرف سے تیار کردہ"), fontSize = 14.sp, color = Color(0xFF4B5563))
                        }
                        Icon(
                            Icons.Filled.ChevronRight, null, tint = Color(0xFF4B5563),
                            modifier = Modifier.size(26.dp).graphicsLayer(scaleX = if (urdu) -1f else 1f)
                        )
                    }

                    SecCard(Icons.Filled.MenuBook, t2("Reading Settings", "مطالعہ کی ترتیبات")) {
                        SetRow(
                            Icons.Filled.Palette, Color(0xFF8E3FE4),
                            t2("Default Reader Theme", "ریڈر کی ڈیفالٹ تھیم"),
                            t2("Choose your favorite reading theme", "اپنی پسندیدہ تھیم منتخب کریں"),
                            value = themeNames[theme], onClick = { dlg = "theme" }
                        )
                        SetRow(
                            Icons.Filled.TextFields, Color(0xFF16A34A),
                            t2("Text Size", "متن کا سائز"),
                            t2("Adjust text size for better reading", "بہتر مطالعے کے لیے سائز ایڈجسٹ کریں"),
                            value = sizeNames[textSize], onClick = { dlg = "text" }
                        )
                        SetRow(
                            Icons.Filled.DarkMode, Color(0xFF0B2A4A),
                            t2("Night Mode", "نائٹ موڈ"),
                            t2("Reduce eye strain in low light", "کم روشنی میں آنکھوں پر زور کم کریں"),
                            switch = night, onSwitch = { onNight() }
                        )
                        SetRow(
                            Icons.Filled.OpenInFull, Color(0xFFF43F5E),
                            t2("Auto Page Fit", "آٹو پیج فٹ"),
                            t2("Fit PDF page to screen", "پی ڈی ایف صفحہ اسکرین کے مطابق کریں"),
                            switch = autoFit, onSwitch = { autoFit = it; prefs.autoFit = it }
                        )
                        SetRow(
                            Icons.Filled.CropPortrait, Color(0xFFFF9800),
                            t2("Continuous Scroll", "مسلسل اسکرول"),
                            t2("Scroll instead of page by page", "صفحہ بہ صفحہ کے بجائے اسکرول کریں"),
                            switch = continuous, onSwitch = { continuous = it; prefs.continuous = it }
                        )
                        SetRow(
                            Icons.Filled.Schedule, Color(0xFF0EA5A5),
                            t2("Open Last Read Page", "آخری پڑھا گیا صفحہ کھولیں"),
                            t2("Resume from where you left", "جہاں چھوڑا تھا وہیں سے جاری رکھیں"),
                            switch = openLast, onSwitch = { openLast = it; prefs.openLast = it },
                            last = true
                        )
                    }

                    SecCard(Icons.Filled.Settings, t2("General Settings", "عمومی ترتیبات")) {
                        SetRow(
                            Icons.Filled.Language, Color(0xFF1E6BF0),
                            t2("Language", "زبان"),
                            t2("Choose your app language", "ایپ کی زبان منتخب کریں"),
                            value = if (urdu) "اردو" else "English", onClick = { dlg = "lang" }
                        )
                        SetRow(
                            Icons.Filled.Download, Color(0xFF7B3FE4),
                            t2("Download Location", "ڈاؤن لوڈ کی جگہ"),
                            t2("Where to save downloaded files", "ڈاؤن لوڈ فائلیں کہاں محفوظ ہوں"),
                            value = dlNames[if (dlPublic) 1 else 0], onClick = { dlg = "dl" }
                        )
                        SetRow(
                            Icons.Filled.Delete, Color(0xFFF43F5E),
                            t2("Clear Cache", "کیش صاف کریں"),
                            t2("Free up storage space", "اسٹوریج خالی کریں"),
                            value = fmtCache(cache), onClick = { dlg = "cache" }
                        )
                        SetRow(
                            Icons.Filled.Notifications, Color(0xFF16A34A),
                            t2("Notifications", "نوٹیفکیشنز"),
                            t2("Get notified about new features", "نئے فیچرز کی اطلاع حاصل کریں"),
                            switch = notif, onSwitch = { setNotif(it) }
                        )
                        SetRow(
                            Icons.Filled.DeleteSweep, Color(0xFFE53935),
                            t2("Clear Library", "لائبریری صاف کریں"),
                            t2("Remove all books from the app ($count)", "ایپ سے تمام کتابیں ہٹائیں ($count)"),
                            onClick = { onClear() }, last = true
                        )
                    }

                    SecCard(Icons.Filled.Info, t2("Support & More", "سپورٹ اور مزید")) {
                        SetRow(
                            Icons.Filled.Help, Color(0xFF1E6BF0),
                            t2("Help & Support", "مدد اور سپورٹ"),
                            t2("Get help or contact us", "مدد لیں یا ہم سے رابطہ کریں"),
                            onClick = { dlg = "help" }
                        )
                        SetRow(
                            Icons.Filled.Star, Color(0xFFFFA000),
                            t2("Rate Us", "ہمیں ریٹ کریں"),
                            t2("If you like our app, please rate us", "اگر ایپ پسند آئے تو ہمیں ریٹ کریں"),
                            onClick = { rateApp(ctx) }
                        )
                        SetRow(
                            Icons.Filled.Shield, Color(0xFF7B3FE4),
                            t2("Privacy Policy", "پرائیویسی پالیسی"),
                            t2("Learn how we protect your data", "جانیں ہم آپ کا ڈیٹا کیسے محفوظ رکھتے ہیں"),
                            onClick = { dlg = "privacy" }
                        )
                        SetRow(
                            Icons.Filled.Groups, Color(0xFF0B2A4A),
                            t2("About Us", "ہمارے بارے میں"),
                            t2("More about MSF PDF Reader", "ایم ایس ایف پی ڈی ایف ریڈر کے بارے میں مزید"),
                            onClick = { dlg = "about" }, last = true
                        )
                    }
                    Spacer(Modifier.height(2.dp))
                }

                // Exit button (always visible above the bottom bar)
                Row(
                    Modifier.fillMaxWidth().padding(12.dp, 6.dp, 12.dp, 8.dp).height(46.dp)
                        .clip(RoundedCornerShape(10.dp))
                        .background(Color(0xFFF42B4F))
                        .clickable { (ctx as? Activity)?.finishAffinity() },
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Filled.ExitToApp, null, tint = Color.White, modifier = Modifier.size(22.dp))
                    Spacer(Modifier.width(8.dp))
                    Text(t2("Exit App", "ایپ بند کریں"), color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Medium)
                }
            }
        }
    }

    // ------------------------------------------------------------ dialogs
    val close = { dlg = null }
    CompositionLocalProvider(
        LocalLayoutDirection provides if (urdu) LayoutDirection.Rtl else LayoutDirection.Ltr
    ) {
        when (dlg) {
            "theme" -> ChoiceDialog(t2("Default Reader Theme", "ریڈر کی ڈیفالٹ تھیم"), themeNames, theme, {
                theme = it; prefs.theme = it; dlg = null
            }, close)
            "text" -> ChoiceDialog(t2("Text Size", "متن کا سائز"), sizeNames, textSize, {
                textSize = it; prefs.textSize = it; dlg = null
            }, close)
            "lang" -> ChoiceDialog(t2("Language", "زبان"), listOf("English", "اردو"), if (urdu) 1 else 0, {
                AppLang.set(ctx, it == 1); dlg = null
            }, close)
            "dl" -> ChoiceDialog(t2("Download Location", "ڈاؤن لوڈ کی جگہ"), dlNames, if (dlPublic) 1 else 0, {
                if (it == 1 && Build.VERSION.SDK_INT < 29) {
                    toast(ctx, t2("Downloads folder needs Android 10 or newer", "ڈاؤن لوڈز فولڈر کے لیے اینڈرائیڈ 10 یا نیا ورژن چاہیے"))
                } else {
                    dlPublic = it == 1; prefs.downloadPublic = it == 1
                    toast(ctx, if (it == 1) t2("New downloads are also copied to Downloads/MSF PDF Reader",
                        "نئی ڈاؤن لوڈز Downloads/MSF PDF Reader میں بھی کاپی ہوں گی")
                    else t2("Downloads stay inside the app", "ڈاؤن لوڈز ایپ کے اندر رہیں گی"))
                }
                dlg = null
            }, close)
            "cache" -> AlertDialog(
                onDismissRequest = close,
                title = { Text(t2("Clear Cache", "کیش صاف کریں")) },
                text = {
                    Text(
                        t2("Free ${fmtCache(cache)} of temporary files? Your books and bookmarks are not deleted.",
                            "${fmtCache(cache)} عارضی فائلیں ہٹائیں؟ آپ کی کتابیں اور بک مارکس محفوظ رہیں گے۔")
                    )
                },
                confirmButton = {
                    TextButton({
                        clearCacheFiles(ctx)
                        cache = 0L
                        dlg = null
                        toast(ctx, t2("Cache cleared", "کیش صاف ہو گیا"))
                    }) { Text(t2("Clear", "صاف کریں")) }
                },
                dismissButton = { TextButton(close) { Text(t2("Cancel", "منسوخ")) } }
            )
            "app" -> InfoDialog(
                t2("App Information", "ایپ کی معلومات"),
                "MSF PDF Reader\n" + t2("Version", "ورژن") + " $version\n" +
                    t2("Books in library: ", "لائبریری میں کتابیں: ") + "$count\n" +
                    t2("Developed by MSF", "ایم ایس ایف کی طرف سے تیار کردہ"),
                close
            )
            "help" -> InfoDialog(
                t2("Help & Support", "مدد اور سپورٹ"),
                t2(
                    "• Tap Add PDF to import books from your phone, scan pages or download a PDF link.\n" +
                        "• Open a book and tap ⋮ for Favorites, Bookmarks, Search, Night Mode and Share.\n" +
                        "• Bookmarks keeps your saved pages. Tap one to jump straight to it.\n" +
                        "• Still stuck? Email us and we will help.",
                    "• فون سے کتابیں شامل کرنے، صفحات اسکین کرنے یا پی ڈی ایف لنک ڈاؤن لوڈ کرنے کے لیے Add PDF دبائیں۔\n" +
                        "• کتاب کھول کر ⋮ دبائیں: فیورٹس، بک مارکس، سرچ، نائٹ موڈ اور شیئر وہیں ملیں گے۔\n" +
                        "• بک مارکس میں آپ کے محفوظ صفحات ہوتے ہیں۔ کسی پر ٹیپ کریں تو سیدھا اسی صفحے پر پہنچ جائیں گے۔\n" +
                        "• مسئلہ حل نہ ہو تو ہمیں ای میل کریں۔"
                ),
                close, t2("Email us", "ای میل کریں")
            ) { emailSupport(ctx) }
            "privacy" -> InfoDialog(
                t2("Privacy Policy", "پرائیویسی پالیسی"),
                t2(
                    "MSF PDF Reader keeps your library, bookmarks and settings only on your phone.\n\n" +
                        "The app has no accounts and does not collect or sell personal data. " +
                        "The internet is used only when you choose to download a PDF from a link. " +
                        "Your PDF files are never uploaded.\n\n" +
                        "You can remove your data at any time with Clear Library and Clear Cache, or by uninstalling the app.",
                    "ایم ایس ایف پی ڈی ایف ریڈر آپ کی لائبریری، بک مارکس اور سیٹنگز صرف آپ کے فون میں رکھتا ہے۔\n\n" +
                        "ایپ میں کوئی اکاؤنٹ نہیں ہے اور یہ ذاتی ڈیٹا جمع یا فروخت نہیں کرتی۔ " +
                        "انٹرنیٹ صرف اسی وقت استعمال ہوتا ہے جب آپ کسی لنک سے پی ڈی ایف ڈاؤن لوڈ کریں۔ " +
                        "آپ کی پی ڈی ایف فائلیں کہیں اپ لوڈ نہیں ہوتیں۔\n\n" +
                        "آپ کسی بھی وقت لائبریری صاف کریں اور کیش صاف کریں سے یا ایپ ان انسٹال کر کے اپنا ڈیٹا ہٹا سکتے ہیں۔"
                ),
                close
            )
            "about" -> InfoDialog(
                t2("About Us", "ہمارے بارے میں"),
                t2(
                    "MSF PDF Reader\nRead • Learn • Grow\n\n" +
                        "A simple PDF library to read, bookmark and organise your books.\n\nVersion $version\nDeveloped by MSF",
                    "ایم ایس ایف پی ڈی ایف ریڈر\nپڑھیں • سیکھیں • آگے بڑھیں\n\n" +
                        "اپنی کتابیں پڑھنے، بک مارک کرنے اور ترتیب دینے کے لیے ایک سادہ پی ڈی ایف لائبریری۔\n\nورژن $version\nایم ایس ایف کی طرف سے تیار کردہ"
                ),
                close
            )
        }
    }
}
