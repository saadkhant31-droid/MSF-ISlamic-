package com.msf.pdfreader

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs

fun toast(ctx: Context, msg: String) = Toast.makeText(ctx, msg, Toast.LENGTH_SHORT).show()

fun fmtDate(t: Long): String =
    if (t <= 0) "Not opened yet"
    else SimpleDateFormat("yyyy-MM-dd  hh:mm a", Locale.US).format(Date(t))

fun queryName(ctx: Context, uri: Uri): String? = try {
    ctx.contentResolver.query(uri, null, null, null, null)?.use { c ->
        if (c.moveToFirst()) {
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (i >= 0) c.getString(i) else null
        } else null
    }
} catch (e: Exception) {
    null
}

/** Pins a shortcut of this PDF on the phone's home screen. */
suspend fun addPdfShortcut(ctx: Context, uri: String, title: String) {
    val store = BookStore(ctx)
    if (store.getShortcut(uri) != null) {
        toast(ctx, "Already added to Home Screen")
        return
    }
    if (!ShortcutManagerCompat.isRequestPinShortcutSupported(ctx)) {
        toast(ctx, "Your launcher does not support Home Screen shortcuts")
        return
    }
    val thumb = Thumbs.get(ctx, uri)
    val icon = if (thumb != null) {
        IconCompat.createWithBitmap(
            Bitmap.createBitmap(thumb, 0, 0, thumb.width, minOf(thumb.height, thumb.width))
        )
    } else {
        IconCompat.createWithResource(ctx, R.mipmap.ic_launcher)
    }
    val id = "pdf_${abs(uri.hashCode())}_${System.currentTimeMillis()}"
    val intent = Intent(ctx, PdfViewerActivity::class.java)
        .setAction(Intent.ACTION_VIEW)
        .putExtra("uri", uri)
        .putExtra("title", title)
    val info = ShortcutInfoCompat.Builder(ctx, id)
        .setShortLabel(title.take(25))
        .setLongLabel(title)
        .setIcon(icon)
        .setIntent(intent)
        .build()
    if (ShortcutManagerCompat.requestPinShortcut(ctx, info, null)) {
        store.setShortcut(uri, id)
        toast(ctx, "Confirm to add the shortcut to Home Screen")
    } else {
        toast(ctx, "Could not add shortcut")
    }
}

fun removePdfShortcut(ctx: Context, uri: String) {
    val store = BookStore(ctx)
    val id = store.getShortcut(uri)
    if (id == null) {
        toast(ctx, "This PDF is not on your Home Screen")
        return
    }
    try {
        ShortcutManagerCompat.disableShortcuts(ctx, listOf(id), "Removed from MSF PDF Reader")
    } catch (_: Exception) {
    }
    store.setShortcut(uri, null)
    toast(ctx, "Shortcut removed. If the icon is still visible, long-press it and delete.")
}

fun sharePdf(ctx: Context, uri: String, title: String) {
    try {
        val u = Uri.parse(uri)
        val send = Intent(Intent.ACTION_SEND)
            .setType("application/pdf")
            .putExtra(Intent.EXTRA_STREAM, u)
            .putExtra(Intent.EXTRA_SUBJECT, title)
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        send.clipData = ClipData.newRawUri(title, u)
        ctx.startActivity(Intent.createChooser(send, "Share PDF"))
    } catch (e: Exception) {
        toast(ctx, "Could not share this file")
    }
}

/** Used when a book is removed from the library: quietly disables its home screen shortcut. */
fun silentRemoveShortcut(ctx: Context, uri: String) {
    val store = BookStore(ctx)
    val id = store.getShortcut(uri) ?: return
    try {
        ShortcutManagerCompat.disableShortcuts(ctx, listOf(id), "Removed from MSF PDF Reader")
    } catch (_: Exception) {
    }
    store.setShortcut(uri, null)
}
