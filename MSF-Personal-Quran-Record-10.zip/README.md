# MSF Personal Quran Record

Android app (Kotlin, no external libraries) for tracking Hifz and Nazra progress.

## GitHub سے APK بنانے کا طریقہ
1. نیا repository بنائیں اور اس زپ کی تمام فائلیں upload کریں (main branch)۔
2. Actions ٹیب کھولیں → "Build APK" خود چلے گا (یا Run workflow دبائیں)۔
3. مکمل ہونے پر نیچے Artifacts سے `MSF-Quran-Record-APK` ڈاؤن لوڈ کریں۔
