package com.msf.quranrecord

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** Bundled fonts (assets/fonts) and the three places they are used. */
object AppFonts {
    class Opt(val key: String, val file: String?, val label: String)

    val opts = listOf(
        Opt("system", null, "سسٹم ڈیفالٹ"),
        Opt("qalam_m1", "al_qalam_quran_majeed_1.ttf", "Al Qalam Quran Majeed 1"),
        Opt("qalam_m2", "al_qalam_quran_majeed_2.ttf", "Al Qalam Quran Majeed 2"),
        Opt("qalam", "al_qalam_quran.ttf", "Al Qalam Quran"),
        Opt("qalam2a", "al_qalam_quran_2a.ttf", "Al Qalam Quran 2A"),
        Opt("majeed", "al_majeed_quranic.ttf", "Al Majeed Quranic Font"),
        Opt("mushaf", "al_mushaf_quran.ttf", "Al Mushaf Quran"),
        Opt("jameel", "jameel_noori_kasheeda.ttf", "Jameel Noori Kasheeda")
    )

    const val BODY = "font_body"
    const val TITLE = "font_title"
    const val QURAN = "font_quran"
    const val DEF_BODY = "qalam_m1"
    const val DEF_TITLE = "jameel"
    const val DEF_QURAN = "majeed"

    private val cache = HashMap<String, Typeface?>()

    fun get(c: Context, key: String): Typeface? {
        val o = opts.firstOrNull { it.key == key } ?: return null
        val f = o.file ?: return null
        if (cache.containsKey(f)) return cache[f]
        val tf = try {
            Typeface.createFromAsset(c.applicationContext.assets, "fonts/$f")
        } catch (e: Exception) {
            null
        }
        cache[f] = tf
        return tf
    }

    fun body(c: Context) = get(c, Store.str(c, BODY, DEF_BODY))
    fun title(c: Context) = get(c, Store.str(c, TITLE, DEF_TITLE))
    fun quran(c: Context) = get(c, Store.str(c, QURAN, DEF_QURAN))

    /** Picks the font for a piece of text, or null to keep the system font (Latin, digits, icons). */
    fun forText(c: Context, t: CharSequence, bold: Boolean, sp: Float): Typeface? {
        var arabic = false
        var marks = 0
        for (ch in t) {
            val x = ch.code
            if (x in 0x0600..0x06FF || x in 0xFB50..0xFDFF || x in 0xFE70..0xFEFF) arabic = true
            if (x in 0x064E..0x0652) marks++
        }
        if (!arabic) return null
        return when {
            marks >= 3 -> quran(c)
            bold && sp >= 15f -> title(c)
            else -> body(c)
        }
    }
}

/** In-memory flag: has the PIN been entered since the app was opened? */
object Lock {
    var unlocked = false
}

/** Colour themes: the green UI is rotated to another hue. Index 0 is the default green. */
object Themes {
    val names = listOf("سبز (ڈارک)", "فیروزی (ڈارک)", "نیلا (ڈارک)", "جامنی (ڈارک)")
    private val deg = floatArrayOf(0f, 40f, 80f, 140f)

    fun index(c: Context): Int = Store.int(c, "theme", 0).coerceIn(0, names.size - 1)

    private fun hue(d: Float): ColorMatrix {
        val r = Math.toRadians(d.toDouble())
        val cs = Math.cos(r).toFloat()
        val sn = Math.sin(r).toFloat()
        return ColorMatrix(floatArrayOf(
            0.213f + cs * 0.787f - sn * 0.213f, 0.715f - cs * 0.715f - sn * 0.715f, 0.072f - cs * 0.072f + sn * 0.928f, 0f, 0f,
            0.213f - cs * 0.213f + sn * 0.143f, 0.715f + cs * 0.285f + sn * 0.140f, 0.072f - cs * 0.072f - sn * 0.283f, 0f, 0f,
            0.213f - cs * 0.213f - sn * 0.787f, 0.715f - cs * 0.715f + sn * 0.715f, 0.072f + cs * 0.928f + sn * 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    fun apply(a: Activity, root: View) {
        val i = index(a)
        if (i == 0) return
        val p = Paint()
        p.colorFilter = ColorMatrixColorFilter(hue(deg[i]))
        root.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        val hsv = FloatArray(3)
        Color.colorToHSV(Color.parseColor("#0F5A2B"), hsv)
        hsv[0] = (hsv[0] + deg[i]) % 360f
        a.window.statusBarColor = Color.HSVToColor(hsv)
    }
}

open class BaseActivity : AppCompatActivity() {
    lateinit var box: LinearLayout
    private var pinDlg: Dialog? = null

    override fun attachBaseContext(newBase: Context) {
        val pct = newBase.getSharedPreferences("msf", Context.MODE_PRIVATE).getInt("font_pct", 100)
        if (pct == 100) {
            super.attachBaseContext(newBase)
            return
        }
        val cfg = Configuration(newBase.resources.configuration)
        cfg.fontScale = pct / 100f
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun setContentView(view: View?) {
        super.setContentView(view)
        if (view != null) Themes.apply(this, view)
    }

    override fun onStart() {
        super.onStart()
        if (!Lock.unlocked && Store.str(this, "pin").isNotBlank() && pinDlg?.isShowing != true) askPin()
    }

    private fun askPin() {
        val d = Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        val col = vbox()
        col.gravity = Gravity.CENTER
        col.setBackgroundColor(c("#F4F8F4"))
        col.setPadding(dp(32), dp(32), dp(32), dp(32))
        col.addView(logoView(150))
        col.addView(tv("پن کوڈ درج کریں", 20f, "#0F5A2B", true, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 18, 0, 10))
        val e = android.widget.EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        e.gravity = Gravity.CENTER
        e.textSize = 24f
        bg(e, "#FFFFFF", "#BBD7C0", 12)
        col.addView(e, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        val err = tv("", 13f, "#C62828", false, Gravity.CENTER)
        col.addView(err, lp(MATCH, WRAP))
        fun tryUnlock() {
            if (e.text.toString() == Store.str(this, "pin")) {
                Lock.unlocked = true
                d.dismiss()
            } else {
                err.text = "غلط پن کوڈ"
                e.setText("")
            }
        }
        col.addView(btn("کھولیں") { tryUnlock() })
        d.setContentView(col)
        d.setCancelable(false)
        d.setOnKeyListener { _, k, ev ->
            if (k == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                d.dismiss()
                finishAffinity()
                true
            } else false
        }
        pinDlg = d
        d.show()
        if (Store.bool(this, "fp_on") && Build.VERSION.SDK_INT >= 28) fingerprint(d)
    }

    private fun fingerprint(d: Dialog) {
        try {
            val ex = androidx.core.content.ContextCompat.getMainExecutor(this)
            val bp = android.hardware.biometrics.BiometricPrompt.Builder(this)
                .setTitle("فنگر پرنٹ سے کھولیں")
                .setNegativeButton("پن استعمال کریں", ex) { _, _ -> }
                .build()
            bp.authenticate(android.os.CancellationSignal(), ex,
                object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                        Lock.unlocked = true
                        if (d.isShowing) d.dismiss()
                    }
                })
        } catch (ex: Exception) {
            // no fingerprint available: the PIN field stays usable
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F5A2B")
    }

    fun dp(i: Int): Int = (i * resources.displayMetrics.density + 0.5f).toInt()
    fun c(s: String): Int = Color.parseColor(s)
    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun bg(v: View, fill: String, stroke: String? = null, r: Int = 16) {
        v.background = GradientDrawable().apply {
            setColor(c(fill))
            cornerRadius = dp(r).toFloat()
            if (stroke != null) setStroke(dp(1), c(stroke))
        }
    }

    fun circle(v: View, fill: String, stroke: String? = null, sw: Int = 0) {
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c(fill))
            if (stroke != null) setStroke(dp(sw), c(stroke))
        }
    }

    fun tv(t: String, sp: Float = 14f, col: String = "#222222", bold: Boolean = false, gravity: Int = Gravity.START): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(c(col))
        val f = AppFonts.forText(this, t, bold, sp)
        if (f != null) {
            val own = f === AppFonts.title(this) || f === AppFonts.quran(this)
            v.typeface = if (bold && !own) Typeface.create(f, Typeface.BOLD) else f
        } else if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.gravity = gravity
        return v
    }

    fun lp(w: Int, h: Int, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    /** Sub-screen with green title bar, back arrow and scrolling content in [box]. */
    fun setup(title: String) {
        val root = vbox()
        root.setBackgroundColor(c("#F4F8F4"))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val bar = hbox()
        bar.setBackgroundColor(c("#0F5A2B"))
        bar.setPadding(dp(16), dp(14), dp(16), dp(14))
        val back = tv("→", 26f, "#FFFFFF", true)
        back.setPadding(0, 0, dp(16), 0)
        back.setOnClickListener { finish() }
        bar.addView(back)
        bar.addView(tv(title, 20f, "#FFFFFF", true))
        val sv = ScrollView(this)
        box = vbox()
        box.setPadding(dp(16), dp(16), dp(16), dp(24))
        sv.addView(box)
        root.addView(bar, lp(MATCH, WRAP))
        root.addView(sv, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    fun btn(t: String, fill: String = "#0F5A2B", onClick: () -> Unit): TextView {
        val v = tv(t, 16f, "#FFFFFF", true, Gravity.CENTER)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        bg(v, fill, null, 14)
        v.setOnClickListener { onClick() }
        v.layoutParams = lp(MATCH, WRAP, 0f, 0, 8, 0, 8)
        return v
    }

    fun input(hint: String, number: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        AppFonts.body(this)?.let { e.typeface = it }
        e.textSize = 16f
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        bg(e, "#FFFFFF", "#BBD7C0", 12)
        if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
        e.layoutParams = lp(MATCH, WRAP, 0f, 0, 6, 0, 6)
        return e
    }

    fun card(fill: String = "#FFFFFF", stroke: String = "#D5E6D8"): LinearLayout {
        val l = vbox()
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        bg(l, fill, stroke, 14)
        l.layoutParams = lp(MATCH, WRAP, 0f, 0, 6, 0, 6)
        return l
    }

    /** Applies the app font to every Urdu text in a dialog (title, message, buttons, list). */
    fun styleDialog(d: Dialog) {
        val decor = d.window?.decorView ?: return
        fun walk(v: View) {
            if (v is android.widget.TextView) {
                val f = AppFonts.forText(this, v.text, false, 12f)
                if (f != null && v.typeface !== f) v.typeface = f
            }
            if (v is ViewGroup) for (i in 0 until v.childCount) walk(v.getChildAt(i))
        }
        walk(decor)
        decor.viewTreeObserver.addOnGlobalLayoutListener { walk(decor) }
    }

    fun android.app.AlertDialog.Builder.showF(): android.app.AlertDialog {
        val d = create()
        d.show()
        styleDialog(d)
        return d
    }

    /** The MSF round logo image used in every screen header. */
    fun logoView(sizeDp: Int): android.widget.ImageView {
        val iv = android.widget.ImageView(this)
        iv.scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        iv.setImageResource(R.drawable.msf_logo)
        iv.layoutParams = lp(dp(sizeDp), dp(sizeDp))
        return iv
    }

    fun go(cls: Class<*>) = startActivity(android.content.Intent(this, cls))
}
