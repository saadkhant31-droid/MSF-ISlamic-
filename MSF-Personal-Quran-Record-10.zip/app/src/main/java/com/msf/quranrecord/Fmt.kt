package com.msf.quranrecord

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object Fmt {
    val days = arrayOf("اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ")
    val months = arrayOf(
        "جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
        "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"
    )
    private val f = SimpleDateFormat("yyyy-MM-dd", Locale.US)

    fun fmt(cal: Calendar) = "${cal.get(Calendar.DAY_OF_MONTH)} ${months[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"
    fun key(cal: Calendar): String = f.format(cal.time)
    fun parse(k: String): Calendar {
        val c = Calendar.getInstance()
        c.time = f.parse(k)!!
        return c
    }
    fun dur(m: Int) = if (m >= 60 && m % 60 == 0) "${m / 60} گھنٹہ" else "$m منٹ"
    fun paras(n: Int) = if (n == 1) "1 پارہ" else "$n پارے"
    fun t12(t: String): String {
        val p = t.split(":")
        val h = p[0].toInt()
        return "${if (h % 12 == 0) 12 else h % 12}:${p[1]}"
    }
    fun between(a: String, b: String): Int {
        val x = a.split(":"); val y = b.split(":")
        var d = (y[0].toInt() * 60 + y[1].toInt()) - (x[0].toInt() * 60 + x[1].toInt())
        if (d < 0) d += 1440
        return d
    }
}
