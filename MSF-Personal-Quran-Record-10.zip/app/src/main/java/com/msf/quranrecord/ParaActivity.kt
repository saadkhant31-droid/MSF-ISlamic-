package com.msf.quranrecord

import android.graphics.Color
import android.os.Bundle
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

class ParaActivity : BaseActivity() {
    private lateinit var type: String
    private var isHifz = true
    private lateinit var grid: LinearLayout
    private lateinit var info: TextView
    private var repTv: TextView? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        type = intent.getStringExtra("type") ?: "hifz"
        isHifz = type == "hifz"
        setup(if (isHifz) "حفظ قرآن مجید" else "ناظرہ قرآن مجید")

        info = tv("", 20f, if (isHifz) "#0F6B33" else "#0B4F9C", true, Gravity.CENTER)
        box.addView(info, lp(MATCH, WRAP, 0f, 0, 0, 0, 4))
        box.addView(tv("جو پارہ مکمل ہو جائے اس پر ٹیپ کریں", 13f, "#666666", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 0, 0, 12))
        grid = vbox()
        box.addView(grid)

        if (!isHifz) {
            val rc = card("#E8F3FF", "#A9CDF2")
            rc.addView(tv("ناظرہ کی دہرائی (کتنی بار مکمل کیا)", 15f, "#0B4F9C", true))
            val r = hbox()
            r.layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            val minus = small("−", "#0B4F9C") { change(-1) }
            val plus = small("+", "#0B4F9C") { change(1) }
            repTv = tv("", 24f, "#222222", true, Gravity.CENTER)
            r.addView(minus, lp(dp(56), dp(48)))
            r.addView(repTv, lp(0, WRAP, 1f))
            r.addView(plus, lp(dp(56), dp(48)))
            rc.addView(r, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
            box.addView(rc, lp(MATCH, WRAP, 0f, 0, 16, 0, 0))
        }

        box.addView(btn("تمام پارے صاف کریں", "#9E9E9E") {
            Store.savePara(this, type, emptySet())
            if (isHifz) Store.putStr(this, "hifz_date", "")
            refresh()
        })
        refresh()
    }

    private fun small(label: String, fill: String, onClick: () -> Unit): TextView {
        val v = tv(label, 26f, "#FFFFFF", true, Gravity.CENTER)
        bg(v, fill, null, 12)
        v.setOnClickListener { onClick() }
        return v
    }

    private fun change(d: Int) {
        val n = (Store.int(this, "nazra_rep") + d).coerceAtLeast(0)
        Store.putInt(this, "nazra_rep", n)
        refresh()
    }

    private fun refresh() {
        val set = Store.paras(this, type)
        val accent = if (isHifz) "#0F6B33" else "#0B4F9C"
        info.text = "${set.size} / 30 پارے مکمل"
        repTv?.text = "${Store.int(this, "nazra_rep")} بار"
        grid.removeAllViews()
        var n = 1
        for (r in 0 until 6) {
            val row = hbox()
            row.layoutDirection = android.view.View.LAYOUT_DIRECTION_LTR
            for (k in 0 until 5) {
                val i = n++
                val done = i in set
                val cell = tv("$i", 20f, if (done) "#FFFFFF" else "#333333", true, Gravity.CENTER)
                bg(cell, if (done) accent else "#FFFFFF", "#BBD7C0", 12)
                cell.setOnClickListener {
                    val s = Store.paras(this, type)
                    if (i in s) s.remove(i) else s.add(i)
                    Store.savePara(this, type, s)
                    if (isHifz) Store.putStr(this, "hifz_date", if (s.size == 30) Store.today() else "")
                    refresh()
                }
                row.addView(cell, lp(0, dp(56), 1f, 3, 3, 3, 3))
            }
            grid.addView(row)
        }
    }
}
