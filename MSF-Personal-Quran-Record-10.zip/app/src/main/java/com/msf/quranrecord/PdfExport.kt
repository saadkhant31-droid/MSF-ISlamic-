package com.msf.quranrecord

import android.content.ContentValues
import android.content.Context
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream

object PdfExport {
    class Line(val text: String, val size: Float = 13f, val bold: Boolean = false, val color: Int = Color.BLACK)

    fun build(lines: List<Line>): PdfDocument {
        val doc = PdfDocument()
        var no = 1
        var page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, no).create())
        var cv = page.canvas
        var y = 40f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.textAlign = Paint.Align.RIGHT
        for (l in lines) {
            if (y + l.size * 1.6f > 800f) {
                doc.finishPage(page)
                no++
                page = doc.startPage(PdfDocument.PageInfo.Builder(595, 842, no).create())
                cv = page.canvas
                y = 40f
            }
            p.textSize = l.size
            p.color = l.color
            p.isFakeBoldText = l.bold
            y += l.size * 1.55f
            val t = if (l.text.length > 85) l.text.take(85) + "…" else l.text
            cv.drawText(t, 555f, y, p)
        }
        doc.finishPage(page)
        return doc
    }

    /** Returns (uri or null, location text). */
    fun save(ctx: Context, doc: PdfDocument, name: String): Pair<Uri?, String> {
        if (Build.VERSION.SDK_INT >= 29) {
            val v = ContentValues()
            v.put(MediaStore.MediaColumns.DISPLAY_NAME, name)
            v.put(MediaStore.MediaColumns.MIME_TYPE, "application/pdf")
            v.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            val uri = ctx.contentResolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, v)
                ?: throw IllegalStateException("insert failed")
            ctx.contentResolver.openOutputStream(uri)!!.use { doc.writeTo(it) }
            return Pair(uri, "Downloads")
        }
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: ctx.filesDir
        dir.mkdirs()
        val f = File(dir, name)
        FileOutputStream(f).use { doc.writeTo(it) }
        return Pair(null, f.absolutePath)
    }
}
