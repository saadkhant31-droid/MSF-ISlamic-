package com.msf.quranrecord

import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.Editable
import android.text.InputFilter
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.ForegroundColorSpan
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject

class ReasonActivity : BaseActivity() {
    // Header text (as in the reference image). Change these two lines to rebrand.
    private val titleWhite = "قرآن"
    private val titleGold = "آسان"
    private val subtitle = "روزانہ قرآن، زندگی میں برکت"

    private class Opt(
        val key: String, val text: String, val icon: String,
        val acc: String, val fill: String, val stroke: String
    )

    private val opts = listOf(
        Opt("sick", "طبیعت خراب تھی۔", "❤️", "#D32F3F", "#FDECEE", "#F2B8BF"),
        Opt("busy", "مصروفیت تھی۔", "💼", "#0B5CA8", "#E8F3FF", "#A9CDF2"),
        Opt("travel", "سفر میں تھا۔", "✈️", "#0F8A4E", "#E6F7F0", "#A9DDC8"),
        Opt("time", "وقت نہیں ملا۔", "⏰", "#5B35B0", "#F3ECFB", "#CBBDEB"),
        Opt("other", "کوئی دوسری وجہ۔", "⋯", "#C98A0E", "#FFF6DC", "#F0D9A0")
    )

    private var selected: String? = null
    private lateinit var optBox: LinearLayout
    private lateinit var edit: EditText
    private lateinit var counter: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#FBFCF8"))
        val sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())

        // banner
        val banner = hbox()
        bg(banner, "#FBF8E6", "#E8E2C0", 18)
        banner.setPadding(dp(8), dp(8), dp(12), dp(8))
        val art = vbox()
        art.gravity = Gravity.CENTER
        art.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c("#143F3A"), c("#3A7A5C"))).apply {
            cornerRadius = dp(14).toFloat()
        }
        art.addView(tv("🌙", 20f, "#FFFFFF", false, Gravity.CENTER))
        art.addView(tv("📖", 46f, "#FFFFFF", false, Gravity.CENTER))
        art.addView(tv("🏮", 26f, "#FFFFFF", false, Gravity.CENTER))
        banner.addView(art, lp(dp(110), dp(140), 0f, 0, 0, 10, 0))
        val bt = vbox()
        bt.addView(tv("آج قرآن کیوں نہیں پڑھا؟", 22f, "#0F3D2A", true, Gravity.END))
        bt.addView(tv("اس پر کلک کرنے سے آپ اپنی وجہ درج کر سکیں گے، مثلاً:", 13f, "#333333", false, Gravity.END), lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        val dv = hbox()
        val l1 = View(this); l1.setBackgroundColor(c("#0F5A2B"))
        val l2 = View(this); l2.setBackgroundColor(c("#0F5A2B"))
        dv.addView(l1, lp(0, dp(1), 1f))
        dv.addView(tv("📖", 16f), lp(WRAP, WRAP, 0f, 6, 0, 6, 0))
        dv.addView(l2, lp(0, dp(1), 1f))
        bt.addView(dv, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        banner.addView(bt, lp(0, WRAP, 1f))
        content.addView(banner, lp(MATCH, WRAP, 0f, 12, 12, 12, 0))

        optBox = vbox()
        content.addView(optBox, lp(MATCH, WRAP, 0f, 12, 12, 12, 0))

        // free text card
        val ec = vbox()
        ec.setPadding(dp(12), dp(12), dp(12), dp(12))
        bg(ec, "#F2F9F4", "#D5E6D8", 16)
        val et = hbox()
        et.layoutDirection = View.LAYOUT_DIRECTION_RTL
        et.addView(tv("✏️", 22f, "#0F5A2B"), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        et.addView(tv("اپنی وجہ خود لکھیں", 17f, "#0F3D2A", true))
        ec.addView(et)
        edit = EditText(this)
        edit.hint = "مثلاً: آج میرا موڈ ٹھیک نہیں تھا ..."
        edit.textSize = 14f
        edit.minLines = 3
        edit.gravity = Gravity.TOP or Gravity.START
        edit.filters = arrayOf<InputFilter>(InputFilter.LengthFilter(100))
        edit.setPadding(dp(12), dp(10), dp(12), dp(10))
        bg(edit, "#FFFFFF", "#CFE3D3", 12)
        ec.addView(edit, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        counter = tv("0/100", 11f, "#777777", false, Gravity.END)
        ec.addView(counter, lp(MATCH, WRAP, 0f, 0, 4, 4, 0))
        edit.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c2: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c2: Int) {}
            override fun afterTextChanged(s: Editable?) {
                counter.text = "${s?.length ?: 0}/100"
                if (selected == null && !s.isNullOrBlank()) { selected = "other"; renderOptions() }
            }
        })
        val send = tv("➤   وجہ درج کریں", 17f, "#FFFFFF", true, Gravity.CENTER)
        send.setPadding(dp(12), dp(14), dp(12), dp(14))
        bg(send, "#0F5A2B", null, 14)
        send.setOnClickListener { save() }
        ec.addView(send, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        content.addView(ec, lp(MATCH, WRAP, 0f, 12, 12, 12, 0))

        // verse footer
        val f = hbox()
        f.setPadding(dp(10), dp(10), dp(10), dp(10))
        bg(f, "#EAF3E4", "#CFE2C9", 14)
        val fi = tv("📖", 20f, "#000000", false, Gravity.CENTER)
        circle(fi, "#FFFFFF", "#D4AF37", 2)
        f.addView(fi, lp(dp(44), dp(44), 0f, 0, 0, 10, 0))
        val ft = vbox()
        ft.addView(tv("وَنُنَزِّلُ مِنَ الْقُرْآنِ مَا هُوَ شِفَاءٌ وَرَحْمَةٌ لِّلْمُؤْمِنِينَ", 13f, "#0F5A2B", true, Gravity.CENTER))
        ft.addView(tv("اور ہم قرآن میں سے وہ نازل کرتے ہیں جو ایمان والوں کے لیے شفا اور رحمت ہے۔ (سورۃ الاسراء: 82)", 10f, "#444444", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 3, 0, 0))
        f.addView(ft, lp(0, WRAP, 1f))
        content.addView(f, lp(MATCH, WRAP, 0f, 12, 12, 12, 16))

        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
        renderOptions()
    }

    // ---------- options ----------
    private fun renderOptions() {
        optBox.removeAllViews()
        val rows = listOf(listOf("sick", "busy"), listOf("travel", "time"), listOf("other"))
        for (r in rows) {
            val row = hbox()
            for ((i, k) in r.withIndex()) {
                val o = opts.first { it.key == k }
                val first = i == 0
                val last = i == r.size - 1
                row.addView(optCard(o), lp(0, WRAP, 1f, if (first) 0 else 5, 0, if (last) 0 else 5, 0))
            }
            optBox.addView(row, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))
        }
    }

    private fun optCard(o: Opt): View {
        val on = selected == o.key
        val card = hbox()
        card.layoutDirection = View.LAYOUT_DIRECTION_RTL
        card.setPadding(dp(10), dp(14), dp(10), dp(14))
        bg(card, o.fill, if (on) o.acc else o.stroke, 14)
        val radio = View(this)
        radio.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c(if (on) o.acc else "#FFFFFF"))
            setStroke(dp(2), c(o.acc))
        }
        card.addView(radio, lp(dp(22), dp(22), 0f, 0, 0, 8, 0))
        card.addView(tv(o.text, 15f, "#222222", true), lp(0, WRAP, 1f))
        val ic = tv(o.icon, if (o.key == "other") 20f else 28f, "#FFFFFF", false, Gravity.CENTER)
        if (o.key == "other") circle(ic, o.acc)
        card.addView(ic, if (o.key == "other") lp(dp(44), dp(44)) else lp(WRAP, WRAP))
        card.setOnClickListener {
            selected = if (selected == o.key) null else o.key
            renderOptions()
            if (selected == "other") edit.requestFocus()
        }
        return card
    }

    private fun save() {
        val typed = edit.text.toString().trim()
        val opt = opts.firstOrNull { it.key == selected }
        if (opt == null && typed.isEmpty()) {
            toast("پہلے کوئی وجہ منتخب کریں یا لکھیں")
            return
        }
        if (opt != null && opt.key == "other" && typed.isEmpty()) {
            toast("اپنی وجہ لکھیں")
            return
        }
        val label = opt?.text?.removeSuffix("۔") ?: ""
        val isOther = opt == null || opt.key == "other"
        val reason = if (isOther) typed else if (typed.isEmpty()) label else "$label — $typed"
        val cat = if (isOther) "دوسری وجہ" else label
        val l = Store.list(this, "reasons")
        l.add(JSONObject().put("d", Store.today()).put("r", reason).put("cat", cat))
        Store.saveList(this, "reasons", l)
        edit.text.clear()
        selected = null
        renderOptions()
        AlertDialog.Builder(this)
            .setMessage("وجہ محفوظ ہو گئی۔ ان شاءاللہ کل قرآن ضرور پڑھیں۔")
            .setPositiveButton("ٹھیک ہے", null)
            .setNeutralButton("تاریخ دیکھیں") { _, _ -> go(ReasonHistoryActivity::class.java) }
            .show()
    }

    // ---------- header / nav ----------
    private fun header(): View {
        val h = hbox()
        h.setPadding(dp(14), dp(12), dp(14), dp(12))
        h.setBackgroundColor(c("#0B4A25"))
        val menu = tv("☰", 28f, "#FFFFFF", true)
        menu.setOnClickListener { v -> showMenu(v) }
        h.addView(menu, lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val logo = tv("📖", 28f, "#FFFFFF", false, Gravity.CENTER)
        circle(logo, "#0B4A22", "#D4AF37", 3)
        h.addView(logo, lp(dp(64), dp(64), 0f, 0, 0, 10, 0))
        val tx = vbox()
        val ttl = SpannableStringBuilder("$titleWhite $titleGold")
        ttl.setSpan(ForegroundColorSpan(c("#FFFFFF")), 0, titleWhite.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        ttl.setSpan(ForegroundColorSpan(c("#F0C94A")), titleWhite.length + 1, ttl.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        val tt = tv("", 32f, "#FFFFFF", true)
        tt.text = ttl
        tx.addView(tt)
        tx.addView(tv(subtitle, 13f, "#FFFFFF"))
        h.addView(tx, lp(0, WRAP, 1f))
        val bell = tv("🔔", 26f, "#FFFFFF")
        bell.setOnClickListener { go(ReminderActivity::class.java) }
        h.addView(bell)
        return h
    }

    private fun showMenu(anchor: View) {
        val items = listOf<Pair<String, () -> Unit>>(
            "وجوہات کی تاریخ" to { go(ReasonHistoryActivity::class.java) },
            "حفظ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "hifz")) },
            "ناظرہ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "nazra")) },
            "روزانہ کا ریکارڈ" to { go(DailyActivity::class.java) },
            "رپورٹ اور گراف" to { go(ReportActivity::class.java) },
            "ٹارگٹ" to { go(TargetActivity::class.java) },
            "یاد دہانی" to { go(ReminderActivity::class.java) },
            "سیٹنگز" to { go(SettingsActivity::class.java) }
        )
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, p -> pm.menu.add(0, i, i, p.first) }
        pm.setOnMenuItemClickListener { m -> items[m.itemId].second(); true }
        pm.show()
    }

    private fun nav(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            1 -> AlertDialog.Builder(this).setTitle("قرآن")
                .setItems(arrayOf("حفظ قرآن مجید", "ناظرہ قرآن مجید")) { _, j ->
                    startActivity(Intent(this, ParaActivity::class.java).putExtra("type", if (j == 0) "hifz" else "nazra"))
                }.show()
            3 -> go(ReasonHistoryActivity::class.java)
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun bottomNav(): View {
        val n = hbox()
        n.setBackgroundColor(c("#0B3D1E"))
        n.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📖" to "قرآن", "💬" to "آج قرآن کیوں نہیں پڑھا؟", "📊" to "تاریخ", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 2
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, if (active) 9.5f else 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(60), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { nav(i) }
            n.addView(col, lp(0, WRAP, if (active) 1.7f else 1f))
        }
        return n
    }
}
