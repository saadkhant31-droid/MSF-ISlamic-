package com.msf.quranrecord

import android.app.AlertDialog
import android.os.Bundle
import android.view.Gravity

class ReasonHistoryActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("وجوہات کی تاریخ")
        refresh()
    }

    private fun refresh() {
        box.removeAllViews()
        val l = Store.list(this, "reasons")
        if (l.isEmpty()) {
            box.addView(tv("ابھی کوئی وجہ درج نہیں۔ ماشاءاللہ!", 15f, "#888888", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 30, 0, 0))
            return
        }
        val counts = linkedMapOf<String, Int>()
        for (o in l) {
            val k = o.optString("cat").ifBlank { "دوسری وجہ" }
            counts[k] = (counts[k] ?: 0) + 1
        }
        val sc = card("#F1ECFB", "#CBBDEB")
        sc.addView(tv("کل ${l.size} بار ناغہ ہوا", 16f, "#4B2FA0", true))
        for ((k, v) in counts.entries.sortedByDescending { it.value }) {
            sc.addView(tv("• $k: $v بار", 14f, "#333333"), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        }
        box.addView(sc)
        box.addView(tv("تفصیل (حذف کرنے کے لیے ٹیپ کریں)", 13f, "#666666"), lp(MATCH, WRAP, 0f, 0, 10, 0, 4))
        for (idx in l.indices.reversed()) {
            val o = l[idx]
            val cd = card("#FFFFFF", "#D5E6D8")
            cd.addView(tv(o.getString("d"), 12f, "#666666"))
            cd.addView(tv(o.getString("r"), 16f, "#222222", true))
            cd.setOnClickListener {
                AlertDialog.Builder(this).setMessage("یہ اندراج حذف کریں؟")
                    .setPositiveButton("حذف") { _, _ ->
                        val all = Store.list(this, "reasons")
                        all.removeAt(idx)
                        Store.saveList(this, "reasons", all)
                        refresh()
                    }.setNegativeButton("نہیں", null).show()
            }
            box.addView(cd)
        }
    }
}
