package com.msf.quranrecord

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Calendar

class RecordActivity : BaseActivity() {
    private lateinit var listBox: LinearLayout
    private lateinit var dateTv: TextView
    private lateinit var allTv: TextView
    private var sel: Calendar = Calendar.getInstance()
    private var showAll = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        val sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())

        // Title row
        val tr = hbox()
        tr.setPadding(dp(12), dp(14), dp(12), dp(6))
        val ic = tv("🗓️", 26f, "#FFFFFF", false, Gravity.CENTER)
        bg(ic, "#0F5A2B", null, 12)
        tr.addView(ic, lp(dp(52), dp(52), 0f, 0, 0, 8, 0))
        val tt = vbox()
        tt.addView(tv("Daily Records", 22f, "#222222", true))
        tt.addView(tv("روزانہ کا ریکارڈ", 17f, "#222222", true))
        tr.addView(tt, lp(0, WRAP, 1f))
        val add = tv("＋  نیا ریکارڈ شامل کریں", 13f, "#FFFFFF", true, Gravity.CENTER)
        add.setPadding(dp(12), dp(12), dp(12), dp(12))
        bg(add, "#0F5A2B", null, 12)
        add.setOnClickListener { newRecord() }
        tr.addView(add)
        content.addView(tr)

        // Date bar
        val bar = hbox()
        bar.setPadding(dp(14), dp(10), dp(14), dp(10))
        bg(bar, "#FFFFFF", "#D5E6D8", 14)
        val prev = tv("‹", 30f, "#0F5A2B", true)
        prev.setPadding(dp(8), 0, dp(8), 0)
        prev.setOnClickListener { sel.add(Calendar.DAY_OF_YEAR, -1); showAll = false; refresh() }
        val next = tv("›", 30f, "#0F5A2B", true)
        next.setPadding(dp(8), 0, dp(8), 0)
        next.setOnClickListener { sel.add(Calendar.DAY_OF_YEAR, 1); showAll = false; refresh() }
        dateTv = tv("", 17f, "#222222", true, Gravity.CENTER)
        dateTv.setOnClickListener { pickDate() }
        bar.addView(prev)
        bar.addView(dateTv, lp(0, WRAP, 1f))
        bar.addView(next)
        content.addView(bar, lp(MATCH, WRAP, 0f, 12, 6, 12, 0))

        allTv = tv("", 13f, "#0F6B33", true, Gravity.CENTER)
        allTv.setPadding(0, dp(8), 0, dp(4))
        allTv.setOnClickListener { showAll = true; refresh() }
        content.addView(allTv, lp(MATCH, WRAP))

        listBox = vbox()
        content.addView(listBox, lp(MATCH, WRAP, 0f, 10, 0, 10, 16))

        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun newRecord() {
        startActivity(Intent(this, RecordFormActivity::class.java).putExtra("date", Fmt.key(if (showAll) Calendar.getInstance() else sel)))
    }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d ->
            sel.set(y, m, d); showAll = false; refresh()
        }, sel.get(Calendar.YEAR), sel.get(Calendar.MONTH), sel.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(12))
        h.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c("#13703A"), c("#0A3D1C")))

        val top = hbox()
        val back = tv("←", 30f, "#FFFFFF", true)
        back.setOnClickListener { finish() }
        val cal = tv("🗓️", 24f, "#FFFFFF")
        cal.setOnClickListener { pickDate() }
        val more = tv("⋮", 30f, "#FFFFFF", true)
        more.setPadding(dp(14), 0, dp(4), 0)
        more.setOnClickListener { v -> menu(v) }
        top.addView(back)
        top.addView(View(this), lp(0, 1, 1f))
        top.addView(cal)
        top.addView(more)
        h.addView(top)

        val mid = hbox()
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(View(this), lp(0, 1, 1f))
        val logoImg = logoView(124)
        mid.addView(logoImg, lp(dp(124), dp(124)))
        mid.addView(View(this), lp(0, 1, 1f))
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 6, 0, 10))

        val tabs = hbox()
        val items = listOf("🏠" to "Home", "📝" to "Records", "📊" to "Reports", "🎯" to "Targets", "⚙️" to "Settings")
        items.forEachIndexed { i, p ->
            val t = vbox()
            t.gravity = Gravity.CENTER
            t.setPadding(dp(2), dp(8), dp(2), dp(8))
            val active = i == 1
            bg(t, if (active) "#F5EFD8" else "#0F4A25", if (active) "#D4AF37" else "#8C7A33", 12)
            t.addView(tv(p.first, 20f, "#FFFFFF", false, Gravity.CENTER))
            t.addView(tv(p.second, 12f, if (active) "#0B3D1E" else "#FFFFFF", true, Gravity.CENTER))
            t.setOnClickListener { tab(i) }
            tabs.addView(t, lp(0, WRAP, 1f, 2, 0, 2, 0))
        }
        h.addView(tabs)
        return h
    }

    private fun tab(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            2 -> { go(ReportActivity::class.java); finish() }
            3 -> { go(TargetActivity::class.java); finish() }
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun menu(anchor: View) {
        val pm = PopupMenu(this, anchor)
        pm.menu.add(0, 0, 0, "نیا ریکارڈ شامل کریں")
        pm.menu.add(0, 1, 1, "آج کا ریکارڈ")
        pm.menu.add(0, 2, 2, "تمام ریکارڈ دکھائیں")
        pm.menu.add(0, 3, 3, "تمام ریکارڈ حذف کریں")
        pm.setOnMenuItemClickListener { m ->
            when (m.itemId) {
                0 -> newRecord()
                1 -> { sel = Calendar.getInstance(); showAll = false; refresh() }
                2 -> { showAll = true; refresh() }
                3 -> AlertDialog.Builder(this).setMessage("تمام ریکارڈ حذف کر دیے جائیں؟")
                    .setPositiveButton("حذف") { _, _ -> Store.saveList(this, "records", emptyList()); refresh() }
                    .setNegativeButton("نہیں", null).show()
            }
            true
        }
        pm.show()
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "📊" to "رپورٹس", "🎯" to "ٹارگٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 1
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(40), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { tab(i) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }

    private fun refresh() {
        dateTv.text = "🗓️  ${Fmt.fmt(sel)}  (${Fmt.days[sel.get(Calendar.DAY_OF_WEEK) - 1]})"
        allTv.text = if (showAll) "📋 تمام ریکارڈ دکھائے جا رہے ہیں — دن بدلنے کے لیے تیر دبائیں"
        else "📋 تمام ریکارڈ دکھائیں (یہاں ٹیپ کریں)"
        listBox.removeAllViews()
        val all = Store.list(this, "records")
        var idxs = all.indices.toList()
        if (!showAll) idxs = idxs.filter { all[it].getString("d") == Fmt.key(sel) }
        idxs = idxs.sortedWith(compareByDescending<Int> { all[it].getString("d") }.thenByDescending { it })
        if (idxs.isEmpty()) {
            listBox.addView(tv("اس دن کا کوئی ریکارڈ نہیں۔ اوپر \"نیا ریکارڈ شامل کریں\" دبائیں۔", 14f, "#888888", false, Gravity.CENTER),
                lp(MATCH, WRAP, 0f, 0, 24, 0, 0))
        }
        for (i in idxs) listBox.addView(recCard(i, all[i]), lp(MATCH, WRAP, 0f, 0, 5, 0, 5))
    }

    private fun sep() = View(this).also { it.setBackgroundColor(c("#E3E8E3")) }

    private fun col(icon: String, title: String, tc: String, l1: String, l2: String?): View {
        val v = vbox()
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.addView(tv(icon, 19f, "#000000", false, Gravity.CENTER))
        v.addView(tv(title, 11f, tc, true, Gravity.CENTER))
        v.addView(tv(l1, 11f, "#222222", true, Gravity.CENTER))
        if (l2 != null) v.addView(tv(l2, 9f, "#555555", false, Gravity.CENTER))
        return v
    }

    private fun recCard(idx: Int, o: JSONObject): View {
        val cal = Fmt.parse(o.getString("d"))
        val legacy = !o.has("np")
        val np = o.optInt("np", 0)
        val npg = if (legacy) o.optInt("pages", 0) else o.optInt("npg", 0)
        val st = o.optString("st"); val en = o.optString("en")
        val range = if (st.isNotEmpty() && en.isNotEmpty()) "${Fmt.t12(st)} - ${Fmt.t12(en)}" else "—"
        val session = o.optString("session", "—")
        val sIcon = when (session) { "فجر" -> "🌅"; "صبح", "دوپہر" -> "☀️"; "عصر" -> "🌤️"; "مغرب", "عشاء" -> "🌙"; else -> "🕌" }

        val row = hbox()
        row.setPadding(dp(5), dp(8), dp(4), dp(8))
        bg(row, "#FFFFFF", "#D5E6D8", 14)
        row.setOnClickListener {
            startActivity(Intent(this, RecordFormActivity::class.java).putExtra("idx", idx))
        }

        val dc = vbox()
        dc.gravity = Gravity.CENTER
        circle(dc, "#0F5A2B")
        dc.addView(tv("${cal.get(Calendar.DAY_OF_MONTH)}", 17f, "#FFFFFF", true, Gravity.CENTER))
        dc.addView(tv(Fmt.months[cal.get(Calendar.MONTH)], 8f, "#FFFFFF", false, Gravity.CENTER))
        dc.addView(tv("${cal.get(Calendar.YEAR)}", 8f, "#FFFFFF", false, Gravity.CENTER))
        row.addView(dc, lp(dp(46), dp(46), 0f, 0, 0, 3, 0))

        fun add(v: View, w: Float = 1f) {
            row.addView(sep(), lp(dp(1), dp(60)))
            row.addView(v, lp(0, WRAP, w, 1, 0, 1, 0))
        }
        add(col(sIcon, session, "#333333", range, null), 1.25f)
        add(col("📗", "حفظ", "#0F6B33", Fmt.paras(o.optInt("hp", 0)), "(صفحات ${o.optInt("hpg", 0)})"))
        add(col("📘", "ناظرہ", "#0B4F9C", Fmt.paras(np), "(صفحات $npg)"))
        add(col("🔄", "دہرائی", "#333333", "${o.optInt("rep", 0)} بار", null), 0.9f)
        add(col("🕐", "وقت", "#333333", Fmt.dur(o.optInt("min", 0)), null), 0.9f)

        val nb = vbox()
        nb.setPadding(dp(4), dp(5), dp(4), dp(5))
        bg(nb, "#EAF3E7", null, 8)
        nb.addView(tv("📝 نوٹس", 10f, "#0F5A2B", true))
        val note = o.optString("note").ifBlank { "—" }
        val nt = tv(note, 10f, "#333333")
        nt.maxLines = 4
        nb.addView(nt)
        row.addView(nb, lp(0, WRAP, 1.6f, 3, 0, 1, 0))
        row.addView(tv("›", 22f, "#0F5A2B", true))
        return row
    }
}
