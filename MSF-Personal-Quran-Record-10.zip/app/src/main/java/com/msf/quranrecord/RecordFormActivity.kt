package com.msf.quranrecord

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.view.Gravity
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Calendar

class RecordFormActivity : BaseActivity() {
    private var idx = -1
    private var date = Store.today()
    private var session = "صبح"
    private var st = ""
    private var en = ""
    private lateinit var dateBtn: TextView
    private lateinit var stBtn: TextView
    private lateinit var enBtn: TextView
    private val chips = mutableMapOf<String, TextView>()

    private fun pill(onClick: () -> Unit): TextView {
        val p = tv("", 15f, "#0F5A2B", true, Gravity.CENTER)
        p.setPadding(dp(10), dp(12), dp(10), dp(12))
        bg(p, "#FFFFFF", "#BBD7C0", 12)
        p.setOnClickListener { onClick() }
        return p
    }

    private fun num(hint: String, v: Int): EditText {
        val e = input(hint, true)
        if (v > 0) e.setText("$v")
        return e
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        idx = intent.getIntExtra("idx", -1)
        intent.getStringExtra("date")?.let { date = it }
        val rec: JSONObject? = if (idx >= 0) Store.list(this, "records").getOrNull(idx) else null
        if (rec != null) {
            date = rec.getString("d")
            session = rec.optString("session", "صبح")
            st = rec.optString("st"); en = rec.optString("en")
        }
        setup(if (rec == null) "نیا ریکارڈ" else "ریکارڈ میں ترمیم")

        box.addView(tv("تاریخ", 14f, "#666666"))
        dateBtn = pill {
            val c0 = Fmt.parse(date)
            DatePickerDialog(this, { _, y, m, d ->
                val c1 = Calendar.getInstance(); c1.set(y, m, d)
                date = Fmt.key(c1); paint()
            }, c0.get(Calendar.YEAR), c0.get(Calendar.MONTH), c0.get(Calendar.DAY_OF_MONTH)).show()
        }
        box.addView(dateBtn, lp(MATCH, WRAP, 0f, 0, 4, 0, 10))

        box.addView(tv("وقت (نماز کے حساب سے)", 14f, "#666666"))
        val hs = HorizontalScrollView(this)
        val cr = hbox()
        for (s in listOf("فجر", "صبح", "دوپہر", "عصر", "مغرب", "عشاء")) {
            val ch = tv(s, 15f, "#0F5A2B", true, Gravity.CENTER)
            ch.setPadding(dp(16), dp(10), dp(16), dp(10))
            ch.setOnClickListener { session = s; paint() }
            chips[s] = ch
            cr.addView(ch, lp(WRAP, WRAP, 0f, 3, 0, 3, 0))
        }
        hs.addView(cr)
        box.addView(hs, lp(MATCH, WRAP, 0f, 0, 4, 0, 10))

        box.addView(tv("شروع اور ختم کا وقت", 14f, "#666666"))
        val tr = hbox()
        stBtn = pill { pickTime(st) { st = it; paint() } }
        enBtn = pill { pickTime(en) { en = it; paint() } }
        tr.addView(stBtn, lp(0, WRAP, 1f, 0, 0, 4, 0))
        tr.addView(enBtn, lp(0, WRAP, 1f, 4, 0, 0, 0))
        box.addView(tr, lp(MATCH, WRAP, 0f, 0, 4, 0, 10))

        val hp = num("حفظ: پارے", rec?.optInt("hp") ?: 0)
        val hpg = num("حفظ: صفحات", rec?.optInt("hpg") ?: 0)
        val np = num("ناظرہ: پارے", rec?.optInt("np") ?: 0)
        val legacyPages = if (rec != null && !rec.has("np")) rec.optInt("pages") else 0
        val npg = num("ناظرہ: صفحات", rec?.optInt("npg") ?: legacyPages)
        val reph = num("حفظ کی دہرائی (بار)", rec?.optInt("reph") ?: 0)
        val repnInit = if (rec == null) 0 else if (rec.has("repn") || rec.has("reph")) rec.optInt("repn") else rec.optInt("rep")
        val repn = num("ناظرہ کی دہرائی (بار)", repnInit)
        val mins = num("کل وقت (منٹ) — خالی ہو تو خود نکلے گا", rec?.optInt("min") ?: 0)
        val note = input("نوٹس")
        note.setText(rec?.optString("note") ?: "")

        fun pair(a: EditText, b: EditText) {
            val r = hbox()
            r.addView(a, lp(0, WRAP, 1f, 0, 0, 4, 0))
            r.addView(b, lp(0, WRAP, 1f, 4, 0, 0, 0))
            box.addView(r)
        }
        box.addView(tv("📗 حفظ", 16f, "#0F6B33", true), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        pair(hp, hpg)
        box.addView(tv("📘 ناظرہ", 16f, "#0B4F9C", true), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        pair(np, npg)
        pair(reph, repn)
        box.addView(mins)
        box.addView(note)

        box.addView(btn("محفوظ کریں") {
            val hpV = hp.text.toString().toIntOrNull() ?: 0
            val hpgV = hpg.text.toString().toIntOrNull() ?: 0
            val npV = np.text.toString().toIntOrNull() ?: 0
            val npgV = npg.text.toString().toIntOrNull() ?: 0
            val rhV = reph.text.toString().toIntOrNull() ?: 0
            val rnV = repn.text.toString().toIntOrNull() ?: 0
            val repV = rhV + rnV
            var m = mins.text.toString().toIntOrNull() ?: 0
            if (m == 0 && st.isNotEmpty() && en.isNotEmpty()) m = Fmt.between(st, en)
            if (hpV + hpgV + npV + npgV + repV + m == 0 && note.text.isBlank()) {
                toast("پہلے کچھ درج کریں")
            } else {
                val o = JSONObject().put("d", date).put("session", session).put("st", st).put("en", en)
                    .put("hp", hpV).put("hpg", hpgV).put("np", npV).put("npg", npgV)
                    .put("reph", rhV).put("repn", rnV).put("rep", repV).put("min", m).put("pages", hpgV + npgV)
                    .put("note", note.text.toString())
                val l = Store.list(this, "records")
                if (idx >= 0 && idx < l.size) l[idx] = o else l.add(o)
                Store.saveList(this, "records", l)
                toast("ریکارڈ محفوظ ہو گیا")
                finish()
            }
        })
        if (rec != null) {
            box.addView(btn("حذف کریں", "#D32F3F") {
                AlertDialog.Builder(this).setMessage("یہ ریکارڈ حذف کریں؟")
                    .setPositiveButton("حذف") { _, _ ->
                        val l = Store.list(this, "records")
                        if (idx < l.size) l.removeAt(idx)
                        Store.saveList(this, "records", l)
                        finish()
                    }.setNegativeButton("نہیں", null).show()
            })
        }
        paint()
    }

    private fun pickTime(cur: String, set: (String) -> Unit) {
        val h = if (cur.isNotEmpty()) cur.split(":")[0].toInt() else 6
        val m = if (cur.isNotEmpty()) cur.split(":")[1].toInt() else 0
        TimePickerDialog(this, { _, hh, mm -> set(String.format("%02d:%02d", hh, mm)) }, h, m, false).show()
    }

    private fun paint() {
        val c0 = Fmt.parse(date)
        dateBtn.text = "🗓️  ${Fmt.fmt(c0)}  (${Fmt.days[c0.get(Calendar.DAY_OF_WEEK) - 1]})"
        stBtn.text = "شروع: " + if (st.isEmpty()) "--" else Fmt.t12(st)
        enBtn.text = "ختم: " + if (en.isEmpty()) "--" else Fmt.t12(en)
        for ((k, v) in chips) {
            val on = k == session
            v.setTextColor(c(if (on) "#FFFFFF" else "#0F5A2B"))
            bg(v, if (on) "#0F5A2B" else "#FFFFFF", "#BBD7C0", 20)
        }
    }
}
