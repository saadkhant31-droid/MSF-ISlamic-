package com.msf.quranrecord

import android.Manifest
import android.app.TimePickerDialog
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.TextView
import androidx.appcompat.widget.SwitchCompat

class ReminderActivity : BaseActivity() {
    private lateinit var timeTv: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("یاد دہانی")

        val cd = card("#E6F7F3", "#A9DDD0")
        val sw = SwitchCompat(this)
        sw.text = "روزانہ یاد دہانی فعال کریں"
        sw.textSize = 16f
        AppFonts.body(this)?.let { sw.typeface = it }
        sw.isChecked = Store.bool(this, "rem_on")
        sw.setOnCheckedChangeListener { _, on ->
            Store.putBool(this, "rem_on", on)
            Reminder.schedule(this)
            if (on && Build.VERSION.SDK_INT >= 33 &&
                checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
            ) {
                requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
            }
        }
        cd.addView(sw)
        timeTv = tv("", 22f, "#0F8A6E", true)
        cd.addView(timeTv, lp(MATCH, WRAP, 0f, 0, 12, 0, 0))
        box.addView(cd)
        showTime()

        box.addView(btn("یاد دہانی کا وقت بدلیں", "#0F8A6E") {
            TimePickerDialog(this, { _, h, m ->
                Store.putInt(this, "rem_h", h)
                Store.putInt(this, "rem_m", m)
                Reminder.schedule(this)
                showTime()
            }, Store.int(this, "rem_h", 20), Store.int(this, "rem_m", 0), false).show()
        })
        box.addView(btn("ٹیسٹ نوٹیفکیشن بھیجیں", "#5B35B0") {
            Reminder.notifyNow(this)
            toast("نوٹیفکیشن بھیج دیا گیا")
        })
    }

    private fun showTime() {
        val h = Store.int(this, "rem_h", 20)
        val m = Store.int(this, "rem_m", 0)
        val h12 = if (h % 12 == 0) 12 else h % 12
        timeTv.text = "وقت: " + String.format("%02d:%02d", h12, m) + if (h < 12) " صبح" else " شام"
    }
}
