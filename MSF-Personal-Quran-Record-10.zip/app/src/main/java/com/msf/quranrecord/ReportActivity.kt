package com.msf.quranrecord

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import org.json.JSONObject
import java.util.Calendar

class ReportActivity : BaseActivity() {
    private var mode = "monthly"
    private val sel: Calendar = Calendar.getInstance()
    private var recs: List<JSONObject> = emptyList()
    private lateinit var body: LinearLayout
    private lateinit var sv: ScrollView
    private var chartsRow: View? = null
    private var pdfRow: View? = null

    private class Stats(
        val hifz: Int, val nazra: Int, val rep: Int, val reph: Int, val repn: Int, val min: Int,
        val tH: Int, val tN: Int, val tR: Int, val tT: Int
    )

    private val modeName = mapOf("daily" to "روزانہ", "weekly" to "ہفتہ وار", "monthly" to "ماہانہ")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())

        val tr = hbox()
        tr.setPadding(dp(12), dp(12), dp(12), dp(2))
        tr.addView(tv("📊", 34f, "#0F5A2B", false, Gravity.CENTER), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        val tt = vbox()
        tt.addView(tv("رپورٹ اور گراف", 22f, "#222222", true))
        tt.addView(tv("اپنی پیش رفت کا جائزہ لیں", 13f, "#333333"))
        tr.addView(tt, lp(0, WRAP, 1f))
        content.addView(tr)

        body = vbox()
        body.setPadding(dp(10), 0, dp(10), dp(16))
        content.addView(body)

        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- data ----------
    private fun range(): Pair<Calendar, Calendar> {
        val s = sel.clone() as Calendar
        val e = sel.clone() as Calendar
        when (mode) {
            "monthly" -> {
                s.set(Calendar.DAY_OF_MONTH, 1)
                e.set(Calendar.DAY_OF_MONTH, e.getActualMaximum(Calendar.DAY_OF_MONTH))
            }
            "weekly" -> s.add(Calendar.DAY_OF_YEAR, -6)
        }
        return Pair(s, e)
    }

    private fun selText(): String {
        val (s, e) = range()
        return when (mode) {
            "monthly" -> "${Fmt.months[sel.get(Calendar.MONTH)]} ${sel.get(Calendar.YEAR)}"
            "weekly" -> "${s.get(Calendar.DAY_OF_MONTH)} ${Fmt.months[s.get(Calendar.MONTH)]} – ${Fmt.fmt(e)}"
            else -> Fmt.fmt(sel)
        }
    }

    private fun total(cat: String, a: String, b: String): Int {
        var s = 0
        for (r in recs) {
            val d = r.getString("d")
            if (d < a || d > b) continue
            s += when (cat) {
                "hifz" -> r.optInt("hpg", 0)
                "nazra" -> if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                "rep" -> r.optInt("rep", 0)
                "reph" -> r.optInt("reph", 0)
                "repn" -> if (r.has("repn") || r.has("reph")) r.optInt("repn", 0) else r.optInt("rep", 0)
                else -> r.optInt("min", 0)
            }
        }
        return s
    }

    private fun stats(a: String, b: String) = Stats(
        total("hifz", a, b), total("nazra", a, b), total("rep", a, b),
        total("reph", a, b), total("repn", a, b), total("min", a, b),
        Store.int(this, "tg_hifz_$mode"), Store.int(this, "tg_nazra_$mode"),
        Store.int(this, "tg_rep_$mode"), Store.int(this, "tg_time_$mode")
    )

    private fun pctOf(v: Int, t: Int) = if (t > 0) minOf(100, v * 100 / t) else 0
    private fun light(acc: String): Int = (c(acc) and 0x00FFFFFF) or (0x33 shl 24)

    private fun buckets(): List<Triple<String, String, String>> {
        val out = mutableListOf<Triple<String, String, String>>()
        when (mode) {
            "monthly" -> for (i in 4 downTo 0) {
                val m = sel.clone() as Calendar
                m.set(Calendar.DAY_OF_MONTH, 1)
                m.add(Calendar.MONTH, -i)
                val s = Fmt.key(m)
                val label = Fmt.months[m.get(Calendar.MONTH)]
                m.set(Calendar.DAY_OF_MONTH, m.getActualMaximum(Calendar.DAY_OF_MONTH))
                out.add(Triple(label, s, Fmt.key(m)))
            }
            "weekly" -> for (i in 4 downTo 0) {
                val e = sel.clone() as Calendar
                e.add(Calendar.DAY_OF_YEAR, -7 * i)
                val s = e.clone() as Calendar
                s.add(Calendar.DAY_OF_YEAR, -6)
                out.add(Triple("${e.get(Calendar.DAY_OF_MONTH)}/${e.get(Calendar.MONTH) + 1}", Fmt.key(s), Fmt.key(e)))
            }
            else -> for (i in 6 downTo 0) {
                val d = sel.clone() as Calendar
                d.add(Calendar.DAY_OF_YEAR, -i)
                out.add(Triple("${d.get(Calendar.DAY_OF_MONTH)}", Fmt.key(d), Fmt.key(d)))
            }
        }
        return out
    }

    // ---------- UI ----------
    private fun refresh() {
        recs = Store.list(this, "records")
        body.removeAllViews()
        val (s, e) = range()
        val st = stats(Fmt.key(s), Fmt.key(e))

        body.addView(controls(), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        val row = hbox()
        row.gravity = Gravity.TOP
        row.addView(statCard("📖", "حفظ", "#0F6B33", "#EAF7EC", "#A8D5B0", st.hifz, "پڑھے گئے صفحات", st.tH), lp(0, WRAP, 1f, 0, 0, 3, 0))
        row.addView(statCard("📘", "ناظرہ", "#0B4F9C", "#E8F3FF", "#A9CDF2", st.nazra, "پڑھے گئے صفحات", st.tN), lp(0, WRAP, 1f, 3, 0, 3, 0))
        row.addView(statCard("🔄", "دہرائی", "#6A2FB0", "#F3ECFB", "#CBBDEB", st.rep, "کل دہرائیوں کی تعداد", st.tR), lp(0, WRAP, 1f, 3, 0, 3, 0))
        row.addView(statCard("🕐", "تلاوت کا وقت", "#C98A0E", "#FFF6E3", "#F0D9A0", st.min, "منٹ", st.tT), lp(0, WRAP, 1f, 3, 0, 0, 0))
        body.addView(row, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        val charts = hbox()
        charts.gravity = Gravity.TOP
        charts.addView(chartCard(), lp(0, WRAP, 1.55f, 0, 0, 4, 0))
        charts.addView(donutCard(st), lp(0, WRAP, 1f, 4, 0, 0, 0))
        body.addView(charts, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        chartsRow = charts

        val tp = hbox()
        tp.gravity = Gravity.TOP
        tp.addView(tableCard(st), lp(0, WRAP, 1.6f, 0, 0, 4, 0))
        tp.addView(pdfCard(st), lp(0, WRAP, 1f, 4, 0, 0, 0))
        body.addView(tp, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        pdfRow = tp

        body.addView(tipsCard(st, s, e), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        val focus = intent.getStringExtra("focus")
        if (focus != null) {
            intent.removeExtra("focus")
            val tgt = if (focus == "chart") chartsRow else pdfRow
            if (tgt != null) sv.post { sv.scrollTo(0, body.top + tgt.top) }
        }
    }

    private fun controls(): View {
        val r = hbox()
        val tabs = hbox()
        bg(tabs, "#FFFFFF", "#D5E6D8", 12)
        for (m in listOf("daily", "weekly", "monthly")) {
            val on = m == mode
            val t = tv(modeName[m]!!, 12f, if (on) "#FFFFFF" else "#333333", on, Gravity.CENTER)
            t.setPadding(dp(6), dp(9), dp(6), dp(9))
            if (on) bg(t, "#0F5A2B", null, 10)
            t.setOnClickListener { mode = m; refresh() }
            tabs.addView(t, lp(0, WRAP, 1f, 2, 2, 2, 2))
        }
        r.addView(tabs, lp(0, WRAP, 1f, 0, 0, 6, 0))

        val bar = hbox()
        bg(bar, "#FFFFFF", "#D5E6D8", 12)
        val prev = tv("‹", 24f, "#0F5A2B", true)
        prev.setPadding(dp(8), 0, dp(6), 0)
        prev.setOnClickListener { step(-1) }
        val next = tv("›", 24f, "#0F5A2B", true)
        next.setPadding(dp(6), 0, dp(8), 0)
        next.setOnClickListener { step(1) }
        val dt = tv("🗓️ " + selText(), 11f, "#222222", true, Gravity.CENTER)
        dt.setPadding(0, dp(8), 0, dp(8))
        dt.setOnClickListener { pickDate() }
        bar.addView(prev)
        bar.addView(dt, lp(0, WRAP, 1f))
        bar.addView(next)
        r.addView(bar, lp(0, WRAP, 1.25f))
        return r
    }

    private fun step(d: Int) {
        when (mode) {
            "monthly" -> sel.add(Calendar.MONTH, d)
            "weekly" -> sel.add(Calendar.DAY_OF_YEAR, 7 * d)
            else -> sel.add(Calendar.DAY_OF_YEAR, d)
        }
        refresh()
    }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d -> sel.set(y, m, d); refresh() },
            sel.get(Calendar.YEAR), sel.get(Calendar.MONTH), sel.get(Calendar.DAY_OF_MONTH)).show()
    }

    private fun statCard(icon: String, title: String, acc: String, fill: String, stroke: String,
                         value: Int, sub: String, t: Int): View {
        val pct = pctOf(value, t)
        val card = vbox()
        card.setPadding(dp(6), dp(8), dp(6), dp(8))
        bg(card, fill, stroke, 14)
        card.setOnClickListener { go(TargetActivity::class.java) }
        val top = hbox()
        val ic = tv(icon, 14f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, acc)
        top.addView(ic, lp(dp(28), dp(28), 0f, 0, 0, 3, 0))
        top.addView(tv(title, 11f, acc, true, Gravity.END), lp(0, WRAP, 1f))
        card.addView(top)
        card.addView(tv("$value", 26f, "#222222", true, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        card.addView(tv(sub, 9f, "#555555", false, Gravity.CENTER))
        card.addView(tv(if (t > 0) "ٹارگٹ: $t" else "ٹارگٹ: --", 10f, "#333333", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        val bot = hbox()
        bot.addView(BarView(this, pct / 100f, c(acc), light(acc)), lp(0, dp(6), 1f, 0, 0, 4, 0))
        bot.addView(tv("$pct%", 9f, acc, true))
        card.addView(bot, lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        return card
    }

    private fun dot(col: String, text: String): View {
        val h = hbox()
        val d = View(this)
        circle(d, col)
        h.addView(d, lp(dp(9), dp(9), 0f, 0, 0, 4, 0))
        h.addView(tv(text, 10f, "#333333"))
        return h
    }

    private fun chartCard(): View {
        val card = vbox()
        card.setPadding(dp(8), dp(10), dp(8), dp(8))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        card.addView(tv("📊 حفظ اور ناظرہ کی پیش رفت", 12f, "#222222", true))
        val lg = hbox()
        lg.addView(dot("#1FA25A", "حفظ"), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        lg.addView(dot("#1E6FD9", "ناظرہ"))
        card.addView(lg, lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        val bs = buckets()
        val a = bs.map { total("hifz", it.second, it.third) }
        val b = bs.map { total("nazra", it.second, it.third) }
        card.addView(GroupBarView(this, bs.map { it.first }, a, b, c("#1FA25A"), c("#1E6FD9")), lp(MATCH, dp(190), 0f, 0, 4, 0, 0))
        return card
    }

    private fun donutCard(st: Stats): View {
        val card = vbox()
        card.setPadding(dp(8), dp(10), dp(8), dp(10))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        card.addView(tv("🥧 کل دہرائیوں کی تقسیم", 12f, "#222222", true))
        val fl = FrameLayout(this)
        fl.addView(DonutView(this, st.reph, st.repn, c("#1FA25A"), c("#1E6FD9")), FrameLayout.LayoutParams(dp(110), dp(110)))
        val ct = vbox()
        ct.gravity = Gravity.CENTER
        ct.addView(tv("کل دہرائیوں\nکی تعداد", 8f, "#555555", false, Gravity.CENTER))
        ct.addView(tv("${st.reph + st.repn}", 22f, "#222222", true, Gravity.CENTER))
        fl.addView(ct, FrameLayout.LayoutParams(dp(110), dp(110)))
        val wrap = LinearLayout(this)
        wrap.gravity = Gravity.CENTER
        wrap.addView(fl, LinearLayout.LayoutParams(dp(110), dp(110)))
        card.addView(wrap, lp(MATCH, WRAP, 0f, 0, 8, 0, 8))
        val tot = (st.reph + st.repn).coerceAtLeast(1)
        val ph = if (st.reph + st.repn == 0) 0 else Math.round(st.reph * 100f / tot)
        val pn = if (st.reph + st.repn == 0) 0 else 100 - ph
        card.addView(dot("#1FA25A", "حفظ:  ${st.reph} ($ph%)"))
        card.addView(dot("#1E6FD9", "ناظرہ:  ${st.repn} ($pn%)"), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        return card
    }

    private fun tableCard(st: Stats): View {
        val card = vbox()
        card.setPadding(dp(8), dp(10), dp(8), dp(8))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        card.addView(tv("🎯 ٹارگٹ بمقابلہ اصل کارکردگی", 12f, "#222222", true))

        fun cell(t: String, w: Float, col: String = "#222222", bold: Boolean = false, sp: Float = 10f): View =
            tv(t, sp, col, bold, Gravity.CENTER).also { it.layoutParams = lp(0, WRAP, w) }

        val hr = hbox()
        hr.setPadding(dp(2), dp(6), dp(2), dp(6))
        bg(hr, "#EEF1E8", null, 8)
        hr.addView(cell("عمل", 1.5f, "#222222", true))
        hr.addView(cell("ٹارگٹ", 1f, "#222222", true))
        hr.addView(cell("حاصل شدہ", 1f, "#222222", true))
        hr.addView(cell("باقی", 1f, "#222222", true))
        card.addView(hr, lp(MATCH, WRAP, 0f, 0, 6, 0, 2))

        data class R(val icon: String, val name: String, val acc: String, val v: Int, val t: Int, val unit: String)
        val rows = listOf(
            R("📖", "حفظ", "#0F6B33", st.hifz, st.tH, "صفحہ"),
            R("📘", "ناظرہ", "#0B4F9C", st.nazra, st.tN, "صفحہ"),
            R("🔄", "دہرائی", "#6A2FB0", st.rep, st.tR, "بار"),
            R("🕐", "تلاوت", "#C98A0E", st.min, st.tT, "منٹ")
        )
        for (r in rows) {
            val line = hbox()
            line.setPadding(dp(2), dp(7), dp(2), dp(7))
            val first = hbox()
            val ic = tv(r.icon, 9f, "#FFFFFF", false, Gravity.CENTER)
            circle(ic, r.acc)
            first.addView(ic, lp(dp(18), dp(18), 0f, 0, 0, 2, 0))
            first.addView(tv(r.name, 10f, r.acc, true))
            first.layoutParams = lp(0, WRAP, 1.5f)
            line.addView(first)
            line.addView(cell(if (r.t > 0) "${r.t} ${r.unit}" else "—", 1f))
            line.addView(cell("${r.v} ${r.unit}", 1f))
            line.addView(cell(if (r.t > 0) "${(r.t - r.v).coerceAtLeast(0)} ${r.unit}" else "—", 1f))
            card.addView(line)
            val sp = View(this)
            sp.setBackgroundColor(c("#E6EBE2"))
            card.addView(sp, lp(MATCH, dp(1)))
        }
        return card
    }

    private fun pdfCard(st: Stats): View {
        val card = vbox()
        card.setPadding(dp(8), dp(10), dp(8), dp(10))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        card.addView(tv("📄 ${modeName[mode]} رپورٹ", 12f, "#222222", true))
        card.addView(tv("تفصیلی رپورٹ محفوظ کریں", 10f, "#555555"))
        val inner = vbox()
        inner.setPadding(dp(6), dp(8), dp(6), dp(8))
        bg(inner, "#F1F8F2", "#CFE3D3", 10)
        inner.addView(tv("PDF", 20f, "#0F6B33", true, Gravity.CENTER))
        inner.addView(tv("${selText()} کی رپورٹ", 11f, "#222222", true, Gravity.CENTER))
        inner.addView(tv("حفظ + ناظرہ + دہرائی + تلاوت کا وقت", 8f, "#555555", false, Gravity.CENTER))
        card.addView(inner, lp(MATCH, WRAP, 0f, 0, 8, 0, 8))
        val b = tv("⬇  ڈاؤنلوڈ کریں", 12f, "#FFFFFF", true, Gravity.CENTER)
        b.setPadding(dp(6), dp(11), dp(6), dp(11))
        bg(b, "#0F6B33", null, 10)
        b.setOnClickListener { exportPdf(st) }
        card.addView(b)
        return card
    }

    private fun tipsCard(st: Stats, s: Calendar, e: Calendar): View {
        val card = hbox()
        card.gravity = Gravity.TOP
        card.setPadding(dp(10), dp(10), dp(10), dp(10))
        bg(card, "#EAF3E4", "#CFE2C9", 14)

        val tips = mutableListOf<String>()
        val ph = pctOf(st.hifz, st.tH); val pn = pctOf(st.nazra, st.tN)
        if (st.tH == 0 && st.tN == 0) tips.add("ٹارگٹ اسکرین سے اپنے اہداف مقرر کریں تاکہ پیش رفت ناپی جا سکے۔")
        else if ((st.tH == 0 || ph >= 80) && (st.tN == 0 || pn >= 80)) tips.add("آپ کی حفظ اور ناظرہ کی کارکردگی تسلی بخش ہے۔")
        else tips.add("حفظ اور ناظرہ کی رفتار بڑھانے کی کوشش کریں۔")
        if (st.tR > 0 && st.rep >= st.tR) tips.add("دہرائی کا ہدف پورا ہو گیا، ماشاءاللہ۔")
        else tips.add("اگلی مدت میں دہرائیوں کی تعداد بڑھانے کی کوشش کریں۔")
        val now = Calendar.getInstance()
        val last = if (e.after(now)) now else e
        val days = (((last.timeInMillis - s.timeInMillis) / 86400000L).toInt() + 1).coerceAtLeast(1)
        if (st.min / days >= 30) tips.add("تلاوت کا وقت اچھا ہے، اسے جاری رکھیں۔")
        else tips.add("روزانہ تلاوت کا وقت کم از کم 30 منٹ رکھیں۔")

        val left = vbox()
        left.addView(tv("💡 اہم نکات", 14f, "#0F5A2B", true))
        for (t in tips) left.addView(tv("✓  $t", 11f, "#333333"), lp(MATCH, WRAP, 0f, 0, 5, 0, 0))
        card.addView(left, lp(0, WRAP, 1.5f, 0, 0, 8, 0))

        val right = vbox()
        right.gravity = Gravity.CENTER
        right.addView(tv("وَرَتِّلِ الْقُرْآنَ تَرْتِيلًا", 14f, "#0F5A2B", true, Gravity.CENTER))
        right.addView(tv("اور قرآن کو ٹھہر ٹھہر کر پڑھو۔", 10f, "#333333", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        right.addView(tv("(سورۃ المزمل: 4)", 9f, "#555555", false, Gravity.CENTER))
        card.addView(right, lp(0, WRAP, 1f))
        return card
    }

    // ---------- PDF ----------
    private fun exportPdf(st: Stats) {
        try {
            val (s, e) = range()
            val a = Fmt.key(s); val b = Fmt.key(e)
            val dark = Color.parseColor("#0F5A2B")
            val lines = mutableListOf<PdfExport.Line>()
            lines.add(PdfExport.Line("MSF Personal Quran Record", 20f, true, dark))
            lines.add(PdfExport.Line("${modeName[mode]} رپورٹ — ${selText()}", 14f, true))
            lines.add(PdfExport.Line("", 8f))
            fun cat(n: String, v: Int, t: Int, u: String) {
                val txt = if (t > 0) "حاصل $v $u  |  ٹارگٹ $t $u  |  باقی ${(t - v).coerceAtLeast(0)} $u  |  ${pctOf(v, t)}%"
                else "حاصل $v $u  |  ٹارگٹ مقرر نہیں"
                lines.add(PdfExport.Line("$n: $txt", 13f))
            }
            cat("حفظ", st.hifz, st.tH, "صفحہ")
            cat("ناظرہ", st.nazra, st.tN, "صفحہ")
            cat("دہرائی", st.rep, st.tR, "بار")
            cat("تلاوت کا وقت", st.min, st.tT, "منٹ")
            lines.add(PdfExport.Line("دہرائی کی تقسیم: حفظ ${st.reph} بار، ناظرہ ${st.repn} بار", 12f))
            lines.add(PdfExport.Line("", 10f))
            lines.add(PdfExport.Line("تفصیلی ریکارڈ", 15f, true, dark))
            val list = recs.filter { val d = it.getString("d"); d >= a && d <= b }.sortedByDescending { it.getString("d") }
            if (list.isEmpty()) lines.add(PdfExport.Line("اس مدت میں کوئی ریکارڈ نہیں", 12f))
            for (r in list) {
                val npg = if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                lines.add(PdfExport.Line(
                    "${r.getString("d")} | ${r.optString("session")} | حفظ ${r.optInt("hpg", 0)} ص | ناظرہ $npg ص | " +
                        "دہرائی ${r.optInt("rep", 0)} | ${r.optInt("min", 0)} منٹ" +
                        (if (r.optString("note").isNotBlank()) " | ${r.optString("note")}" else ""), 11f))
            }
            val doc = PdfExport.build(lines)
            val name = "MSF_Report_${a}_to_$b.pdf"
            val (uri, where) = PdfExport.save(this, doc, name)
            doc.close()
            showSaved(uri, where)
        } catch (ex: Exception) {
            toast("PDF نہیں بن سکی")
        }
    }

    private fun showSaved(uri: Uri?, where: String) {
        val b = AlertDialog.Builder(this).setTitle("رپورٹ محفوظ ہو گئی")
        if (uri == null) {
            b.setMessage("فائل یہاں محفوظ ہوئی:\n$where").setPositiveButton("ٹھیک ہے", null).show()
            return
        }
        b.setMessage("PDF ڈاؤنلوڈز فولڈر میں محفوظ ہو گئی۔")
            .setPositiveButton("کھولیں") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (ex: ActivityNotFoundException) {
                    toast("PDF کھولنے والی ایپ موجود نہیں")
                }
            }
            .setNeutralButton("شیئر کریں") { _, _ ->
                val i = Intent(Intent.ACTION_SEND).setType("application/pdf")
                    .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "رپورٹ شیئر کریں"))
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    // ---------- header / nav ----------
    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(10))
        h.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c("#13703A"), c("#0A3D1C")))

        val mid = hbox()
        val back = tv("←", 28f, "#FFFFFF", true)
        back.setOnClickListener { finish() }
        mid.addView(back, lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(View(this), lp(0, 1, 1f))
        val logoImg = logoView(96)
        mid.addView(logoImg, lp(dp(96), dp(96)))
        mid.addView(View(this), lp(0, 1, 1f))
        val cal = tv("🗓️", 26f, "#FFFFFF")
        cal.setOnClickListener { pickDate() }
        mid.addView(cal)
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val tabs = hbox()
        bg(tabs, "#0C4A24", "#B8962E", 12)
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val t = vbox()
            t.gravity = Gravity.CENTER
            t.setPadding(dp(2), dp(8), dp(2), dp(8))
            val active = i == 3
            if (active) bg(t, "#F8E7A6", null, 10)
            t.addView(tv(p.first, 20f, "#FFFFFF", false, Gravity.CENTER))
            t.addView(tv(p.second, 12f, if (active) "#3A2A00" else "#FFFFFF", true, Gravity.CENTER))
            t.setOnClickListener { tab(i) }
            tabs.addView(t, lp(0, WRAP, 1f, 1, 1, 1, 1))
        }
        h.addView(tabs)
        return h
    }

    private fun tab(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            1 -> { go(RecordActivity::class.java); finish() }
            2 -> { go(TargetActivity::class.java); finish() }
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 3
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(40), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { tab(i) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }
}
