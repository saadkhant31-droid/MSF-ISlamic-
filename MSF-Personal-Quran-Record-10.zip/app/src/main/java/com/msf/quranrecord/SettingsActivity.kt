package com.msf.quranrecord

import android.app.AlertDialog
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Outline
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.text.InputFilter
import android.text.InputType
import android.text.TextUtils
import android.view.Gravity
import android.view.View
import android.view.ViewOutlineProvider
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File

class SettingsActivity : BaseActivity() {
    private lateinit var sv: ScrollView
    private lateinit var list: LinearLayout

    private val pickImg = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) saveAvatar(uri)
    }
    private val makeBackup = registerForActivityResult(ActivityResultContracts.CreateDocument()) { uri ->
        if (uri != null) writeBackup(uri)
    }
    private val openBackup = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) readBackup(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F4F8F4"))
        sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())
        list = vbox()
        list.setPadding(dp(10), dp(10), dp(10), dp(14))
        content.addView(list)
        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    // ---------- list ----------
    private fun render() {
        list.removeAllViews()
        list.addView(profileCard(), lp(MATCH, WRAP, 0f, 0, 0, 0, 8))

        list.addView(row("👤", "اکاؤنٹ اور پروفائل", "اپنا نام، تصویر اور ذاتی معلومات تبدیل کریں") { profileDialog() })
        list.addView(row("⚙️", "ایپ کی عمومی سیٹنگز", "فونٹ سائز، پڑھنے کے اوقات اور ڈیٹا ری سیٹ") { generalDialog() })
        val on = Store.bool(this, "rem_on")
        list.addView(row("🔔", "یاد دہانی (نوٹیفیکیشنز)", "قرآن پڑھنے کی یاد دہانی کا وقت مقرر کریں",
            if (on) "آن" else "آف", if (on) "#1F9D55" else "#8A8F8A") { go(ReminderActivity::class.java) })
        list.addView(row("🎯", "ٹارگٹ سیٹنگز", "روزانہ، ہفتہ وار اور ماہانہ اہداف مقرر کریں") { go(TargetActivity::class.java) })
        list.addView(row("☁️", "بیک اپ اور بحالی", "اپنا ریکارڈ محفوظ کریں اور دوبارہ بحال کریں") { backupDialog() })
        val locked = Store.str(this, "pin").isNotBlank()
        list.addView(row("🔒", "ذاتی ریکارڈ کی حفاظت", "پاس کوڈ، فنگر پرنٹ اور رازداری کی ترتیبات",
            if (locked) "فعال" else null) { privacyDialog() })
        list.addView(row("🎨", "ظاہری شکل (تھیم)", "اپنی پسند کے مطابق تھیم منتخب کریں",
            Themes.names[Themes.index(this)], "#0B3D1E") { themeDialog() })
        list.addView(row("❓", "مدد اور سپورٹ", "سوالات، رہنمائی اور رابطہ کریں") { helpDialog() })
        list.addView(row("ℹ️", "ایپ کے بارے میں", "ایپ کی معلومات، شرائط و ضوابط") { aboutDialog() })
        list.addView(row("🚪", "لاگ آؤٹ", "اپنے اکاؤنٹ سے لاگ آؤٹ کریں", null, "#0F5A2B", true) { logout() })
    }

    private fun row(
        icon: String, title: String, sub: String, badge: String? = null,
        badgeFill: String = "#0F5A2B", dark: Boolean = false, onClick: () -> Unit
    ): View {
        val r = hbox()
        r.setPadding(dp(10), dp(10), dp(12), dp(10))
        if (dark) bg(r, "#0F5A2B", "#0B3D1E", 14) else bg(r, "#FFFFFF", "#BBD7C0", 14)
        val ic = tv(icon, 18f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, if (dark) "#FFFFFF" else "#0F6B33")
        r.addView(ic, lp(dp(44), dp(44), 0f, 0, 0, 10, 0))
        val t = vbox()
        t.addView(tv(title, 15f, if (dark) "#FFFFFF" else "#222222", true))
        t.addView(tv(sub, 11f, if (dark) "#DCEBDD" else "#666666"), lp(MATCH, WRAP, 0f, 0, 2, 0, 0))
        r.addView(t, lp(0, WRAP, 1f))
        if (badge != null) {
            val b = tv(badge, 11f, "#FFFFFF", true, Gravity.CENTER)
            b.setPadding(dp(12), dp(5), dp(12), dp(5))
            bg(b, badgeFill, null, 14)
            r.addView(b, lp(WRAP, WRAP, 0f, 4, 0, 4, 0))
        }
        r.addView(tv("›", 26f, if (dark) "#FFFFFF" else "#0F5A2B", true), lp(WRAP, WRAP, 0f, 6, 0, 0, 0))
        r.setOnClickListener { onClick() }
        val w = vbox()
        w.addView(r)
        return w.also { it.setPadding(0, 0, 0, dp(8)) }
    }

    private fun profileCard(): View {
        val card = hbox()
        card.setPadding(dp(10), dp(10), dp(10), dp(10))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        card.addView(avatar(), lp(dp(58), dp(58), 0f, 0, 0, 8, 0))

        val info = vbox()
        val nameRow = hbox()
        val name = tv(Store.str(this, "profile_name", "Muhammad Sohaib"), 14f, "#222222", true)
        name.maxLines = 1
        name.ellipsize = TextUtils.TruncateAt.END
        nameRow.addView(name, lp(0, WRAP, 1f))
        val pen = tv("✏️", 12f, "#000000", false, Gravity.CENTER)
        bg(pen, "#EEF3EE", null, 10)
        pen.setOnClickListener { profileDialog() }
        nameRow.addView(pen, lp(dp(26), dp(26), 0f, 4, 0, 4, 0))
        info.addView(nameRow)
        info.addView(tv(Store.str(this, "profile_sub", "اللہ کے فضل سے"), 11f, "#555555"))
        val ver = tv("⚙ ایپ ورژن ${version()}", 10f, "#0F5A2B", true, Gravity.CENTER)
        ver.setPadding(dp(8), dp(4), dp(8), dp(4))
        bg(ver, "#E8F3E8", null, 8)
        ver.setOnClickListener { aboutDialog() }
        info.addView(ver, lp(WRAP, WRAP, 0f, 0, 6, 0, 0))
        card.addView(info, lp(0, WRAP, 1.15f))

        val panel = vbox()
        panel.gravity = Gravity.CENTER
        panel.setPadding(dp(8), dp(8), dp(8), dp(8))
        panel.background = MosqueArt(true, dp(12).toFloat())
        panel.addView(tv("اللہ کے کلام کی تلاوت زندگی کی کامیابی ہے۔", 11f, "#0F5A2B", true, Gravity.CENTER))
        card.addView(panel, lp(0, MATCH, 0.85f, 4, 0, 0, 0))
        return card
    }

    private fun avatar(): View {
        val f = File(filesDir, "profile.jpg")
        val bmp = if (f.exists()) BitmapFactory.decodeFile(f.absolutePath) else null
        val iv = ImageView(this)
        iv.scaleType = ImageView.ScaleType.CENTER_CROP
        if (bmp != null) iv.setImageBitmap(bmp) else iv.setImageResource(R.drawable.msf_logo)
        iv.outlineProvider = object : ViewOutlineProvider() {
            override fun getOutline(view: View, outline: Outline) {
                outline.setOval(0, 0, view.width, view.height)
            }
        }
        iv.clipToOutline = true
        iv.setOnClickListener { pickImg.launch("image/*") }
        return iv
    }

    private fun version(): String = try {
        packageManager.getPackageInfo(packageName, 0).versionName ?: "1.0"
    } catch (e: Exception) {
        "1.0"
    }

    private fun saveAvatar(uri: android.net.Uri) {
        try {
            val opts = BitmapFactory.Options()
            opts.inJustDecodeBounds = true
            contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, opts) }
            var sample = 1
            while (opts.outWidth / sample > 600 || opts.outHeight / sample > 600) sample *= 2
            val o2 = BitmapFactory.Options()
            o2.inSampleSize = sample
            val bmp = contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
            if (bmp == null) {
                toast("تصویر نہیں کھل سکی")
                return
            }
            File(filesDir, "profile.jpg").outputStream().use { bmp.compress(android.graphics.Bitmap.CompressFormat.JPEG, 90, it) }
            toast("تصویر محفوظ ہو گئی")
            render()
        } catch (ex: Exception) {
            toast("تصویر محفوظ نہیں ہو سکی")
        }
    }

    // ---------- dialogs ----------
    private fun profileDialog() {
        val col = vbox()
        col.setPadding(dp(20), dp(10), dp(20), 0)
        val n = input("آپ کا نام")
        n.setText(Store.str(this, "profile_name", "Muhammad Sohaib"))
        val s = input("تعارفی جملہ")
        s.setText(Store.str(this, "profile_sub", "اللہ کے فضل سے"))
        col.addView(n)
        col.addView(s)
        AlertDialog.Builder(this).setTitle("اکاؤنٹ اور پروفائل").setView(col)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val nm = n.text.toString().trim()
                if (nm.isNotEmpty()) Store.putStr(this, "profile_name", nm)
                Store.putStr(this, "profile_sub", s.text.toString().trim())
                toast("پروفائل محفوظ ہو گئی")
                render()
            }
            .setNeutralButton("تصویر بدلیں") { _, _ -> pickImg.launch("image/*") }
            .setNegativeButton("منسوخ", null).showF()
    }

    private fun generalDialog() {
        val items = arrayOf("📏  فونٹ سائز", "🔠  ایپ کا فونٹ", "🔤  عنوان کا فونٹ", "📖  آیات کا فونٹ",
            "⏰  پڑھنے کے اوقات", "📖  حفظ ری سیٹ کریں", "📘  ناظرہ ری سیٹ کریں", "🗑️  تمام ڈیٹا مٹائیں")
        AlertDialog.Builder(this).setTitle("ایپ کی عمومی سیٹنگز").setItems(items) { _, i ->
            when (i) {
                0 -> fontDialog()
                1 -> fontChooser("ایپ کا فونٹ", AppFonts.BODY, AppFonts.DEF_BODY, "ذاتی حفظ و ناظرہ ریکارڈ ایپ")
                2 -> fontChooser("عنوان کا فونٹ", AppFonts.TITLE, AppFonts.DEF_TITLE, "ذاتی حفظ و ناظرہ ریکارڈ")
                3 -> fontChooser("آیات کا فونٹ", AppFonts.QURAN, AppFonts.DEF_QURAN, "وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ")
                4 -> go(TimesActivity::class.java)
                5 -> confirm("حفظ کے تمام پارے صاف کریں؟") {
                    Store.savePara(this, "hifz", emptySet()); Store.putStr(this, "hifz_date", "")
                }
                6 -> confirm("ناظرہ کے تمام پارے اور دہرائی صاف کریں؟") {
                    Store.savePara(this, "nazra", emptySet()); Store.putInt(this, "nazra_rep", 0)
                }
                7 -> confirm("ایپ کا تمام ڈیٹا مٹا دیا جائے؟ یہ واپس نہیں ہو سکے گا۔") {
                    Store.clearAll(this)
                    File(filesDir, "profile.jpg").delete()
                    Reminder.schedule(this)
                    Lock.unlocked = true
                    recreate()
                }
                else -> {}
            }
        }.setNegativeButton("بند کریں", null).showF()
    }

    /** Lists every bundled font, each drawn in its own typeface, and saves the pick. */
    private fun fontChooser(title: String, key: String, def: String, sample: String) {
        val opts = AppFonts.opts
        val cur = opts.indexOfFirst { it.key == Store.str(this, key, def) }.coerceAtLeast(0)
        val labels = opts.map { if (it.file == null) it.label else sample + "\n" + it.label }
        val ad = object : android.widget.ArrayAdapter<String>(this, android.R.layout.simple_list_item_single_choice, labels) {
            override fun getView(position: Int, convertView: View?, parent: android.view.ViewGroup): View {
                val v = super.getView(position, convertView, parent) as android.widget.TextView
                val tf = AppFonts.get(this@SettingsActivity, opts[position].key)
                if (tf != null) v.typeface = tf
                v.textSize = 17f
                return v
            }
        }
        AlertDialog.Builder(this).setTitle(title)
            .setSingleChoiceItems(ad, cur) { d, i ->
                Store.putStr(this, key, opts[i].key)
                d.dismiss()
                toast("فونٹ تبدیل ہو گیا")
                recreate()
            }.setNegativeButton("بند کریں", null).show()
    }

    private fun fontDialog() {
        val names = arrayOf("چھوٹا", "درمیانہ (معمول)", "بڑا", "بہت بڑا")
        val pcts = intArrayOf(90, 100, 115, 130)
        val cur = pcts.indexOf(Store.int(this, "font_pct", 100)).coerceAtLeast(0)
        AlertDialog.Builder(this).setTitle("فونٹ سائز")
            .setSingleChoiceItems(names, cur) { d, i ->
                Store.putInt(this, "font_pct", pcts[i])
                d.dismiss()
                recreate()
            }.setNegativeButton("بند کریں", null).showF()
    }

    private fun themeDialog() {
        AlertDialog.Builder(this).setTitle("ظاہری شکل (تھیم)")
            .setSingleChoiceItems(Themes.names.toTypedArray(), Themes.index(this)) { d, i ->
                Store.putInt(this, "theme", i)
                d.dismiss()
                recreate()
            }.setNegativeButton("بند کریں", null).showF()
    }

    private fun backupDialog() {
        val items = arrayOf("☁️  بیک اپ فائل بنائیں", "♻️  بیک اپ سے بحال کریں")
        AlertDialog.Builder(this).setTitle("بیک اپ اور بحالی").setItems(items) { _, i ->
            if (i == 0) makeBackup.launch("MSF_Quran_Backup.json")
            else confirm("بحال کرنے سے موجودہ ریکارڈ بیک اپ کے ریکارڈ سے بدل جائے گا۔ جاری رکھیں؟", false) {
                openBackup.launch(arrayOf("*/*"))
            }
        }.setNegativeButton("بند کریں", null).showF()
    }

    private fun writeBackup(uri: android.net.Uri) {
        try {
            contentResolver.openOutputStream(uri)?.use { it.write(Store.exportAll(this).toByteArray(Charsets.UTF_8)) }
            toast("بیک اپ محفوظ ہو گیا")
        } catch (ex: Exception) {
            toast("بیک اپ نہیں بن سکا")
        }
    }

    private fun readBackup(uri: android.net.Uri) {
        try {
            val text = contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) }
            Store.importAll(this, text)
            Reminder.schedule(this)
            toast("ریکارڈ بحال ہو گیا")
            recreate()
        } catch (ex: Exception) {
            toast("یہ درست بیک اپ فائل نہیں ہے")
        }
    }

    private fun privacyDialog() {
        val has = Store.str(this, "pin").isNotBlank()
        val labels = mutableListOf<String>()
        val acts = mutableListOf<() -> Unit>()
        if (!has) {
            labels.add("🔢  پن کوڈ لگائیں"); acts.add { pinDialog("set") }
        } else {
            labels.add("🔢  پن کوڈ تبدیل کریں"); acts.add { pinDialog("change") }
            labels.add("🚫  پن کوڈ ہٹائیں"); acts.add { pinDialog("remove") }
            if (Build.VERSION.SDK_INT >= 28) {
                val fp = Store.bool(this, "fp_on")
                labels.add("👆  فنگر پرنٹ: " + if (fp) "آن (بند کریں)" else "آف (چالو کریں)")
                acts.add {
                    Store.putBool(this, "fp_on", !fp)
                    toast(if (fp) "فنگر پرنٹ بند" else "فنگر پرنٹ چالو")
                }
            }
        }
        AlertDialog.Builder(this).setTitle("ذاتی ریکارڈ کی حفاظت")
            .setItems(labels.toTypedArray()) { _, i -> acts[i]() }
            .setNegativeButton("بند کریں", null).showF()
    }

    private fun pinDialog(mode: String) {
        val has = Store.str(this, "pin").isNotBlank()
        val col = vbox()
        col.setPadding(dp(20), dp(10), dp(20), 0)
        fun field(h: String): EditText {
            val e = input(h, true)
            e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            e.filters = arrayOf(InputFilter.LengthFilter(6))
            return e
        }
        val old = if (has) field("موجودہ پن کوڈ") else null
        val n1 = if (mode != "remove") field("نیا پن (4 سے 6 ہندسے)") else null
        val n2 = if (mode != "remove") field("پن دوبارہ لکھیں") else null
        for (e in listOfNotNull(old, n1, n2)) col.addView(e)
        val title = when (mode) { "set" -> "پن کوڈ لگائیں"; "change" -> "پن کوڈ تبدیل کریں"; else -> "پن کوڈ ہٹائیں" }
        val d = AlertDialog.Builder(this).setTitle(title).setView(col)
            .setPositiveButton("محفوظ کریں", null).setNegativeButton("منسوخ", null).create()
        d.setOnShowListener {
            d.getButton(android.content.DialogInterface.BUTTON_POSITIVE).setOnClickListener {
                if (old != null && old.text.toString() != Store.str(this, "pin")) {
                    toast("موجودہ پن کوڈ غلط ہے"); return@setOnClickListener
                }
                if (mode == "remove") {
                    Store.putStr(this, "pin", "")
                    Store.putBool(this, "fp_on", false)
                    toast("پن کوڈ ہٹا دیا گیا")
                } else {
                    val a = n1!!.text.toString()
                    if (a.length < 4) { toast("پن کم از کم 4 ہندسوں کا ہو"); return@setOnClickListener }
                    if (a != n2!!.text.toString()) { toast("دونوں پن ایک جیسے نہیں ہیں"); return@setOnClickListener }
                    Store.putStr(this, "pin", a)
                    Lock.unlocked = true
                    toast("پن کوڈ محفوظ ہو گیا")
                }
                d.dismiss()
                render()
            }
        }
        d.show()
        styleDialog(d)
    }

    private fun helpDialog() {
        val q = arrayOf("ریکارڈ کیسے شامل کریں؟", "ٹارگٹ کیسے مقرر کریں؟",
            "PDF رپورٹ کہاں محفوظ ہوتی ہے؟", "رائے / شکایت بھیجیں", "ایپ دوسروں کو بھیجیں")
        val a = arrayOf(
            "ہوم اسکرین سے \"روزانہ کا ریکارڈ\" کھولیں، حفظ، ناظرہ، دہرائی اور وقت درج کر کے محفوظ کریں۔",
            "نیچے \"ٹارگٹ\" ٹیب کھولیں اور روزانہ، ہفتہ وار یا ماہانہ ہدف درج کر دیں۔",
            "رپورٹ یا گراف اسکرین پر \"رپورٹ ڈاؤنلوڈ کریں\" دبائیں۔ فائل آپ کے فون کے ڈاؤنلوڈز فولڈر میں محفوظ ہوتی ہے۔",
            "", ""
        )
        AlertDialog.Builder(this).setTitle("مدد اور سپورٹ").setItems(q) { _, i ->
            when (i) {
                3 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_SUBJECT, "MSF Personal Quran Record — رائے")
                    .putExtra(Intent.EXTRA_TEXT, "السلام علیکم،\n"), "رائے بھیجیں"))
                4 -> startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).setType("text/plain")
                    .putExtra(Intent.EXTRA_TEXT, "MSF Personal Quran Record — ذاتی حفظ و ناظرہ ریکارڈ ایپ"), "ایپ شیئر کریں"))
                else -> AlertDialog.Builder(this).setTitle(q[i]).setMessage(a[i])
                    .setPositiveButton("ٹھیک ہے", null).showF()
            }
        }.setNegativeButton("بند کریں", null).showF()
    }

    private fun aboutDialog() {
        AlertDialog.Builder(this)
            .setTitle("MSF Personal Quran Record")
            .setMessage("ذاتی حفظ و ناظرہ ریکارڈ ایپ\nورژن ${version()}\n\n" +
                "تمام ڈیٹا صرف آپ کے فون میں محفوظ رہتا ہے۔ ایپ آپ کا ڈیٹا کسی کے ساتھ شیئر نہیں کرتی۔\n\n" +
                "شرائط: یہ ایپ ذاتی ریکارڈ رکھنے کے لیے ہے۔ ڈیٹا کی حفاظت کے لیے بیک اپ بناتے رہیں۔")
            .setPositiveButton("ٹھیک ہے", null).showF()
    }

    private fun logout() {
        AlertDialog.Builder(this)
            .setMessage("ایپ بند کر دی جائے؟ آپ کا ریکارڈ محفوظ رہے گا" +
                if (Store.str(this, "pin").isNotBlank()) "، اور دوبارہ کھولنے پر پن کوڈ پوچھا جائے گا۔" else "۔")
            .setPositiveButton("لاگ آؤٹ") { _, _ ->
                Lock.unlocked = false
                finishAffinity()
            }
            .setNegativeButton("نہیں", null).showF()
    }

    private fun confirm(msg: String, done: Boolean = true, action: () -> Unit) {
        AlertDialog.Builder(this).setMessage(msg)
            .setPositiveButton("ہاں") { _, _ -> action(); if (done) toast("مکمل ہو گیا") }
            .setNegativeButton("نہیں", null).showF()
    }

    // ---------- header / nav ----------
    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(14))
        h.background = MosqueArt(false)

        val mid = hbox()
        val back = tv("←", 28f, "#FFFFFF", true)
        back.setOnClickListener { finish() }
        mid.addView(back, lp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        mid.addView(tv("سیٹنگز", 18f, "#FFFFFF", true), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(View(this), lp(0, 1, 1f))
        val logoImg = logoView(96)
        logoImg.setOnClickListener { tab(0) }
        mid.addView(logoImg, lp(dp(96), dp(96)))
        mid.addView(View(this), lp(0, 1, 1f))
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        return h
    }

    private fun tab(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            1 -> { go(RecordActivity::class.java); finish() }
            2 -> { go(TargetActivity::class.java); finish() }
            3 -> { go(ReportActivity::class.java); finish() }
            4 -> sv.smoothScrollTo(0, 0)
        }
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 4
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(44), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { tab(i) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }
}
