package com.msf.quranrecord

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

object Store {
    private fun sp(c: Context) = c.getSharedPreferences("msf", Context.MODE_PRIVATE)

    fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())

    fun paras(c: Context, k: String): MutableSet<Int> =
        sp(c).getString(k, "")!!.split(",").filter { it.isNotBlank() }.map { it.toInt() }.toMutableSet()

    fun savePara(c: Context, k: String, s: Set<Int>) =
        sp(c).edit().putString(k, s.sorted().joinToString(",")).apply()

    fun int(c: Context, k: String, d: Int = 0): Int = sp(c).getInt(k, d)
    fun putInt(c: Context, k: String, v: Int) = sp(c).edit().putInt(k, v).apply()
    fun str(c: Context, k: String, d: String = ""): String = sp(c).getString(k, d) ?: d
    fun putStr(c: Context, k: String, v: String) = sp(c).edit().putString(k, v).apply()
    fun bool(c: Context, k: String): Boolean = sp(c).getBoolean(k, false)
    fun putBool(c: Context, k: String, v: Boolean) = sp(c).edit().putBoolean(k, v).apply()
    fun clearAll(c: Context) = sp(c).edit().clear().apply()

    fun list(c: Context, k: String): MutableList<JSONObject> {
        val a = JSONArray(sp(c).getString(k, "[]"))
        val out = mutableListOf<JSONObject>()
        for (i in 0 until a.length()) out.add(a.getJSONObject(i))
        return out
    }

    fun saveList(c: Context, k: String, l: List<JSONObject>) {
        val a = JSONArray()
        l.forEach { a.put(it) }
        sp(c).edit().putString(k, a.toString()).apply()
    }

    /** All saved data as JSON text (the app lock settings are not included). */
    fun exportAll(c: Context): String {
        val o = JSONObject()
        o.put("_msf_backup", 1)
        for ((k, v) in sp(c).all) {
            if (k == "pin" || k == "fp_on") continue
            when (v) {
                is Int -> o.put(k, JSONObject().put("t", "i").put("v", v))
                is Boolean -> o.put(k, JSONObject().put("t", "b").put("v", v))
                is String -> o.put(k, JSONObject().put("t", "s").put("v", v))
            }
        }
        return o.toString()
    }

    /** Restores a backup made by [exportAll]. Throws if the text is not a valid backup. */
    fun importAll(c: Context, text: String) {
        val o = JSONObject(text)
        if (!o.has("_msf_backup")) throw IllegalArgumentException("not a backup")
        val pin = str(c, "pin")
        val fp = bool(c, "fp_on")
        val e = sp(c).edit()
        e.clear()
        for (k in o.keys()) {
            if (k == "_msf_backup" || k == "pin" || k == "fp_on") continue
            val x = o.getJSONObject(k)
            when (x.getString("t")) {
                "i" -> e.putInt(k, x.getInt("v"))
                "b" -> e.putBoolean(k, x.getBoolean("v"))
                else -> e.putString(k, x.getString("v"))
            }
        }
        if (pin.isNotBlank()) e.putString("pin", pin)
        if (fp) e.putBoolean("fp_on", true)
        e.apply()
    }

    fun pagesOn(c: Context, d: String): Int = list(c, "records").filter { it.getString("d") == d }.sumOf { it.getInt("pages") }
    fun minutesOn(c: Context, d: String): Int = list(c, "records").filter { it.getString("d") == d }.sumOf { it.getInt("min") }
}

object Reminder {
    fun schedule(c: Context) {
        val am = c.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            c, 1, Intent(c, ReminderReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        am.cancel(pi)
        if (!Store.bool(c, "rem_on")) return
        val cal = Calendar.getInstance()
        cal.set(Calendar.HOUR_OF_DAY, Store.int(c, "rem_h", 20))
        cal.set(Calendar.MINUTE, Store.int(c, "rem_m", 0))
        cal.set(Calendar.SECOND, 0)
        if (cal.timeInMillis <= System.currentTimeMillis()) cal.add(Calendar.DAY_OF_YEAR, 1)
        am.setInexactRepeating(AlarmManager.RTC_WAKEUP, cal.timeInMillis, AlarmManager.INTERVAL_DAY, pi)
    }

    fun notifyNow(c: Context) {
        if (Build.VERSION.SDK_INT >= 33 &&
            c.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) return
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel("msf_rem", "Quran Reminder", NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val pi = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(c, "msf_rem")
            .setSmallIcon(android.R.drawable.ic_popup_reminder)
            .setContentTitle("MSF Personal Quran Record")
            .setContentText("آج کی تلاوت کا وقت ہو گیا ہے۔ قرآن پڑھیں!")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(77, n)
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) = Reminder.notifyNow(c)
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent?) = Reminder.schedule(c)
}
