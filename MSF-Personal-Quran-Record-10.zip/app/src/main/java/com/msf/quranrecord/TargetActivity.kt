package com.msf.quranrecord

import android.app.AlertDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import org.json.JSONObject
import java.util.Calendar

class TargetActivity : BaseActivity() {
    private class Cat(
        val key: String, val ur: String, val icon: String, val acc: String,
        val fill: String, val stroke: String, val unit: String
    )

    private val cats = listOf(
        Cat("hifz", "حفظ قرآن مجید", "📖", "#0F6B33", "#F1FAF3", "#BFE0C6", "صفحہ"),
        Cat("nazra", "ناظرہ قرآن مجید", "📘", "#0B4F9C", "#EEF6FF", "#B5D3F2", "صفحہ"),
        Cat("rep", "دہرائی", "🔄", "#6A2FB0", "#F6F0FC", "#D5C0EE", "بار"),
        Cat("time", "تلاوت کا وقت", "🕐", "#C98A0E", "#FFF8E8", "#F0D9A0", "منٹ")
    )
    private val tabNames = mapOf("hifz" to "حفظ", "nazra" to "ناظرہ", "rep" to "دہرائی", "time" to "تلاوت")
    private val pers = listOf("daily", "weekly", "monthly")
    private val perTab = mapOf("daily" to "روزانہ", "weekly" to "ہفتہ وار", "monthly" to "ماہانہ")
    private val perTarget = mapOf("daily" to "روزانہ کا ہدف", "weekly" to "ہفتہ وار ہدف", "monthly" to "ماہانہ ہدف")
    private val perLabel = mapOf("daily" to "آج", "weekly" to "7 دن", "monthly" to "اس ماہ")

    private val per = mutableMapOf<String, String>()
    private var filter: String? = null
    private var recs: List<JSONObject> = emptyList()

    private lateinit var summaryBox: LinearLayout
    private lateinit var catTabs: LinearLayout
    private lateinit var cardsBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        val sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())

        // Title + verse badge
        val tr = hbox()
        tr.setPadding(dp(12), dp(12), dp(12), dp(4))
        tr.addView(tv("🎯", 36f, "#0F5A2B", false, Gravity.CENTER), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        val tt = vbox()
        tt.addView(tv("ٹارگٹ", 24f, "#222222", true))
        tt.addView(tv("اپنے اہداف مقرر کریں اور اپنی پیش رفت دیکھیں", 12f, "#333333"))
        tr.addView(tt, lp(0, WRAP, 1f))
        val badge = vbox()
        badge.setPadding(dp(12), dp(8), dp(12), dp(8))
        bg(badge, "#0F5A2B", null, 14)
        badge.addView(tv("وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ", 13f, "#FFFFFF", true, Gravity.CENTER))
        badge.addView(tv("میری توفیق صرف اللہ ہی کے لیے ہے۔", 9f, "#CFE8D3", false, Gravity.CENTER))
        tr.addView(badge, lp(WRAP, WRAP, 0f, 6, 0, 0, 0))
        content.addView(tr)

        summaryBox = hbox()
        summaryBox.gravity = Gravity.TOP
        content.addView(summaryBox, lp(MATCH, WRAP, 0f, 10, 8, 10, 0))

        // Detail section
        val sec = vbox()
        sec.setPadding(dp(8), dp(10), dp(8), dp(8))
        bg(sec, "#FBFCF8", "#DDE5D6", 16)
        val hr = hbox()
        hr.addView(tv("🎯", 22f, "#0F5A2B"), lp(WRAP, WRAP, 0f, 4, 0, 8, 0))
        hr.addView(tv("تفصیلی ٹارگٹ سیٹ کریں", 16f, "#222222", true), lp(0, WRAP, 1f))
        val nb = tv("＋  نیا ٹارگٹ بنائیں", 12f, "#FFFFFF", true, Gravity.CENTER)
        nb.setPadding(dp(10), dp(9), dp(10), dp(9))
        bg(nb, "#0F5A2B", null, 10)
        nb.setOnClickListener { newTarget() }
        hr.addView(nb)
        sec.addView(hr)
        catTabs = hbox()
        sec.addView(catTabs, lp(MATCH, WRAP, 0f, 0, 10, 0, 6))
        cardsBox = vbox()
        sec.addView(cardsBox)
        content.addView(sec, lp(MATCH, WRAP, 0f, 10, 10, 10, 0))

        // Footer
        val f = hbox()
        f.setPadding(dp(12), dp(12), dp(12), dp(12))
        bg(f, "#EAF3E4", "#CFE2C9", 14)
        f.addView(tv("🎯", 26f), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val ft = vbox()
        ft.addView(tv("آج کا ٹارگٹ پورا کریں!", 15f, "#0F5A2B", true))
        ft.addView(tv("اللہ آپ کی کوششوں کو قبول فرمائے۔", 12f, "#444444"))
        f.addView(ft)
        content.addView(f, lp(MATCH, WRAP, 0f, 10, 10, 10, 16))

        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- data ----------
    private fun keys(p: String): Set<String> {
        val out = mutableSetOf<String>()
        val now = Calendar.getInstance()
        when (p) {
            "daily" -> out.add(Fmt.key(now))
            "weekly" -> for (i in 0..6) {
                val c2 = Calendar.getInstance(); c2.add(Calendar.DAY_OF_YEAR, -i); out.add(Fmt.key(c2))
            }
            else -> for (d in 1..now.get(Calendar.DAY_OF_MONTH)) {
                val c2 = Calendar.getInstance(); c2.set(Calendar.DAY_OF_MONTH, d); out.add(Fmt.key(c2))
            }
        }
        return out
    }

    private fun done(cat: String, p: String): Int {
        val ks = keys(p)
        var s = 0
        for (r in recs) {
            if (r.getString("d") !in ks) continue
            s += when (cat) {
                "hifz" -> r.optInt("hpg", 0)
                "nazra" -> if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                "rep" -> r.optInt("rep", 0)
                else -> r.optInt("min", 0)
            }
        }
        return s
    }

    private fun target(cat: String, p: String) = Store.int(this, "tg_${cat}_$p")

    private fun summary(p: String): Triple<Int, Int, Int> {
        var sum = 0; var met = 0; var total = 0
        for (c in cats) {
            val t = target(c.key, p)
            if (t > 0) {
                val d = done(c.key, p)
                total++
                sum += minOf(100, d * 100 / t)
                if (d >= t) met++
            }
        }
        return Triple(if (total == 0) 0 else sum / total, met, total)
    }

    private fun light(acc: String): Int = (c(acc) and 0x00FFFFFF) or (0x33 shl 24)

    // ---------- UI ----------
    private fun refresh() {
        recs = Store.list(this, "records")
        summaryBox.removeAllViews()
        summaryBox.addView(sumCard("daily", "روزانہ کا ٹارگٹ", "آج کے اہداف", "#0F6B33", "#EAF7EC", "#A8D5B0"), lp(0, WRAP, 1f, 0, 0, 3, 0))
        summaryBox.addView(sumCard("weekly", "ہفتہ وار ٹارگٹ", "7 دن کے اہداف", "#0B4F9C", "#E8F3FF", "#A9CDF2"), lp(0, WRAP, 1f, 3, 0, 3, 0))
        summaryBox.addView(sumCard("monthly", "ماہانہ ٹارگٹ", "اس ماہ کے اہداف", "#6A2FB0", "#F3ECFB", "#CBBDEB"), lp(0, WRAP, 1f, 3, 0, 0, 0))

        catTabs.removeAllViews()
        for (c in cats) {
            val on = filter == c.key
            val t = tv(tabNames[c.key]!!, 13f, if (on) "#FFFFFF" else "#444444", on, Gravity.CENTER)
            t.setPadding(dp(4), dp(9), dp(4), dp(9))
            bg(t, if (on) "#0F5A2B" else "#EEF1E8", "#D9E0D2", 8)
            t.setOnClickListener { filter = if (filter == c.key) null else c.key; refresh() }
            catTabs.addView(t, lp(0, WRAP, 1f, 1, 0, 1, 0))
        }

        cardsBox.removeAllViews()
        for (c in cats) {
            if (filter != null && filter != c.key) continue
            cardsBox.addView(detailCard(c), lp(MATCH, WRAP, 0f, 0, 4, 0, 4))
        }
    }

    private fun ringView(pct: Int, acc: String, size: Int, sp: Float): View {
        val fl = FrameLayout(this)
        fl.addView(RingView(this, pct, 100, c(acc), light(acc)), FrameLayout.LayoutParams(dp(size), dp(size)))
        val t = tv("$pct%", sp, "#222222", true, Gravity.CENTER)
        fl.addView(t, FrameLayout.LayoutParams(dp(size), dp(size)))
        return fl
    }

    private fun sumCard(p: String, ur: String, sub: String, acc: String, fill: String, stroke: String): View {
        val (pct, met, total) = summary(p)
        val card = vbox()
        card.setPadding(dp(7), dp(9), dp(7), dp(9))
        bg(card, fill, stroke, 14)
        card.setOnClickListener {
            for (c in cats) per[c.key] = p
            refresh()
            toast("${perTab[p]} اہداف دکھائے جا رہے ہیں")
        }
        val top = hbox()
        val ic = tv("📅", 15f, "#FFFFFF", false, Gravity.CENTER)
        bg(ic, acc, null, 9)
        top.addView(ic, lp(dp(30), dp(30), 0f, 0, 0, 5, 0))
        val tt = vbox()
        tt.addView(tv(ur, 11f, acc, true))
        tt.addView(tv(sub, 8f, "#555555"))
        top.addView(tt, lp(0, WRAP, 1f))
        card.addView(top)
        val bot = hbox()
        bot.addView(ringView(pct, acc, 48, 11f), lp(dp(48), dp(48), 0f, 0, 0, 5, 0))
        val bt = vbox()
        bt.addView(tv("مکمل ہوا", 9f, "#555555"))
        bt.addView(tv("$met/$total", 14f, "#222222", true))
        bot.addView(bt)
        card.addView(bot, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        return card
    }

    private fun detailCard(cat: Cat): View {
        val p = per[cat.key] ?: "daily"
        val t = target(cat.key, p)
        val d = done(cat.key, p)
        val rem = (t - d).coerceAtLeast(0)
        val pct = if (t > 0) minOf(100, d * 100 / t) else 0
        val acc = cat.acc

        val card = hbox()
        card.gravity = Gravity.TOP
        card.setPadding(dp(8), dp(8), dp(8), dp(8))
        bg(card, cat.fill, cat.stroke, 14)
        card.setOnClickListener { setTarget(cat, p) }

        val ic = tv(cat.icon, 22f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, acc)
        card.addView(ic, lp(dp(46), dp(46), 0f, 0, 6, 8, 0))

        val right = vbox()
        val top = hbox()
        top.addView(tv(cat.ur, 15f, acc, true), lp(0, WRAP, 1f))
        val tabs = hbox()
        for (pp in listOf("monthly", "weekly", "daily")) {
            val on = pp == p
            val tb = tv(perTab[pp]!!, 9f, if (on) "#FFFFFF" else "#555555", on, Gravity.CENTER)
            tb.setPadding(dp(6), dp(4), dp(6), dp(4))
            bg(tb, if (on) acc else "#ECEEE8", null, 9)
            tb.setOnClickListener { per[cat.key] = pp; refresh() }
            tabs.addView(tb, lp(WRAP, WRAP, 0f, 1, 0, 1, 0))
        }
        top.addView(tabs)
        right.addView(top)

        val body = hbox()
        fun sep() = View(this).also { it.setBackgroundColor(c("#E0E4DC")) }
        fun col(label: String, value: String, bar: View?): View {
            val v = vbox()
            v.addView(tv(label, 10f, "#555555"))
            v.addView(tv(value, 14f, "#222222", true))
            if (bar != null) v.addView(bar, lp(MATCH, dp(6), 0f, 0, 3, 0, 0))
            return v
        }
        val fd = if (t > 0) d.toFloat() / t else 0f
        val fr = if (t > 0) rem.toFloat() / t else 0f
        val c1 = col(perTarget[p]!!, if (t > 0) "$t ${cat.unit}" else "مقرر نہیں", null)
        val c2 = col("مکمل کیا", "$d ${cat.unit}", BarView(this, fd, c(acc), light(acc)))
        val c3 = col("باقی", if (t > 0) "$rem ${cat.unit}" else "—", BarView(this, fr, c(acc), light(acc)))
        body.addView(c1, lp(0, WRAP, 1f, 0, 0, 4, 0))
        body.addView(sep(), lp(dp(1), dp(42)))
        body.addView(c2, lp(0, WRAP, 1f, 4, 0, 4, 0))
        body.addView(sep(), lp(dp(1), dp(42)))
        body.addView(c3, lp(0, WRAP, 1f, 4, 0, 4, 0))
        val rg = vbox()
        rg.gravity = Gravity.CENTER_HORIZONTAL
        rg.addView(ringView(pct, acc, 46, 10f), lp(dp(46), dp(46)))
        rg.addView(tv(perLabel[p]!!, 9f, "#555555", false, Gravity.CENTER))
        body.addView(rg)
        right.addView(body, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        if (t == 0) right.addView(tv("ہدف مقرر کرنے کے لیے کارڈ پر ٹیپ کریں", 10f, acc), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))

        card.addView(right, lp(0, WRAP, 1f))
        return card
    }

    private fun setTarget(cat: Cat, p: String) {
        val e = EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER
        e.hint = "ہدف (${cat.unit})"
        val cur = target(cat.key, p)
        if (cur > 0) e.setText("$cur")
        val w = FrameLayout(this)
        w.setPadding(dp(20), dp(8), dp(20), 0)
        w.addView(e)
        AlertDialog.Builder(this)
            .setTitle("${cat.ur} — ${perTarget[p]}")
            .setView(w)
            .setPositiveButton("محفوظ کریں") { _, _ ->
                val v = e.text.toString().toIntOrNull() ?: 0
                Store.putInt(this, "tg_${cat.key}_$p", v)
                per[cat.key] = p
                toast("ہدف محفوظ ہو گیا")
                refresh()
            }
            .setNeutralButton("ہدف ہٹائیں") { _, _ ->
                Store.putInt(this, "tg_${cat.key}_$p", 0)
                refresh()
            }
            .setNegativeButton("منسوخ", null)
            .show()
    }

    private fun newTarget() {
        AlertDialog.Builder(this).setTitle("کیٹیگری منتخب کریں")
            .setItems(cats.map { it.ur }.toTypedArray()) { _, i ->
                AlertDialog.Builder(this).setTitle("مدت منتخب کریں")
                    .setItems(pers.map { perTab[it]!! }.toTypedArray()) { _, j -> setTarget(cats[i], pers[j]) }
                    .show()
            }.show()
    }

    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(10))
        h.background = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c("#13703A"), c("#0A3D1C")))

        val mid = hbox()
        val menu = tv("☰", 28f, "#FFFFFF", true)
        menu.setOnClickListener { v -> showMenu(v) }
        mid.addView(menu, lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        mid.gravity = Gravity.CENTER_VERTICAL
        mid.addView(View(this), lp(0, 1, 1f))
        val logoImg = logoView(96)
        mid.addView(logoImg, lp(dp(96), dp(96)))
        mid.addView(View(this), lp(0, 1, 1f))
        val bell = tv("🔔", 26f, "#FFFFFF")
        bell.setOnClickListener { go(ReminderActivity::class.java) }
        mid.addView(bell)
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val tabs = hbox()
        bg(tabs, "#0C4A24", "#B8962E", 12)
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val t = vbox()
            t.gravity = Gravity.CENTER
            t.setPadding(dp(2), dp(8), dp(2), dp(8))
            val active = i == 2
            if (active) bg(t, "#F5D26B", null, 10)
            t.addView(tv(p.first, 20f, "#FFFFFF", false, Gravity.CENTER))
            t.addView(tv(p.second, 12f, if (active) "#3A2A00" else "#FFFFFF", true, Gravity.CENTER))
            t.setOnClickListener { tab(i) }
            tabs.addView(t, lp(0, WRAP, 1f, 1, 1, 1, 1))
        }
        h.addView(tabs)
        return h
    }

    private fun tab(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            1 -> { go(RecordActivity::class.java); finish() }
            3 -> { go(ReportActivity::class.java); finish() }
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun showMenu(anchor: View) {
        val items = listOf<Pair<String, () -> Unit>>(
            "حفظ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "hifz")) },
            "ناظرہ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "nazra")) },
            "روزانہ کا ریکارڈ" to { go(RecordActivity::class.java) },
            "رپورٹ اور گراف" to { go(ReportActivity::class.java) },
            "پڑھنے کا وقت" to { go(TimesActivity::class.java) },
            "یاد دہانی" to { go(ReminderActivity::class.java) },
            "سیٹنگز" to { go(SettingsActivity::class.java) }
        )
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, p -> pm.menu.add(0, i, i, p.first) }
        pm.setOnMenuItemClickListener { m -> items[m.itemId].second(); true }
        pm.show()
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 2
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(40), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { tab(i) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }
}
