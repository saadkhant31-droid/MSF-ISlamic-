package com.msf.quranrecord

import android.app.AlertDialog
import android.app.TimePickerDialog
import android.os.Bundle
import android.widget.LinearLayout
import org.json.JSONObject

class TimesActivity : BaseActivity() {
    private lateinit var listBox: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setup("پڑھنے کا وقت")
        val label = input("وقت کا نام (مثلاً فجر کے بعد)")
        box.addView(label)
        box.addView(btn("وقت منتخب کریں اور شامل کریں", "#D32F3F") {
            TimePickerDialog(this, { _, h, m ->
                val l = Store.list(this, "times")
                l.add(JSONObject().put("t", String.format("%02d:%02d", h, m)).put("n", label.text.toString()))
                l.sortBy { it.getString("t") }
                Store.saveList(this, "times", l)
                label.text.clear()
                refresh()
            }, 6, 0, false).show()
        })
        box.addView(tv("محفوظ اوقات (حذف کرنے کے لیے ٹیپ کریں)", 14f, "#666666"), lp(MATCH, WRAP, 0f, 0, 10, 0, 4))
        listBox = vbox()
        box.addView(listBox)
        refresh()
    }

    private fun refresh() {
        listBox.removeAllViews()
        val l = Store.list(this, "times")
        if (l.isEmpty()) listBox.addView(tv("ابھی کوئی وقت درج نہیں", 14f, "#888888"))
        l.forEachIndexed { idx, o ->
            val cd = card("#FDECEE", "#F2B8BF")
            cd.addView(tv("⏰  ${o.getString("t")}   ${o.optString("n")}", 17f, "#D32F3F", true))
            cd.setOnClickListener {
                AlertDialog.Builder(this).setMessage("یہ وقت حذف کریں؟")
                    .setPositiveButton("حذف") { _, _ ->
                        val all = Store.list(this, "times")
                        all.removeAt(idx)
                        Store.saveList(this, "times", all)
                        refresh()
                    }.setNegativeButton("نہیں", null).show()
            }
            listBox.addView(cd)
        }
    }
}
