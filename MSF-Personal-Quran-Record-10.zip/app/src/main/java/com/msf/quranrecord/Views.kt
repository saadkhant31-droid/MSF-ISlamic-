package com.msf.quranrecord

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ColorFilter
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.PixelFormat
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.drawable.Drawable
import android.view.MotionEvent
import android.view.View

class RingView(
    ctx: Context,
    private val value: Int,
    private val total: Int,
    private val col: Int,
    private val track: Int
) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = width * 0.11f
        p.style = Paint.Style.STROKE
        p.strokeWidth = s
        p.strokeCap = Paint.Cap.ROUND
        val r = RectF(s / 2, s / 2, width - s / 2, height - s / 2)
        p.color = track
        cv.drawArc(r, 0f, 360f, false, p)
        p.color = col
        if (value > 0) cv.drawArc(r, -90f, 360f * value / total, false, p)
    }
}

class BarChartView(
    ctx: Context,
    private val labels: List<String>,
    private val values: List<Int>
) : View(ctx) {
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F5A2B") }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.parseColor("#444444"); textSize = 30f; textAlign = Paint.Align.CENTER
    }

    override fun onDraw(cv: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val max = (values.maxOrNull() ?: 0).coerceAtLeast(1)
        val n = values.size
        val slot = w / n
        val bw = slot * 0.55f
        val top = 44f
        val bottom = h - 50f
        for (i in 0 until n) {
            val bh = (bottom - top) * values[i] / max
            val cx = slot * i + slot / 2
            cv.drawRoundRect(cx - bw / 2, bottom - bh, cx + bw / 2, bottom, 12f, 12f, bar)
            cv.drawText(values[i].toString(), cx, bottom - bh - 8f, txt)
            cv.drawText(labels[i], cx, h - 12f, txt)
        }
    }
}

class BarView(
    ctx: Context,
    private val frac: Float,
    private val col: Int,
    private val track: Int
) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val h = height.toFloat()
        val r = h / 2f
        p.color = track
        cv.drawRoundRect(0f, 0f, width.toFloat(), h, r, r, p)
        val w = width * frac.coerceIn(0f, 1f)
        if (w > 0f) {
            p.color = col
            cv.drawRoundRect(0f, 0f, maxOf(w, h), h, r, r, p)
        }
    }
}

class GroupBarView(
    ctx: Context,
    private val labels: List<String>,
    private val a: List<Int>,
    private val b: List<Int>,
    private val ca: Int,
    private val cb: Int
) : View(ctx) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val hl = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1A0F5A2B") }
    private val grid = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DDE3DA"); strokeWidth = 2f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#444444"); textSize = 24f }
    private val val1 = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER; isFakeBoldText = true; textSize = 21f
    }
    private val leftPad = 64f
    private var picked = -1

    /** Called with the bar-group index when the user taps a bar. */
    var onTap: ((Int) -> Unit)? = null

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.action) {
            MotionEvent.ACTION_DOWN -> return true
            MotionEvent.ACTION_UP -> {
                val slot = (width - 8f - leftPad) / labels.size
                val i = ((e.x - leftPad) / slot).toInt()
                if (e.x >= leftPad && i in labels.indices) {
                    picked = i
                    invalidate()
                    onTap?.invoke(i)
                }
                performClick()
                return true
            }
        }
        return super.onTouchEvent(e)
    }

    override fun performClick(): Boolean = super.performClick()

    override fun onDraw(cv: Canvas) {
        val left = leftPad
        val right = width - 8f
        val top = 34f
        val bottom = height - 46f
        val mx = ((a + b).maxOrNull() ?: 0).coerceAtLeast(1)
        val step = listOf(5, 10, 20, 50, 100, 200, 500, 1000, 5000).firstOrNull { (mx + it - 1) / it <= 4 } ?: 10000
        val ticks = ((mx + step - 1) / step).coerceAtLeast(1)
        val topVal = step * ticks
        txt.textAlign = Paint.Align.RIGHT
        txt.textSize = 24f
        for (i in 0..ticks) {
            val y = bottom - (bottom - top) * i / ticks
            cv.drawLine(left, y, right, y, grid)
            cv.drawText("${step * i}", left - 8f, y + 8f, txt)
        }
        val n = labels.size
        val slot = (right - left) / n
        val bw = slot * 0.28f
        txt.textAlign = Paint.Align.CENTER
        for (i in 0 until n) {
            val cx = left + slot * i + slot / 2
            if (i == picked) cv.drawRoundRect(cx - slot / 2 + 2f, top - 18f, cx + slot / 2 - 2f, height - 4f, 10f, 10f, hl)
            val ha = (bottom - top) * a[i] / topVal
            val hb = (bottom - top) * b[i] / topVal
            fill.color = ca
            cv.drawRoundRect(cx - bw - 2f, bottom - ha, cx - 2f, bottom, 6f, 6f, fill)
            fill.color = cb
            cv.drawRoundRect(cx + 2f, bottom - hb, cx + bw + 2f, bottom, 6f, 6f, fill)
            val1.color = ca
            cv.drawText("${a[i]}", cx - bw / 2 - 2f, bottom - ha - 6f, val1)
            val1.color = cb
            cv.drawText("${b[i]}", cx + bw / 2 + 2f, bottom - hb - 6f, val1)
            txt.textSize = 24f
            cv.drawText(labels[i], cx, height - 12f, txt)
        }
    }
}

class DonutView(
    ctx: Context,
    private val v1: Int,
    private val v2: Int,
    private val c1: Int,
    private val c2: Int,
    private val thick: Float = 0.17f
) : View(ctx) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(cv: Canvas) {
        val s = width * thick
        p.style = Paint.Style.STROKE
        p.strokeWidth = s
        val r = RectF(s / 2, s / 2, width - s / 2, height - s / 2)
        val total = v1 + v2
        if (total == 0) {
            p.color = Color.parseColor("#E3E8E0")
            cv.drawArc(r, 0f, 360f, false, p)
            return
        }
        val sw1 = 360f * v1 / total
        p.color = c1
        cv.drawArc(r, -90f, sw1, false, p)
        p.color = c2
        cv.drawArc(r, -90f + sw1, 360f - sw1, false, p)
    }
}

class PieView(
    ctx: Context,
    private val vals: List<Int>,
    private val cols: List<Int>
) : View(ctx) {
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val t = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true; textSize = 11f * d
    }

    override fun onDraw(cv: Canvas) {
        val size = minOf(width, height).toFloat()
        val r = RectF((width - size) / 2, (height - size) / 2, (width + size) / 2, (height + size) / 2)
        val total = vals.sum()
        if (total <= 0) {
            p.color = Color.parseColor("#E3E8E0")
            cv.drawArc(r, 0f, 360f, true, p)
            return
        }
        var angle = -90f
        for (i in vals.indices) {
            val sweep = 360f * vals[i] / total
            p.color = cols[i]
            cv.drawArc(r, angle, sweep, true, p)
            val pct = Math.round(vals[i] * 100f / total)
            if (pct >= 6) {
                val mid = Math.toRadians((angle + sweep / 2).toDouble())
                val cx = r.centerX() + (size * 0.30f) * Math.cos(mid).toFloat()
                val cy = r.centerY() + (size * 0.30f) * Math.sin(mid).toFloat()
                cv.drawText("$pct%", cx, cy + 4f * d, t)
            }
            angle += sweep
        }
    }
}

/** Green gradient header (or light footer) with mosque silhouettes, crescent moon and lantern. */
class MosqueArt(private val light: Boolean, private val radius: Float = 0f) : Drawable() {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun minaret(cv: Canvas, cx: Float, base: Float, mw: Float, mh: Float) {
        cv.drawRect(cx - mw / 2, base - mh, cx + mw / 2, base, p)
        val cap = Path()
        cap.moveTo(cx - mw * 0.8f, base - mh)
        cap.lineTo(cx, base - mh - mw * 2.4f)
        cap.lineTo(cx + mw * 0.8f, base - mh)
        cap.close()
        cv.drawPath(cap, p)
        val by = base - mh * 0.72f
        cv.drawRect(cx - mw * 0.95f, by, cx + mw * 0.95f, by + mw * 0.4f, p)
    }

    private fun dome(cv: Canvas, cx: Float, base: Float, r: Float, bodyH: Float) {
        cv.drawRect(cx - r, base - bodyH, cx + r, base, p)
        cv.drawArc(RectF(cx - r, base - bodyH - r, cx + r, base - bodyH + r), 180f, 180f, true, p)
        cv.drawRect(cx - 2f, base - bodyH - r * 1.5f, cx + 2f, base - bodyH - r + 2f, p)
    }

    override fun draw(cv: Canvas) {
        val w = bounds.width().toFloat()
        val h = bounds.height().toFloat()
        if (radius > 0f) {
            val clip = Path()
            clip.addRoundRect(RectF(0f, 0f, w, h), radius, radius, Path.Direction.CW)
            cv.clipPath(clip)
        }
        if (light) {
            p.shader = null
            p.color = Color.parseColor("#EAF3E4")
            cv.drawRect(0f, 0f, w, h, p)
            p.color = Color.parseColor("#CFE2C9")
        } else {
            p.shader = LinearGradient(0f, 0f, w, h, Color.parseColor("#13703A"), Color.parseColor("#0A3D1C"), Shader.TileMode.CLAMP)
            cv.drawRect(0f, 0f, w, h, p)
            p.shader = null
            p.color = Color.parseColor("#B0062A14")
        }
        val base = if (light) h else h * 0.68f
        val u = base / 10f
        dome(cv, w * 0.72f, base, u * 1.8f, u * 2.2f)
        minaret(cv, w * 0.60f, base, u * 0.45f, u * 6.5f)
        minaret(cv, w * 0.84f, base, u * 0.5f, u * 7.5f)
        dome(cv, w * 0.92f, base, u * 1.2f, u * 1.8f)
        minaret(cv, w * 0.97f, base, u * 0.4f, u * 5f)
        dome(cv, w * 0.54f, base, u * 0.9f, u * 1.4f)
        if (light) return

        // crescent moon
        val mr = h * 0.10f
        val mx = w * 0.80f
        val my = h * 0.24f
        val moon = Path()
        moon.addCircle(mx, my, mr, Path.Direction.CW)
        val cut = Path()
        cut.addCircle(mx + mr * 0.45f, my - mr * 0.2f, mr * 0.85f, Path.Direction.CW)
        moon.op(cut, Path.Op.DIFFERENCE)
        p.color = Color.parseColor("#F3DC8E")
        cv.drawPath(moon, p)

        // lantern
        val lx = w * 0.962f
        val lw = h * 0.045f
        p.color = Color.parseColor("#D9A93B")
        cv.drawRect(lx - 1.5f, 0f, lx + 1.5f, h * 0.12f, p)
        cv.drawRoundRect(RectF(lx - lw, h * 0.12f, lx + lw, h * 0.31f), lw * 0.6f, lw * 0.6f, p)
        p.color = Color.parseColor("#FFE9A8")
        cv.drawRoundRect(RectF(lx - lw * 0.5f, h * 0.15f, lx + lw * 0.5f, h * 0.28f), lw * 0.4f, lw * 0.4f, p)
    }

    override fun setAlpha(alpha: Int) {}
    override fun setColorFilter(colorFilter: ColorFilter?) {}
    @Suppress("DEPRECATION", "OVERRIDE_DEPRECATION")
    override fun getOpacity(): Int = PixelFormat.OPAQUE
}
