package com.msf.quranrecord

import android.app.Activity
import android.app.Dialog
import android.content.Context
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** In-memory flag: has the PIN been entered since the app was opened? */
object Lock {
    var unlocked = false
}

/** Colour themes: the green UI is rotated to another hue. Index 0 is the default green. */
object Themes {
    val names = listOf("سبز (ڈارک)", "فیروزی (ڈارک)", "نیلا (ڈارک)", "جامنی (ڈارک)")
    private val deg = floatArrayOf(0f, 40f, 80f, 140f)

    fun index(c: Context): Int = Store.int(c, "theme", 0).coerceIn(0, names.size - 1)

    private fun hue(d: Float): ColorMatrix {
        val r = Math.toRadians(d.toDouble())
        val cs = Math.cos(r).toFloat()
        val sn = Math.sin(r).toFloat()
        return ColorMatrix(floatArrayOf(
            0.213f + cs * 0.787f - sn * 0.213f, 0.715f - cs * 0.715f - sn * 0.715f, 0.072f - cs * 0.072f + sn * 0.928f, 0f, 0f,
            0.213f - cs * 0.213f + sn * 0.143f, 0.715f + cs * 0.285f + sn * 0.140f, 0.072f - cs * 0.072f - sn * 0.283f, 0f, 0f,
            0.213f - cs * 0.213f - sn * 0.787f, 0.715f - cs * 0.715f + sn * 0.715f, 0.072f + cs * 0.928f + sn * 0.072f, 0f, 0f,
            0f, 0f, 0f, 1f, 0f
        ))
    }

    fun apply(a: Activity, root: View) {
        val i = index(a)
        if (i == 0) return
        val p = Paint()
        p.colorFilter = ColorMatrixColorFilter(hue(deg[i]))
        root.setLayerType(View.LAYER_TYPE_HARDWARE, p)
        val hsv = FloatArray(3)
        Color.colorToHSV(Color.parseColor("#0F5A2B"), hsv)
        hsv[0] = (hsv[0] + deg[i]) % 360f
        a.window.statusBarColor = Color.HSVToColor(hsv)
    }
}

open class BaseActivity : AppCompatActivity() {
    lateinit var box: LinearLayout
    private var pinDlg: Dialog? = null

    override fun attachBaseContext(newBase: Context) {
        val pct = newBase.getSharedPreferences("msf", Context.MODE_PRIVATE).getInt("font_pct", 100)
        if (pct == 100) {
            super.attachBaseContext(newBase)
            return
        }
        val cfg = Configuration(newBase.resources.configuration)
        cfg.fontScale = pct / 100f
        super.attachBaseContext(newBase.createConfigurationContext(cfg))
    }

    override fun setContentView(view: View?) {
        super.setContentView(view)
        if (view != null) Themes.apply(this, view)
    }

    override fun onStart() {
        super.onStart()
        if (!Lock.unlocked && Store.str(this, "pin").isNotBlank() && pinDlg?.isShowing != true) askPin()
    }

    private fun askPin() {
        val d = Dialog(this, android.R.style.Theme_Material_Light_NoActionBar)
        val col = vbox()
        col.gravity = Gravity.CENTER
        col.setBackgroundColor(c("#F4F8F4"))
        col.setPadding(dp(32), dp(32), dp(32), dp(32))
        val logo = tv("MSF", 22f, "#D4AF37", true, Gravity.CENTER)
        circle(logo, "#0B4A22", "#D4AF37", 3)
        col.addView(logo, lp(dp(88), dp(88)))
        col.addView(tv("پن کوڈ درج کریں", 20f, "#0F5A2B", true, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 18, 0, 10))
        val e = android.widget.EditText(this)
        e.inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
        e.gravity = Gravity.CENTER
        e.textSize = 24f
        bg(e, "#FFFFFF", "#BBD7C0", 12)
        col.addView(e, lp(MATCH, WRAP, 0f, 0, 6, 0, 6))
        val err = tv("", 13f, "#C62828", false, Gravity.CENTER)
        col.addView(err, lp(MATCH, WRAP))
        fun tryUnlock() {
            if (e.text.toString() == Store.str(this, "pin")) {
                Lock.unlocked = true
                d.dismiss()
            } else {
                err.text = "غلط پن کوڈ"
                e.setText("")
            }
        }
        col.addView(btn("کھولیں") { tryUnlock() })
        d.setContentView(col)
        d.setCancelable(false)
        d.setOnKeyListener { _, k, ev ->
            if (k == KeyEvent.KEYCODE_BACK && ev.action == KeyEvent.ACTION_UP) {
                d.dismiss()
                finishAffinity()
                true
            } else false
        }
        pinDlg = d
        d.show()
        if (Store.bool(this, "fp_on") && Build.VERSION.SDK_INT >= 28) fingerprint(d)
    }

    private fun fingerprint(d: Dialog) {
        try {
            val ex = androidx.core.content.ContextCompat.getMainExecutor(this)
            val bp = android.hardware.biometrics.BiometricPrompt.Builder(this)
                .setTitle("فنگر پرنٹ سے کھولیں")
                .setNegativeButton("پن استعمال کریں", ex) { _, _ -> }
                .build()
            bp.authenticate(android.os.CancellationSignal(), ex,
                object : android.hardware.biometrics.BiometricPrompt.AuthenticationCallback() {
                    override fun onAuthenticationSucceeded(result: android.hardware.biometrics.BiometricPrompt.AuthenticationResult?) {
                        Lock.unlocked = true
                        if (d.isShowing) d.dismiss()
                    }
                })
        } catch (ex: Exception) {
            // no fingerprint available: the PIN field stays usable
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.parseColor("#0F5A2B")
    }

    fun dp(i: Int): Int = (i * resources.displayMetrics.density + 0.5f).toInt()
    fun c(s: String): Int = Color.parseColor(s)
    fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    fun bg(v: View, fill: String, stroke: String? = null, r: Int = 16) {
        v.background = GradientDrawable().apply {
            setColor(c(fill))
            cornerRadius = dp(r).toFloat()
            if (stroke != null) setStroke(dp(1), c(stroke))
        }
    }

    fun circle(v: View, fill: String, stroke: String? = null, sw: Int = 0) {
        v.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(c(fill))
            if (stroke != null) setStroke(dp(sw), c(stroke))
        }
    }

    fun tv(t: String, sp: Float = 14f, col: String = "#222222", bold: Boolean = false, gravity: Int = Gravity.START): TextView {
        val v = TextView(this)
        v.text = t
        v.textSize = sp
        v.setTextColor(c(col))
        if (bold) v.setTypeface(v.typeface, Typeface.BOLD)
        v.gravity = gravity
        return v
    }

    fun lp(w: Int, h: Int, wt: Float = 0f, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, wt)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    fun vbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        return l
    }

    fun hbox(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.HORIZONTAL
        l.gravity = Gravity.CENTER_VERTICAL
        return l
    }

    /** Sub-screen with green title bar, back arrow and scrolling content in [box]. */
    fun setup(title: String) {
        val root = vbox()
        root.setBackgroundColor(c("#F4F8F4"))
        root.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val bar = hbox()
        bar.setBackgroundColor(c("#0F5A2B"))
        bar.setPadding(dp(16), dp(14), dp(16), dp(14))
        val back = tv("→", 26f, "#FFFFFF", true)
        back.setPadding(0, 0, dp(16), 0)
        back.setOnClickListener { finish() }
        bar.addView(back)
        bar.addView(tv(title, 20f, "#FFFFFF", true))
        val sv = ScrollView(this)
        box = vbox()
        box.setPadding(dp(16), dp(16), dp(16), dp(24))
        sv.addView(box)
        root.addView(bar, lp(MATCH, WRAP))
        root.addView(sv, lp(MATCH, 0, 1f))
        setContentView(root)
    }

    fun btn(t: String, fill: String = "#0F5A2B", onClick: () -> Unit): TextView {
        val v = tv(t, 16f, "#FFFFFF", true, Gravity.CENTER)
        v.setPadding(dp(16), dp(14), dp(16), dp(14))
        bg(v, fill, null, 14)
        v.setOnClickListener { onClick() }
        v.layoutParams = lp(MATCH, WRAP, 0f, 0, 8, 0, 8)
        return v
    }

    fun input(hint: String, number: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.textSize = 16f
        e.setPadding(dp(14), dp(12), dp(14), dp(12))
        bg(e, "#FFFFFF", "#BBD7C0", 12)
        if (number) e.inputType = InputType.TYPE_CLASS_NUMBER
        e.layoutParams = lp(MATCH, WRAP, 0f, 0, 6, 0, 6)
        return e
    }

    fun card(fill: String = "#FFFFFF", stroke: String = "#D5E6D8"): LinearLayout {
        val l = vbox()
        l.setPadding(dp(14), dp(12), dp(14), dp(12))
        bg(l, fill, stroke, 14)
        l.layoutParams = lp(MATCH, WRAP, 0f, 0, 6, 0, 6)
        return l
    }

    fun go(cls: Class<*>) = startActivity(android.content.Intent(this, cls))
}
