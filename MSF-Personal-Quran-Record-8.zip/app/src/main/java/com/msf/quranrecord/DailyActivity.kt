package com.msf.quranrecord

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import org.json.JSONObject
import java.util.Calendar

class DailyActivity : BaseActivity() {
    private class Cat(
        val key: String, val ur: String, val icon: String, val acc: String,
        val fill: String, val stroke: String, val unit: String
    )

    private val cats = listOf(
        Cat("hifz", "حفظ قرآن", "📖", "#0F6B33", "#F1FAF3", "#BFE0C6", "صفحہ"),
        Cat("nazra", "ناظرہ قرآن", "📘", "#0B4F9C", "#EEF6FF", "#B5D3F2", "صفحہ"),
        Cat("rep", "دہرائی", "🔄", "#6A2FB0", "#F6F0FC", "#D5C0EE", "بار"),
        Cat("time", "تلاوت", "🕐", "#C98A0E", "#FFF8E8", "#F0D9A0", "منٹ")
    )

    private var scope = "daily"
    private val sel: Calendar = Calendar.getInstance()
    private var recs: List<JSONObject> = emptyList()
    private lateinit var body: LinearLayout
    private lateinit var tabsBox: LinearLayout
    private lateinit var dateTv: android.widget.TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        val sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())
        tabsBox = hbox()
        content.addView(tabsBox, lp(MATCH, WRAP, 0f, 10, 10, 10, 0))
        body = vbox()
        body.setPadding(dp(10), 0, dp(10), dp(14))
        content.addView(body)
        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- data ----------
    private fun isToday(cal: Calendar) = Fmt.key(cal) == Fmt.key(Calendar.getInstance())

    private fun keys(): Set<String> {
        val out = mutableSetOf<String>()
        when (scope) {
            "daily" -> out.add(Fmt.key(sel))
            "weekly" -> for (i in 0..6) {
                val c2 = sel.clone() as Calendar; c2.add(Calendar.DAY_OF_YEAR, -i); out.add(Fmt.key(c2))
            }
            else -> {
                val c2 = sel.clone() as Calendar
                c2.set(Calendar.DAY_OF_MONTH, 1)
                for (d in 1..c2.getActualMaximum(Calendar.DAY_OF_MONTH)) {
                    c2.set(Calendar.DAY_OF_MONTH, d); out.add(Fmt.key(c2))
                }
            }
        }
        return out
    }

    private fun sum(cat: String, ks: Set<String>): Int {
        var s = 0
        for (r in recs) {
            if (r.getString("d") !in ks) continue
            s += when (cat) {
                "hifz" -> r.optInt("hpg", 0)
                "nazra" -> if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                "rep" -> r.optInt("rep", 0)
                else -> r.optInt("min", 0)
            }
        }
        return s
    }

    private fun light(acc: String): Int = (c(acc) and 0x00FFFFFF) or (0x33 shl 24)

    private fun word(): String = when (scope) {
        "daily" -> if (isToday(sel)) "آج" else "اس دن"
        "weekly" -> "ہفتے"
        else -> "مہینے"
    }

    private fun dateLabel(): String = when (scope) {
        "daily" -> (if (isToday(sel)) "آج  " else Fmt.days[sel.get(Calendar.DAY_OF_WEEK) - 1] + "  ") + Fmt.fmt(sel)
        "weekly" -> {
            val s = sel.clone() as Calendar
            s.add(Calendar.DAY_OF_YEAR, -6)
            "${s.get(Calendar.DAY_OF_MONTH)} ${Fmt.months[s.get(Calendar.MONTH)]} – ${Fmt.fmt(sel)}"
        }
        else -> "${Fmt.months[sel.get(Calendar.MONTH)]} ${sel.get(Calendar.YEAR)}"
    }

    private fun step(d: Int) {
        when (scope) {
            "daily" -> sel.add(Calendar.DAY_OF_YEAR, d)
            "weekly" -> sel.add(Calendar.DAY_OF_YEAR, 7 * d)
            else -> sel.add(Calendar.MONTH, d)
        }
        refresh()
    }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d -> sel.set(y, m, d); refresh() },
            sel.get(Calendar.YEAR), sel.get(Calendar.MONTH), sel.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---------- UI ----------
    private fun refresh() {
        recs = Store.list(this, "records")
        dateTv.text = "🗓️  " + dateLabel()

        tabsBox.removeAllViews()
        val tabs = listOf(
            Triple("daily", "🗓️", "روزانہ ریکارڈ"),
            Triple("weekly", "🗓️", "ہفتہ وار ریکارڈ"),
            Triple("monthly", "🗓️", "ماہانہ ریکارڈ"),
            Triple("all", "📄", "مکمل ریکارڈ")
        )
        for (t in tabs) {
            val on = t.first == scope
            val v = vbox()
            v.gravity = Gravity.CENTER
            v.setPadding(dp(2), dp(8), dp(2), dp(8))
            bg(v, if (on) "#F8E7A6" else "#EEF4EA", if (on) "#E0C56A" else "#D5E6D8", 12)
            v.addView(tv(t.second, 16f, "#000000", false, Gravity.CENTER))
            v.addView(tv(t.third, 10f, if (on) "#3A2A00" else "#333333", true, Gravity.CENTER))
            v.setOnClickListener {
                if (t.first == "all") go(RecordActivity::class.java) else { scope = t.first; refresh() }
            }
            tabsBox.addView(v, lp(0, WRAP, 1f, 2, 0, 2, 0))
        }

        body.removeAllViews()
        val ks = keys()
        val vals = cats.associate { it.key to sum(it.key, ks) }
        val tg = cats.associate { it.key to Store.int(this, "tg_${it.key}_$scope") }
        var sumPct = 0; var total = 0; var met = 0
        for (cat in cats) {
            val t = tg[cat.key]!!
            if (t > 0) {
                val v = vals[cat.key]!!
                total++
                sumPct += minOf(100, v * 100 / t)
                if (v >= t) met++
            }
        }
        val overall = if (total == 0) 0 else sumPct / total
        val w = word()

        // summary card
        val sc = hbox()
        sc.setPadding(dp(8), dp(10), dp(8), dp(10))
        bg(sc, "#F4F9F1", "#D2E4CC", 16)
        val gr = tv("📖", 34f, "#000000", false, Gravity.CENTER)
        circle(gr, "#E3F1DD")
        sc.addView(gr, lp(dp(60), dp(60), 0f, 0, 0, 6, 0))
        val ct = vbox()
        ct.addView(tv("$w کا مجموعی ریکارڈ", 15f, "#222222", true))
        val msg = when {
            total == 0 -> "ٹارگٹ مقرر کریں تاکہ پیش رفت نظر آئے۔"
            overall >= 80 -> "آپ نے بہت اچھی محنت کی ہے۔"
            overall >= 50 -> "اچھی کوشش ہے، تھوڑی اور محنت کریں۔"
            else -> "قرآن کے لیے کچھ اور وقت نکالیں۔"
        }
        ct.addView(tv(msg, 11f, "#444444"), lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        sc.addView(ct, lp(0, WRAP, 1f))
        val ring = FrameLayout(this)
        ring.addView(RingView(this, overall, 100, c("#0F6B33"), light("#0F6B33")), FrameLayout.LayoutParams(dp(66), dp(66)))
        ring.addView(tv("$overall%", 15f, "#222222", true, Gravity.CENTER), FrameLayout.LayoutParams(dp(66), dp(66)))
        sc.addView(ring, lp(dp(66), dp(66), 0f, 4, 0, 8, 0))
        val st = vbox()
        st.addView(tv("🕐 کل وقت", 10f, "#555555"))
        st.addView(tv("${vals["time"]} منٹ", 14f, "#222222", true))
        st.addView(tv("✅ مکمل ٹارگٹ", 10f, "#555555"), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        st.addView(tv(if (total == 0) "--" else "$met/$total", 14f, "#222222", true))
        sc.addView(st)
        body.addView(sc, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        // progress section
        body.addView(sectionBar("📅", "$w کے ٹارگٹ کی پیش رفت"), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        val row = hbox()
        row.gravity = Gravity.TOP
        cats.forEachIndexed { i, cat ->
            row.addView(
                progressCard(cat, vals[cat.key]!!, tg[cat.key]!!),
                lp(0, WRAP, 1f, if (i == 0) 0 else 2, 0, if (i == cats.size - 1) 0 else 2, 0)
            )
        }
        body.addView(row, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))

        // details table
        body.addView(sectionBar("📋", "$w کی تفصیلات"), lp(MATCH, WRAP, 0f, 0, 12, 0, 0))
        body.addView(table(vals, tg), lp(MATCH, WRAP, 0f, 0, 8, 0, 0))

        // footer
        val f = hbox()
        f.setPadding(dp(10), dp(12), dp(10), dp(12))
        bg(f, "#EAF3E4", "#CFE2C9", 14)
        val fi = tv("📖", 20f, "#000000", false, Gravity.CENTER)
        circle(fi, "#FFFFFF", "#D4AF37", 2)
        f.addView(fi, lp(dp(42), dp(42), 0f, 0, 0, 10, 0))
        f.addView(tv("ہر دن کی تھوڑی محنت، زندگی بھر کی کامیابی ہے۔", 14f, "#0F5A2B", true), lp(0, WRAP, 1f))
        body.addView(f, lp(MATCH, WRAP, 0f, 0, 12, 0, 0))
    }

    private fun sectionBar(icon: String, title: String): View {
        val b = hbox()
        b.setPadding(dp(12), dp(10), dp(12), dp(10))
        b.background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, intArrayOf(c("#0F6B33"), c("#CFE6D0"))).apply {
            cornerRadius = dp(10).toFloat()
        }
        b.addView(tv(icon, 18f, "#FFFFFF"), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        b.addView(tv(title, 15f, "#FFFFFF", true))
        return b
    }

    private fun progressCard(cat: Cat, v: Int, t: Int): View {
        val pct = if (t > 0) minOf(100, v * 100 / t) else 0
        val card = vbox()
        card.setPadding(dp(5), dp(8), dp(5), dp(8))
        bg(card, cat.fill, cat.stroke, 12)
        card.setOnClickListener { go(TargetActivity::class.java) }
        val top = hbox()
        val ic = tv(cat.icon, 14f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, cat.acc)
        top.addView(ic, lp(dp(28), dp(28), 0f, 0, 0, 3, 0))
        top.addView(tv(cat.ur, 10f, cat.acc, true), lp(0, WRAP, 1f))
        card.addView(top)
        card.addView(tv("مقررہ: " + if (t > 0) "$t ${cat.unit}" else "--", 9f, "#333333"), lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        card.addView(tv("مکمل: $v ${cat.unit}", 9f, "#333333"), lp(MATCH, WRAP, 0f, 0, 2, 0, 0))
        val bot = hbox()
        bot.addView(BarView(this, pct / 100f, c(cat.acc), light(cat.acc)), lp(0, dp(6), 1f, 0, 0, 3, 0))
        bot.addView(tv(if (t > 0) "$pct%" else "--", 9f, cat.acc, true))
        card.addView(bot, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        return card
    }

    private fun table(vals: Map<String, Int>, tg: Map<String, Int>): View {
        val card = vbox()
        bg(card, "#FFFFFF", "#D5E6D8", 12)
        card.setPadding(dp(4), dp(4), dp(4), dp(4))
        val wts = floatArrayOf(0.6f, 1.9f, 1.1f, 1.1f, 0.9f, 0.9f, 1.4f)

        fun cell(t: String, i: Int, col: String = "#222222", bold: Boolean = false): View =
            tv(t, 9.5f, col, bold, Gravity.CENTER).also { it.layoutParams = lp(0, WRAP, wts[i]) }

        val hr = hbox()
        hr.setPadding(0, dp(7), 0, dp(7))
        bg(hr, "#EEF3EA", null, 8)
        listOf("نمبر", "قسم", "مقررہ", "مکمل", "باقی", "فیصد", "حالت").forEachIndexed { i, s ->
            hr.addView(cell(s, i, "#333333", true))
        }
        card.addView(hr)

        cats.forEachIndexed { n, cat ->
            val v = vals[cat.key]!!
            val t = tg[cat.key]!!
            val pct = if (t > 0) minOf(100, v * 100 / t) else 0
            val line = hbox()
            line.setPadding(0, dp(8), 0, dp(8))
            line.addView(cell("${n + 1}", 0))
            val q = hbox()
            val ic = tv(cat.icon, 10f, "#FFFFFF", false, Gravity.CENTER)
            circle(ic, cat.acc)
            q.addView(ic, lp(dp(22), dp(22), 0f, 0, 0, 3, 0))
            q.addView(tv(cat.ur, 9.5f, cat.acc, true), lp(0, WRAP, 1f))
            q.layoutParams = lp(0, WRAP, wts[1])
            line.addView(q)
            line.addView(cell(if (t > 0) "$t ${cat.unit}" else "--", 2))
            line.addView(cell("$v ${cat.unit}", 3))
            line.addView(cell(if (t > 0) "${(t - v).coerceAtLeast(0)}" else "--", 4))
            line.addView(cell(if (t > 0) "$pct%" else "--", 5))
            val (txt, col) = when {
                t == 0 -> "ہدف نہیں" to "#9E9E9E"
                v >= t -> "مکمل ✓" to "#0F6B33"
                else -> "نامکمل ✕" to "#E5484D"
            }
            val pill = tv(txt, 8.5f, "#FFFFFF", true, Gravity.CENTER)
            pill.setPadding(dp(3), dp(5), dp(3), dp(5))
            bg(pill, col, null, 10)
            pill.layoutParams = lp(0, WRAP, wts[6], 1, 0, 1, 0)
            line.addView(pill)
            card.addView(line)
            val sp = View(this)
            sp.setBackgroundColor(c("#E6EBE2"))
            card.addView(sp, lp(MATCH, dp(1)))
        }
        return card
    }

    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(16))
        val gd = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(c("#13703A"), c("#0A3D1C")))
        val r = dp(28).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        h.background = gd

        val mid = hbox()
        val menu = tv("☰", 28f, "#FFFFFF", true)
        menu.setOnClickListener { v -> showMenu(v) }
        mid.addView(menu, lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
        val logo = tv("MSF", 18f, "#D4AF37", true, Gravity.CENTER)
        logo.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        circle(logo, "#0B4A22", "#D4AF37", 3)
        mid.addView(logo, lp(dp(72), dp(72), 0f, 0, 0, 10, 0))
        val tx = vbox()
        val big = tv("MSF", 30f, "#E3C36A", true)
        big.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        tx.addView(big)
        tx.addView(tv("Personal Quran Record", 17f, "#FFFFFF", true))
        tx.addView(tv("— دینی سفر، بہتر انداز میں —", 12f, "#E3C36A"))
        mid.addView(tx, lp(0, WRAP, 1f))
        h.addView(mid)

        val bar = hbox()
        bar.setPadding(dp(8), dp(8), dp(8), dp(8))
        bg(bar, "#0E4A25", "#B8962E", 22)
        val prev = tv("‹", 28f, "#FFFFFF", true)
        prev.setPadding(dp(10), 0, dp(10), 0)
        prev.setOnClickListener { step(-1) }
        val next = tv("›", 28f, "#FFFFFF", true)
        next.setPadding(dp(10), 0, dp(10), 0)
        next.setOnClickListener { step(1) }
        dateTv = tv("", 15f, "#FFFFFF", true, Gravity.CENTER)
        dateTv.setOnClickListener { pickDate() }
        bar.addView(prev)
        bar.addView(dateTv, lp(0, WRAP, 1f))
        bar.addView(next)
        h.addView(bar, lp(MATCH, WRAP, 0f, 6, 12, 6, 0))
        return h
    }

    private fun showMenu(anchor: View) {
        val items = listOf<Pair<String, () -> Unit>>(
            "حفظ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "hifz")) },
            "ناظرہ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "nazra")) },
            "تمام ریکارڈز" to { go(RecordActivity::class.java) },
            "رپورٹ اور گراف" to { go(ReportActivity::class.java) },
            "ٹارگٹ" to { go(TargetActivity::class.java) },
            "پڑھنے کا وقت" to { go(TimesActivity::class.java) },
            "یاد دہانی" to { go(ReminderActivity::class.java) },
            "سیٹنگز" to { go(SettingsActivity::class.java) }
        )
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, p -> pm.menu.add(0, i, i, p.first) }
        pm.setOnMenuItemClickListener { m -> items[m.itemId].second(); true }
        pm.show()
    }

    private fun nav(i: Int) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            2 -> { go(GraphActivity::class.java); finish() }
            3 -> { startActivity(Intent(this, ReportActivity::class.java).putExtra("focus", "pdf")); finish() }
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun bottomNav(): View {
        val n = hbox()
        n.setBackgroundColor(c("#0B3D1E"))
        n.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "🗓️" to "روزانہ ریکارڈ", "📊" to "گراف", "📄" to "رپورٹ", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 1
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 11f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(44), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { nav(i) }
            n.addView(col, lp(0, WRAP, 1f))
        }
        return n
    }
}
