package com.msf.quranrecord

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import org.json.JSONObject
import java.util.Calendar

class GraphActivity : BaseActivity() {
    private class Cat(
        val key: String, val ur: String, val icon: String, val acc: String,
        val fill: String, val stroke: String, val unit: String, val sub: String
    )

    private val cats = listOf(
        Cat("hifz", "حفظ قرآن", "📖", "#0F6B33", "#EAF7EC", "#A8D5B0", "صفحہ", "کل صفحات"),
        Cat("nazra", "ناظرہ قرآن", "📘", "#0B4F9C", "#E8F3FF", "#A9CDF2", "صفحہ", "کل صفحات"),
        Cat("rep", "دہرائی", "🔄", "#6A2FB0", "#F3ECFB", "#CBBDEB", "بار", "کل بار"),
        Cat("time", "تلاوت کا وقت", "🕐", "#C98A0E", "#FFF6E3", "#F0D9A0", "منٹ", "کل منٹ")
    )
    private val modeName = mapOf("daily" to "روزانہ", "weekly" to "ہفتہ وار", "monthly" to "ماہانہ")
    private val DUA = "اللہ تعالیٰ ہماری محنت قبول فرمائے اور قرآن سے جڑے رہنے کی توفیق دے۔"
    private val green = "#1FA25A"
    private val blue = "#1E6FD9"

    private var period = "monthly"
    private val sel: Calendar = Calendar.getInstance()
    private var recs: List<JSONObject> = emptyList()
    private lateinit var body: LinearLayout
    private lateinit var sv: ScrollView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        sv = ScrollView(this)
        val content = vbox()
        sv.addView(content)
        content.addView(header())
        body = vbox()
        body.setPadding(dp(10), dp(10), dp(10), dp(14))
        content.addView(body)
        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    // ---------- data ----------
    private fun range(): Pair<String, String> {
        val s = sel.clone() as Calendar
        val e = sel.clone() as Calendar
        when (period) {
            "monthly" -> {
                s.set(Calendar.DAY_OF_MONTH, 1)
                e.set(Calendar.DAY_OF_MONTH, e.getActualMaximum(Calendar.DAY_OF_MONTH))
            }
            "weekly" -> s.add(Calendar.DAY_OF_YEAR, -6)
        }
        return Pair(Fmt.key(s), Fmt.key(e))
    }

    private fun selText(): String = when (period) {
        "monthly" -> "${Fmt.months[sel.get(Calendar.MONTH)]} ${sel.get(Calendar.YEAR)}"
        "weekly" -> {
            val s = sel.clone() as Calendar
            s.add(Calendar.DAY_OF_YEAR, -6)
            "${s.get(Calendar.DAY_OF_MONTH)} ${Fmt.months[s.get(Calendar.MONTH)]} – ${Fmt.fmt(sel)}"
        }
        else -> Fmt.fmt(sel)
    }

    private fun total(cat: String, a: String, b: String): Int {
        var s = 0
        for (r in recs) {
            val d = r.getString("d")
            if (d < a || d > b) continue
            s += when (cat) {
                "hifz" -> r.optInt("hpg", 0)
                "nazra" -> if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                "rep" -> r.optInt("rep", 0)
                "reph" -> r.optInt("reph", 0)
                "repn" -> if (r.has("repn") || r.has("reph")) r.optInt("repn", 0) else r.optInt("rep", 0)
                else -> r.optInt("min", 0)
            }
        }
        return s
    }

    private fun light(acc: String): Int = (c(acc) and 0x00FFFFFF) or (0x33 shl 24)

    private fun step(d: Int) {
        when (period) {
            "monthly" -> sel.add(Calendar.MONTH, d)
            "weekly" -> sel.add(Calendar.DAY_OF_YEAR, 7 * d)
            else -> sel.add(Calendar.DAY_OF_YEAR, d)
        }
        refresh()
    }

    private fun pickDate() {
        DatePickerDialog(this, { _, y, m, d -> sel.set(y, m, d); refresh() },
            sel.get(Calendar.YEAR), sel.get(Calendar.MONTH), sel.get(Calendar.DAY_OF_MONTH)).show()
    }

    // ---------- UI ----------
    private fun refresh() {
        recs = Store.list(this, "records")
        body.removeAllViews()
        val (a, b) = range()
        val vals = cats.associate { it.key to total(it.key, a, b) }
        val tg = cats.associate { it.key to Store.int(this, "tg_${it.key}_$period") }

        body.addView(controls())

        val row = hbox()
        row.gravity = Gravity.TOP
        cats.forEachIndexed { i, cat ->
            row.addView(statCard(cat, vals[cat.key]!!, tg[cat.key]!!),
                lp(0, MATCH, 1f, if (i == 0) 0 else 2, 0, if (i == cats.size - 1) 0 else 2, 0))
        }
        body.addView(row, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))

        val usable = resources.displayMetrics.widthPixels - dp(20)
        fun colW(wt: Float, tot: Float): Int = (usable * wt / tot).toInt() - dp(4 + 16)

        // monthly chart + donut
        val y = sel.get(Calendar.YEAR)
        val mLabels = mutableListOf<String>()
        val mH = mutableListOf<Int>(); val mN = mutableListOf<Int>()
        for (m in 0..sel.get(Calendar.MONTH)) {
            val c0 = Calendar.getInstance(); c0.clear(); c0.set(y, m, 1)
            val ma = Fmt.key(c0)
            c0.set(Calendar.DAY_OF_MONTH, c0.getActualMaximum(Calendar.DAY_OF_MONTH))
            val mb = Fmt.key(c0)
            mLabels.add(Fmt.months[m]); mH.add(total("hifz", ma, mb)); mN.add(total("nazra", ma, mb))
        }
        body.addView(
            twoCols(
                chartCard("ماہانہ پیش رفت (حفظ اور ناظرہ)", scrollChart(mLabels, mH, mN, colW(1.85f, 2.85f)), true),
                donutCard(a, b), 1.85f, 1f
            ), lp(MATCH, WRAP, 0f, 0, 10, 0, 0)
        )

        // daily chart (days of selected month) + detailed progress
        val now = Calendar.getInstance()
        val sameMonth = now.get(Calendar.YEAR) == y && now.get(Calendar.MONTH) == sel.get(Calendar.MONTH)
        val nDays = if (sameMonth) now.get(Calendar.DAY_OF_MONTH) else sel.getActualMaximum(Calendar.DAY_OF_MONTH)
        val dLabels = mutableListOf<String>()
        val dH = mutableListOf<Int>(); val dN = mutableListOf<Int>()
        for (d in 1..nDays) {
            val c0 = Calendar.getInstance(); c0.clear(); c0.set(y, sel.get(Calendar.MONTH), d)
            val k = Fmt.key(c0)
            dLabels.add("$d"); dH.add(total("hifz", k, k)); dN.add(total("nazra", k, k))
        }
        body.addView(
            twoCols(
                chartCard("روزانہ کی پیش رفت", scrollChart(dLabels, dH, dN, colW(1.65f, 2.65f), "دن "), true),
                detailCard(vals, tg), 1.65f, 1f
            ), lp(MATCH, WRAP, 0f, 0, 10, 0, 0)
        )

        // pie + weekly chart
        val wLabels = mutableListOf<String>()
        val wH = mutableListOf<Int>(); val wN = mutableListOf<Int>()
        val maxD = sel.getActualMaximum(Calendar.DAY_OF_MONTH)
        for (w in 0..3) {
            val from = w * 7 + 1
            val to = if (w == 3) maxD else from + 6
            val c0 = Calendar.getInstance(); c0.clear(); c0.set(y, sel.get(Calendar.MONTH), from)
            val wa = Fmt.key(c0)
            c0.set(Calendar.DAY_OF_MONTH, to)
            val wb = Fmt.key(c0)
            wLabels.add("ہفتہ ${w + 1}"); wH.add(total("hifz", wa, wb)); wN.add(total("nazra", wa, wb))
        }
        body.addView(
            twoCols(
                pieCard(vals, tg),
                chartCard("ہفتہ وار پیش رفت", scrollChart(wLabels, wH, wN, colW(1f, 2f)), false),
                1f, 1f
            ), lp(MATCH, WRAP, 0f, 0, 10, 0, 0)
        )

        body.addView(pdfCard(vals, tg), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        body.addView(footer(), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
    }

    private fun twoCols(left: View, right: View, wl: Float, wr: Float): View {
        val r = hbox()
        r.gravity = Gravity.TOP
        r.addView(left, lp(0, MATCH, wl, 0, 0, 4, 0))
        r.addView(right, lp(0, MATCH, wr, 4, 0, 0, 0))
        return r
    }

    private fun footer(): View {
        val f = hbox()
        f.setPadding(dp(10), dp(12), dp(10), dp(12))
        f.background = MosqueArt(true, dp(14).toFloat())
        val fi = tv("📖", 20f, "#000000", false, Gravity.CENTER)
        circle(fi, "#FFFFFF", "#D4AF37", 2)
        f.addView(fi, lp(dp(44), dp(44), 0f, 0, 0, 10, 0))
        f.addView(tv(DUA, 13f, "#0F5A2B", true), lp(0, WRAP, 1f))
        f.setOnClickListener {
            val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, DUA)
            startActivity(Intent.createChooser(i, "شیئر کریں"))
        }
        return f
    }

    private fun controls(): View {
        val r = hbox()
        val tabs = hbox()
        bg(tabs, "#FFFFFF", "#D5E6D8", 12)
        for (m in listOf("daily", "weekly", "monthly")) {
            val on = m == period
            val t = tv(modeName[m]!!, 12f, if (on) "#FFFFFF" else "#333333", on, Gravity.CENTER)
            t.setPadding(dp(6), dp(10), dp(6), dp(10))
            if (on) bg(t, "#0F5A2B", null, 10)
            t.setOnClickListener { period = m; refresh() }
            tabs.addView(t, lp(0, WRAP, 1f, 2, 2, 2, 2))
        }
        r.addView(tabs, lp(0, WRAP, 1f, 0, 0, 6, 0))

        val bar = hbox()
        bg(bar, "#FFFFFF", "#D5E6D8", 12)
        val prev = tv("‹", 24f, "#0F5A2B", true)
        prev.setPadding(dp(8), 0, dp(6), 0)
        prev.setOnClickListener { step(-1) }
        val next = tv("›", 24f, "#0F5A2B", true)
        next.setPadding(dp(6), 0, dp(8), 0)
        next.setOnClickListener { step(1) }
        val dt = tv("🗓️ " + selText(), 11f, "#222222", true, Gravity.CENTER)
        dt.setPadding(0, dp(9), 0, dp(9))
        dt.setOnClickListener { pickDate() }
        bar.addView(prev)
        bar.addView(dt, lp(0, WRAP, 1f))
        bar.addView(next)
        r.addView(bar, lp(0, WRAP, 1.25f))
        return r
    }

    private fun statCard(cat: Cat, v: Int, t: Int): View {
        val pct = if (t > 0) minOf(100, v * 100 / t) else 0
        val card = vbox()
        card.setPadding(dp(4), dp(8), dp(4), dp(8))
        bg(card, cat.fill, cat.stroke, 14)
        card.setOnClickListener { go(TargetActivity::class.java) }
        val top = hbox()
        val ic = tv(cat.icon, 12f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, cat.acc)
        top.addView(ic, lp(dp(24), dp(24), 0f, 0, 0, 3, 0))
        top.addView(tv(cat.ur, 9.5f, cat.acc, true), lp(0, WRAP, 1f))
        card.addView(top)
        card.addView(tv(cat.sub, 9f, "#555555", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        card.addView(tv(if (t > 0) "$t" else "--", 20f, "#222222", true, Gravity.CENTER))

        val rr = hbox()
        rr.gravity = Gravity.CENTER
        val ring = FrameLayout(this)
        ring.addView(RingView(this, pct, 100, c(cat.acc), light(cat.acc)), FrameLayout.LayoutParams(dp(38), dp(38)))
        ring.addView(tv("$pct%", 9f, "#222222", true, Gravity.CENTER), FrameLayout.LayoutParams(dp(38), dp(38)))
        rr.addView(ring, lp(dp(38), dp(38), 0f))
        val div = View(this)
        div.setBackgroundColor(c(cat.stroke))
        rr.addView(div, lp(dp(1), dp(34), 0f, 3, 0, 3, 0))
        val vals = vbox()
        vals.addView(tv("مکمل", 8f, "#555555", false, Gravity.CENTER), lp(MATCH, WRAP))
        vals.addView(tv("$v", 11f, "#222222", true, Gravity.CENTER), lp(MATCH, WRAP))
        vals.addView(tv("باقی", 8f, "#555555", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 3, 0, 0))
        vals.addView(tv(if (t > 0) "${(t - v).coerceAtLeast(0)}" else "--", 11f, "#222222", true, Gravity.CENTER), lp(MATCH, WRAP))
        rr.addView(vals, lp(0, WRAP, 1f))
        card.addView(rr, lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        return card
    }

    private fun dot(col: String, text: String): View {
        val h = hbox()
        val d = View(this)
        circle(d, col)
        h.addView(d, lp(dp(9), dp(9), 0f, 0, 0, 4, 0))
        h.addView(tv(text, 10f, "#333333"))
        return h
    }

    private fun titleRow(icon: String, title: String): View {
        val h = hbox()
        val ic = tv(icon, 13f, "#FFFFFF", false, Gravity.CENTER)
        bg(ic, "#0F6B33", null, 8)
        h.addView(ic, lp(dp(26), dp(26), 0f, 0, 0, 6, 0))
        h.addView(tv(title, 12f, "#222222", true), lp(0, WRAP, 1f))
        return h
    }

    private fun cardBox(): LinearLayout {
        val card = vbox()
        card.setPadding(dp(8), dp(10), dp(8), dp(8))
        bg(card, "#FFFFFF", "#BBD7C0", 14)
        return card
    }

    private fun chartCard(title: String, chart: View, legendInline: Boolean): View {
        val card = cardBox()
        val tr = titleRow("📊", title)
        if (legendInline) {
            val lg = hbox()
            lg.addView(dot(green, "حفظ"), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
            lg.addView(dot(blue, "ناظرہ"))
            (tr as LinearLayout).addView(lg)
            card.addView(tr)
        } else {
            card.addView(tr)
            val lg = hbox()
            lg.addView(dot(green, "حفظ"), lp(WRAP, WRAP, 0f, 0, 0, 10, 0))
            lg.addView(dot(blue, "ناظرہ"))
            card.addView(lg, lp(MATCH, WRAP, 0f, 0, 4, 0, 0))
        }
        card.addView(chart, lp(MATCH, dp(170), 0f, 0, 4, 0, 0))
        return card
    }

    private fun scrollChart(labels: List<String>, a: List<Int>, b: List<Int>, availPx: Int, prefix: String = ""): View {
        val hs = HorizontalScrollView(this)
        hs.isHorizontalScrollBarEnabled = false
        val w = maxOf(availPx, labels.size * dp(34) + dp(36))
        val chart = GroupBarView(this, labels, a, b, c(green), c(blue))
        chart.onTap = { i ->
            toast("$prefix${labels[i]}  —  حفظ: ${a[i]}  |  ناظرہ: ${b[i]} صفحات")
        }
        hs.addView(chart, FrameLayout.LayoutParams(w, dp(170)))
        return hs
    }

    private fun donutCard(a: String, b: String): View {
        val h = total("reph", a, b)
        val n = total("repn", a, b)
        val tot = h + n
        val ph = if (tot == 0) 0 else Math.round(h * 100f / tot)
        val pn = if (tot == 0) 0 else 100 - ph
        val card = cardBox()
        card.addView(titleRow("🔄", "کل دہرائیوں کی تعداد"))
        val rw = hbox()
        val fl = FrameLayout(this)
        fl.addView(DonutView(this, h, n, c(green), c(blue), 0.16f), FrameLayout.LayoutParams(dp(58), dp(58)))
        val ct = vbox()
        ct.gravity = Gravity.CENTER
        ct.addView(tv("دہرائیاں", 7f, "#555555", false, Gravity.CENTER))
        ct.addView(tv("$tot", 14f, "#222222", true, Gravity.CENTER))
        fl.addView(ct, FrameLayout.LayoutParams(dp(58), dp(58)))
        rw.addView(fl, lp(dp(58), dp(58), 0f, 0, 0, 4, 0))
        val lg = vbox()
        fun leg(col: String, name: String, v: Int, p: Int): View {
            val x = vbox()
            x.addView(dot(col, name))
            x.addView(tv("$v ($p%)", 9f, "#333333", true), lp(WRAP, WRAP, 0f, 13, 0, 0, 0))
            return x
        }
        lg.addView(leg(green, "حفظ", h, ph))
        lg.addView(leg(blue, "ناظرہ", n, pn), lp(MATCH, WRAP, 0f, 0, 6, 0, 0))
        rw.addView(lg, lp(0, WRAP, 1f))
        card.addView(rw, lp(MATCH, WRAP, 0f, 0, 10, 0, 6))
        card.setOnClickListener { toast("حفظ کی دہرائی: $h بار  |  ناظرہ کی دہرائی: $n بار") }
        return card
    }

    private fun detailCard(vals: Map<String, Int>, tg: Map<String, Int>): View {
        val card = cardBox()
        card.addView(titleRow("📖", "تفصیلی پیش رفت"))
        for (cat in cats) {
            val t = tg[cat.key]!!
            val pct = if (t > 0) minOf(100, vals[cat.key]!! * 100 / t) else 0
            val row = hbox()
            val ic = tv(cat.icon, 11f, "#FFFFFF", false, Gravity.CENTER)
            circle(ic, cat.acc)
            row.addView(ic, lp(dp(24), dp(24), 0f, 0, 0, 5, 0))
            val col = vbox()
            col.addView(tv(cat.ur, 9.5f, cat.acc, true))
            val bot = hbox()
            bot.addView(BarView(this, pct / 100f, c(cat.acc), light(cat.acc)), lp(0, dp(7), 1f, 0, 0, 4, 0))
            bot.addView(tv(if (t > 0) "$pct%" else "--", 9.5f, "#333333", true))
            col.addView(bot, lp(MATCH, WRAP, 0f, 0, 2, 0, 0))
            row.addView(col, lp(0, WRAP, 1f))
            row.setOnClickListener { go(TargetActivity::class.java) }
            card.addView(row, lp(MATCH, WRAP, 0f, 0, 9, 0, 0))
        }
        return card
    }

    private fun pieCard(vals: Map<String, Int>, tg: Map<String, Int>): View {
        val pcts = cats.map { cat ->
            val t = tg[cat.key]!!
            if (t > 0) minOf(100, vals[cat.key]!! * 100 / t) else 0
        }
        val sum = pcts.sum()
        val card = cardBox()
        card.addView(titleRow("📖", "مجموعی کارکردگی"))
        val pie = PieView(this, pcts, cats.map { c(it.acc) })
        card.addView(pie, lp(MATCH, dp(96), 0f, 0, 8, 0, 6))
        cats.forEachIndexed { i, cat ->
            val share = if (sum == 0) 0 else Math.round(pcts[i] * 100f / sum)
            val r = hbox()
            r.addView(dot(cat.acc, cat.ur), lp(0, WRAP, 1f))
            r.addView(tv("$share%", 10f, "#333333", true))
            card.addView(r, lp(MATCH, WRAP, 0f, 0, 3, 0, 0))
        }
        card.setOnClickListener {
            toast(cats.mapIndexed { i, cat -> "${cat.ur}: ${pcts[i]}%" }.joinToString("  |  "))
        }
        return card
    }

    private fun pdfCard(vals: Map<String, Int>, tg: Map<String, Int>): View {
        val card = cardBox()
        val row = hbox()
        val ic = tv("PDF", 13f, "#FFFFFF", true, Gravity.CENTER)
        bg(ic, "#E53935", null, 8)
        ic.setOnClickListener { exportPdf(vals, tg) }
        row.addView(ic, lp(dp(46), dp(52), 0f, 0, 0, 10, 0))
        val t = vbox()
        t.addView(tv("رپورٹ PDF", 14f, "#222222", true))
        t.addView(tv("اپنی ماہانہ، ہفتہ وار اور روزانہ کی رپورٹ PDF میں محفوظ کریں۔", 10f, "#555555"))
        row.addView(t, lp(0, WRAP, 1f))
        card.addView(row)
        val b = tv("⬇   رپورٹ ڈاؤنلوڈ کریں", 14f, "#FFFFFF", true, Gravity.CENTER)
        b.setPadding(dp(10), dp(13), dp(10), dp(13))
        bg(b, "#0F5A2B", null, 12)
        b.setOnClickListener { exportPdf(vals, tg) }
        card.addView(b, lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        return card
    }

    // ---------- PDF ----------
    private fun exportPdf(vals: Map<String, Int>, tg: Map<String, Int>) {
        try {
            val (a, b) = range()
            val dark = Color.parseColor("#0F5A2B")
            val lines = mutableListOf<PdfExport.Line>()
            lines.add(PdfExport.Line("MSF Personal Quran Record", 20f, true, dark))
            lines.add(PdfExport.Line("${modeName[period]} رپورٹ — ${selText()}", 14f, true))
            lines.add(PdfExport.Line("", 8f))
            for (cat in cats) {
                val v = vals[cat.key]!!
                val t = tg[cat.key]!!
                val txt = if (t > 0) "حاصل $v ${cat.unit}  |  ٹارگٹ $t ${cat.unit}  |  باقی ${(t - v).coerceAtLeast(0)} ${cat.unit}  |  ${minOf(100, v * 100 / t)}%"
                else "حاصل $v ${cat.unit}  |  ٹارگٹ مقرر نہیں"
                lines.add(PdfExport.Line("${cat.ur}: $txt", 13f))
            }
            lines.add(PdfExport.Line("دہرائی کی تقسیم: حفظ ${total("reph", a, b)} بار، ناظرہ ${total("repn", a, b)} بار", 12f))
            lines.add(PdfExport.Line("", 10f))
            lines.add(PdfExport.Line("تفصیلی ریکارڈ", 15f, true, dark))
            val list = recs.filter { val d = it.getString("d"); d >= a && d <= b }.sortedByDescending { it.getString("d") }
            if (list.isEmpty()) lines.add(PdfExport.Line("اس مدت میں کوئی ریکارڈ نہیں", 12f))
            for (r in list) {
                val npg = if (r.has("np")) r.optInt("npg", 0) else r.optInt("pages", 0)
                lines.add(PdfExport.Line(
                    "${r.getString("d")} | ${r.optString("session")} | حفظ ${r.optInt("hpg", 0)} ص | ناظرہ $npg ص | " +
                        "دہرائی ${r.optInt("rep", 0)} | ${r.optInt("min", 0)} منٹ", 11f))
            }
            val doc = PdfExport.build(lines)
            val (uri, where) = PdfExport.save(this, doc, "MSF_Graph_Report_${a}_to_$b.pdf")
            doc.close()
            showSaved(uri, where)
        } catch (ex: Exception) {
            toast("PDF نہیں بن سکی")
        }
    }

    private fun showSaved(uri: Uri?, where: String) {
        val b = AlertDialog.Builder(this).setTitle("رپورٹ محفوظ ہو گئی")
        if (uri == null) {
            b.setMessage("فائل یہاں محفوظ ہوئی:\n$where").setPositiveButton("ٹھیک ہے", null).show()
            return
        }
        b.setMessage("PDF ڈاؤنلوڈز فولڈر میں محفوظ ہو گئی۔")
            .setPositiveButton("کھولیں") { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, "application/pdf")
                        .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (ex: ActivityNotFoundException) {
                    toast("PDF کھولنے والی ایپ موجود نہیں")
                }
            }
            .setNeutralButton("شیئر کریں") { _, _ ->
                val i = Intent(Intent.ACTION_SEND).setType("application/pdf")
                    .putExtra(Intent.EXTRA_STREAM, uri).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                startActivity(Intent.createChooser(i, "رپورٹ شیئر کریں"))
            }
            .setNegativeButton("بند کریں", null)
            .show()
    }

    // ---------- header / nav ----------
    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(12), dp(10), dp(12), dp(10))
        h.background = MosqueArt(false)

        val mid = hbox()
        val back = tv("←", 28f, "#FFFFFF", true)
        back.setOnClickListener { finish() }
        mid.addView(back, lp(WRAP, WRAP, 0f, 0, 0, 6, 0))
        mid.addView(tv("گراف", 18f, "#FFFFFF", true), lp(WRAP, WRAP, 0f, 0, 0, 8, 0))
        val logo = tv("MSF", 16f, "#D4AF37", true, Gravity.CENTER)
        logo.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        circle(logo, "#0B4A22", "#D4AF37", 3)
        logo.setOnClickListener { tab(0, false) }
        mid.addView(logo, lp(dp(62), dp(62), 0f, 0, 0, 8, 0))
        val tx = vbox()
        val big = tv("MSF", 26f, "#E3C36A", true)
        big.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        tx.addView(big)
        tx.addView(tv("Personal Quran Record", 14f, "#FFFFFF", true))
        tx.addView(tv("— ذاتی حفظ و ناظرہ ریکارڈ ایپ —", 11f, "#E3C36A"))
        mid.addView(tx, lp(0, WRAP, 1f))
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 0, 0, 10))

        val tabs = hbox()
        bg(tabs, "#0C4A24", "#B8962E", 12)
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val t = vbox()
            t.gravity = Gravity.CENTER
            t.setPadding(dp(2), dp(8), dp(2), dp(8))
            t.addView(tv(p.first, 20f, "#FFFFFF", false, Gravity.CENTER))
            t.addView(tv(p.second, 12f, "#FFFFFF", true, Gravity.CENTER))
            t.setOnClickListener { tab(i, false) }
            tabs.addView(t, lp(0, WRAP, 1f, 1, 1, 1, 1))
            if (i < items.size - 1) {
                val dv = View(this)
                dv.setBackgroundColor(c("#3F7F58"))
                tabs.addView(dv, lp(dp(1), dp(38)))
            }
        }
        h.addView(tabs)
        return h
    }

    private fun tab(i: Int, bottom: Boolean) {
        when (i) {
            0 -> startActivity(Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP))
            1 -> { go(RecordActivity::class.java); finish() }
            2 -> { go(TargetActivity::class.java); finish() }
            3 -> if (bottom) sv.smoothScrollTo(0, 0) else { go(ReportActivity::class.java); finish() }
            4 -> { go(SettingsActivity::class.java); finish() }
        }
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf("🏠" to "ہوم", "📝" to "ریکارڈز", "🎯" to "ٹارگٹ", "📊" to "رپورٹس", "⚙️" to "سیٹنگز")
        items.forEachIndexed { i, p ->
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = i == 3
            col.addView(tv(p.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(p.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(44), dp(3), 0f, 0, 3, 0, 0))
            }
            col.setOnClickListener { tab(i, true) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }
}
