package com.msf.quranrecord

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class MainActivity : BaseActivity() {
    private lateinit var content: LinearLayout

    private val days = arrayOf("اتوار", "پیر", "منگل", "بدھ", "جمعرات", "جمعہ", "ہفتہ")
    private val months = arrayOf(
        "جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
        "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) Lock.unlocked = false
        super.onCreate(savedInstanceState)
        val root = vbox()
        root.setBackgroundColor(c("#F7FAF7"))
        val sv = ScrollView(this)
        content = vbox()
        sv.addView(content)
        root.addView(sv, lp(MATCH, 0, 1f))
        root.addView(bottomNav(), lp(MATCH, WRAP))
        setContentView(root)
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }
    }

    override fun onResume() {
        super.onResume()
        render()
    }

    private fun fmt(cal: Calendar) =
        "${cal.get(Calendar.DAY_OF_MONTH)} ${months[cal.get(Calendar.MONTH)]} ${cal.get(Calendar.YEAR)}"

    private fun render() {
        content.removeAllViews()
        val hifz = Store.paras(this, "hifz").size
        val nazra = Store.paras(this, "nazra").size

        content.addView(header())

        // Greeting card (overlaps header)
        val cal = Calendar.getInstance()
        val g = hbox()
        g.setPadding(dp(12), dp(12), dp(12), dp(12))
        bg(g, "#F4F9EE", "#D9E8D2", 18)
        g.elevation = dp(4).toFloat()
        g.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val gi = tv("🕌", 30f, "#000000", false, Gravity.CENTER)
        bg(gi, "#EAF2D9", null, 16)
        g.addView(gi, lp(dp(56), dp(56), 0f, 0, 0, 10, 0))
        val gt = vbox()
        gt.addView(tv("السلام علیکم!", 20f, "#0F5A2B", true))
        gt.addView(tv("آج کا دن: ${days[cal.get(Calendar.DAY_OF_WEEK) - 1]}، ${fmt(cal)}", 14f, "#333333"))
        g.addView(gt, lp(0, WRAP, 1f))
        content.addView(g, lp(MATCH, WRAP, 0f, 16, -30, 16, 0))

        // Hifz & Nazra cards
        var hifzDate = "--"
        val hd = Store.str(this, "hifz_date")
        if (hd.isNotEmpty()) {
            val c2 = Calendar.getInstance()
            c2.time = SimpleDateFormat("yyyy-MM-dd", Locale.US).parse(hd)!!
            hifzDate = fmt(c2)
        }
        val row = hbox()
        row.gravity = Gravity.TOP
        row.addView(
            paraCard("حفظ قرآن مجید", "Hifz", "📖", hifz, "#0F6B33", "#EAF7EC", "#A8D5B0",
                "مکمل حفظ کی تاریخ: $hifzDate", "📅", "hifz"),
            lp(0, WRAP, 1f, 0, 0, 5, 0)
        )
        row.addView(
            paraCard("ناظرہ قرآن مجید", "Nazra", "📘", nazra, "#0B4F9C", "#E8F3FF", "#A9CDF2",
                "ناظرہ کی دہرائی: ${Store.int(this, "nazra_rep")} بار", "📖", "nazra"),
            lp(0, WRAP, 1f, 5, 0, 0, 0)
        )
        content.addView(row, lp(MATCH, WRAP, 0f, 12, 12, 12, 0))

        // 4 feature tiles
        val tiles = hbox()
        tiles.gravity = Gravity.TOP
        tiles.addView(mini("🗓️", "روزانہ کا ریکارڈ", "آج کی تفصیلات دیکھیں", "#5B35B0", "#F1ECFB", "#CBBDEB", DailyActivity::class.java), lp(0, WRAP, 1f, 0, 0, 4, 0))
        tiles.addView(mini("📊", "رپورٹ اور گراف", "اپنی پیش رفت دیکھیں", "#C98A0E", "#FFF6E3", "#F0D9A0", ReportActivity::class.java), lp(0, WRAP, 1f, 2, 0, 4, 0))
        tiles.addView(mini("🎯", "ٹارگٹ", "اپنے اہداف مقرر کریں", "#0F8A6E", "#E6F7F3", "#A9DDD0", TargetActivity::class.java), lp(0, WRAP, 1f, 2, 0, 4, 0))
        tiles.addView(mini("⏰", "پڑھنے کا وقت", "اوقات درج کریں", "#D32F3F", "#FDECEE", "#F2B8BF", TimesActivity::class.java), lp(0, WRAP, 1f, 2, 0, 0, 0))
        content.addView(tiles, lp(MATCH, WRAP, 0f, 12, 10, 12, 0))

        // 2 wide cards
        val wides = hbox()
        wides.addView(wide("📅", "آج قرآن کیوں نہیں پڑھا؟", "اپنی وجہ درج کریں", "#4B2FA0", "#F1ECFB", "#CBBDEB", ReasonActivity::class.java), lp(0, WRAP, 1f, 0, 0, 5, 0))
        wides.addView(wide("🔔", "یاد دہانی", "روزانہ قرآن پڑھنے کے لیے", "#0F8A6E", "#E6F7F3", "#A9DDD0", ReminderActivity::class.java), lp(0, WRAP, 1f, 5, 0, 0, 0))
        content.addView(wides, lp(MATCH, WRAP, 0f, 12, 10, 12, 0))

        // Footer quote
        val f = tv("“قرآن دلوں کی زندگی ہے، اسے پڑھیں، سمجھیں اور اس پر عمل کریں۔”", 15f, "#0F5A2B", true, Gravity.CENTER)
        f.setPadding(dp(14), dp(18), dp(14), dp(18))
        bg(f, "#EAF3E4", "#CFE2C9", 16)
        content.addView(f, lp(MATCH, WRAP, 0f, 12, 10, 12, 16))
    }

    private fun header(): View {
        val h = vbox()
        h.setPadding(dp(16), dp(14), dp(16), dp(44))
        val gd = GradientDrawable(
            GradientDrawable.Orientation.TL_BR,
            intArrayOf(c("#13703A"), c("#0A3D1C"))
        )
        val r = dp(28).toFloat()
        gd.cornerRadii = floatArrayOf(0f, 0f, 0f, 0f, r, r, r, r)
        h.background = gd

        val top = hbox()
        val menu = tv("☰", 28f, "#FFFFFF", true)
        menu.setOnClickListener { v -> showMenu(v) }
        val bell = tv("🔔", 26f, "#FFFFFF")
        bell.setOnClickListener { go(ReminderActivity::class.java) }
        top.addView(menu, lp(WRAP, WRAP, 0f, 0, 0, 0, 0))
        top.addView(View(this), lp(0, 1, 1f))
        top.addView(bell)
        h.addView(top)

        val mid = hbox()
        val logo = tv("MSF", 24f, "#D4AF37", true, Gravity.CENTER)
        logo.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        circle(logo, "#0B4A22", "#D4AF37", 3)
        mid.addView(logo, lp(dp(92), dp(92), 0f, 4, 0, 14, 0))
        val tx = vbox()
        val big = tv("MSF", 36f, "#E3C36A", true)
        big.typeface = android.graphics.Typeface.create("serif", android.graphics.Typeface.BOLD)
        tx.addView(big)
        tx.addView(tv("Personal Quran Record", 20f, "#FFFFFF", true))
        tx.addView(tv("— ذاتی حفظ و ناظرہ ریکارڈ ایپ —", 14f, "#E3C36A"))
        mid.addView(tx, lp(0, WRAP, 1f))
        h.addView(mid, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))

        val v1 = tv("وَمَا تَوْفِيقِي إِلَّا بِاللَّهِ", 20f, "#FFFFFF", true, Gravity.END)
        val v2 = tv("میری توفیق تو صرف اللہ ہی سے ہے۔ (ھود: 88)", 12f, "#E8F2E8", false, Gravity.END)
        h.addView(v1, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        h.addView(v2)
        return h
    }

    private fun showMenu(anchor: View) {
        val items = listOf<Pair<String, () -> Unit>>(
            "حفظ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "hifz")) },
            "ناظرہ قرآن مجید" to { startActivity(Intent(this, ParaActivity::class.java).putExtra("type", "nazra")) },
            "روزانہ کا ریکارڈ" to { go(DailyActivity::class.java) },
            "تمام ریکارڈز" to { go(RecordActivity::class.java) },
            "رپورٹ اور گراف" to { go(ReportActivity::class.java) },
            "گراف" to { go(GraphActivity::class.java) },
            "ٹارگٹ" to { go(TargetActivity::class.java) },
            "پڑھنے کا وقت" to { go(TimesActivity::class.java) },
            "یاد دہانی" to { go(ReminderActivity::class.java) },
            "سیٹنگز" to { go(SettingsActivity::class.java) }
        )
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, p -> pm.menu.add(0, i, i, p.first) }
        pm.setOnMenuItemClickListener { m -> items[m.itemId].second(); true }
        pm.show()
    }

    private fun paraCard(
        ur: String, en: String, icon: String, done: Int, accent: String, fill: String, stroke: String,
        strip: String, stripIcon: String, type: String
    ): View {
        val card = vbox()
        card.setPadding(dp(10), dp(12), dp(10), dp(10))
        bg(card, fill, stroke, 18)
        card.setOnClickListener {
            startActivity(Intent(this, ParaActivity::class.java).putExtra("type", type))
        }

        val top = hbox()
        top.layoutDirection = View.LAYOUT_DIRECTION_RTL
        val ic = tv(icon, 20f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, accent)
        top.addView(ic, lp(dp(44), dp(44), 0f, 0, 0, 6, 0))
        val tt = vbox()
        tt.addView(tv(ur, 16f, accent, true))
        tt.addView(tv(en, 13f, accent))
        top.addView(tt, lp(0, WRAP, 1f))
        top.addView(tv("‹", 26f, accent, true))
        card.addView(top)

        val mid = hbox()
        val ringBox = FrameLayout(this)
        val ac = c(accent)
        val trackCol = (ac and 0x00FFFFFF) or (0x33 shl 24)
        ringBox.addView(RingView(this, done, 30, ac, trackCol), FrameLayout.LayoutParams(dp(78), dp(78)))
        val ct = vbox()
        ct.gravity = Gravity.CENTER
        ct.addView(tv("$done/30", 16f, "#222222", true, Gravity.CENTER))
        ct.addView(tv("پارے مکمل", 9f, "#555555", false, Gravity.CENTER))
        ringBox.addView(ct, FrameLayout.LayoutParams(dp(78), dp(78)))
        mid.addView(ringBox, lp(dp(78), dp(78), 0f, 0, 8, 6, 0))
        val st = vbox()
        st.addView(tv("کل پارے: 30", 13f, "#222222", true, Gravity.END))
        st.addView(tv("باقی پارے: ${30 - done}", 13f, "#222222", true, Gravity.END), lp(MATCH, WRAP, 0f, 0, 10, 0, 0))
        mid.addView(st, lp(0, WRAP, 1f))
        card.addView(mid)

        val s = hbox()
        s.layoutDirection = View.LAYOUT_DIRECTION_RTL
        s.setPadding(dp(6), dp(8), dp(6), dp(8))
        bg(s, "#FFFFFF", stroke, 10)
        s.addView(tv(stripIcon, 15f), lp(WRAP, WRAP, 0f, 0, 0, 4, 0))
        s.addView(tv(strip, 10f, "#333333"), lp(0, WRAP, 1f))
        card.addView(s, lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        return card
    }

    private fun mini(icon: String, ur: String, sub: String, accent: String, fill: String, stroke: String, cls: Class<*>): View {
        val v = vbox()
        v.gravity = Gravity.CENTER_HORIZONTAL
        v.setPadding(dp(4), dp(12), dp(4), dp(8))
        bg(v, fill, stroke, 16)
        v.setOnClickListener { go(cls) }
        val ic = tv(icon, 22f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, accent)
        v.addView(ic, lp(dp(46), dp(46)))
        v.addView(tv(ur, 12f, accent, true, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 8, 0, 0))
        v.addView(tv(sub, 9f, "#555555", false, Gravity.CENTER), lp(MATCH, WRAP, 0f, 0, 3, 0, 0))
        v.addView(tv("›", 20f, accent, true, Gravity.CENTER))
        return v
    }

    private fun wide(icon: String, ur: String, sub: String, accent: String, fill: String, stroke: String, cls: Class<*>): View {
        val v = hbox()
        v.layoutDirection = View.LAYOUT_DIRECTION_RTL
        v.setPadding(dp(8), dp(12), dp(8), dp(12))
        bg(v, fill, stroke, 16)
        v.setOnClickListener { go(cls) }
        val ic = tv(icon, 20f, "#FFFFFF", false, Gravity.CENTER)
        circle(ic, accent)
        v.addView(ic, lp(dp(42), dp(42), 0f, 0, 0, 8, 0))
        val t = vbox()
        t.addView(tv(ur, 13f, accent, true))
        t.addView(tv(sub, 10f, "#555555"))
        v.addView(t, lp(0, WRAP, 1f))
        v.addView(tv("‹", 22f, accent, true))
        return v
    }

    private fun bottomNav(): View {
        val nav = hbox()
        nav.setBackgroundColor(c("#0B3D1E"))
        nav.setPadding(0, dp(8), 0, dp(8))
        val items = listOf<Triple<String, String, Class<*>?>>(
            Triple("🏠", "ہوم", null),
            Triple("📖", "ریکارڈ", RecordActivity::class.java),
            Triple("🎯", "ٹارگٹ", TargetActivity::class.java),
            Triple("📊", "رپورٹ", ReportActivity::class.java),
            Triple("⚙️", "سیٹنگز", SettingsActivity::class.java)
        )
        for (it in items) {
            val col = vbox()
            col.gravity = Gravity.CENTER_HORIZONTAL
            val active = it.third == null
            col.addView(tv(it.first, 22f, "#FFFFFF", false, Gravity.CENTER))
            col.addView(tv(it.second, 12f, if (active) "#F5B301" else "#FFFFFF", active, Gravity.CENTER))
            if (active) {
                val line = View(this)
                line.setBackgroundColor(c("#F5B301"))
                col.addView(line, lp(dp(40), dp(3), 0f, 0, 3, 0, 0))
            }
            val cls = it.third
            if (cls != null) col.setOnClickListener { go(cls) }
            nav.addView(col, lp(0, WRAP, 1f))
        }
        return nav
    }
}
