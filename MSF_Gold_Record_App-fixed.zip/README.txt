MSF Gold Business Record - Android App (Kotlin + Jetpack Compose)

GitHub par upload karne ke baad:
1. Zip extract karke sari files repository mein push karein.
2. GitHub > Actions > "Build APK" chalaein (push par khud chalta hai).
3. Run complete hone par Artifacts se MSF-Gold-Record-APK download karein.

Ya Android Studio mein folder open karke Run karein.
Icons: app/src/main/res/mipmap-*  |  GitHub profile image: store/github_profile_500.png

Update: Reports screen (ReportsScreen.kt) ab naye design ke mutabiq hai.
- Date range (aaj/hafta/maah/saal ya khud ki tareekh), 5 summary cards, sone ka donut, mazdoori ka chart,
  sone ki qeemat, karigar table, rozana report, aur 5 "mazeed reports" (sab buttons kaam karte hain).
- Mazdoori form mein ab "sone ka wazan" aur "ada shuda raqam" bhi darj hota hai.

Update: Settings screen (SettingsScreen.kt) naye design ke mutabiq. Account, privacy (app lock), notifications,
theme, language, backup, app info, help aur logout - sab buttons kaam karte hain.

Update: Working People screen (WorkerScreen.kt) ab naye design ke mutabiq hai.
- Header banner, 4 rang-birangay cards (kul afrad / mard / khawateen / duty par), search, date, filter,
  5 action buttons (naya mulazim, tankhwah ki fehrist, hazri report, excel/CSV export, print) aur mulazimeen ki table.
- Table mein tasveer, naam, ohda, shanakhti number, phone, hazri (tap se badlein), tankhwah, halat (tap se chutti/mukammal),
  aur view / edit / delete buttons. Neeche kul mulazimeen, kul tankhwah, hazri ausat, aaj ki hazri.
- Naye screens: Hazri (AttendanceScreen) aur Tankhwah (SalaryScreen); nav bar ke sab buttons kaam karte hain.

Update: Kaam ke ghante o minute screen (HoursScreen.kt) ab naye design ke mutabiq hai.
- Header, 4 cards (kul mulazimeen, kul ghante, kul minute, ausat ghante), search, date, "aaj ka data" button,
  filter chips (tamam/mard/khawateen/mehkma/halat), records table (aghaz/khatam waqt, ghante, minute, halat, tafseelat, view/edit/delete).
- "Naya record darj karein" mein mulazim, tareekh, aghaz aur khatam waqt (time picker) aur halat. Halat par tap se badalti hai.
- Naya Graph screen (HoursGraphScreen) bhi shamil hai; nav bar ke sab buttons kaam karte hain.
- Working People screen ki ordering reference image ke mutabiq theek ki gayi.

Update: Mazdoori ka Hisab screen (WageScreen.kt) ab naye design ke mutabiq hai.
- Header (logo + banner), 6 buttons wali nav bar (ہوم / مزدور / حساب / تاریخ / رپورٹس / سیٹنگز), 4 cards
  (آج کی مزدوری, کل کام کے گھنٹے, کل ادائیگی, کل مزدور), تازہ کریں, date picker, search, filter (کام کی قسم / خواتین / مرد / تمام).
- Table: tasveer, naam, kaam ki qism, mulazimat ke din, kul ghante, fi ghanta rate, kul mazdoori, halat (ada ho chuka / baqi hai),
  view / edit / delete. Halat par tap: baqi ho to adaigi dialog, warna tafseel; mazdoori na ho to naya indraj.
- "نیا مزدور شامل کریں" mein ab "فی گھنٹہ ریٹ" bhi hai; mazdoori khali chhorne par ghante x rate se khud ban jati hai.
- Naya "تاریخ" screen (WageHistoryScreen): mahine ke hisab se rozana mazdoori ka record, edit / delete / share.

Update: Fonts (app/src/main/res/font + Fonts.kt).
- 4 fonts shamil hain: Jameel Noori Kasheeda (default), Al Majeed Quranic, Al Mushaf Quran, Al Qalam Quran.
- Poori app mein font lagta hai (MaterialTheme typography + ProvideTextStyle).
- Settings > "فونٹ" se font badal sakte hain; intikhab save rehta hai.

Update: Reports (ReportsScreen.kt) aur Receipts (ReceiptsScreen.kt) naye design ke mutabiq.
- Reports: header + 6 button nav (ہوم / رپورٹس / مالی رپورٹ / فہرست / گراف / سیٹنگز), tareekh dropdown + تازہ کریں,
  4 rang-birangay cards (آمدن / خرچ / منافع / لین دین, pichli muddat se % farq), خرچ کی تقسیم (pie), آمدن و خرچ (bar),
  منافع کا رجحان (line), ٹرانزیکشنز table, 4 summary cards. Har card/chart/button kaam karta hai.
  "➕ خرچ" se bijli/pani, kiraya/bill, deegar akhrajat darj hote hain (pie chart mein nazar aate hain).
- Receipts: header + nav, 4 cards, talash + tareekh filter, qism/zamra filter, "نئی رسید بنائیں",
  table (view / edit / delete), 4 summary cards. Sale/purchase/wage ki raseedein khud list mein aati hain;
  nayi raseed haath se bhi bani ja sakti hai (share/print, mukammal ada, tarmeem, hazf).
- Nichli nav bar (ہوم / گاہک / رسیدیں / خریداری-فروخت / رپورٹس / سیٹنگز) dono screens par.

Update: Calculator (CalcScreen.kt) aur Settings (SettingsScreen.kt) naye design ke mutabiq.
- Calculator: header (تاریخ / سیٹنگز), display, "حال ہی کی گنتیاں" (tap se dobara istemal, تمام صاف کریں, save rehti hai),
  MC / MR / M+ / M- / MS, % √ +/- ÷ × − +, 0-9, ., =. Display mein C aur DEL bhi hain. Button ki awaz/vibration Settings se.
- Settings: profile card, 9 items (network, اطلاعات, آواز, ڈسپلے, رازداری, ایپس, اسٹوریج, زبان, ایپ کے بارے میں) + ڈارک موڈ switch.
  Display mein font, font size aur chamak; Storage mein backup; Privacy mein app lock / logout / data mitana.
- Nichli nav bar: ہوم / مزدوری / ریپورٹس / کیلکولیٹر / سیٹنگز (Ui4.kt).

Update: Backup screens (BackupScreens.kt + BackupLogic.kt) naye design ke mutabiq.
- Screens: backup (بیک اپ), bkfiles (بیک اپ فائلیں), bkrestore (بحالی), bkhist (ہسٹری). Home > بیک اپ se ya Settings > اسٹوریج se khulti hain.
- Backup ek ZIP file hoti hai (data.json + karigaron ki tasaweer) jo app ke andar "backups" folder mein save hoti hai;
  share / phone mein save / bahal / delete sab kaam karte hain. Zyada se zyada 20 backups rakhe jate hain.
- Schedule (roozana / haftawar / mahana): app kholte waqt agar waqt ho gaya ho to khud backup ho jata hai.
- Restore: "zam karein" (naye records shamil) ya "tabdeel karein" (backup wali qismon ka mojooda data badal dein).
  Purani JSON / clipboard backup bhi bahal hoti hai.
