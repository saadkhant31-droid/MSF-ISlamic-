package com.msf.goldrecord

import android.content.Context
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.compose.ui.graphics.Color
import androidx.core.content.FileProvider
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedOutputStream
import java.io.ByteArrayInputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

class BkType(val key: String, val name: String, val src: String, val icon: String)
class BkGroup(val key: String, val name: String, val sub: String, val icon: String, val c1: Color, val c2: Color, val types: List<String>)
class BkStat(val count: Int, val bytes: Long, val last: Long)
class BkLog(val ms: Long, val kind: String, val name: String, val bytes: Long, val count: Int, val ok: Boolean)
class BkMade(val file: File, val count: Int)
class BkRes(val ok: Boolean, val msg: String, val count: Int)

object Bk {
    val types = listOf(
        BkType("purchase", "خریداری", "/خریداری", "🛒"), BkType("sale", "فروخت", "/فروخت", "🧾"),
        BkType("stock", "سونے کا اسٹاک", "/اسٹاک", "🪙"), BkType("customer", "گاہک", "/گاہک", "👥"),
        BkType("worker", "کاریگر", "/کاریگر", "👷"), BkType("wage", "مزدوری", "/مزدوری", "💰"),
        BkType("hours", "کام کے اوقات", "/اوقات", "⏱"), BkType("attend", "حاضری", "/حاضری", "📅"),
        BkType("salpay", "تنخواہ کی ادائیگی", "/تنخواہ", "💵"), BkType("receipt", "رسیدیں", "/رسیدیں", "📄"),
        BkType("expense", "اخراجات", "/اخراجات", "💡"), BkType("#photos", "کاریگروں کی تصاویر", "/Photos", "🖼"),
        BkType("#app", "ایپ کی ترتیبات", "/Settings", "⚙"))

    val groups = listOf(
        BkGroup("photos", "تصاویر", "کاریگروں کی تمام تصاویر", "🖼", Color(0xFF34B866), Color(0xFF1B8A3F), listOf("#photos")),
        BkGroup("trade", "خریداری اور فروخت", "سونے کی خرید، فروخت اور اسٹاک", "🛒", Color(0xFFF2545B), Color(0xFFD32F2F), listOf("purchase", "sale", "stock")),
        BkGroup("people", "گاہک اور کاریگر", "گاہکوں اور کاریگروں کا ریکارڈ", "👤", Color(0xFF2E8BFF), Color(0xFF0B5ED7), listOf("customer", "worker")),
        BkGroup("work", "مزدوری اور حاضری", "مزدوری، اوقات، حاضری اور تنخواہ", "💰", Color(0xFFFFB02E), Color(0xFFF57C00), listOf("wage", "hours", "attend", "salpay")),
        BkGroup("docs", "رسیدیں اور اخراجات", "رسیدیں اور روزمرہ اخراجات", "📄", Color(0xFF8E5CE6), Color(0xFF5E35B1), listOf("receipt", "expense")),
        BkGroup("app", "ایپ ڈیٹا", "سیٹنگز، ریٹ اور ترتیبات", "⚙", Color(0xFF78909C), Color(0xFF455A64), listOf("#app")))

    fun known(t: String) = types.any { it.key == t }
    fun allKeys(): List<String> = types.map { it.key }
    fun groupOf(k: String): BkGroup = groups.firstOrNull { k in it.types } ?: groups[0]

    fun selected(): Set<String> {
        val s = Store.prefs["bk_sel"] ?: return allKeys().toSet()
        if (s.isBlank()) return emptySet()
        return s.split(",").filter { it.isNotBlank() }.toSet()
    }

    fun setSelected(s: Set<String>) { Store.prefs["bk_sel"] = s.joinToString(","); Store.save() }

    fun fmtSz(b: Long): String = when {
        b >= 1_000_000_000L -> String.format(Locale.US, "%.1f GB", b / 1e9)
        b >= 1_000_000L -> String.format(Locale.US, "%.1f MB", b / 1e6)
        b >= 1_000L -> String.format(Locale.US, "%.1f KB", b / 1e3)
        else -> "$b B"
    }

    fun dt(ms: Long, p: String): String = SimpleDateFormat(p, Locale.ENGLISH).format(Date(ms))

    fun disk(): Pair<Long, Long> = try {
        val s = android.os.StatFs(android.os.Environment.getDataDirectory().path); Pair(s.totalBytes, s.availableBytes)
    } catch (e: Exception) { Pair(0L, 0L) }

    private fun prefsMap(): Map<String, String> =
        Store.prefs.filterKeys { !it.startsWith("bk_") && it != "pass" && it != "lock" && it != "calc_hist" }

    fun entryJson(e: Entry, photo: String): JSONObject = JSONObject().put("id", e.id).put("type", e.type).put("name", e.name)
        .put("weight", e.weight).put("amount", e.amount).put("note", e.note).put("date", e.date)
        .put("karat", e.karat).put("rate", e.rate).put("paid", e.paid).put("phone", e.phone).put("status", e.status)
        .put("cnic", e.cnic).put("city", e.city).put("ready", e.ready).put("mins", e.mins).put("bill", e.bill)
        .put("gender", e.gender).put("photo", photo)

    private fun entryFrom(x: JSONObject, photos: Map<String, String>): Entry = Entry(
        x.getLong("id"), x.getString("type"), x.getString("name"), x.getDouble("weight"), x.getDouble("amount"),
        x.getString("note"), x.getString("date"), x.optString("karat", ""), x.optDouble("rate", 0.0), x.optDouble("paid", 0.0),
        x.optString("phone", ""), x.optString("status", ""), x.optString("cnic", ""), x.optString("city", ""),
        x.optDouble("ready", 0.0), x.optDouble("mins", 0.0), x.optString("bill", ""), x.optString("gender", ""),
        photos[x.optString("photo", "")] ?: "")

    private fun stamp(e: Entry): Long =
        if (e.id > 1_000_000_000_000L) e.id
        else try { java.time.LocalDate.parse(e.date).atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli() } catch (ex: Exception) { 0L }

    fun stats(): Map<String, BkStat> {
        val m = HashMap<String, BkStat>()
        val all = Store.entries.toList()
        types.forEach { t ->
            if (t.key == "#photos") {
                val ps = all.map { it.photo }.filter { it.isNotBlank() }.distinct().map { File(it) }.filter { it.isFile }
                m[t.key] = BkStat(ps.size, ps.sumOf { it.length() }, ps.maxOfOrNull { it.lastModified() } ?: 0L)
            } else if (t.key == "#app") {
                val p = prefsMap()
                var n = 0L
                p.forEach { (k, v) -> n += (k.length + v.length).toLong() }
                m[t.key] = BkStat(p.size, n, 0L)
            } else {
                val l = all.filter { it.type == t.key }
                var n = 0L
                l.forEach { n += entryJson(it, "").toString().toByteArray().size.toLong() }
                m[t.key] = BkStat(l.size, n, l.maxOfOrNull { stamp(it) } ?: 0L)
            }
        }
        return m
    }

    fun create(ctx: Context, sel: Set<String>): BkMade? = try {
        val dir = File(ctx.filesDir, "backups"); dir.mkdirs()
        val f = File(dir, "MSF_Backup_" + SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date()) + ".zip")
        val withPh = "#photos" in sel
        val photoMap = LinkedHashMap<String, String>()
        val arr = JSONArray()
        val list = Store.entries.toList().filter { it.type in sel || !known(it.type) }
        list.forEach { e ->
            var ph = ""
            if (withPh && e.photo.isNotBlank() && File(e.photo).isFile) {
                ph = photoMap.getOrPut(e.photo) { "photos/" + (photoMap.size + 1) + "_" + File(e.photo).name }
            }
            arr.put(entryJson(e, ph))
        }
        val o = JSONObject().put("format", 2).put("created", System.currentTimeMillis())
            .put("types", JSONArray(sel.toList())).put("entries", arr)
        if ("#app" in sel) {
            val p = JSONObject()
            prefsMap().forEach { (k, v) -> p.put(k, v) }
            o.put("prefs", p)
        }
        ZipOutputStream(BufferedOutputStream(FileOutputStream(f))).use { z ->
            z.putNextEntry(ZipEntry("data.json"))
            z.write(o.toString().toByteArray(Charsets.UTF_8))
            z.closeEntry()
            photoMap.forEach { (src, zn) ->
                z.putNextEntry(ZipEntry(zn))
                FileInputStream(src).use { ins -> ins.copyTo(z) }
                z.closeEntry()
            }
        }
        BkMade(f, list.size)
    } catch (e: Exception) { null }

    fun createAsync(ctx: Context, sel: Set<String>, done: (BkMade?) -> Unit) {
        val app = ctx.applicationContext
        Thread {
            val r = create(app, sel)
            Handler(Looper.getMainLooper()).post { done(r) }
        }.start()
    }

    fun files(ctx: Context): List<File> =
        (File(ctx.filesDir, "backups").listFiles() ?: emptyArray<File>())
            .filter { it.isFile && it.name.endsWith(".zip") }.sortedByDescending { it.lastModified() }

    fun prune(ctx: Context) { files(ctx).drop(20).forEach { it.delete() } }

    fun log(kind: String, name: String, bytes: Long, count: Int, ok: Boolean = true) {
        val l = (Store.prefs["bk_log"] ?: "").split("\n").filter { it.isNotBlank() }
        val line = listOf(System.currentTimeMillis().toString(), kind, name, bytes.toString(), count.toString(), if (ok) "1" else "0").joinToString("\t")
        Store.prefs["bk_log"] = (listOf(line) + l).take(40).joinToString("\n")
        Store.save()
    }

    fun logs(): List<BkLog> = (Store.prefs["bk_log"] ?: "").split("\n").mapNotNull { ln ->
        val p = ln.split("\t")
        if (p.size >= 6) BkLog(p[0].toLongOrNull() ?: 0L, p[1], p[2], p[3].toLongOrNull() ?: 0L, p[4].toIntOrNull() ?: 0, p[5] == "1") else null
    }

    fun clearLog() { Store.prefs["bk_log"] = ""; Store.save() }

    fun countFor(name: String): Int = logs().firstOrNull { it.name == name && it.kind.contains("بیک اپ") }?.count ?: -1

    fun interval(): Long = when (Store.prefs["bk_sched"]) {
        "daily" -> 86_400_000L
        "weekly" -> 7 * 86_400_000L
        "monthly" -> 30 * 86_400_000L
        else -> 0L
    }

    /** ایپ کھلنے پر: اگر شیڈیول کے مطابق بیک اپ کا وقت ہو گیا ہو تو خود بیک اپ لے لیتا ہے */
    fun autoIfDue(ctx: Context) {
        val iv = interval()
        if (iv == 0L) return
        val last = files(ctx).firstOrNull()?.lastModified() ?: 0L
        if (System.currentTimeMillis() - last < iv) return
        val sel = selected()
        if (sel.isEmpty()) return
        val app = ctx.applicationContext
        createAsync(ctx, sel) { r ->
            if (r != null) { log("خودکار بیک اپ", r.file.name, r.file.length(), r.count); prune(app) }
        }
    }

    fun shareFile(ctx: Context, f: File) {
        try {
            val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
            val i = Intent(Intent.ACTION_SEND).apply {
                type = "application/zip"
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            ctx.startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) {
            Toast.makeText(ctx, "فائل شیئر نہیں ہو سکی", Toast.LENGTH_SHORT).show()
        }
    }

    fun restoreBytes(ctx: Context, data: ByteArray, replace: Boolean): BkRes {
        return try {
            if (data.size > 2 && data[0] == 'P'.code.toByte() && data[1] == 'K'.code.toByte()) {
                var json: String? = null
                val pdir = File(ctx.filesDir, "photos"); pdir.mkdirs()
                val names = HashMap<String, String>()
                ZipInputStream(ByteArrayInputStream(data)).use { z ->
                    var e = z.nextEntry
                    while (e != null) {
                        if (!e.isDirectory) {
                            if (e.name == "data.json") json = z.readBytes().toString(Charsets.UTF_8)
                            else if (e.name.startsWith("photos/")) {
                                val dest = File(pdir, File(e.name).name)
                                FileOutputStream(dest).use { out -> z.copyTo(out) }
                                names[e.name] = dest.absolutePath
                            }
                        }
                        e = z.nextEntry
                    }
                }
                val js = json ?: return BkRes(false, "فائل میں data.json نہیں ملا", 0)
                applyData(JSONObject(js), names, replace)
            } else {
                val txt = data.toString(Charsets.UTF_8)
                val o = JSONObject(txt)
                if (o.has("types")) applyData(o, emptyMap(), replace)
                else if (Store.restore(txt)) BkRes(true, "پرانے فارمیٹ کا ڈیٹا بحال ہو گیا", Store.entries.size)
                else BkRes(false, "یہ درست بیک اپ نہیں ہے", 0)
            }
        } catch (e: Exception) { BkRes(false, "بحالی ناکام: فائل درست نہیں ہے", 0) }
    }

    private fun applyData(o: JSONObject, photos: Map<String, String>, replace: Boolean): BkRes {
        val tset = HashSet<String>()
        val ta = o.optJSONArray("types")
        if (ta != null) for (i in 0 until ta.length()) tset.add(ta.getString(i))
        val a = o.getJSONArray("entries")
        val incoming = (0 until a.length()).map { entryFrom(a.getJSONObject(it), photos) }
        val rm = tset + incoming.map { it.type }
        if (replace) Store.entries.removeAll { it.type in rm }
        val have = Store.entries.map { it.type + ":" + it.id }.toHashSet()
        var added = 0
        incoming.forEach { e ->
            if (have.add(e.type + ":" + e.id)) { Store.entries.add(e); added++ }
        }
        val p = o.optJSONObject("prefs")
        if (p != null) {
            p.keys().forEach { k ->
                if (k != "pass" && k != "lock" && !k.startsWith("bk_") && (replace || !Store.prefs.containsKey(k))) Store.prefs[k] = p.getString(k)
            }
        }
        Store.save()
        return BkRes(true, added.toString() + " ریکارڈ بحال ہوئے", added)
    }
}
