package com.msf.goldrecord

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.io.File

private val BkNavy = Color(0xFF0A2A6B)
private val BkBlue = Color(0xFF1565E0)
private val BkBg = Color(0xFFF2F5FB)
private val BkLine = Color(0xFFD6DFEE)
private val BkText = Color(0xFF0F2347)
private val BkSub = Color(0xFF6A7A93)
private val BkGreen = Color(0xFF1E9E4A)
private val BkRed = Color(0xFFD32F2F)

// ───────────────────────── مشترکہ حصے ─────────────────────────

@Composable
private fun BkHeader(white: String, gold: String, sub: String, tags: String, shieldA: String, shieldB: String,
                     art: String, art2: String, go: (String) -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(BkNavy, Color(0xFF0B3A8C), BkNavy)))) {
            Row(Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 12.dp, bottom = 12.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(84.dp)) {
                    Text(art, fontSize = 60.sp, modifier = Modifier.align(Alignment.TopStart))
                    Text(art2, fontSize = 36.sp, modifier = Modifier.align(Alignment.BottomEnd))
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(buildAnnotatedString {
                        withStyle(SpanStyle(color = Color.White)) { append(white) }
                        if (gold.isNotEmpty()) withStyle(SpanStyle(color = Gold)) { append(" " + gold) }
                    }, fontSize = 34.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    T(sub, 15, Color.White, al = TextAlign.Center)
                    T(tags, 11, Color(0xFFBBD0F5), al = TextAlign.Center)
                }
                Column(Modifier.width(90.dp).padding(top = 26.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("🛡️", fontSize = 34.sp)
                    T(shieldA, 13, Color.White, true, al = TextAlign.Center)
                    T(shieldB, 10, Color(0xFFBBD0F5), al = TextAlign.Center)
                }
            }
            Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(36.dp).clip(RoundedCornerShape(10.dp))
                .border(1.dp, Color(0x88FFFFFF), RoundedCornerShape(10.dp)).clickable { go("settings") }, contentAlignment = Alignment.Center) {
                Text("⚙", fontSize = 20.sp, color = Color.White)
            }
        }
    }
}

@Composable
private fun BkNav(cur: String, items: List<Triple<String, String, String>>, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(Color(0xFF0A2259)).padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.reversed().forEach { (k, i, l) ->
            val sel = k == cur
            Column(Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(14.dp))
                .background(if (sel) BkBlue else Color.Transparent).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 22.sp)
                T(l, 12, Color.White, true)
            }
        }
    }
}

@Composable
fun BkNav5(cur: String, go: (String) -> Unit) = BkNav(cur, listOf(Triple("home", "🏠", "ہوم"), Triple("bkfiles", "📁", "بیک اپ فائلیں"),
    Triple("backup", "☁️", "بیک اپ"), Triple("bkrestore", "🕘", "بحالی"), Triple("settings", "⚙️", "سیٹنگز")), go)

@Composable
fun BkNav4(cur: String, go: (String) -> Unit) = BkNav(cur, listOf(Triple("home", "🏠", "ہوم"), Triple("bkfiles", "📁", "فائلیں"),
    Triple("bkhist", "🕘", "ہسٹری"), Triple("settings", "⚙️", "سیٹنگز")), go)

@Composable
private fun BkBar(frac: Float, color: Color, m: Modifier) {
    Box(m.height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFDCE4F0))) {
        Box(Modifier.fillMaxWidth(frac.coerceIn(0.02f, 1f)).fillMaxHeight().clip(RoundedCornerShape(6.dp)).background(color))
    }
}

@Composable
private fun BkIcon(icon: String, c1: Color, c2: Color, size: Int = 50) {
    Box(Modifier.size(size.dp).clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(c1, c2))), contentAlignment = Alignment.Center) {
        Text(icon, fontSize = (size / 2).sp, color = Color.White)
    }
}

@Composable
private fun BkBtn(text: String, sub: String, c1: Color, c2: Color, m: Modifier, on: () -> Unit) {
    Row(m.clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(listOf(c1, c2))).clickable(onClick = on).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("☁️", fontSize = 28.sp)
        Column(Modifier.weight(1f)) {
            T(text, 16, Color.White, true, Modifier.fillMaxWidth(), TextAlign.Left)
            if (sub.isNotEmpty()) T(sub, 11, Color(0xEEFFFFFF), false, Modifier.fillMaxWidth(), TextAlign.Left)
        }
    }
}

private class BkRun {
    var busy by mutableStateOf(false)
    var msg by mutableStateOf<String?>(null)
    var file by mutableStateOf<File?>(null)

    fun start(ctx: Context, after: () -> Unit) {
        if (busy) return
        val s = Bk.selected()
        if (s.isEmpty()) { Toast.makeText(ctx, "کم از کم ایک آئٹم منتخب کریں", Toast.LENGTH_SHORT).show(); return }
        busy = true
        Bk.createAsync(ctx, s) { r ->
            busy = false
            if (r != null) {
                Bk.log("بیک اپ", r.file.name, r.file.length(), r.count); Bk.prune(ctx)
                file = r.file
                msg = "بیک اپ مکمل ہو گیا ✅\n" + r.count + " ریکارڈ  |  " + Bk.fmtSz(r.file.length())
            } else {
                Bk.log("بیک اپ", "-", 0L, 0, false); file = null; msg = "بیک اپ ناکام ہوا ❌"
            }
            after()
        }
    }
}

@Composable
private fun BkRunDialogs(r: BkRun) {
    val ctx = LocalContext.current
    if (r.busy) AlertDialog(onDismissRequest = {}, title = { Text("بیک اپ جاری ہے") },
        text = { Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            CircularProgressIndicator(Modifier.size(28.dp)); Text("براہ کرم انتظار کریں…") } },
        confirmButton = {})
    val m = r.msg
    if (m != null) AlertDialog(onDismissRequest = { r.msg = null }, title = { Text("بیک اپ") }, text = { Text(m) },
        confirmButton = { val f = r.file; if (f != null) TextButton(onClick = { Bk.shareFile(ctx, f) }) { Text("📤 شیئر") } },
        dismissButton = { TextButton(onClick = { r.msg = null }) { Text("ٹھیک ہے") } })
}

private class BkRestore {
    var data by mutableStateOf<ByteArray?>(null)
    var name by mutableStateOf("")
    var msg by mutableStateOf<String?>(null)
}

@Composable
private fun BkRestoreDialogs(r: BkRestore, onDone: () -> Unit) {
    val ctx = LocalContext.current
    val d = r.data
    if (d != null) AlertDialog(onDismissRequest = { r.data = null }, title = { Text("بحالی کا طریقہ") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("فائل: " + r.name + "  (" + Bk.fmtSz(d.size.toLong()) + ")")
                Text("ضم کریں: موجودہ ڈیٹا رہے گا، صرف نئے ریکارڈ شامل ہوں گے۔\nتبدیل کریں: بیک اپ والی اقسام کا موجودہ ڈیٹا ہٹا کر بیک اپ والا ڈیٹا آئے گا۔", fontSize = 13.sp)
                Btn("➕ ضم کریں", BkBlue, Modifier.fillMaxWidth()) {
                    val x = Bk.restoreBytes(ctx, d, false); Bk.log("بحالی", r.name, d.size.toLong(), x.count, x.ok)
                    r.data = null; r.msg = (if (x.ok) "✅ " else "❌ ") + x.msg; onDone()
                }
                Btn("♻ تبدیل کریں", BkRed, Modifier.fillMaxWidth()) {
                    val x = Bk.restoreBytes(ctx, d, true); Bk.log("بحالی", r.name, d.size.toLong(), x.count, x.ok)
                    r.data = null; r.msg = (if (x.ok) "✅ " else "❌ ") + x.msg; onDone()
                }
            }
        }, confirmButton = {}, dismissButton = { TextButton(onClick = { r.data = null }) { Text("منسوخ") } })
    val m = r.msg
    if (m != null) AlertDialog(onDismissRequest = { r.msg = null }, title = { Text("بحالی") }, text = { Text(m) },
        confirmButton = { TextButton(onClick = { r.msg = null }) { Text("ٹھیک ہے") } })
}

/** بیک اپ فائلوں کی فہرست: شیئر / فون میں محفوظ / بحالی / حذف */
@Composable
private fun BkFilesList(files: List<File>, onRestore: (File) -> Unit, onChanged: () -> Unit) {
    val ctx = LocalContext.current
    var pendSave by remember { mutableStateOf<File?>(null) }
    var delF by remember { mutableStateOf<File?>(null) }
    val saver = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri: Uri? ->
        val f = pendSave
        if (uri != null && f != null) {
            try {
                ctx.contentResolver.openOutputStream(uri)?.use { o -> f.inputStream().use { i -> i.copyTo(o) } }
                Toast.makeText(ctx, "فائل محفوظ ہو گئی ✅", Toast.LENGTH_SHORT).show()
            } catch (e: Exception) { Toast.makeText(ctx, "فائل محفوظ نہیں ہو سکی", Toast.LENGTH_SHORT).show() }
        }
    }
    if (files.isEmpty()) {
        T("ابھی کوئی بیک اپ فائل نہیں ہے۔", 14, BkSub, al = TextAlign.Left, m = Modifier.padding(12.dp))
    }
    files.forEachIndexed { idx, f ->
        val cnt = Bk.countFor(f.name)
        Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                BkIcon("🗜", Color(0xFF2E8BFF), Color(0xFF0B5ED7), 44)
                Column(Modifier.weight(1f)) {
                    T(Bk.dt(f.lastModified(), "dd-MM-yyyy   hh:mm a"), 16, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                    T((if (cnt >= 0) "$cnt ریکارڈ  |  " else "") + Bk.fmtSz(f.length()), 12, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                }
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Btn("📤 شیئر", BkBlue, Modifier.weight(1f)) { Bk.shareFile(ctx, f) }
                Btn("💾 محفوظ", Color(0xFF0E7D3A), Modifier.weight(1f)) { pendSave = f; saver.launch(f.name) }
                Btn("♻ بحال", Color(0xFF7B3FD6), Modifier.weight(1f)) { onRestore(f) }
                Btn("🗑 حذف", BkRed, Modifier.weight(1f)) { delF = f }
            }
        }
        if (idx < files.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(BkLine))
    }
    val df = delF
    if (df != null) AlertDialog(onDismissRequest = { delF = null }, title = { Text("بیک اپ حذف کریں؟") },
        text = { Text(Bk.dt(df.lastModified(), "dd-MM-yyyy hh:mm a") + " کا بیک اپ ہمیشہ کے لیے ہٹ جائے گا۔") },
        confirmButton = { TextButton(onClick = { df.delete(); delF = null; onChanged() }) { Text("حذف کریں") } },
        dismissButton = { TextButton(onClick = { delF = null }) { Text("منسوخ") } })
}

@Composable
private fun LogDialog(close: () -> Unit, onClear: () -> Unit) {
    val logs = Bk.logs()
    AlertDialog(onDismissRequest = close, title = { Text("بیک اپ ہسٹری") },
        text = {
            if (logs.isEmpty()) Text("ابھی کوئی سرگرمی نہیں۔")
            else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                logs.forEach { l ->
                    Column(Modifier.fillMaxWidth()) {
                        Text((if (l.ok) "✅ " else "❌ ") + l.kind, fontWeight = FontWeight.Bold)
                        Text(Bk.dt(l.ms, "dd-MM-yyyy  hh:mm a") + "  |  " + l.count + " ریکارڈ  |  " + Bk.fmtSz(l.bytes), fontSize = 12.sp, color = Color.Gray)
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = close) { Text("بند کریں") } },
        dismissButton = { TextButton(onClick = onClear) { Text("🗑 صاف کریں") } })
}

// ───────────────────────── بیک اپ ─────────────────────────

@Composable
fun BackupScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var rk by remember { mutableStateOf(0) }
    val stats = remember(rk) { Bk.stats() }
    val files = remember(rk) { Bk.files(ctx) }
    val st = remember(rk) { Bk.disk() }
    val sel = Bk.selected()
    val run = remember { BkRun() }
    var dlg by remember { mutableStateOf<String?>(null) }
    val sched = Store.prefs["bk_sched"] ?: ""
    val schedName = when (sched) { "daily" -> "روزانہ"; "weekly" -> "ہفتہ وار"; "monthly" -> "ماہانہ"; else -> "" }
    val last = files.firstOrNull()
    val used = (st.first - st.second).coerceAtLeast(0L)
    val pct = if (st.first > 0) (used * 100 / st.first).toInt() else 0

    Column(Modifier.fillMaxSize().background(BkBg)) {
        BkHeader("بیک", "اپ", "اپنے ڈیٹا کو محفوظ رکھیں", "رسیدیں  •  تصاویر  •  ریکارڈ  •  ترتیبات", "محفوظ ڈیٹا", "محفوظ مستقبل", "☁️", "💾", go)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // آخری بیک اپ
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (last != null) Color(0xFFE5F6EA) else Color(0xFFEEF1F6))
                    .border(1.dp, if (last != null) Color(0xFFA6DDB4) else BkLine, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(56.dp).clip(CircleShape).background(if (last != null) BkGreen else Color(0xFF9AA8BD)), contentAlignment = Alignment.Center) {
                        Text(if (last != null) "✔" else "!", fontSize = 28.sp, color = Color.White)
                    }
                    Column(Modifier.weight(1f)) {
                        T(if (last != null) "آخری بیک اپ مکمل" else "ابھی کوئی بیک اپ نہیں", 18, if (last != null) Color(0xFF0E6B33) else BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                        T(if (last != null) "تاریخ: " + Bk.dt(last.lastModified(), "dd-MM-yyyy") + "  |  وقت: " + Bk.dt(last.lastModified(), "hh:mm a")
                          else "دائیں بٹن سے پہلا بیک اپ لیں", 12, BkText, false, Modifier.fillMaxWidth(), TextAlign.Left)
                    }
                    Row(Modifier.clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(Color(0xFF1FA650), Color(0xFF0E7D3A))))
                        .clickable { run.start(ctx) { rk++ } }.padding(horizontal = 12.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text("☁️", fontSize = 20.sp)
                        T("ابھی بیک اپ لیں", 14, Color.White, true)
                    }
                }
                // اسٹوریج
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    BkIcon("🗄", Color(0xFF1E4FA8), Color(0xFF0A2A6B), 54)
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        T("کل اسٹوریج استعمال", 17, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            T(Bk.fmtSz(used) + " / " + Bk.fmtSz(st.first), 13, BkText)
                            BkBar(if (st.first > 0) used.toFloat() / st.first.toFloat() else 0f, BkGreen, Modifier.weight(1f))
                        }
                    }
                    T("$pct%", 22, BkText, true)
                }
                // آئٹمز
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp))) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFEAF0FA)).padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(BkBlue), contentAlignment = Alignment.Center) { Text("☰", fontSize = 18.sp, color = Color.White) }
                        Spacer(Modifier.width(10.dp))
                        T("بیک اپ کے لیے آئٹمز", 17, BkText, true, Modifier.weight(1f), TextAlign.Left)
                        val allOn = sel.containsAll(Bk.allKeys())
                        Row(Modifier.clip(RoundedCornerShape(10.dp)).background(BkBlue)
                            .clickable { Bk.setSelected(if (allOn) emptySet() else Bk.allKeys().toSet()) }.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            T(if (allOn) "سب ہٹائیں" else "سب منتخب کریں", 13, Color.White, true)
                            Text("✔", fontSize = 14.sp, color = Color.White)
                        }
                    }
                    Bk.groups.forEachIndexed { idx, g ->
                        val gs = g.types.mapNotNull { stats[it] }
                        val cnt = gs.sumOf { it.count }
                        val bytes = gs.sumOf { it.bytes }
                        val on = g.types.all { it in sel }
                        Row(Modifier.fillMaxWidth().clickable { dlg = "g:" + g.key }.padding(horizontal = 10.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BkIcon(g.icon, g.c1, g.c2, 50)
                            Column(Modifier.weight(1f)) {
                                T(g.name, 16, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                                T(g.sub, 11, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                T(Bk.fmtSz(bytes), 13, BkText, true)
                                T("(" + cnt + (if (g.key == "photos") " فائلیں)" else " ریکارڈ)"), 11, BkSub)
                            }
                            Switch(checked = on, onCheckedChange = { v ->
                                val s = Bk.selected().toMutableSet()
                                if (v) s.addAll(g.types) else s.removeAll(g.types.toSet())
                                Bk.setSelected(s)
                            }, colors = SwitchDefaults.colors(checkedTrackColor = BkGreen, checkedThumbColor = Color.White))
                            Text("›", fontSize = 24.sp, color = BkSub)
                        }
                        if (idx < Bk.groups.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(BkLine))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f).height(66.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F0FD))
                    .border(1.dp, Color(0xFFB9CDF0), RoundedCornerShape(14.dp)).clickable { dlg = "sched" }.padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Box(Modifier.size(40.dp).clip(CircleShape).border(2.dp, BkBlue, CircleShape), contentAlignment = Alignment.Center) { Text("🕒", fontSize = 20.sp) }
                    Column(Modifier.weight(1f)) {
                        T("بیک اپ شیڈیول کریں", 15, BkBlue, true, Modifier.fillMaxWidth(), TextAlign.Left)
                        T(if (schedName.isEmpty()) "روزانہ / ہفتہ وار / ماہانہ" else "فعال: " + schedName, 11, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                    }
                }
                BkBtn("ابھی بیک اپ لیں", "تمام منتخب ڈیٹا کا بیک اپ لیں", Color(0xFF2E7BF0), Color(0xFF0B52C8), Modifier.weight(1f).height(66.dp)) { run.start(ctx) { rk++ } }
            }
        }
    }

    BkRunDialogs(run)
    val d = dlg
    if (d == "sched") AlertDialog(onDismissRequest = { dlg = null }, title = { Text("بیک اپ شیڈیول") },
        text = {
            Column {
                listOf("" to "بند", "daily" to "روزانہ", "weekly" to "ہفتہ وار", "monthly" to "ماہانہ").forEach { (k, n) ->
                    Row(Modifier.fillMaxWidth().clickable { Store.prefs["bk_sched"] = k; Store.save() }.padding(vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected = sched == k, onClick = { Store.prefs["bk_sched"] = k; Store.save() })
                        Text(n, fontSize = 16.sp)
                    }
                }
                Text("خودکار بیک اپ ایپ کھولتے وقت لیا جاتا ہے، اگر شیڈیول کے مطابق وقت ہو چکا ہو۔", fontSize = 12.sp, color = Color.Gray)
            }
        }, confirmButton = { TextButton(onClick = { dlg = null }) { Text("ٹھیک ہے") } })
    if (d != null && d.startsWith("g:")) {
        val g = Bk.groups.first { it.key == d.drop(2) }
        AlertDialog(onDismissRequest = { dlg = null }, title = { Text(g.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    g.types.forEach { k ->
                        val t = Bk.types.first { it.key == k }
                        val s = stats[k]
                        Column {
                            Text(t.icon + " " + t.name, fontWeight = FontWeight.Bold)
                            Text((s?.count ?: 0).toString() + (if (k == "#photos") " فائلیں" else " ریکارڈ") + "  |  " + Bk.fmtSz(s?.bytes ?: 0L) +
                                (if ((s?.last ?: 0L) > 0L) "  |  آخری: " + Bk.dt(s!!.last, "dd-MM-yyyy") else ""), fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }, confirmButton = { TextButton(onClick = { dlg = null }) { Text("ٹھیک ہے") } })
    }
}

// ───────────────────────── بیک اپ فائلیں ─────────────────────────

@Composable
private fun RowScope.ActCard(icon: String, title: String, sub: String, c1: Color, c2: Color, on: () -> Unit) {
    Column(Modifier.weight(1f).height(116.dp).clip(RoundedCornerShape(14.dp)).background(Brush.verticalGradient(listOf(c1, c2)))
        .clickable(onClick = on).padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 32.sp, color = Color.White)
        T(title, 13, Color.White, true, al = TextAlign.Center)
        T(sub, 10, Color(0xEEFFFFFF), al = TextAlign.Center)
    }
}

@Composable
fun BkFilesScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var rk by remember { mutableStateOf(0) }
    val stats = remember(rk) { Bk.stats() }
    val files = remember(rk) { Bk.files(ctx) }
    val sel = Bk.selected()
    val run = remember { BkRun() }
    var filter by remember { mutableStateOf("سب فائلیں") }
    var fMenu by remember { mutableStateOf(false) }
    var showSearch by remember { mutableStateOf(false) }
    var query by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf<String?>(null) }
    val totalBk = files.sumOf { it.length() }
    val free = remember(rk) { Bk.disk().second }
    val pct = if (totalBk + free > 0) (totalBk * 100 / (totalBk + free)).toInt() else 0
    val rows = Bk.types.filter { t ->
        (query.isBlank() || t.name.contains(query.trim())) &&
            (filter == "سب فائلیں" || (filter == "منتخب" && t.key in sel) || (filter == "غیر منتخب" && t.key !in sel))
    }
    val selCount = Bk.types.filter { it.key in sel }.sumOf { stats[it.key]?.count ?: 0 }
    val selBytes = Bk.types.filter { it.key in sel }.sumOf { stats[it.key]?.bytes ?: 0L }

    Column(Modifier.fillMaxSize().background(BkBg)) {
        BkHeader("بیک اپ", "فائلیں", "اپنے قیمتی ریکارڈ کو محفوظ رکھیں", "ریکارڈ  •  تصاویر  •  رسیدیں  •  ترتیبات", "محفوظ بیک اپ", "آپ کا ڈیٹا، آپ کی حفاظت", "☁️", "📁", go)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color(0xFFE5F6EA)).border(1.dp, Color(0xFFA6DDB4), RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(54.dp).clip(CircleShape).background(BkGreen), contentAlignment = Alignment.Center) { Text("🗄", fontSize = 26.sp) }
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        T("کل بیک اپ سٹوریج", 17, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            T(Bk.fmtSz(totalBk) + "  (" + files.size + " فائلیں)", 12, BkText)
                            BkBar(pct / 100f, BkGreen, Modifier.weight(1f))
                        }
                    }
                    T("$pct%", 20, BkText, true)
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    ActCard("☁️", "بیک اپ لیں", "موجودہ ڈیٹا محفوظ کریں", Color(0xFF2E9BFF), Color(0xFF0B5FD8)) { run.start(ctx) { rk++ } }
                    ActCard("📥", "ریسٹور کریں", "محفوظ ڈیٹا واپس لائیں", Color(0xFF22B25A), Color(0xFF0E8A3E)) { go("bkrestore") }
                    ActCard("📂", "بیک اپ فائلیں دیکھیں", "تمام محفوظ فائلیں", Color(0xFF8E3CF0), Color(0xFF5E1FC2)) { go("bkhist") }
                    ActCard("🕘", "بیک اپ ہسٹری", "پچھلے بیک اپ کی تفصیلات", Color(0xFFFFA11E), Color(0xFFF57C00)) { dlg = "log" }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp))) {
                    Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("📁", fontSize = 24.sp)
                        T("فائلوں کی فہرست", 18, BkText, true, Modifier.weight(1f), TextAlign.Left)
                        Box {
                            Row(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, BkLine, RoundedCornerShape(10.dp)).clickable { fMenu = true }.padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                T(filter, 13, BkText); Text("⌄", fontSize = 16.sp, color = BkText)
                            }
                            DropdownMenu(expanded = fMenu, onDismissRequest = { fMenu = false }) {
                                listOf("سب فائلیں", "منتخب", "غیر منتخب").forEach { o ->
                                    DropdownMenuItem(text = { Text(o) }, onClick = { filter = o; fMenu = false })
                                }
                            }
                        }
                        Text("🔍", fontSize = 22.sp, modifier = Modifier.clickable { showSearch = !showSearch; if (!showSearch) query = "" })
                    }
                    if (showSearch) LF(query, Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 4.dp), ph = "تلاش کریں") { query = it }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(BkLine))
                    if (rows.isEmpty()) T("کوئی نتیجہ نہیں ملا۔", 14, BkSub, al = TextAlign.Left, m = Modifier.padding(14.dp))
                    rows.forEachIndexed { idx, t ->
                        val s = stats[t.key]
                        val g = Bk.groupOf(t.key)
                        Row(Modifier.fillMaxWidth().clickable { dlg = "t:" + t.key }.padding(horizontal = 10.dp, vertical = 9.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            BkIcon(t.icon, g.c1, g.c2, 46)
                            Column(Modifier.weight(1f)) {
                                T(t.name, 16, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                                T((if (t.key == "#photos") "فائلیں " else "ریکارڈ ") + (s?.count ?: 0) + "  |  " + Bk.fmtSz(s?.bytes ?: 0L), 12, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                                T(t.src, 11, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                            }
                            Column(horizontalAlignment = Alignment.Start) {
                                val ls = s?.last ?: 0L
                                T(if (ls > 0L) Bk.dt(ls, "dd-MM-yyyy") else "—", 11, BkSub)
                                T(if (ls > 0L) Bk.dt(ls, "hh:mm a") else "", 11, BkSub)
                            }
                            Checkbox(checked = t.key in sel, onCheckedChange = { v ->
                                val x = Bk.selected().toMutableSet(); if (v) x.add(t.key) else x.remove(t.key); Bk.setSelected(x)
                            }, colors = CheckboxDefaults.colors(checkedColor = BkBlue))
                            Text("›", fontSize = 22.sp, color = BkSub)
                        }
                        if (idx < rows.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(BkLine))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE8F0FD)).border(1.dp, Color(0xFFB9CDF0), RoundedCornerShape(14.dp)).padding(horizontal = 10.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ⓘ", fontSize = 26.sp, color = BkBlue)
                    Column {
                        T("منتخب فائلیں", 12, BkBlue, true)
                        T(Bk.fmtSz(selBytes) + "  (" + selCount + ")", 14, BkText)
                    }
                }
                BkBtn("منتخب بیک اپ لیں", "ابھی بیک اپ کریں", Color(0xFF2E7BF0), Color(0xFF0B52C8), Modifier.weight(1.15f).height(60.dp)) { run.start(ctx) { rk++ } }
            }
        }
    }

    BkRunDialogs(run)
    val d = dlg
    if (d == "log") LogDialog({ dlg = null }) { Bk.clearLog(); dlg = null }
    if (d != null && d.startsWith("t:")) {
        val t = Bk.types.first { it.key == d.drop(2) }
        val s = stats[t.key]
        AlertDialog(onDismissRequest = { dlg = null }, title = { Text(t.icon + " " + t.name) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text((if (t.key == "#photos") "فائلیں: " else "ریکارڈ: ") + (s?.count ?: 0))
                    Text("سائز: " + Bk.fmtSz(s?.bytes ?: 0L))
                    if ((s?.last ?: 0L) > 0L) Text("آخری تبدیلی: " + Bk.dt(s!!.last, "dd-MM-yyyy hh:mm a"))
                    Text("بیک اپ میں شامل: " + (if (t.key in sel) "ہاں ✅" else "نہیں"))
                }
            },
            confirmButton = { TextButton(onClick = { dlg = null }) { Text("ٹھیک ہے") } },
            dismissButton = {
                TextButton(onClick = {
                    val x = Bk.selected().toMutableSet(); if (t.key in x) x.remove(t.key) else x.add(t.key); Bk.setSelected(x)
                }) { Text(if (t.key in sel) "نکال دیں" else "شامل کریں") }
            })
    }
}

// ───────────────────────── بحالی ─────────────────────────

@Composable
fun BkRestoreScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val cb = LocalClipboardManager.current
    var rk by remember { mutableStateOf(0) }
    val files = remember(rk) { Bk.files(ctx) }
    val rs = remember { BkRestore() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            try {
                val b = ctx.contentResolver.openInputStream(uri)?.use { it.readBytes() }
                if (b != null) { rs.name = uri.lastPathSegment ?: "فائل"; rs.data = b }
            } catch (e: Exception) { Toast.makeText(ctx, "فائل کھل نہیں سکی", Toast.LENGTH_SHORT).show() }
        }
    }
    Column(Modifier.fillMaxSize().background(BkBg)) {
        BkHeader("بحالی", "", "اپنا ڈیٹا واپس لائیں", "بیک اپ فائل  •  فون کی فائل  •  کلپ بورڈ", "محفوظ ڈیٹا", "محفوظ مستقبل", "☁️", "📥", go)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                BkBtn("فون سے بیک اپ فائل منتخب کریں", "ZIP یا پرانی JSON بیک اپ فائل", Color(0xFF22B25A), Color(0xFF0E8A3E), Modifier.fillMaxWidth().height(70.dp)) {
                    picker.launch(arrayOf("*/*"))
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp))) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFEAF0FA)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🗜", fontSize = 22.sp)
                        T("محفوظ بیک اپ (" + files.size + ")", 17, BkText, true, Modifier.weight(1f), TextAlign.Left)
                    }
                    BkFilesList(files, { f ->
                        try { rs.name = f.name; rs.data = f.readBytes() } catch (e: Exception) { Toast.makeText(ctx, "فائل کھل نہیں سکی", Toast.LENGTH_SHORT).show() }
                    }) { rk++ }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp)).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    T("دیگر طریقے", 17, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                    Btn("📤 مکمل ڈیٹا (JSON) شیئر کریں", BkBlue, Modifier.fillMaxWidth()) { share(ctx, Store.json()) }
                    Btn("📋 کلپ بورڈ میں کاپی کریں", Color(0xFF0E7D3A), Modifier.fillMaxWidth()) {
                        cb.setText(AnnotatedString(Store.json())); Toast.makeText(ctx, "کلپ بورڈ میں کاپی ہو گیا ✅", Toast.LENGTH_SHORT).show()
                    }
                    Btn("📥 کلپ بورڈ سے بحال کریں", Color(0xFF7B3FD6), Modifier.fillMaxWidth()) {
                        val t = cb.getText()?.text
                        if (t.isNullOrBlank()) Toast.makeText(ctx, "کلپ بورڈ خالی ہے", Toast.LENGTH_SHORT).show()
                        else { rs.name = "کلپ بورڈ"; rs.data = t.toByteArray(Charsets.UTF_8) }
                    }
                }
            }
        }
    }
    BkRestoreDialogs(rs) { rk++ }
}

// ───────────────────────── ہسٹری ─────────────────────────

@Composable
fun BkHistScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var rk by remember { mutableStateOf(0) }
    val files = remember(rk) { Bk.files(ctx) }
    val logs = remember(rk) { Bk.logs() }
    val rs = remember { BkRestore() }
    var clr by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(BkBg)) {
        BkHeader("بیک اپ", "ہسٹری", "پچھلے بیک اپ کی تفصیلات", "فائلیں  •  تاریخ  •  سائز", "محفوظ بیک اپ", "آپ کا ڈیٹا، آپ کی حفاظت", "☁️", "🕘", go)
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(10.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp))) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFEAF0FA)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("📂", fontSize = 22.sp)
                        T("بیک اپ فائلیں (" + files.size + ")", 17, BkText, true, Modifier.weight(1f), TextAlign.Left)
                    }
                    BkFilesList(files, { f ->
                        try { rs.name = f.name; rs.data = f.readBytes() } catch (e: Exception) { Toast.makeText(ctx, "فائل کھل نہیں سکی", Toast.LENGTH_SHORT).show() }
                    }) { rk++ }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White).border(1.dp, BkLine, RoundedCornerShape(16.dp))) {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFFF1DC)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text("🕘", fontSize = 22.sp)
                        T("سرگرمی کا ریکارڈ", 17, BkText, true, Modifier.weight(1f), TextAlign.Left)
                        if (logs.isNotEmpty()) Box(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, BkLine, RoundedCornerShape(10.dp)).clickable { clr = true }.padding(horizontal = 10.dp, vertical = 6.dp)) {
                            T("🗑 صاف کریں", 12, BkText)
                        }
                    }
                    if (logs.isEmpty()) T("ابھی کوئی سرگرمی نہیں۔", 14, BkSub, al = TextAlign.Left, m = Modifier.padding(12.dp))
                    logs.forEachIndexed { idx, l ->
                        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Text(if (l.ok) "✅" else "❌", fontSize = 20.sp)
                            Column(Modifier.weight(1f)) {
                                T(l.kind, 15, BkText, true, Modifier.fillMaxWidth(), TextAlign.Left)
                                T(Bk.dt(l.ms, "dd-MM-yyyy  hh:mm a") + "  |  " + l.count + " ریکارڈ  |  " + Bk.fmtSz(l.bytes), 11, BkSub, false, Modifier.fillMaxWidth(), TextAlign.Left)
                            }
                        }
                        if (idx < logs.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(BkLine))
                    }
                }
            }
        }
    }
    BkRestoreDialogs(rs) { rk++ }
    if (clr) AlertDialog(onDismissRequest = { clr = false }, title = { Text("ریکارڈ صاف کریں؟") }, text = { Text("صرف سرگرمی کا ریکارڈ ہٹے گا، بیک اپ فائلیں نہیں۔") },
        confirmButton = { TextButton(onClick = { Bk.clearLog(); clr = false; rk++ }) { Text("صاف کریں") } },
        dismissButton = { TextButton(onClick = { clr = false }) { Text("منسوخ") } })
}
