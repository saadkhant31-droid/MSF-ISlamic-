package com.msf.goldrecord

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private class CalcRec(val ms: Long, val expr: String, val res: String)

private fun loadHist(): List<CalcRec> {
    val s = Store.prefs["calc_hist"] ?: return emptyList()
    if (s.isBlank()) return emptyList()
    return s.split("\n").mapNotNull { ln ->
        val p = ln.split("\t")
        if (p.size >= 3) CalcRec(p[0].toLongOrNull() ?: 0L, p[1], p[2]) else null
    }
}

private fun saveHist(l: List<CalcRec>) {
    Store.prefs["calc_hist"] = l.take(60).joinToString("\n") { it.ms.toString() + "\t" + it.expr + "\t" + it.res }
    Store.save()
}

private fun cFmt(d: Double): String {
    if (d.isNaN() || d.isInfinite()) return "غلطی"
    if (d == Math.rint(d) && Math.abs(d) < 1e15) return d.toLong().toString()
    if (Math.abs(d) >= 1e15 || Math.abs(d) < 1e-9) return String.format(java.util.Locale.US, "%.6e", d)
    return java.math.BigDecimal(d).round(java.math.MathContext(12)).stripTrailingZeros().toPlainString()
}

private fun tm(ms: Long, p: String): String =
    java.text.SimpleDateFormat(p, java.util.Locale.ENGLISH).format(java.util.Date(ms))

private val CkNum1 = Color(0xFF34464D)
private val CkNum2 = Color(0xFF222F35)
private val CkOp1 = Color(0xFFFFAB2E)
private val CkOp2 = Color(0xFFF08000)
private val CkEq1 = Color(0xFFF2545B)
private val CkEq2 = Color(0xFFD32F2F)
private val CkMem1 = Color(0xFF138A47)
private val CkMem2 = Color(0xFF0B6B35)
private val Mono = FontFamily.Default

@Composable
private fun RowScope.CK(t: String, c1: Color, c2: Color, w: Float = 1f, fs: Int = 28, on: () -> Unit) {
    Box(Modifier.weight(w).fillMaxHeight().clip(RoundedCornerShape(16.dp))
        .background(Brush.verticalGradient(listOf(c1, c2)))
        .border(1.dp, Color(0x22FFFFFF), RoundedCornerShape(16.dp)).clickable(onClick = on),
        contentAlignment = Alignment.Center) {
        Text(t, color = Color.White, fontSize = fs.sp, fontWeight = FontWeight.Medium, fontFamily = Mono)
    }
}

@Composable
private fun CalcLogo() {
    Column(Modifier.size(58.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFF0B3D25))
        .border(2.dp, Color(0xFF2E9E6A), RoundedCornerShape(14.dp)).padding(5.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(Color(0xFF2ECC71)), contentAlignment = Alignment.Center) { Text("+", color = Color.White, fontSize = 16.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(Color(0xFF2196F3)), contentAlignment = Alignment.Center) { Text("−", color = Color.White, fontSize = 16.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
        }
        Row(Modifier.weight(1f).fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(Color(0xFFFF9800)), contentAlignment = Alignment.Center) { Text("×", color = Color.White, fontSize = 16.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
            Box(Modifier.weight(1f).fillMaxHeight().clip(RoundedCornerShape(5.dp)).background(Color(0xFF29B6F6)), contentAlignment = Alignment.Center) { Text("÷", color = Color.White, fontSize = 16.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
        }
    }
}

@Composable
private fun HdrBtn(icon: String, label: String, on: () -> Unit) {
    Column(Modifier.width(68.dp).height(68.dp).clip(RoundedCornerShape(16.dp)).background(Color(0x33000000))
        .border(1.5.dp, Color(0xFF2E7D4F), RoundedCornerShape(16.dp)).clickable(onClick = on),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 24.sp, color = Color.White)
        T(label, 12, Color.White, true)
    }
}

@Composable
fun CalcScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val view = LocalView.current
    var cur by remember { mutableStateOf("0") }
    var expr by remember { mutableStateOf("") }
    var acc by remember { mutableStateOf<Double?>(null) }
    var op by remember { mutableStateOf("") }
    var replace by remember { mutableStateOf(true) }
    var typed by remember { mutableStateOf(false) }
    var justEq by remember { mutableStateOf(false) }
    var mem by remember { mutableStateOf(0.0) }
    var err by remember { mutableStateOf("") }
    var hist by remember { mutableStateOf(loadHist()) }
    var showHist by remember { mutableStateOf(false) }

    fun curVal(): Double = cur.toDoubleOrNull() ?: 0.0
    fun tick() {
        if (Store.prefs["snd"] != "0") view.playSoundEffect(android.view.SoundEffectConstants.CLICK)
        if (Store.prefs["vib"] != "0") view.performHapticFeedback(android.view.HapticFeedbackConstants.KEYBOARD_TAP)
    }
    fun addHist(e: String, r: String) {
        hist = (listOf(CalcRec(System.currentTimeMillis(), e, r)) + hist).take(60)
        saveHist(hist)
    }
    fun fail(m: String) {
        cur = "0"; expr = ""; acc = null; op = ""; replace = true; typed = false; justEq = false; err = m
    }
    fun calc(a: Double, o: String, b: Double): Double? = when (o) {
        "+" -> a + b
        "−" -> a - b
        "×" -> a * b
        "÷" -> if (b == 0.0) null else a / b
        else -> b
    }
    fun digit(d: String) {
        err = ""
        if (justEq) { expr = ""; justEq = false }
        if (replace) { cur = d; replace = false }
        else if (cur.replace("-", "").replace(".", "").length < 15) {
            cur = if (cur == "0") d else if (cur == "-0") "-" + d else cur + d
        }
        typed = true
    }
    fun dot() {
        err = ""
        if (justEq) { expr = ""; justEq = false }
        if (replace) { cur = "0."; replace = false } else if (!cur.contains(".")) cur = cur + "."
        typed = true
    }
    fun setOp(o: String) {
        err = ""
        val a = acc
        if (a != null && op.isNotEmpty() && typed) {
            val r = calc(a, op, curVal())
            if (r == null) { fail("0 سے تقسیم نہیں ہو سکتا"); return }
            acc = r; cur = cFmt(r)
        } else if (a == null || op.isEmpty()) {
            acc = curVal()
        }
        op = o; replace = true; typed = false; justEq = false
        expr = cFmt(acc ?: 0.0) + " " + o
    }
    fun doEq() {
        err = ""
        val a = acc
        if (a == null || op.isEmpty()) return
        val b = curVal()
        val r = calc(a, op, b)
        if (r == null) { fail("0 سے تقسیم نہیں ہو سکتا"); return }
        val e = cFmt(a) + " " + op + " " + cFmt(b)
        addHist(e, cFmt(r))
        expr = e
        cur = cFmt(r); acc = null; op = ""; replace = true; typed = false; justEq = true
    }
    fun percent() {
        err = ""
        val a = acc
        val c = curVal()
        val r = if (a != null && op.isNotEmpty() && (op == "+" || op == "−")) a * c / 100.0 else c / 100.0
        cur = cFmt(r); replace = true; typed = true
    }
    fun sqrtF() {
        err = ""
        val c = curVal()
        if (c < 0) { fail("منفی عدد کا جذر ممکن نہیں"); return }
        val e = "√(" + cFmt(c) + ")"
        val r = Math.sqrt(c)
        addHist(e, cFmt(r))
        if (op.isEmpty()) expr = e
        cur = cFmt(r); replace = true; typed = true
    }
    fun negate() {
        err = ""
        if (cur == "0") return
        cur = if (cur.startsWith("-")) cur.drop(1) else "-" + cur
        typed = true
    }
    fun clearAll() {
        cur = "0"; expr = ""; acc = null; op = ""; replace = true; typed = false; justEq = false; err = ""
    }
    fun back() {
        err = ""
        if (replace) return
        cur = if (cur.length <= 1 || (cur.length == 2 && cur.startsWith("-"))) "0" else cur.dropLast(1)
    }
    fun memOp(k: String) {
        err = ""
        when (k) {
            "MC" -> mem = 0.0
            "MR" -> { cur = cFmt(mem); replace = true; typed = true }
            "M+" -> { mem += curVal(); replace = true }
            "M-" -> { mem -= curVal(); replace = true }
            else -> { mem = curVal(); replace = true }
        }
    }
    fun load(r: CalcRec) {
        err = ""; cur = r.res; expr = ""; acc = null; op = ""; replace = true; typed = false; justEq = false
    }
    fun press(f: () -> Unit) { tick(); f() }

    val shown = if (err.isNotEmpty()) err else cur
    val sz = if (err.isNotEmpty()) 24 else when {
        shown.length > 14 -> 30
        shown.length > 11 -> 38
        shown.length > 8 -> 48
        else -> 60
    }

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color(0xFF063A1E), Color(0xFF031A0D))))
            .padding(horizontal = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            // ہیڈر
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                CalcLogo()
                Column(Modifier.weight(1f)) {
                    T("کیلکولیٹر", 34, Color.White, true, al = TextAlign.Left)
                    T("تیز  •  آسان  •  درست", 15, Color(0xFFFFC83D), al = TextAlign.Left)
                }
                HdrBtn("🕘", "تاریخ") { showHist = true }
                HdrBtn("⚙", "سیٹنگز") { go("settings") }
            }
            // ڈسپلے
            Box(Modifier.fillMaxWidth().height(124.dp).clip(RoundedCornerShape(18.dp)).background(Color(0xFF031A0C))
                .border(2.dp, Color(0xFF2ECC71), RoundedCornerShape(18.dp)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                Row(Modifier.align(Alignment.TopStart), horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)).clickable { press { clearAll() } }
                        .padding(horizontal = 10.dp, vertical = 3.dp)) { Text("C", color = Color(0xFFFF8A80), fontSize = 14.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
                    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0x33FFFFFF)).clickable { press { back() } }
                        .padding(horizontal = 10.dp, vertical = 3.dp)) { Text("DEL", color = Color.White, fontSize = 14.sp, fontFamily = Mono, fontWeight = FontWeight.Bold) }
                    if (mem != 0.0) Text("M", color = Gold, fontSize = 16.sp, fontFamily = Mono, fontWeight = FontWeight.Bold)
                }
                Column(Modifier.fillMaxWidth().padding(start = 120.dp), horizontalAlignment = Alignment.End) {
                    Text(if (expr.isEmpty()) " " else expr, color = Color(0xFFB8C4BC), fontSize = 24.sp, fontFamily = Mono, maxLines = 1, softWrap = false)
                    Text(shown, color = Color.White, fontSize = sz.sp, fontFamily = Mono, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
            // حالیہ گنتیاں
            Column(Modifier.fillMaxWidth().weight(1.25f).clip(RoundedCornerShape(16.dp)).background(Color(0x33062A14))
                .border(1.dp, Color(0xFF1F7A45), RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 8.dp)) {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("🕘", fontSize = 20.sp, color = Color.White)
                    Spacer(Modifier.width(8.dp))
                    T("حال ہی کی گنتیاں", 18, Color.White, true, Modifier.weight(1f), TextAlign.Left)
                    Row(Modifier.clip(RoundedCornerShape(10.dp)).border(1.dp, Color(0xFF2E7D4F), RoundedCornerShape(10.dp))
                        .clickable { hist = emptyList(); saveHist(hist) }.padding(horizontal = 10.dp, vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        T("تمام صاف کریں", 13, Color.White)
                        Text("🗑", fontSize = 16.sp, color = Color.White)
                    }
                }
                Spacer(Modifier.height(4.dp))
                if (hist.isEmpty()) {
                    T("ابھی کوئی گنتی نہیں", 14, Color(0xFF8FB29E), al = TextAlign.Left)
                } else {
                    LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                        items(hist) { r ->
                            Column(Modifier.fillMaxWidth().clickable { tick(); load(r) }) {
                                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp, horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Text(r.expr, color = Color.White, fontSize = 17.sp, fontFamily = Mono, maxLines = 1, modifier = Modifier.weight(1.5f))
                                    Text("=", color = Color(0xFFB8C4BC), fontSize = 17.sp, fontFamily = Mono, modifier = Modifier.width(26.dp))
                                    Text(r.res, color = Color.White, fontSize = 17.sp, fontFamily = Mono, maxLines = 1, modifier = Modifier.weight(1f))
                                    Text(tm(r.ms, "hh:mm a"), color = Color(0xFF4FB3A8), fontSize = 13.sp, fontFamily = Mono)
                                    Text("›", color = Color(0xFF8FB29E), fontSize = 20.sp, modifier = Modifier.padding(start = 10.dp))
                                }
                                Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x221ED760)))
                            }
                        }
                    }
                }
            }
            // میموری
            Row(Modifier.fillMaxWidth().height(46.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("MC", "MR", "M+", "M-", "MS").forEach { k -> CK(k, CkMem1, CkMem2, 1f, 17) { press { memOp(k) } } }
            }
            // کی پیڈ
            Column(Modifier.fillMaxWidth().weight(3.4f).padding(bottom = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CK("%", CkNum1, CkNum2) { press { percent() } }
                    CK("√", CkNum1, CkNum2) { press { sqrtF() } }
                    CK("+/–", CkNum1, CkNum2, 1f, 24) { press { negate() } }
                    CK("÷", CkOp1, CkOp2, 1.1f, 32) { press { setOp("÷") } }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CK("7", CkNum1, CkNum2) { press { digit("7") } }
                    CK("8", CkNum1, CkNum2) { press { digit("8") } }
                    CK("9", CkNum1, CkNum2) { press { digit("9") } }
                    CK("×", CkOp1, CkOp2, 1.1f, 32) { press { setOp("×") } }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CK("4", CkNum1, CkNum2) { press { digit("4") } }
                    CK("5", CkNum1, CkNum2) { press { digit("5") } }
                    CK("6", CkNum1, CkNum2) { press { digit("6") } }
                    CK("−", CkOp1, CkOp2, 1.1f, 32) { press { setOp("−") } }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CK("1", CkNum1, CkNum2) { press { digit("1") } }
                    CK("2", CkNum1, CkNum2) { press { digit("2") } }
                    CK("3", CkNum1, CkNum2) { press { digit("3") } }
                    CK("+", CkOp1, CkOp2, 1.1f, 32) { press { setOp("+") } }
                }
                Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    CK("0", CkNum1, CkNum2, 2.05f) { press { digit("0") } }
                    CK(".", CkNum1, CkNum2, 1f, 32) { press { dot() } }
                    CK("=", CkEq1, CkEq2, 1.1f, 32) { press { doEq() } }
                }
            }
        }
    }

    if (showHist) AlertDialog(onDismissRequest = { showHist = false }, title = { Text("گنتیوں کی تاریخ") },
        text = {
            if (hist.isEmpty()) Text("ابھی کوئی گنتی نہیں")
            else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                hist.forEach { r ->
                    Column(Modifier.fillMaxWidth().clickable { load(r); showHist = false }.padding(vertical = 6.dp)) {
                        Text(r.expr + " = " + r.res, fontWeight = FontWeight.Bold, fontFamily = Mono, fontSize = 16.sp)
                        Text(tm(r.ms, "dd-MM-yyyy hh:mm a"), fontSize = 11.sp, color = Color.Gray, fontFamily = Mono)
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                if (hist.isNotEmpty()) share(ctx, hist.joinToString("\n") { it.expr + " = " + it.res })
            }) { Text("📤 شیئر") }
        },
        dismissButton = { TextButton(onClick = { showHist = false }) { Text("بند کریں") } })
}
