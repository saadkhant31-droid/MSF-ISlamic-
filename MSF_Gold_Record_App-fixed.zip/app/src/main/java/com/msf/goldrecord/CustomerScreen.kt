package com.msf.goldrecord

import android.content.Context
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

val custW = listOf(36, 110, 110, 140, 80, 96, 96, 70, 76, 120)
val RowA = Color(0xFF0F2415)
val RowB = Color(0xFF14301C)

fun cStatus(e: Entry) = e.status.ifBlank { "فعال" }
fun cPhone(e: Entry) = e.phone.ifBlank { e.note }
fun buyOf(c: Entry) = Store.entries.filter { it.type == "purchase" && it.name == c.name }.sumOf { it.amount }
fun sellOf(c: Entry) = Store.entries.filter { it.type == "sale" && it.name == c.name }.sumOf { it.amount }
fun dueOf(c: Entry) = Store.entries.filter { it.type == "sale" && it.name == c.name }.sumOf { it.amount - it.paid }

fun importCsv(ctx: Context, uri: Uri): String = try {
    val text = ctx.contentResolver.openInputStream(uri)!!.bufferedReader().readText()
    var n = 0
    text.lines().map { it.trim() }.filter { it.isNotEmpty() }.forEach { line ->
        val c = line.split(",").map { it.trim().trim('"') }
        if (c[0].isBlank() || c[0] == "نام" || c[0].lowercase() == "name") return@forEach
        val ph = c.getOrElse(1) { "" }
        if (Store.entries.none { it.type == "customer" && it.name == c[0] && cPhone(it) == ph }) {
            Store.entries.add(Entry(System.currentTimeMillis() + n, "customer", c[0], 0.0, 0.0, "", LocalDate.now().toString(),
                phone = ph, cnic = c.getOrElse(2) { "" }, city = c.getOrElse(3) { "" },
                status = c.getOrElse(4) { "فعال" }.ifBlank { "فعال" }))
            n++
        }
    }
    Store.save(); "$n گاہک درآمد ہو گئے ✅"
} catch (e: Exception) { "فائل پڑھنے میں مسئلہ ⚠️ (ترتیب: نام، موبائل، شناختی کارڈ، شہر، حالت)" }

@Composable
fun Tabs2(cur: String, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(3.dp)) {
        listOf(Triple("home", "🏠", "ہوم"), Triple("customer", "👥", "گاہک"), Triple("purchase", "💎", "خریداری"),
            Triple("sale", "🛒", "فروخت"), Triple("worker", "🗄", "کاریگر"), Triple("reports", "📊", "رپورٹس"),
            Triple("settings", "⚙️", "سیٹنگز")).forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) Gold else CardBg).border(1.dp, GoldD, RoundedCornerShape(8.dp)).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 17.sp)
                T(l, 9, if (k == cur) Color.Black else Color.White)
            }
        }
    }
}

@Composable
fun SumItem(icon: String, label: String, value: String, m: Modifier) {
    Column(m, horizontalAlignment = Alignment.CenterHorizontally) {
        Text(icon, fontSize = 18.sp)
        T(label, 9, Color.White, al = TextAlign.Center)
        T(value, 11, Color.White, true, al = TextAlign.Center)
    }
}

@Composable
fun CustDialog(init: Entry?, close: () -> Unit) {
    var n by remember { mutableStateOf(init?.name ?: "") }
    var p by remember { mutableStateOf(init?.let { cPhone(it) } ?: "") }
    var c by remember { mutableStateOf(init?.cnic ?: "") }
    var ct by remember { mutableStateOf(init?.city ?: "") }
    var st by remember { mutableStateOf(init?.let { cStatus(it) } ?: "فعال") }
    AlertDialog(onDismissRequest = close, title = { Text(if (init == null) "نیا گاہک شامل کریں" else "گاہک ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (n.isNotBlank()) {
                    val base = init ?: Entry(System.currentTimeMillis(), "customer", "", 0.0, 0.0, "", LocalDate.now().toString())
                    val e = base.copy(name = n.trim(), phone = p.trim(), cnic = c.trim(), city = ct.trim(), status = st, note = "")
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    if (init != null && init.name.trim() != n.trim()) {
                        for (ix in Store.entries.indices) {
                            val x = Store.entries[ix]
                            if ((x.type == "sale" || x.type == "purchase") && x.name.trim() == init.name.trim()) Store.entries[ix] = x.copy(name = n.trim())
                        }
                    }
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                F("نام", n) { n = it }
                F("موبائل نمبر", p) { p = it }
                F("شناختی کارڈ نمبر", c) { c = it }
                F("پتہ / شہر", ct) { ct = it }
                Drop(st, listOf("فعال", "غیر فعال")) { st = it }
            }
        })
}


private const val CU_ALL_FROM = "2000-01-01"
private const val CU_ALL_TO = "2100-12-31"
private val CuSorts = listOf("نام کے مطابق", "بقایا کے مطابق", "کل خریداری کے مطابق", "آخری ادائیگی کے مطابق")
private val CuCols = listOf(0xFF1B7A3A, 0xFF1565C0, 0xFF6A1B9A, 0xFFEF6C00, 0xFF00838F, 0xFFAD1457)
private val cuW = listOf(40, 150, 112, 100, 92, 96, 84, 132)

private class CuRow(val c: Entry, val total: Double, val paid: Double, val last: String) {
    val due get() = total - paid
}

private fun cuSales(c: Entry, f: String, t: String) =
    Store.entries.filter { it.type == "sale" && it.name.trim() == c.name.trim() && it.date >= f && it.date <= t }
private fun cuLast(c: Entry): String =
    c.bill.ifBlank { cuSales(c, CU_ALL_FROM, CU_ALL_TO).filter { it.paid > 0 }.maxOfOrNull { it.date } ?: "" }
private fun cuState(total: Double, paid: Double): String = when { total - paid <= 0.0 -> "مکمل"; paid > 0 -> "جزوی"; else -> "بقایا" }
private fun cuColor(s: String) = when (s) { "مکمل" -> Color(0xFF2E7D32); "جزوی" -> Color(0xFFEF6C00); else -> Color(0xFFD32F2F) }

private fun cuApplyPay(c: Entry, amt: Double) {
    var left = amt
    val sales = Store.entries.filter { it.type == "sale" && it.name.trim() == c.name.trim() && it.amount - it.paid > 0 }
        .sortedWith(compareBy<Entry> { it.date }.thenBy { it.id })
    for (s in sales) {
        if (left <= 0) break
        val p = minOf(s.amount - s.paid, left)
        val i = Store.entries.indexOfFirst { it.id == s.id }
        if (i >= 0) Store.entries[i] = s.copy(paid = s.paid + p)
        left -= p
    }
    val ci = Store.entries.indexOfFirst { it.id == c.id }
    if (ci >= 0) Store.entries[ci] = Store.entries[ci].copy(bill = LocalDate.now().toString())
    Store.save()
}

@Composable
private fun CuStat(icon: String, title: String, value: String, bg: Long, m: Modifier) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(Color(bg)).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 28.sp)
        T(title, 13, Color.White, true, al = TextAlign.Center)
        T(value, 16, Color.White, true, al = TextAlign.Center)
    }
}

@Composable
private fun CuSum(icon: String, label: String, value: String, vc: Color, m: Modifier) {
    Row(m.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 24.sp)
        Spacer(Modifier.width(6.dp))
        Column { T(label, 11, Color.DarkGray); T(value, 14, vc, true) }
    }
}

@Composable
fun CustomerScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    var from by remember { mutableStateOf(CU_ALL_FROM) }
    var to by remember { mutableStateOf(CU_ALL_TO) }
    var rangeMenu by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var chip by remember { mutableStateOf(0) }
    var sort by remember { mutableStateOf(CuSorts[0]) }
    var msg by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }
    var payFor by remember { mutableStateOf<Entry?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) msg = importCsv(ctx, uri)
    }

    val all = Store.entries.filter { it.type == "customer" }.sortedBy { it.id }
    val month = today.toString().take(7)
    val data = all.map { c -> val s = cuSales(c, from, to); CuRow(c, s.sumOf { it.amount }, s.sumOf { it.paid }, cuLast(c)) }
    val rows = data.filter { r ->
        (chip == 0 || (chip == 1 && r.due > 0) || (chip == 2 && r.due <= 0) || (chip == 3 && r.c.date.startsWith(month))) &&
                (q.isBlank() || r.c.name.contains(q) || cPhone(r.c).contains(q) || r.c.cnic.contains(q) || r.c.city.contains(q))
    }.let { l ->
        when (sort) {
            CuSorts[1] -> l.sortedByDescending { it.due }
            CuSorts[2] -> l.sortedByDescending { it.total }
            CuSorts[3] -> l.sortedByDescending { it.last }
            else -> l.sortedBy { it.c.name }
        }
    }
    val tPaid = rows.sumOf { it.paid }
    val tDue = rows.sumOf { it.due }
    val tAll = rows.sumOf { it.total }
    val rangeLbl = if (from == CU_ALL_FROM) "تمام ریکارڈ" else "${fmtD(from)} تا ${fmtD(to)}"
    val vc = view?.let { v -> Store.entries.firstOrNull { it.id == v.id } }

    Column(Modifier.fillMaxSize().background(Light)) {
        MsfHeader("🤝", "گاہک کا حساب", "تمام گاہکوں کے ادائیگی اور بقایا حساب کا ریکارڈ", "اعتماد  •  ایمانداری  •  کامیاب کاروبار")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            MsfNav("customer", listOf(Triple("home", "🏠", "ہوم"), Triple("customer", "📒", "گاہک کا حساب"), Triple("sale", "🛒", "فروخت"),
                Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")), go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CuStat("👥", "کل گاہک", rows.size.toString(), 0xFF1B7A3A, Modifier.weight(1f))
                    CuStat("💰", "کل وصولی", money(tPaid), 0xFF1565C0, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    CuStat("🪙", "کل بقایا", money(tDue), 0xFFC62828, Modifier.weight(1f))
                    CuStat("📄", "مجموعی رقم", money(tAll), 0xFF6A1B9A, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    LF(q, Modifier.weight(1f), ph = "🔍 گاہک کا نام یا موبائل نمبر...") { q = it }
                    Box(Modifier.width(150.dp)) {
                        Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp)).clickable { rangeMenu = true }.padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            T("📅 $rangeLbl", 10, Color.Black, true, Modifier.weight(1f)); T("▾", 14, Color.Black)
                        }
                        DropdownMenu(expanded = rangeMenu, onDismissRequest = { rangeMenu = false }) {
                            DropdownMenuItem(text = { Text("تمام ریکارڈ") }, onClick = { from = CU_ALL_FROM; to = CU_ALL_TO; rangeMenu = false })
                            DropdownMenuItem(text = { Text("اس ماہ") }, onClick = { from = today.withDayOfMonth(1).toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("اس سال") }, onClick = { from = today.withDayOfYear(1).toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("تاریخ منتخب کریں") }, onClick = {
                                rangeMenu = false
                                pickDate(ctx, today.toString()) { f ->
                                    pickDate(ctx, today.toString()) { t -> if (f <= t) { from = f; to = t } else { from = t; to = f } }
                                }
                            })
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MChip("تمام گاہک", Color(0xFF1B7A3A), chip == 0) { chip = 0 }
                    MChip("بقایا والے", Color(0xFFC62828), chip == 1) { chip = 1 }
                    MChip("مکمل ادائیگی والے", Color(0xFF1565C0), chip == 2) { chip = 2 }
                    MChip("نئے گاہک", Color(0xFF6A1B9A), chip == 3) { chip = 3 }
                    Drop("ترتیب: $sort", CuSorts, Modifier.width(210.dp)) { sort = it }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(GreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("👥 گاہکوں کی فہرست", 17, Color.White, true, Modifier.weight(1f))
                        Btn("＋ نیا گاہک شامل کریں", Color(0xFF1B7A3A), Modifier.width(140.dp)) { editing = null; dlg = true }
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        Row(Modifier.background(GreenD).padding(vertical = 10.dp)) {
                            listOf("#", "گاہک کا نام", "موبائل نمبر", "کل خریداری", "بقایا رقم", "آخری ادائیگی", "حالت", "تفصیلات")
                                .forEachIndexed { i, h -> Cell(h, cuW[i], Color.White, true) }
                        }
                        rows.forEachIndexed { i, r ->
                            val st = cuState(r.total, r.paid)
                            Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF3F6F9)).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Cell((i + 1).toString(), cuW[0])
                                Row(Modifier.width(cuW[1].dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(32.dp).clip(CircleShape).background(Color(CuCols[(r.c.id % CuCols.size).toInt()])), contentAlignment = Alignment.Center) {
                                        T(r.c.name.take(1), 14, Color.White, true)
                                    }
                                    Spacer(Modifier.width(6.dp))
                                    T(r.c.name, 12, Color.Black, true, Modifier.weight(1f))
                                }
                                Cell(cPhone(r.c), cuW[2]); Cell("Rs. " + mny(r.total), cuW[3])
                                Cell("Rs. " + mny(r.due.coerceAtLeast(0.0)), cuW[4], if (r.due > 0) Color(0xFFD32F2F) else Color(0xFF2E7D32), true)
                                Cell(if (r.last.isBlank()) "-" else fmtD(r.last), cuW[5])
                                Box(Modifier.width(cuW[6].dp), contentAlignment = Alignment.Center) {
                                    Text(st, color = Color.White, fontSize = 11.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp))
                                        .background(cuColor(st)).clickable { if (r.due > 0) payFor = r.c }.padding(horizontal = 14.dp, vertical = 4.dp))
                                }
                                Row(Modifier.width(cuW[7].dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Act("👁", Color(0xFF2E7D32)) { view = r.c }
                                    Act("✏️", Color(0xFF1565C0)) { editing = r.c; dlg = true }
                                    Act("🗑", Color(0xFFC62828)) { del = r.c }
                                }
                            }
                        }
                        if (rows.isEmpty()) T("کوئی گاہک نہیں", 13, Color.Gray, m = Modifier.padding(16.dp))
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFBF3D6)).padding(vertical = 8.dp)) {
                        CuSum("🪙", "کل ادائیگی", money(tPaid), Color.Black, Modifier.weight(1.2f))
                        CuSum("💵", "کل بقایا", money(tDue), Color(0xFFC62828), Modifier.weight(1.2f))
                        CuSum("👥", "کل گاہک", rows.size.toString(), Color.Black, Modifier.weight(1f))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("⬇️ فائل سے درآمد", Color(0xFF1565C0), Modifier.weight(1f)) { picker.launch("*/*") }
                    Btn("⬆️ فائل برآمد", Color(0xFF6A1B9A), Modifier.weight(1f)) {
                        share(ctx, "نام,موبائل,شناختی کارڈ,شہر,حالت\n" +
                                all.joinToString("\n") { listOf(it.name, cPhone(it), it.cnic, it.city, cStatus(it)).joinToString(",") })
                    }
                    Btn("📤 حساب شیئر", Color(0xFF1B7A3A), Modifier.weight(1f)) {
                        share(ctx, "${Store.prefs["shop"]}\nگاہکوں کا حساب\n" + rows.joinToString("\n") {
                            "${it.c.name} | ${cPhone(it.c)} | خریداری ${mny(it.total)} | بقایا ${mny(it.due.coerceAtLeast(0.0))}"
                        } + "\nکل وصولی: ${money(tPaid)}\nکل بقایا: ${money(tDue)}")
                    }
                }
                if (msg.isNotEmpty()) T(msg, 13, GreenM, true)
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (dlg) CustDialog(editing) { dlg = false; editing = null }
    payFor?.let { c ->
        var amt by remember { mutableStateOf("") }
        val due = cuSales(c, CU_ALL_FROM, CU_ALL_TO).sumOf { it.amount - it.paid }
        AlertDialog(onDismissRequest = { payFor = null }, title = { Text("وصولی درج کریں — ${c.name}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    T("کل بقایا: ${money(due)}", 14, Color(0xFFEF9A9A), true)
                    F("وصول شدہ رقم (Rs.)", amt, true) { amt = it }
                    TextButton(onClick = { amt = fmtW(due) }) { Text("✔ پورا بقایا") }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    if (num(amt) > 0) { cuApplyPay(c, num(amt)); msg = "${money(minOf(num(amt), due))} وصول ہو گئے ✅"; payFor = null }
                }) { Text("محفوظ کریں") }
            },
            dismissButton = { TextButton(onClick = { payFor = null }) { Text("منسوخ") } })
    }
    vc?.let { e ->
        val s = cuSales(e, CU_ALL_FROM, CU_ALL_TO).sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
        val tot = s.sumOf { it.amount }; val pd = s.sumOf { it.paid }
        val last = cuLast(e)
        val text = "${e.name}\nموبائل: ${cPhone(e)}\nشناختی کارڈ: ${e.cnic}\nپتہ: ${e.city}\nحالت: ${cStatus(e)}\nشامل: ${fmtD(e.date)}\n" +
                "کل خریداری: ${money(tot)}\nکل وصولی: ${money(pd)}\nبقایا: ${money(tot - pd)}\nآخری ادائیگی: ${if (last.isBlank()) "-" else fmtD(last)}"
        AlertDialog(onDismissRequest = { view = null }, title = { Text(e.name) },
            confirmButton = { TextButton(onClick = { share(ctx, "${Store.prefs["shop"]}\n$text") }) { Text("📤 شیئر") } },
            dismissButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(text)
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Btn("💵 وصولی درج کریں", Color(0xFF1B7A3A), Modifier.weight(1f)) { payFor = e }
                        Btn("📞 کال", Color(0xFF1565C0), Modifier.weight(1f)) {
                            val ph = cPhone(e).filter { it.isDigit() || it == '+' }
                            if (ph.isNotEmpty()) ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:$ph")))
                        }
                    }
                    T("📋 فروخت کا ریکارڈ", 14, Gold, true)
                    if (s.isEmpty()) T("ابھی کوئی فروخت نہیں", 12, Color.Gray)
                    s.take(30).forEach { x ->
                        T("${fmtD(x.date)} • ${x.karat} • ${money(x.amount)} • وصول ${money(x.paid)} • ${suPay(x)}", 11, Color.LightGray)
                    }
                }
            })
    }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("گاہک حذف کریں") },
            text = { Text("${e.name} کو فہرست سے حذف کر دیں؟ (اس کی خریداری/فروخت کا ریکارڈ باقی رہے گا)") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); Store.save(); del = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
}
