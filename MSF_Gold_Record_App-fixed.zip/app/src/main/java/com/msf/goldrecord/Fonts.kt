package com.msf.goldrecord

import androidx.compose.material3.Typography
import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight

val JameelNoori = FontFamily(Font(R.font.jameel_noori_kasheeda, FontWeight.Normal))
val AlMajeed = FontFamily(Font(R.font.al_majeed_quranic, FontWeight.Normal))
val AlMushaf = FontFamily(Font(R.font.al_mushaf_quran, FontWeight.Normal))
val AlQalam = FontFamily(Font(R.font.al_qalam_quran, FontWeight.Normal))

/** key, نام، فونٹ */
val appFonts = listOf(
    Triple("jameel", "جمیل نوری کشیدہ", JameelNoori),
    Triple("majeed", "الماجد قرآنی", AlMajeed),
    Triple("mushaf", "المصحف قرآن", AlMushaf),
    Triple("qalam", "القلم قرآن", AlQalam)
)

/** منتخب فونٹ (Store.prefs["font"]) — ڈیفالٹ: جمیل نوری کشیدہ */
fun currentFont(): FontFamily {
    val k = Store.prefs["font"] ?: "jameel"
    return appFonts.firstOrNull { it.first == k }?.third ?: JameelNoori
}

fun appTypography(f: FontFamily): Typography {
    val d = Typography()
    return Typography(
        displayLarge = d.displayLarge.copy(fontFamily = f), displayMedium = d.displayMedium.copy(fontFamily = f),
        displaySmall = d.displaySmall.copy(fontFamily = f), headlineLarge = d.headlineLarge.copy(fontFamily = f),
        headlineMedium = d.headlineMedium.copy(fontFamily = f), headlineSmall = d.headlineSmall.copy(fontFamily = f),
        titleLarge = d.titleLarge.copy(fontFamily = f), titleMedium = d.titleMedium.copy(fontFamily = f),
        titleSmall = d.titleSmall.copy(fontFamily = f), bodyLarge = d.bodyLarge.copy(fontFamily = f),
        bodyMedium = d.bodyMedium.copy(fontFamily = f), bodySmall = d.bodySmall.copy(fontFamily = f),
        labelLarge = d.labelLarge.copy(fontFamily = f), labelMedium = d.labelMedium.copy(fontFamily = f),
        labelSmall = d.labelSmall.copy(fontFamily = f)
    )
}
