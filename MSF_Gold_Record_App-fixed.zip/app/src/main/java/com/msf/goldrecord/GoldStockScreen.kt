package com.msf.goldrecord

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val stItems = listOf("سونے کی سلاخ", "گھنمی (چوڑیاں)", "ہار", "انگوٹھی", "کڑا", "سکہ", "سونے کی ڈھلی", "دیگر")
private val stKarats = listOf("24K", "22K", "21K", "18K")
private val stSorts = listOf("تاریخ داخلہ", "وزن کے مطابق", "قیمت کے مطابق", "منافع کے مطابق")
private val stW = listOf(40, 150, 60, 80, 108, 108, 108, 112, 132)
private const val ST_ALL_FROM = "2000-01-01"
private const val ST_ALL_TO = "2100-12-31"

private fun stT(g: Double): String = "%.3f".format(g / TOLA)
private fun stK(k: String): String = k.filter { it.isDigit() }.take(2).ifBlank { "24" }
private fun stCur(karat: String): Double = num(Store.prefs["rate"] ?: "0") * stK(karat).toDouble() / 24.0
private fun stIcon(n: String): String = when {
    n.contains("سلاخ") -> "🟨"
    n.contains("چوڑ") || n.contains("گھنمی") -> "⭕"
    n.contains("ہار") -> "📿"
    n.contains("انگوٹھی") -> "💍"
    n.contains("کڑا") || n.contains("گڑا") -> "🔗"
    n.contains("سکہ") -> "🪙"
    n.contains("ڈھلی") -> "🥇"
    else -> "✨"
}

private class StRow(val e: Entry) {
    val tola get() = e.weight / TOLA
    val cost get() = e.amount
    val curRate get() = stCur(e.karat)
    val curVal get() = tola * curRate
    val profit get() = curVal - cost
    val pct get() = if (cost > 0) profit / cost * 100 else 0.0
}

private fun stImport(): Int {
    val have = Store.entries.filter { it.type == "stock" }.map { it.bill }.toSet()
    var n = 0
    Store.entries.filter { it.type == "purchase" && puCat(it.karat) == "سونا" && it.weight > 0 }.sortedBy { it.id }.forEach { p ->
        val key = "P${p.id}"
        if (key !in have) {
            Store.entries.add(Entry(id = System.currentTimeMillis() + n, type = "stock", name = "سونے کی سلاخ", weight = p.weight, amount = p.amount,
                note = "خریداری: ${p.name}", date = p.date, karat = stK(p.karat) + "K", rate = p.amount / (p.weight / TOLA), bill = key))
            n++
        }
    }
    if (n > 0) Store.save()
    return n
}

@Composable
private fun StCard(icon: String, title: String, value: String, sub: String, bg: Long, m: Modifier) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(Color(bg)).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 24.sp)
        T(title, 11, Color.White, true, al = TextAlign.Center)
        T(value, 14, Color.White, true, al = TextAlign.Center)
        if (sub.isNotEmpty()) T(sub, 10, Color(0xFFE0E0E0), al = TextAlign.Center)
    }
}

@Composable
private fun StSum(icon: String, label: String, value: String, vc: Color, m: Modifier) {
    Row(m.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(4.dp))
        Column { T(label, 10, Color.DarkGray); T(value, 12, vc, true) }
    }
}

@Composable
fun GoldStockScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    val td = today.toString()
    var from by remember { mutableStateOf(ST_ALL_FROM) }
    var to by remember { mutableStateOf(ST_ALL_TO) }
    var rangeMenu by remember { mutableStateOf(false) }
    var q by remember { mutableStateOf("") }
    var kf by remember { mutableStateOf("تمام") }
    var sort by remember { mutableStateOf(stSorts[0]) }
    var msg by remember { mutableStateOf("") }
    var dlg by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }
    var sysDlg by remember { mutableStateOf(false) }

    val rows = Store.entries.filter { it.type == "stock" && it.date >= from && it.date <= to }.map { StRow(it) }.filter { r ->
        (kf == "تمام" || stK(r.e.karat) == kf) &&
                (q.isBlank() || r.e.name.contains(q) || r.e.note.contains(q) || r.e.karat.contains(q) || stT(r.e.weight).contains(q) || fmtD(r.e.date).contains(q))
    }.let { l ->
        when (sort) {
            stSorts[1] -> l.sortedByDescending { it.tola }
            stSorts[2] -> l.sortedByDescending { it.cost }
            stSorts[3] -> l.sortedByDescending { it.profit }
            else -> l.sortedWith(compareByDescending<StRow> { it.e.date }.thenByDescending { it.e.id })
        }
    }
    val tTola = rows.sumOf { it.tola }
    val tCost = rows.sumOf { it.cost }
    val tVal = rows.sumOf { it.curVal }
    val tProfit = rows.sumOf { it.profit }
    val tdBuy = Store.entries.filter { it.type == "purchase" && puCat(it.karat) == "سونا" && it.date == td }
    val tdSale = Store.entries.filter { it.type == "sale" && it.date == td }
    val rangeLbl = if (from == ST_ALL_FROM) "تمام ریکارڈ" else "${fmtD(from)} تا ${fmtD(to)}"
    val viewE = view?.let { v -> Store.entries.firstOrNull { it.id == v.id } }

    Column(Modifier.fillMaxSize().background(Light)) {
        MsfHeader("🥇", "سونے کا اسٹاک", "سونے کے اسٹاک، خرید و فروخت اور اسٹاک ریکارڈ", "خالص سونا  •  درست وزن  •  بہترین کاروبار")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            MsfNav("stock", listOf(Triple("home", "🏠", "ہوم"), Triple("customer", "👥", "گاہک"), Triple("stock", "🥇", "اسٹاک"),
                Triple("purchase", "🛍", "خریداری"), Triple("sale", "🛒", "فروخت"), Triple("reports", "📊", "رپورٹس"),
                Triple("settings", "⚙️", "سیٹنگز")), go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StCard("🥇", "کل اسٹاک", "%.3f تولہ".format(tTola), "(وزن)", 0xFF1B7A3A, Modifier.weight(1f))
                    StCard("🪙", "کل مالیت", money(tVal), "(تقریبی)", 0xFF1565C0, Modifier.weight(1f))
                    StCard("⚖️", "اوسط قیمت فی تولہ", money(if (tTola > 0) tCost / tTola else 0.0), "", 0xFF6A1B9A, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    StCard("💵", "آج کی خریداری", "%.3f تولہ".format(tdBuy.sumOf { it.weight } / TOLA), "(${money(tdBuy.sumOf { it.amount })})", 0xFFEF6C00, Modifier.weight(1f))
                    StCard("💰", "آج کی فروخت", "%.3f تولہ".format(tdSale.sumOf { it.weight } / TOLA), "(${money(tdSale.sumOf { it.amount })})", 0xFFC62828, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    LF(q, Modifier.weight(1f), ph = "🔍 آئٹم، وزن یا تفصیل تلاش کریں...") { q = it }
                    Box(Modifier.width(150.dp)) {
                        Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp)).clickable { rangeMenu = true }.padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            T("📅 $rangeLbl", 10, Color.Black, true, Modifier.weight(1f)); T("▾", 14, Color.Black)
                        }
                        DropdownMenu(expanded = rangeMenu, onDismissRequest = { rangeMenu = false }) {
                            DropdownMenuItem(text = { Text("تمام ریکارڈ") }, onClick = { from = ST_ALL_FROM; to = ST_ALL_TO; rangeMenu = false })
                            DropdownMenuItem(text = { Text("اس ماہ") }, onClick = { from = today.withDayOfMonth(1).toString(); to = td; rangeMenu = false })
                            DropdownMenuItem(text = { Text("اس سال") }, onClick = { from = today.withDayOfYear(1).toString(); to = td; rangeMenu = false })
                            DropdownMenuItem(text = { Text("تاریخ منتخب کریں") }, onClick = {
                                rangeMenu = false
                                pickDate(ctx, td) { f -> pickDate(ctx, td) { t -> if (f <= t) { from = f; to = t } else { from = t; to = f } } }
                            })
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MChip("تمام سونا", Color(0xFF1B7A3A), kf == "تمام") { kf = "تمام" }
                    listOf("24", "22", "21", "18").forEach { k -> MChip("$k قیراط", Color(0xFF8D6E00), kf == k) { kf = k } }
                    Drop("ترتیب: $sort", stSorts, Modifier.width(190.dp)) { sort = it }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(GreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("🥇 سونے کا اسٹاک لسٹ", 17, Color.White, true, Modifier.weight(1f))
                        Btn("＋ نیا اسٹاک درج کریں", Color(0xFF1B7A3A), Modifier.width(140.dp)) { editing = null; dlg = true }
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        Row(Modifier.background(GreenD).padding(vertical = 10.dp)) {
                            listOf("#", "تفصیل", "قیراط", "وزن (تولہ)", "خریداری قیمت (فی تولہ)", "کل قیمت", "موجودہ قیمت (فی تولہ)", "منافع / نقصان", "عمل")
                                .forEachIndexed { i, h -> Cell(h, stW[i], Color.White, true) }
                        }
                        rows.forEachIndexed { i, r ->
                            val up = r.profit >= 0
                            val pc = if (up) Color(0xFF2E7D32) else Color(0xFFC62828)
                            Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF3F6F9)).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Cell((i + 1).toString(), stW[0])
                                Row(Modifier.width(stW[1].dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Box(Modifier.size(36.dp).clip(RoundedCornerShape(8.dp)).background(Color(0xFFFFF1C2)), contentAlignment = Alignment.Center) {
                                        Text(stIcon(r.e.name), fontSize = 20.sp)
                                    }
                                    Spacer(Modifier.width(6.dp))
                                    T(r.e.name, 12, Color.Black, true, Modifier.weight(1f))
                                }
                                Cell(stK(r.e.karat) + "K", stW[2]); Cell("%.3f".format(r.tola), stW[3])
                                Cell("Rs. " + mny(r.e.rate), stW[4]); Cell("Rs. " + mny(r.cost), stW[5]); Cell("Rs. " + mny(r.curRate), stW[6])
                                Column(Modifier.width(stW[7].dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                    T((if (up) "▲ " else "▼ ") + "Rs. " + mny(Math.abs(r.profit)), 11, pc, true)
                                    T("(%.2f%%)".format(Math.abs(r.pct)), 10, pc)
                                }
                                Row(Modifier.width(stW[8].dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Act("👁", Color(0xFF2E7D32)) { view = r.e }
                                    Act("✏️", Color(0xFF1565C0)) { editing = r.e; dlg = true }
                                    Act("🗑", Color(0xFFC62828)) { del = r.e }
                                }
                            }
                        }
                        if (rows.isEmpty()) T("ابھی کوئی اسٹاک نہیں۔ نیا اسٹاک درج کریں یا خریداری سے شامل کریں۔", 13, Color.Gray, m = Modifier.padding(16.dp))
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFBF3D6)).padding(vertical = 8.dp)) {
                        StSum("🧾", "کل ٹرانزیکشنز", rows.size.toString(), Color.Black, Modifier.weight(1f))
                        StSum("📈", "کل منافع", money(tProfit), if (tProfit >= 0) Color(0xFF2E7D32) else Color(0xFFC62828), Modifier.weight(1.3f))
                        StSum("💲", "کل مالیت", money(tVal), Color.Black, Modifier.weight(1.3f))
                        StSum("🥇", "کل سونا", "%.3f تولہ".format(tTola), Color.Black, Modifier.weight(1.2f))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("⬇️ خریداری سے شامل کریں", Color(0xFF1565C0), Modifier.weight(1f)) {
                        val n = stImport(); msg = if (n > 0) "$n خریداریاں اسٹاک میں شامل ہو گئیں ✅" else "کوئی نئی سونے کی خریداری نہیں ملی"
                    }
                    Btn("📊 سسٹم اسٹاک", Color(0xFF6A1B9A), Modifier.weight(1f)) { sysDlg = true }
                    Btn("📤 شیئر", Color(0xFF1B7A3A), Modifier.weight(1f)) {
                        share(ctx, "${Store.prefs["shop"]}\nسونے کا اسٹاک\n" + rows.joinToString("\n") {
                            "${it.e.name} | ${stK(it.e.karat)}K | ${"%.3f".format(it.tola)} تولہ | خریداری ${mny(it.cost)} | موجودہ ${mny(it.curVal)}"
                        } + "\nکل سونا: ${"%.3f".format(tTola)} تولہ\nکل مالیت: ${money(tVal)}\nکل منافع: ${money(tProfit)}")
                    }
                }
                if (msg.isNotEmpty()) T(msg, 13, GreenM, true)
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (dlg) StDialog(editing) { dlg = false; editing = null }
    viewE?.let { e ->
        val r = StRow(e)
        val text = "${e.name}\nتاریخ: ${fmtD(e.date)}\nقیراط: ${stK(e.karat)}K\nوزن: ${"%.3f".format(r.tola)} تولہ (${fmtW(e.weight)} گرام)\n" +
                "خریداری قیمت (فی تولہ): ${money(e.rate)}\nکل قیمت: ${money(r.cost)}\nموجودہ قیمت (فی تولہ): ${money(r.curRate)}\n" +
                "موجودہ مالیت: ${money(r.curVal)}\n${if (r.profit >= 0) "منافع" else "نقصان"}: ${money(Math.abs(r.profit))} (${"%.2f".format(Math.abs(r.pct))}%)\n${e.note}"
        AlertDialog(onDismissRequest = { view = null }, title = { Text(stIcon(e.name) + " " + e.name) }, text = { Text(text) },
            confirmButton = { TextButton(onClick = { share(ctx, "${Store.prefs["shop"]}\n$text") }) { Text("📤 شیئر") } },
            dismissButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } })
    }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("اسٹاک حذف کریں") },
            text = { Text("${e.name} (${stT(e.weight)} تولہ) فہرست سے حذف کر دیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); Store.save(); del = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
    if (sysDlg) {
        var op by remember { mutableStateOf(Store.prefs["open"] ?: "0") }
        val pg = Store.entries.filter { it.type == "purchase" && puCat(it.karat) == "سونا" }.sumOf { it.weight }
        val sg = Store.entries.filter { it.type == "sale" }.sumOf { it.weight }
        val g = stockG()
        AlertDialog(onDismissRequest = { sysDlg = false }, title = { Text("📊 خریداری / فروخت کے مطابق اسٹاک") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("موجودہ وزن: ${"%.2f".format(g)} گرام (${"%.3f".format(g / TOLA)} تولہ)\nاندازاً قیمت: ${money(g / TOLA * num(Store.prefs["rate"] ?: "0"))}\n" +
                            "کل خریداری: ${"%.2f".format(pg)} گرام\nکل فروخت: ${"%.2f".format(sg)} گرام")
                    F("ابتدائی اسٹاک (گرام)", op, true) { op = it }
                }
            },
            confirmButton = { TextButton(onClick = { Store.prefs["open"] = num(op).toString(); Store.save(); sysDlg = false }) { Text("محفوظ کریں") } },
            dismissButton = { TextButton(onClick = { sysDlg = false }) { Text("بند کریں") } })
    }
}

@Composable
private fun StDialog(init: Entry?, close: () -> Unit) {
    val ctx = LocalContext.current
    var d by remember { mutableStateOf(init?.date ?: LocalDate.now().toString()) }
    var item by remember { mutableStateOf(init?.name ?: stItems[0]) }
    var k by remember { mutableStateOf(init?.let { stK(it.karat) + "K" } ?: stKarats[0]) }
    var w by remember { mutableStateOf(init?.let { "%.3f".format(it.weight / TOLA) } ?: "") }
    var r by remember { mutableStateOf(if (init == null || init.rate == 0.0) "" else fmtW(init.rate)) }
    var nt by remember { mutableStateOf(init?.note ?: "") }
    var err by remember { mutableStateOf("") }
    val total = num(w) * num(r)
    val cur = stCur(k)
    AlertDialog(onDismissRequest = close, title = { Text(if (init == null) "نیا اسٹاک درج کریں" else "اسٹاک ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (num(w) <= 0) err = "وزن (تولہ) درج کریں ⚠️" else {
                    val base = init ?: Entry(id = System.currentTimeMillis(), type = "stock", name = item, weight = 0.0, amount = 0.0, note = "", date = d)
                    val e = base.copy(name = item, weight = num(w) * TOLA, amount = total, note = nt.trim(), date = d, karat = k, rate = num(r))
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { pickDate(ctx, d) { d = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("📅 تاریخ", 13, Color.LightGray); T(fmtD(d), 14, Color.White, true)
                }
                Drop(item, stItems) { item = it }
                Drop(k, stKarats) { k = it }
                F("وزن (تولہ)", w, true) { w = it }
                F("خریداری قیمت فی تولہ (Rs.)", r, true) { r = it }
                T("کل قیمت: " + money(total), 15, Gold, true)
                T("آج کی قیمت فی تولہ ($k): " + money(cur) + "  — سیٹنگز کے ریٹ سے", 11, Color.LightGray)
                F("نوٹ / تفصیل", nt) { nt = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}
