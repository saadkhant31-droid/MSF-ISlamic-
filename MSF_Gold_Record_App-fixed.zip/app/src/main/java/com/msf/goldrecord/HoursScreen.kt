package com.msf.goldrecord

import android.app.TimePickerDialog
import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val HrGreenD = Color(0xFF0B3B1A)
private val HrGreen = Color(0xFF1E8E3E)
private val HrGold = Color(0xFFE8B923)
private val HrBg = Color(0xFFEEF3EE)
private val HrRed = Color(0xFFE53935)
private val HrBlue = Color(0xFF1565D8)
private val HrPurple = Color(0xFF7B1FA2)
private val HrOrange = Color(0xFFD9820A)
private val HrLine = Color(0xFFDDE3DD)
private val HrW = listOf(30, 150, 84, 84, 70, 66, 84, 90, 108)
private const val HR_ALL_DEPT = "تمام محکمے"
private val HrStatuses = listOf("تمام", "مکمل", "دیر سے آیا", "آدھا دن")

// ---------------- helpers ----------------
private fun hrRecs() = Store.entries.filter { it.type == "hours" }
private fun hrWorker(n: String) = Store.entries.firstOrNull { it.type == "worker" && it.name.trim() == n.trim() }
private fun hrMin(e: Entry) = Math.round(e.weight * 60).toInt()
private fun hrToMin(t: String) = (t.take(2).toIntOrNull() ?: 0) * 60 + (t.drop(3).take(2).toIntOrNull() ?: 0)
private fun hrFromMin(m: Int): String { val x = ((m % 1440) + 1440) % 1440; return "%02d:%02d".format(x / 60, x % 60) }
private fun hrT(s: String): String {
    if (s.length < 5) return "—"
    val h = s.substring(0, 2).toIntOrNull() ?: return "—"
    val ap = if (h >= 12) "PM" else "AM"
    val h12 = if (h % 12 == 0) 12 else h % 12
    return "%02d:%s %s".format(h12, s.substring(3, 5), ap)
}
private fun hrStatusTxt(s: String) = when (s) { "late" -> "دیر سے آیا"; "half" -> "آدھا دن"; else -> "مکمل" }
private fun hrStatusCol(s: String) = if (s == "late" || s == "half") HrOrange else HrGreen
private fun hrNext(s: String) = when (s) { "" -> "late"; "late" -> "half"; else -> "" }
private fun hrHM(m: Int) = "${m / 60} گھنٹے ${m % 60} منٹ"

private fun hrPickTime(ctx: Context, cur: String, on: (String) -> Unit) {
    val h = cur.take(2).toIntOrNull() ?: 9
    val m = cur.drop(3).take(2).toIntOrNull() ?: 0
    TimePickerDialog(ctx, { _, hh, mm -> on("%02d:%02d".format(hh, mm)) }, h, m, false).show()
}

// ---------------- shared UI ----------------
@Composable
private fun HrHeader(title: String, sub: String, tags: String) {
    Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0B3B1A), Color(0xFF062B14))))) {
        Row(Modifier.fillMaxWidth().height(110.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(100.dp).fillMaxHeight()) {
                Image(painterResource(R.drawable.hr_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xFF0B3B1A), 0.8f to Color.Transparent)))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T("🕐 $title", 20, HrGold, true, al = TextAlign.Center)
                T(sub, 10, Color.White, true, al = TextAlign.Center)
                T(tags, 9, HrGold, al = TextAlign.Center)
            }
            Image(painterResource(R.drawable.hr_logo), null,
                Modifier.padding(6.dp).size(84.dp).clip(CircleShape).border(2.dp, HrGold, CircleShape))
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(HrGold).align(Alignment.BottomCenter))
    }
}

@Composable
private fun HrNav(cur: String, go: (String) -> Unit) {
    val items = listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👤", "ملازمین"), Triple("hours", "🕐", "کام کے گھنٹے"),
        Triple("reports", "📅", "رپورٹس"), Triple("hgraph", "📊", "گراف"), Triple("settings", "⚙️", "سیٹنگز")).reversed()
    Row(Modifier.fillMaxWidth().background(HrGreenD).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) HrGold else Color(0xFF0F4D26)).border(1.dp, Color(0xFF8A6D00), RoundedCornerShape(8.dp))
                .clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (k == cur) Color.Black else Color.White, true, al = TextAlign.Center)
            }
        }
    }
}

@Composable
fun HrBottomBar(cur: String, go: (String) -> Unit) {
    NavigationBar(containerColor = HrGreenD) {
        listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👤", "ملازمین"), Triple("hours", "🕐", "کام کے گھنٹے"),
            Triple("reports", "📅", "رپورٹس"), Triple("hgraph", "📊", "گراف"), Triple("settings", "⚙️", "سیٹنگز")).reversed().forEach { (k, i, l) ->
            NavigationBarItem(selected = cur == k, onClick = { go(k) },
                icon = { Text(i, fontSize = 20.sp) }, label = { Text(l, fontSize = 9.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(selectedTextColor = HrGold, unselectedTextColor = Color.White,
                    indicatorColor = Color(0xFF5A4300)))
        }
    }
}

@Composable
private fun HrCard(icon: String, title: String, value: String, sub: String, bg: Color, m: Modifier) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(bg).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 22.sp)
        T(title, 10, Color.White, true, al = TextAlign.Center)
        T(value, 20, Color.White, true, al = TextAlign.Center)
        T(sub, 9, Color(0xFFE8F5E9), al = TextAlign.Center)
    }
}

@Composable
private fun HrStat(icon: String, label: String, value: String, m: Modifier) {
    Row(m.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 20.sp)
        Column { T(label, 10, Color.DarkGray); T(value, 13, Color.Black, true) }
    }
}

@Composable
private fun HrChip(t: String, sel: Boolean, on: () -> Unit) {
    Box(Modifier.height(44.dp).clip(RoundedCornerShape(6.dp)).background(if (sel) HrGreen else Color.White)
        .border(1.dp, if (sel) HrGreen else Color(0xFFCFD8CF), RoundedCornerShape(6.dp)).clickable(onClick = on).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center) { T(t, 12, if (sel) Color.White else Color(0xFF1B3A1F), true) }
}

@Composable
private fun HrStatus(s: String, on: () -> Unit) =
    Text(hrStatusTxt(s), color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(hrStatusCol(s)).clickable(onClick = on).padding(horizontal = 10.dp, vertical = 4.dp))

@Composable
private fun HrHead() {
    Row(Modifier.background(HrGreenD).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("#", "ملازم کا نام", "آغاز وقت", "ختم وقت", "کل گھنٹے", "کل منٹ", "حالت", "تفصیلات", "ایکشن").forEachIndexed { i, t ->
            T(t, 12, Color.White, true, Modifier.width(HrW[i].dp), TextAlign.Center)
        }
    }
}

@Composable
private fun HrRow(i: Int, e: Entry, onStatus: () -> Unit, onView: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val w = hrWorker(e.name)
    Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF4F9F4)).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Cell((i + 1).toString(), HrW[0])
        Row(Modifier.width(HrW[1].dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            WkAvatar(w?.photo ?: "", w?.gender ?: "", e.name, w?.id ?: 0L, 34)
            T(e.name, 12, Color.Black, true, Modifier.weight(1f))
        }
        Cell(hrT(e.karat), HrW[2])
        Cell(hrT(e.city), HrW[3])
        Cell("%.2f".format(e.weight), HrW[4])
        Cell(hrMin(e).toString(), HrW[5])
        Box(Modifier.width(HrW[6].dp), contentAlignment = Alignment.Center) { HrStatus(e.status, onStatus) }
        Cell(e.note.ifBlank { "—" }, HrW[7], Color.DarkGray)
        Row(Modifier.width(HrW[8].dp), horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            Act("🗑", HrRed, onDel); Act("✏️", HrBlue, onEdit); Act("👁", HrGreen, onView)
        }
    }
}

// ---------------- Work Hours screen ----------------
@Composable
fun HoursScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now().toString()
    var day by remember { mutableStateOf(today) }
    var q by remember { mutableStateOf("") }
    var gf by remember { mutableStateOf(0) }
    var dept by remember { mutableStateOf(HR_ALL_DEPT) }
    var sf by remember { mutableStateOf("تمام") }
    var dMenu by remember { mutableStateOf(false) }
    var sMenu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf(false) }
    var edit by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }

    val depts = listOf(HR_ALL_DEPT) + wkWorkersForHours().map { wkRole(it) }.filter { it.isNotBlank() }.distinct()
    val rows = hrRecs().filter { e ->
        val w = hrWorker(e.name)
        e.date == day &&
                (gf == 0 || (gf == 1 && w?.gender == "مرد") || (gf == 2 && w?.gender == "عورت")) &&
                (dept == HR_ALL_DEPT || (w != null && wkRole(w) == dept)) &&
                (sf == "تمام" || hrStatusTxt(e.status) == sf) &&
                (q.isBlank() || e.name.contains(q) || (w != null && (wkPhone(w).contains(q) || w.cnic.contains(q))))
    }.sortedWith(compareBy<Entry> { it.karat }.thenBy { it.id })
    val people = rows.map { it.name.trim() }.distinct().size
    val totM = rows.sumOf { hrMin(it) }
    val totH = totM / 60.0
    val avg = if (people == 0) 0.0 else totH / people
    val allW = wkWorkersForHours().size
    val vr = view?.let { v -> Store.entries.firstOrNull { it.id == v.id } }

    Column(Modifier.fillMaxSize().background(HrBg)) {
        HrHeader("کام کے گھنٹے و منٹ", "ملازمین کے کام کے اوقات کی مکمل ریکارڈنگ", "وقت کی پابندی  •  بہتر کارکردگی  •  درست حساب")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            HrNav("hours", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HrCard("📅", "اوسط کام کے گھنٹے", "%.2f".format(avg), "فی ملازم (${if (day == today) "آج" else fmtD(day)})", HrOrange, Modifier.weight(1f))
                    HrCard("⏱", "کل منٹ", mny(totM.toDouble()), "(${if (day == today) "آج" else fmtD(day)})", HrPurple, Modifier.weight(1f))
                    HrCard("🕐", "کل گھنٹے", fmtW(Math.round(totH * 100) / 100.0), "(${if (day == today) "آج" else fmtD(day)})", HrBlue, Modifier.weight(1f))
                    HrCard("👥", "کل ملازمین", people.toString(), "(کام کر رہے ہیں)", HrGreen, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.height(56.dp).clip(RoundedCornerShape(6.dp)).background(HrGreen).clickable {
                        day = today; q = ""; gf = 0; dept = HR_ALL_DEPT; sf = "تمام"
                    }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("🔄", fontSize = 14.sp); T("آج کا ڈیٹا", 12, Color.White, true)
                    }
                    Row(Modifier.width(118.dp).height(56.dp).clip(RoundedCornerShape(6.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(6.dp)).clickable { pickDate(ctx, day) { day = it } }.padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        T("📅 " + fmtD(day), 11, Color.Black, true); T("▾", 12, Color.Black)
                    }
                    LF(q, Modifier.weight(1f), ph = "🔍 ملازم کا نام یا آئی ڈی تلاش کریں...") { q = it }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box {
                        HrChip("🔻 فلٹر: $sf ▾", sf != "تمام") { sMenu = true }
                        DropdownMenu(expanded = sMenu, onDismissRequest = { sMenu = false }) {
                            HrStatuses.forEach { s -> DropdownMenuItem(text = { Text((if (s == sf) "✔ " else "") + s) }, onClick = { sf = s; sMenu = false }) }
                        }
                    }
                    Box {
                        HrChip("$dept ▾", dept != HR_ALL_DEPT) { dMenu = true }
                        DropdownMenu(expanded = dMenu, onDismissRequest = { dMenu = false }) {
                            depts.forEach { d -> DropdownMenuItem(text = { Text((if (d == dept) "✔ " else "") + d) }, onClick = { dept = d; dMenu = false }) }
                        }
                    }
                    HrChip("خواتین", gf == 2) { gf = 2 }
                    HrChip("مرد", gf == 1) { gf = 1 }
                    HrChip("تمام ملازمین", gf == 0) { gf = 0 }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, HrLine, RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(HrGreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("＋ نیا ریکارڈ درج کریں", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(HrGreen).clickable { edit = null; dlg = true }.padding(horizontal = 12.dp, vertical = 9.dp))
                        Spacer(Modifier.weight(1f))
                        T("کام کے گھنٹے کا ریکارڈ 🕐", 15, Color.White, true)
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        HrHead()
                        rows.forEachIndexed { i, e ->
                            HrRow(i, e,
                                onStatus = {
                                    val ix = Store.entries.indexOfFirst { it.id == e.id }
                                    if (ix >= 0) { Store.entries[ix] = e.copy(status = hrNext(e.status)); Store.save() }
                                },
                                onView = { view = e }, onEdit = { edit = e; dlg = true }, onDel = { del = e })
                        }
                    }
                    if (rows.isEmpty()) T("اس دن کا کوئی ریکارڈ نہیں۔ اوپر سے نیا ریکارڈ درج کریں۔", 14, Color.Gray, m = Modifier.padding(16.dp))
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, HrLine, RoundedCornerShape(12.dp)).padding(vertical = 8.dp)) {
                    HrStat("📅", "اوسط کام کے گھنٹے", "%.2f".format(avg), Modifier.weight(1f))
                    HrStat("⏱", "کل منٹ", mny(totM.toDouble()), Modifier.weight(1f))
                    HrStat("🕐", "کل گھنٹے", fmtW(Math.round(totH * 100) / 100.0), Modifier.weight(1f))
                    HrStat("👥", "کل ملازمین", allW.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (dlg) HrDialog(edit, day) { dlg = false; edit = null }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("ریکارڈ حذف کریں") },
            text = { Text("${e.name} کا ${fmtD(e.date)} کا ریکارڈ حذف کر دیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); Store.save(); del = null; view = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
    vr?.let { e ->
        val month = e.date.take(7)
        val mm = hrRecs().filter { it.name.trim() == e.name.trim() && it.date.startsWith(month) }.sumOf { hrMin(it) }
        val text = "${e.name}\nتاریخ: ${fmtD(e.date)}\nآغاز وقت: ${hrT(e.karat)}\nختم وقت: ${hrT(e.city)}\n" +
                "کل وقت: ${hrHM(hrMin(e))}\nکل گھنٹے: ${"%.2f".format(e.weight)}\nکل منٹ: ${hrMin(e)}\nحالت: ${hrStatusTxt(e.status)}\n" +
                (if (e.note.isNotBlank()) "تفصیل: ${e.note}\n" else "") + "اس ماہ کا کل وقت: ${hrHM(mm)}"
        AlertDialog(onDismissRequest = { view = null }, title = { Text(e.name) },
            text = { Text(text) },
            confirmButton = { TextButton(onClick = { edit = e; dlg = true; view = null }) { Text("✏️ ایڈٹ") } },
            dismissButton = {
                Row {
                    TextButton(onClick = { share(ctx, "${Store.prefs["shop"]}\n$text") }) { Text("📤 شیئر") }
                    TextButton(onClick = { view = null }) { Text("بند کریں") }
                }
            })
    }
}

private fun wkWorkersForHours() = Store.entries.filter { it.type == "worker" }

// ---------------- add / edit dialog ----------------
@Composable
private fun HrDialog(init: Entry?, defDay: String, close: () -> Unit) {
    val ctx = LocalContext.current
    val names = wkWorkersForHours().sortedBy { it.name }.map { it.name }
    var n by remember { mutableStateOf(init?.name ?: "") }
    var d by remember { mutableStateOf(init?.date ?: defDay) }
    val s0 = init?.karat?.takeIf { it.length >= 5 } ?: "09:00"
    val e0 = init?.city?.takeIf { it.length >= 5 } ?: (if (init != null && init.weight > 0) hrFromMin(hrToMin(s0) + hrMin(init)) else "17:00")
    var st by remember { mutableStateOf(s0) }
    var en by remember { mutableStateOf(e0) }
    var nt by remember { mutableStateOf(init?.note ?: "") }
    var sts by remember { mutableStateOf(init?.status ?: "") }
    var err by remember { mutableStateOf("") }
    val dur = hrToMin(en) - hrToMin(st)
    AlertDialog(onDismissRequest = close, title = { Text(if (init == null) "نیا ریکارڈ درج کریں" else "ریکارڈ ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (n.isBlank()) err = "ملازم کا نام درج کریں ⚠️"
                else if (dur <= 0) err = "ختم وقت آغاز وقت کے بعد ہونا چاہیے ⚠️"
                else {
                    val base = init ?: Entry(id = System.currentTimeMillis(), type = "hours", name = "", weight = 0.0, amount = 0.0, note = "", date = d)
                    val e = base.copy(name = n.trim(), weight = dur / 60.0, note = nt.trim(), date = d, karat = st, city = en, status = sts)
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (names.isNotEmpty()) Drop(if (n.isBlank()) "ملازم منتخب کریں" else n, names, Modifier.fillMaxWidth()) { n = it }
                F("ملازم کا نام", n) { n = it }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { pickDate(ctx, d) { d = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("📅 تاریخ", 13, Color.LightGray); T(fmtD(d), 14, Color.White, true)
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { hrPickTime(ctx, st) { st = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("🕘 آغاز وقت", 13, Color.LightGray); T(hrT(st), 14, Color.White, true)
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { hrPickTime(ctx, en) { en = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("🕔 ختم وقت", 13, Color.LightGray); T(hrT(en), 14, Color.White, true)
                }
                T(if (dur > 0) "کل وقت: ${hrHM(dur)}  (${"%.2f".format(dur / 60.0)} گھنٹے)" else "ختم وقت آغاز کے بعد منتخب کریں", 13, Gold, true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MChip("مکمل", HrGreen, sts == "", Modifier.weight(1f)) { sts = "" }
                    MChip("دیر سے آیا", HrOrange, sts == "late", Modifier.weight(1f)) { sts = "late" }
                    MChip("آدھا دن", HrOrange, sts == "half", Modifier.weight(1f)) { sts = "half" }
                }
                F("تفصیل / نوٹ", nt) { nt = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}

// ---------------- Graph screen ----------------
@Composable
fun HoursGraphScreen(go: (String) -> Unit) {
    var days by remember { mutableStateOf(7) }
    val today = LocalDate.now()
    val recs = hrRecs()
    val list = (days - 1 downTo 0).map { today.minusDays(it.toLong()).toString() }
    val vals = list.map { d -> recs.filter { it.date == d }.sumOf { it.weight } }
    val mx = maxOf(vals.maxOrNull() ?: 0.0, 1.0)
    val per = recs.filter { it.date >= list.first() && it.date <= list.last() }
        .groupBy { it.name.trim() }.map { Pair(it.key, it.value.sumOf { r -> r.weight }) }
        .sortedByDescending { it.second }.take(10)
    val pmx = maxOf(per.maxOfOrNull { it.second } ?: 0.0, 1.0)
    Column(Modifier.fillMaxSize().background(HrBg)) {
        HrHeader("گراف", "کام کے گھنٹوں کا گراف اور تجزیہ", "وقت کی پابندی  •  بہتر کارکردگی  •  درست حساب")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            HrNav("hgraph", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HrChip("آخری 30 دن", days == 30) { days = 30 }
                    HrChip("آخری 7 دن", days == 7) { days = 7 }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    HrCard("🕐", "کل گھنٹے", fmtW(Math.round(vals.sum() * 100) / 100.0), "آخری $days دن", HrBlue, Modifier.weight(1f))
                    HrCard("📅", "روزانہ اوسط", "%.1f".format(vals.sum() / days), "گھنٹے", HrOrange, Modifier.weight(1f))
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, HrLine, RoundedCornerShape(12.dp)).padding(10.dp)) {
                    T("📊 روزانہ کام کے گھنٹے", 15, HrGreenD, true)
                    Spacer(Modifier.height(8.dp))
                    Row(Modifier.horizontalScroll(rememberScrollState()).height(200.dp), verticalAlignment = Alignment.Bottom) {
                        list.forEachIndexed { i, d ->
                            Column(Modifier.width(44.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                                T(if (vals[i] > 0) "%.1f".format(vals[i]) else "", 10, Color.DarkGray)
                                Box(Modifier.width(22.dp).height((vals[i] / mx * 140).dp.coerceAtLeast(2.dp)).clip(RoundedCornerShape(4.dp)).background(if (vals[i] > 0) HrGreen else Color(0xFFCFD8CF)))
                                T(d.takeLast(5).split("-").reversed().joinToString("/"), 9, Color.Gray)
                            }
                        }
                    }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, HrLine, RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    T("👥 ملازمین کے کل گھنٹے", 15, HrGreenD, true)
                    if (per.isEmpty()) T("اس مدت میں کوئی ریکارڈ نہیں", 13, Color.Gray)
                    per.forEach { (name, v) ->
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            T(name, 12, Color.Black, true, Modifier.width(86.dp))
                            Box(Modifier.weight(1f)) {
                                Box(Modifier.fillMaxWidth((v / pmx).toFloat().coerceIn(0.02f, 1f)).height(14.dp).clip(RoundedCornerShape(4.dp)).background(HrBlue))
                            }
                            T("%.1f".format(v), 11, Color.DarkGray, true, Modifier.width(40.dp), TextAlign.Center)
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}
