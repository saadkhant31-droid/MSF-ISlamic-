package com.msf.goldrecord

import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Density
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject
import java.time.LocalDate

val Gold = Color(0xFFFFC107)
val GoldD = Color(0xFFB8860B)
val Bg = Color(0xFF0B0B0B)
val CardBg = Color(0xFF151515)
const val TOLA = 11.664

data class Entry(val id: Long, val type: String, val name: String, val weight: Double,
                 val amount: Double, val note: String, val date: String,
                 val karat: String = "", val rate: Double = 0.0, val paid: Double = 0.0, val phone: String = "", val status: String = "", val cnic: String = "", val city: String = "",
                 val ready: Double = 0.0, val mins: Double = 0.0, val bill: String = "", val gender: String = "", val photo: String = "")

object Store {
    private lateinit var sp: SharedPreferences
    val entries = mutableStateListOf<Entry>()
    val prefs = mutableStateMapOf("shop" to "MSF Gold Jewellers", "admin" to "ایڈمن", "rate" to "350000", "open" to "0")

    fun init(c: Context) {
        sp = c.getSharedPreferences("msf", Context.MODE_PRIVATE)
        restore(sp.getString("data", null))
    }

    fun restore(s: String?): Boolean = try {
        if (s == null) false else {
            val o = JSONObject(s)
            val a = o.getJSONArray("entries")
            val l = (0 until a.length()).map {
                val x = a.getJSONObject(it)
                Entry(x.getLong("id"), x.getString("type"), x.getString("name"), x.getDouble("weight"),
                    x.getDouble("amount"), x.getString("note"), x.getString("date"),
                    x.optString("karat", ""), x.optDouble("rate", 0.0), x.optDouble("paid", 0.0), x.optString("phone", ""), x.optString("status", ""), x.optString("cnic", ""), x.optString("city", ""),
                    x.optDouble("ready", 0.0), x.optDouble("mins", 0.0), x.optString("bill", ""), x.optString("gender", ""), x.optString("photo", ""))
            }
            entries.clear(); entries.addAll(l)
            val c = o.getJSONObject("prefs")
            c.keys().forEach { k -> prefs[k] = c.getString(k) }
            save(); true
        }
    } catch (e: Exception) { false }

    fun json(): String {
        val o = JSONObject(); val a = JSONArray()
        entries.forEach {
            a.put(JSONObject().put("id", it.id).put("type", it.type).put("name", it.name)
                .put("weight", it.weight).put("amount", it.amount).put("note", it.note).put("date", it.date)
                .put("karat", it.karat).put("rate", it.rate).put("paid", it.paid).put("phone", it.phone).put("status", it.status).put("cnic", it.cnic).put("city", it.city)
                .put("ready", it.ready).put("mins", it.mins).put("bill", it.bill).put("gender", it.gender).put("photo", it.photo))
        }
        val c = JSONObject()
        prefs.entries.forEach { c.put(it.key, it.value) }
        return o.put("entries", a).put("prefs", c).toString()
    }

    fun save() { sp.edit().putString("data", json()).apply() }
}

fun mny(d: Double) = "%,.0f".format(d)
fun money(d: Double) = "Rs. " + mny(d)
fun num(s: String) = s.trim().toDoubleOrNull() ?: 0.0
fun sum(t: String, f: (Entry) -> Boolean = { true }) = Store.entries.filter { it.type == t && f(it) }.sumOf { it.amount }
fun sumPaid(t: String) = Store.entries.filter { it.type == t }.sumOf { it.paid }
fun stockG(): Double = num(Store.prefs["open"] ?: "0") +
        Store.entries.filter { it.type == "purchase" && puCat(it.karat) == "سونا" }.sumOf { it.weight } -
        Store.entries.filter { it.type == "sale" }.sumOf { it.weight }
fun share(ctx: Context, text: String) {
    val i = Intent(Intent.ACTION_SEND).apply { type = "text/plain"; putExtra(Intent.EXTRA_TEXT, text) }
    ctx.startActivity(Intent.createChooser(i, null))
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Store.init(this)
        applyBrightness(this)
        setContent {
            val dn = LocalDensity.current
            val fs = (Store.prefs["fscale"] ?: "1.0").toFloatOrNull() ?: 1f
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl,
                LocalDensity provides Density(dn.density, dn.fontScale * fs)) {
                val ff = currentFont()
                MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Bg, surface = CardBg), typography = appTypography(ff)) {
                    ProvideTextStyle(androidx.compose.ui.text.TextStyle(fontFamily = ff)) { App() }
                }
            }
        }
    }
}

@Composable
fun App() {
    var locked by remember { mutableStateOf(Store.prefs["lock"] == "1" && !Store.prefs["pass"].isNullOrEmpty()) }
    var screen by remember { mutableStateOf("home") }
    val appCtx = LocalContext.current
    LaunchedEffect(Unit) { Bk.autoIfDue(appCtx) }
    if (locked) { LockScreen { locked = false }; return }
    BackHandler(screen != "home") { screen = "home" }
    val go = { s: String -> screen = s }
    Scaffold(containerColor = Bg, bottomBar = { if (screen == "reports" || screen == "receipts") RcBottomBar(screen, go) else if (screen == "worker" || screen == "attendance" || screen == "salary") WkBottomBar(screen, go) else if (screen == "hours" || screen == "hgraph") HrBottomBar(screen, go) else if (screen == "wage" || screen == "wagehist") WgBottomBar(screen, go) else if (screen == "calc" || screen == "settings") NavBar5(screen, go) else if (screen == "backup" || screen == "bkrestore") BkNav5(screen, go) else if (screen == "bkfiles" || screen == "bkhist") BkNav4(screen, go) else BottomBar(screen, go) }) { p ->
        Box(Modifier.padding(p).fillMaxSize()) {
            when (screen) {
                "home" -> Home(go)
                "more" -> Page("مزید") { Column(Modifier.verticalScroll(rememberScrollState())) { FnGrid(go) } }
                "purchase" -> key(screen) { PurchaseScreen(go) }
                "sale" -> key(screen) { SaleScreen(go) }
                "customer" -> key(screen) { CustomerScreen(go) }
                "worker" -> key(screen) { WorkerScreen(go) }
                "attendance" -> key(screen) { AttendanceScreen(go) }
                "salary" -> key(screen) { SalaryScreen(go) }
                "hours" -> key(screen) { HoursScreen(go) }
                "hgraph" -> key(screen) { HoursGraphScreen(go) }
                "wage" -> key(screen) { WageScreen(go) }
                "wagehist" -> key(screen) { WageHistoryScreen(go) }
                "stock" -> key(screen) { GoldStockScreen(go) }
                "reports" -> key(screen) { Reports(go) }
                "receipts" -> key(screen) { Receipts(go) }
                "calc" -> key(screen) { CalcScreen(go) }
                "settings" -> key(screen) { SettingsScreen(go) { locked = true; screen = "home" } }
                "backup" -> key(screen) { BackupScreen(go) }
                "bkfiles" -> key(screen) { BkFilesScreen(go) }
                "bkrestore" -> key(screen) { BkRestoreScreen(go) }
                "bkhist" -> key(screen) { BkHistScreen(go) }
            }
        }
    }
}

@Composable
fun BottomBar(cur: String, go: (String) -> Unit) {
    NavigationBar(containerColor = Color(0xFF101010)) {
        listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "کاریگر"), Triple("purchase", "🛍", "خریداری"),
            Triple("sale", "🛒", "فروخت"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")).reversed().forEach { (k, i, l) ->
            NavigationBarItem(selected = cur == k, onClick = { go(k) },
                icon = { Text(i, fontSize = 20.sp) }, label = { Text(l, fontSize = 11.sp) },
                colors = NavigationBarItemDefaults.colors(selectedTextColor = Gold, unselectedTextColor = Color.Gray,
                    indicatorColor = Color(0xFF2A2200)))
        }
    }
}

@Composable
fun T(s: String, sz: Int = 14, c: Color = Color.White, b: Boolean = false, m: Modifier = Modifier, al: TextAlign? = null) =
    Text(s, modifier = m, color = c, fontSize = sz.sp, fontWeight = if (b) FontWeight.Bold else null, textAlign = al)

@Composable
fun Page(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        T(title, 22, Gold, true)
        content()
    }
}

class Stat(val title: String, val value: String, val sub: String, val bg: Long, val icon: String, val go: String)
class Fn(val key: String, val title: String, val icon: String)

val fns = listOf(
    Fn("purchase", "خریداری کا ریکارڈ", "🛒"), Fn("sale", "فروخت کا ریکارڈ", "🧾"),
    Fn("customer", "گاہکوں کا حساب", "👥"), Fn("stock", "سونے کا اسٹاک", "🪙"),
    Fn("worker", "کام کرنے والے افراد", "👷"), Fn("hours", "کام کے گھنٹے و منٹ", "⏱"),
    Fn("wage", "مزدوری کا حساب", "💰"), Fn("reports", "رپورٹس", "📊"),
    Fn("receipts", "رسیدیں", "📄"), Fn("calc", "کیلکولیٹر", "🧮"),
    Fn("settings", "سیٹنگز", "⚙️"), Fn("backup", "بیک اپ", "🔒"))

@Composable
fun Home(go: (String) -> Unit) {
    val td = LocalDate.now().toString()
    val s = sum("sale") { it.date == td }
    val p = sum("purchase") { it.date == td }
    val w = sum("wage") { it.date == td }
    val cash = sumPaid("sale") - sumPaid("purchase") - sum("wage")
    val custs = Store.entries.count { it.type == "customer" }
    val r1 = listOf(
        Stat("آج سونے کا ریٹ", mny(num(Store.prefs["rate"] ?: "0")), "Rs. فی تولہ", 0xFFFFE9A8, "🪙", "settings"),
        Stat("آج کی کل فروخت", mny(s), "Rs.", 0xFFC9F5C0, "🛒", "sale"),
        Stat("آج کی کل خریداری", mny(p), "Rs.", 0xFFCFE6FF, "🛍", "purchase"),
        Stat("آج کا منافع", mny(s - p - w), "Rs.", 0xFFFFCDD2, "📈", "reports"))
    val r2 = listOf(
        Stat("موجودہ سونے کا اسٹاک", mny(stockG()), "گرام", 0xFFCFE6FF, "⚖️", "stock"),
        Stat("نقد رقم کا بیلنس", mny(cash), "Rs.", 0xFFE3D4FF, "💵", "reports"),
        Stat("گاہکوں کی تعداد", custs.toString(), "", 0xFFC8F5F0, "👥", "customer"),
        Stat("آج کا حساب کتاب", "مکمل ✅", "", 0xFFFFF0C2, "📒", "reports"))
    Column(Modifier.verticalScroll(rememberScrollState())) {
        Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF3A2A00), Color.Black, Color(0xFF3A2A00)))).padding(12.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.logo), null, Modifier.size(84.dp).clip(CircleShape))
            Spacer(Modifier.width(12.dp))
            Column {
                T("MSF", 34, Gold, true)
                T("Gold Business Record", 17, Gold, true)
                T("سونے کے کاروبار کا مکمل حساب کتاب", 14, Color(0xFFFFD866))
            }
        }
        Row(Modifier.padding(8.dp).fillMaxWidth().border(1.dp, GoldD, RoundedCornerShape(12.dp)).padding(10.dp),
            horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Column { T("📅 آج کی تاریخ", 11, Color.Gray); T(td, 14, Color.White, true) }
            Column(Modifier.clickable { go("settings") }) { T("🏪 دکان کا نام", 11, Color.Gray); T(Store.prefs["shop"] ?: "", 14, Color.White, true) }
            Column(Modifier.clickable { go("settings") }) { T("⚙️ صارف", 11, Color.Gray); T(Store.prefs["admin"] ?: "", 14, Color.White, true) }
        }
        listOf(r1, r2).forEach { row ->
            Row(Modifier.padding(horizontal = 8.dp, vertical = 3.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { StatCard(it, Modifier.weight(1f), go) }
            }
        }
        Row(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, top = 12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            T("📊 اہم فنکشنز", 18, Gold, true)
            T("مزید دیکھیں ◂", 12, Color.LightGray, m = Modifier.clickable { go("more") })
        }
        FnGrid(go)
        Spacer(Modifier.height(8.dp))
    }
}

@Composable
fun StatCard(st: Stat, m: Modifier, go: (String) -> Unit) {
    Column(m.height(120.dp).clip(RoundedCornerShape(12.dp)).background(Color(st.bg)).clickable { go(st.go) }.padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(st.icon, fontSize = 26.sp)
        T(st.title, 11, Color.Black, al = TextAlign.Center)
        T(st.value, 14, Color.Black, true, al = TextAlign.Center)
        T(st.sub, 10, Color.DarkGray, al = TextAlign.Center)
    }
}

@Composable
fun FnGrid(go: (String) -> Unit) {
    Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
        fns.chunked(4).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                row.forEach { f ->
                    Column(Modifier.weight(1f).height(86.dp).clip(RoundedCornerShape(12.dp)).background(CardBg)
                        .border(1.dp, GoldD, RoundedCornerShape(12.dp)).clickable { go(f.key) }.padding(4.dp),
                        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                        Text(f.icon, fontSize = 26.sp)
                        T(f.title, 11, Color.White, al = TextAlign.Center)
                    }
                }
            }
        }
    }
}

class Kind(val title: String, val name: String, val weight: String?, val amount: Boolean, val note: String)

val kinds = mapOf(
    "purchase" to Kind("خریداری کا ریکارڈ", "سپلائر کا نام", "وزن (گرام)", true, "تفصیل"),
    "sale" to Kind("فروخت کا ریکارڈ", "گاہک کا نام", "وزن (گرام)", true, "تفصیل"),
    "customer" to Kind("گاہکوں کا حساب", "گاہک کا نام", null, false, "فون / پتہ"),
    "worker" to Kind("کام کرنے والے افراد", "کاریگر / مزدور کا نام", null, false, "کام / فون"),
    "hours" to Kind("کام کے گھنٹے و منٹ", "کاریگر کا نام", "گھنٹے", false, "تفصیل"),
    "wage" to Kind("مزدوری کا حساب", "کاریگر کا نام", "سونے کا وزن (گرام)", true, "تفصیل"))

@Composable
fun EntryScreen(type: String) {
    val k = kinds[type] ?: return
    var dlg by remember { mutableStateOf(false) }
    val list = Store.entries.filter { it.type == type }.sortedByDescending { it.id }
    Page(k.title) {
        Button(onClick = { dlg = true }, modifier = Modifier.fillMaxWidth()) { Text("➕ نیا اندراج") }
        if (k.amount) T("کل: " + money(list.sumOf { it.amount }), 16, Gold, true)
        if (k.weight != null && type != "hours") T("کل وزن: " + "%.2f".format(list.sumOf { it.weight }) + " گرام", 14)
        if (type == "hours") T("کل گھنٹے: " + "%.1f".format(list.sumOf { it.weight }), 14)
        LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            items(list, key = { it.id }) { e ->
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(CardBg).padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        T(e.name, 16, Color.White, true)
                        T(e.date + (if (k.weight != null) "  •  ${"%.2f".format(e.weight)}" else "") +
                                (if (k.amount) "  •  ${money(e.amount)}" else "") +
                                (if (type == "wage") "  •  ادا: ${money(e.paid)}  •  بقایا: ${money(e.amount - e.paid)}" else ""), 12, Color.LightGray)
                        if (e.note.isNotBlank()) T(e.note, 12, Color.Gray)
                    }
                    Text("🗑", fontSize = 22.sp, modifier = Modifier.clickable { Store.entries.remove(e); Store.save() })
                }
            }
        }
    }
    if (dlg) AddDialog(type, k) { dlg = false }
}

@Composable
fun F(label: String, v: String, numb: Boolean = false, on: (String) -> Unit) =
    OutlinedTextField(v, on, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        keyboardOptions = KeyboardOptions(keyboardType = if (numb) KeyboardType.Decimal else KeyboardType.Text))

@Composable
fun AddDialog(type: String, k: Kind, close: () -> Unit) {
    var n by remember { mutableStateOf("") }
    var w by remember { mutableStateOf("") }
    var a by remember { mutableStateOf("") }
    var t by remember { mutableStateOf("") }
    var pd by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text(k.title) },
        confirmButton = {
            TextButton(onClick = {
                if (n.isNotBlank()) {
                    Store.entries.add(Entry(System.currentTimeMillis(), type, n.trim(), num(w), num(a), t.trim(), LocalDate.now().toString(), paid = if (type == "wage") num(pd) else 0.0))
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                F(k.name, n) { n = it }
                k.weight?.let { lbl -> F(lbl, w, true) { w = it } }
                if (k.amount) F(if (type == "wage") "مزدوری کی رقم (Rs.)" else "رقم (Rs.)", a, true) { a = it }
                if (type == "wage") F("ادا شدہ رقم (Rs.)", pd, true) { pd = it }
                F(k.note, t) { t = it }
            }
        })
}

@Composable
fun StockScreen() {
    val g = stockG(); val rate = num(Store.prefs["rate"] ?: "0")
    Page("سونے کا اسٹاک") {
        T("موجودہ وزن: ${"%.2f".format(g)} گرام", 20, Gold, true)
        T("یعنی ${"%.3f".format(g / TOLA)} تولہ", 16)
        T("اندازاً قیمت: " + money(g / TOLA * rate), 18, Color.White, true)
        T("کل خریداری: ${"%.2f".format(Store.entries.filter { it.type == "purchase" }.sumOf { it.weight })} گرام", 14, Color.LightGray)
        T("کل فروخت: ${"%.2f".format(Store.entries.filter { it.type == "sale" }.sumOf { it.weight })} گرام", 14, Color.LightGray)
        T("ابتدائی اسٹاک سیٹنگز میں تبدیل کریں۔", 12, Color.Gray)
    }
}
