package com.msf.goldrecord

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

val puItems = listOf("سونا 24 قیراط", "سونا 22 قیراط", "سونا 21 قیراط", "سونا 18 قیراط", "چاندی", "دیگر")
private val puW = listOf(46, 92, 116, 116, 70, 76, 96, 78, 92, 132)
private const val PU_ALL_FROM = "2000-01-01"
private const val PU_ALL_TO = "2100-12-31"

fun puCat(k: String): String = when {
    k.contains("چاندی") -> "چاندی"
    k.isBlank() || k.contains("قیراط") || k.contains("سونا") -> "سونا"
    else -> "دیگر"
}

private fun puItem(k: String): String = when {
    k.isBlank() -> "سونا 24 قیراط"
    k.contains("قیراط") && !k.contains("سونا") -> "سونا $k"
    else -> k
}

private fun puBill(e: Entry): String {
    if (e.bill.isNotBlank()) return e.bill
    val i = Store.entries.filter { it.type == "purchase" }.sortedBy { it.id }.indexOfFirst { it.id == e.id } + 1
    return "#%03d".format(i)
}

private fun puNextBill(): String {
    val mx = Store.entries.filter { it.type == "purchase" }.maxOfOrNull { puBill(it).filter { c -> c.isDigit() }.toIntOrNull() ?: 0 } ?: 0
    return "#%03d".format(mx + 1)
}

private fun puText(e: Entry): String =
    "${Store.prefs["shop"]}\nخریداری رسید ${puBill(e)}\nتاریخ: ${fmtD(e.date)}\nسپلائر: ${e.name}\nموبائل: ${e.phone}\n" +
            "آئٹم: ${puItem(e.karat)}\nوزن: ${fmtW(e.weight)} گرام\nفی گرام ریٹ: ${mny(e.rate)}\nکل قیمت: ${money(e.amount)}\n" +
            "ادائیگی: ${money(e.paid)}\nبقایا: ${money(e.amount - e.paid)}\n${e.note}\nشکریہ"

@Composable
private fun PuSum(icon: String, label: String, value: String, m: Modifier) {
    Row(m.clip(RoundedCornerShape(10.dp)).background(Color(0xFFE8F1FB)).border(1.dp, Color(0xFFBBD3EE), RoundedCornerShape(10.dp)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 22.sp)
        Spacer(Modifier.width(6.dp))
        Column {
            T(label, 11, Color.DarkGray)
            T(value, 12, Color.Black, true)
        }
    }
}

@Composable
fun PurchaseScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    var from by remember { mutableStateOf(today.withDayOfMonth(1).toString()) }
    var to by remember { mutableStateOf(today.toString()) }
    var q by remember { mutableStateOf("") }
    var cat by remember { mutableStateOf("تمام") }
    var sup by remember { mutableStateOf("تمام سپلائرز") }
    var rangeMenu by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }
    var pay by remember { mutableStateOf<Entry?>(null) }
    val sel = remember { mutableStateListOf<Long>() }

    val all = Store.entries.filter { it.type == "purchase" }
    val inRange = all.filter { it.date >= from && it.date <= to }
    val rows = inRange.filter {
        (cat == "تمام" || puCat(it.karat) == cat) &&
                (sup == "تمام سپلائرز" || it.name == sup) &&
                (q.isBlank() || it.name.contains(q) || puItem(it.karat).contains(q) || puBill(it).contains(q) ||
                        it.date.contains(q) || fmtD(it.date).contains(q) || it.phone.contains(q))
    }.sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
    val todayList = all.filter { it.date == today.toString() }
    val picked = rows.filter { sel.contains(it.id) }
    val rangeLbl = if (from == PU_ALL_FROM) "تمام ریکارڈ" else "${fmtD(from)} تا ${fmtD(to)}"
    val suppliers = listOf("تمام سپلائرز") + all.map { it.name }.distinct()

    Column(Modifier.fillMaxSize().background(Light)) {
        MsfHeader("🛒", "خریداری", "خریداری کا ریکارڈ", "روزانہ کی خریداری کا مکمل حساب اور ریکارڈ")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            MsfNav("purchase", listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "کاریگر"), Triple("purchase", "🛍", "خریداری"),
                Triple("sale", "🛒", "فروخت"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")), go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SCard("🛒", "آج کی خریداری", money(todayList.sumOf { it.amount }), "(${todayList.size} آئٹم)", 0xFF1B7A3A, Modifier.weight(1f))
                    SCard("🪙", "کل خریداری", money(inRange.sumOf { it.amount }), "(${inRange.size} آئٹم)", 0xFF1565C0, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SCard("📦", "مجموعی وزن", fmtW(inRange.sumOf { it.weight }) + " گرام", "", 0xFF6A1B9A, Modifier.weight(1f))
                    SCard("💰", "کل رقم", money(inRange.sumOf { it.amount }), "(بقایا: ${money(inRange.sumOf { it.amount - it.paid })})", 0xFFEF6C00, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    LF(q, Modifier.weight(1f), ph = "🔍 نام، چیز، تاریخ یا بل نمبر...") { q = it }
                    Box(Modifier.width(150.dp)) {
                        Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp)).clickable { rangeMenu = true }.padding(horizontal = 6.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                            T("📅 $rangeLbl", 10, Color.Black, true, Modifier.weight(1f)); T("▾", 14, Color.Black)
                        }
                        DropdownMenu(expanded = rangeMenu, onDismissRequest = { rangeMenu = false }) {
                            DropdownMenuItem(text = { Text("اس ماہ") }, onClick = { from = today.withDayOfMonth(1).toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("آج") }, onClick = { from = today.toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("آخری 7 دن") }, onClick = { from = today.minusDays(6).toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("اس سال") }, onClick = { from = today.withDayOfYear(1).toString(); to = today.toString(); rangeMenu = false })
                            DropdownMenuItem(text = { Text("تمام ریکارڈ") }, onClick = { from = PU_ALL_FROM; to = PU_ALL_TO; rangeMenu = false })
                            DropdownMenuItem(text = { Text("تاریخ منتخب کریں") }, onClick = {
                                rangeMenu = false
                                pickDate(ctx, if (from == PU_ALL_FROM) today.toString() else from) { f ->
                                    pickDate(ctx, if (to == PU_ALL_TO) today.toString() else to) { t ->
                                        if (f <= t) { from = f; to = t } else { from = t; to = f }
                                    }
                                }
                            })
                        }
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MChip("تمام", Color(0xFF1B7A3A), cat == "تمام") { cat = "تمام" }
                    MChip("🪙 سونا", Color(0xFF1565C0), cat == "سونا") { cat = "سونا" }
                    MChip("چاندی", Color(0xFFC62828), cat == "چاندی") { cat = "چاندی" }
                    MChip("دیگر", Color(0xFF6A1B9A), cat == "دیگر") { cat = "دیگر" }
                    Drop(sup, suppliers, Modifier.width(170.dp)) { sup = it }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFD5E3F0), RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("🛒 خریداری کا ریکارڈ", 17, Color.Black, true, Modifier.weight(1f))
                        Btn("＋ نئی خریداری درج کریں", Color(0xFF1B7A3A), Modifier.width(150.dp)) { editing = null; dlg = true }
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        Row(Modifier.background(GreenD).padding(vertical = 10.dp)) {
                            listOf("نمبر", "تاریخ", "سپلائر کا نام", "آئٹم / چیز", "وزن (گرام)", "فی گرام", "کل قیمت", "ادائیگی", "تفصیل", "عمل")
                                .forEachIndexed { i, h -> Cell(h, puW[i], Color.White, true) }
                        }
                        rows.forEachIndexed { i, e ->
                            val on = sel.contains(e.id)
                            val ok = e.paid >= e.amount
                            Row(Modifier.background(if (on) Color(0xFFFFF3C4) else if (i % 2 == 0) Color.White else Color(0xFFF3F6F9))
                                .clickable { if (on) sel.remove(e.id) else sel.add(e.id) }.padding(vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically) {
                                Cell(if (on) "✔" else (i + 1).toString(), puW[0], if (on) GreenM else Color.Black, on)
                                Cell(fmtD(e.date), puW[1]); Cell(e.name, puW[2]); Cell(puItem(e.karat), puW[3])
                                Cell(fmtW(e.weight), puW[4]); Cell(mny(e.rate), puW[5]); Cell("Rs. " + mny(e.amount), puW[6])
                                Box(Modifier.width(puW[7].dp), contentAlignment = Alignment.Center) {
                                    Text(if (ok) "ادا" else "بقایا", color = Color.White, fontSize = 11.sp, modifier = Modifier.clip(RoundedCornerShape(12.dp))
                                        .background(if (ok) Color(0xFF2E7D32) else Color(0xFFD32F2F))
                                        .clickable { if (!ok) pay = e }.padding(horizontal = 14.dp, vertical = 4.dp))
                                }
                                Cell("بل نمبر " + puBill(e), puW[8])
                                Row(Modifier.width(puW[9].dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Act("👁", Color(0xFF2E7D32)) { view = e }
                                    Act("✏️", Color(0xFF1565C0)) { editing = e; dlg = true }
                                    Act("🗑", Color(0xFFC62828)) { del = e }
                                }
                            }
                        }
                        if (rows.isEmpty()) T("اس مدت میں کوئی خریداری نہیں", 13, Color.Gray, m = Modifier.padding(16.dp))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("☑ سب منتخب کریں", Color(0xFF1565C0), Modifier.weight(1f)) { rows.forEach { if (!sel.contains(it.id)) sel.add(it.id) } }
                    Btn("✖ انتخاب صاف کریں", Color(0xFFC62828), Modifier.weight(1f)) { sel.clear() }
                    Btn("📤 فہرست شیئر کریں", Color(0xFF6A1B9A), Modifier.weight(1f)) {
                        val src = if (picked.isEmpty()) rows else picked
                        share(ctx, "تاریخ,سپلائر,آئٹم,وزن,فی گرام,کل قیمت,ادا شدہ,بل نمبر\n" +
                                src.joinToString("\n") { listOf(fmtD(it.date), it.name, puItem(it.karat), fmtW(it.weight), mny(it.rate), mny(it.amount), mny(it.paid), puBill(it)).joinToString(",") })
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PuSum("📋", "منتخب خریداری", "${picked.size} آئٹم   ${money(picked.sumOf { it.amount })}", Modifier.weight(1.3f))
                    PuSum("🪙", "کل وزن", fmtW(picked.sumOf { it.weight }) + " گرام", Modifier.weight(1f))
                    PuSum("💰", "کل رقم", money(picked.sumOf { it.amount }), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (dlg) PuDialog(editing) { dlg = false; editing = null }
    view?.let { e ->
        AlertDialog(onDismissRequest = { view = null }, title = { Text(e.name + "  " + puBill(e)) },
            text = { Text(puText(e)) },
            confirmButton = { TextButton(onClick = { share(ctx, puText(e)) }) { Text("📤 شیئر / پرنٹ") } },
            dismissButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } })
    }
    pay?.let { e ->
        AlertDialog(onDismissRequest = { pay = null }, title = { Text("بقایا رقم ادا کریں") },
            text = { Text("${e.name} کی ${puBill(e)} کی بقایا رقم ${money(e.amount - e.paid)} مکمل ادا کر دیں؟") },
            confirmButton = {
                TextButton(onClick = {
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e.copy(paid = e.amount)
                    Store.save(); pay = null
                }) { Text("ہاں، ادا ہو گئی") }
            },
            dismissButton = { TextButton(onClick = { pay = null }) { Text("منسوخ") } })
    }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("خریداری حذف کریں") },
            text = { Text("${e.name} کی ${puBill(e)} (${money(e.amount)}) حذف کر دیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); sel.remove(e.id); Store.save(); del = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
}

@Composable
private fun PuDialog(init: Entry?, close: () -> Unit) {
    val ctx = LocalContext.current
    var d by remember { mutableStateOf(init?.date ?: LocalDate.now().toString()) }
    var n by remember { mutableStateOf(init?.name ?: "") }
    var ph by remember { mutableStateOf(init?.phone ?: "") }
    var item by remember { mutableStateOf(init?.let { puItem(it.karat) } ?: puItems[0]) }
    var w by remember { mutableStateOf(init?.let { fmtW(it.weight) } ?: "") }
    var r by remember { mutableStateOf(if (init == null || init.rate == 0.0) "" else fmtW(init.rate)) }
    var pd by remember { mutableStateOf(init?.let { fmtW(it.paid) } ?: "") }
    var bill by remember { mutableStateOf(init?.let { puBill(it) } ?: puNextBill()) }
    var nt by remember { mutableStateOf(init?.note ?: "") }
    var err by remember { mutableStateOf("") }
    val total = num(w) * num(r)
    val names = Store.entries.filter { it.type == "customer" || it.type == "purchase" }.map { it.name }.distinct()
    AlertDialog(onDismissRequest = close, title = { Text(if (init == null) "نئی خریداری درج کریں" else "خریداری ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (n.isBlank() || num(w) <= 0) err = "سپلائر کا نام اور وزن درج کریں ⚠️" else {
                    val base = init ?: Entry(id = System.currentTimeMillis(), type = "purchase", name = "", weight = 0.0, amount = 0.0,
                        note = "", date = d)
                    val e = base.copy(name = n.trim(), weight = num(w), amount = total, note = nt.trim(), date = d, karat = item,
                        rate = num(r), paid = num(pd), phone = ph.trim(), bill = bill.trim().ifBlank { puNextBill() })
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { pickDate(ctx, d) { d = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("📅 تاریخ", 13, Color.LightGray); T(fmtD(d), 14, Color.White, true)
                }
                F("سپلائر کا نام", n) { n = it }
                if (names.isNotEmpty()) Drop("▾ موجودہ نام منتخب کریں", names) { n = it }
                F("موبائل نمبر", ph) { ph = it }
                Drop(item, puItems) { item = it }
                F("وزن (گرام)", w, true) { w = it }
                F("فی گرام ریٹ (Rs.)", r, true) { r = it }
                T("کل قیمت: " + money(total), 15, Gold, true)
                F("ادا شدہ رقم (Rs.)", pd, true) { pd = it }
                TextButton(onClick = { pd = fmtW(total) }) { Text("✔ مکمل رقم ادا") }
                T("بقایا: " + money(total - num(pd)), 13, Color(0xFFEF9A9A), true)
                F("بل نمبر", bill) { bill = it }
                F("نوٹ / تفصیل", nt) { nt = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}
