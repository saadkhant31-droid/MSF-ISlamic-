package com.msf.goldrecord

import android.app.DatePickerDialog
import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val RxGreen = Color(0xFF1E8E3E)
private val RxBlue = Color(0xFF1976D2)
private val RxPurple = Color(0xFF7B1FA2)
private val RxTeal = Color(0xFF00897B)
private val RxOrange = Color(0xFFF59E0B)
private val RxRed = Color(0xFFE53935)
private val RxLine = Color(0xFFDDE5DE)
private val RxInk = Color(0xFF1B3A1F)

private val rxMonths = listOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
    "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")
private val rxKinds = listOf("خریداری", "فروخت", "ادائیگی")
private val rxCats = listOf("سامان", "سونا", "مزدوری", "بل / کرایہ", "دیگر")

private class Rc(val e: Entry, val no: String, val kind: String, val cat: String, val detail: String, val manual: Boolean) {
    val amount get() = e.amount
    val paid get() = e.paid
    val date get() = e.date
    val rest get() = Math.max(0.0, e.amount - e.paid)
    val state get() = if (e.amount <= 0.0 || e.paid >= e.amount) "ادا ہو چکی" else if (e.paid > 0.0) "جزوی ادائیگی" else "بقایا ہے"
}

private fun rxRows(): List<Rc> = Store.entries.mapNotNull { e ->
    val no = if (e.bill.isNotBlank()) e.bill else "R-" + e.date.take(4) + "-" + (e.id % 1000).toString().padStart(3, '0')
    val d = (e.name + (if (e.note.isBlank()) "" else " - " + e.note)).trim()
    when (e.type) {
        "sale" -> Rc(e, no, "فروخت", "سونا", d, false)
        "purchase" -> Rc(e, no, "خریداری", puCat(e.karat), d, false)
        "wage" -> Rc(e, no, "ادائیگی", "مزدوری", d, false)
        "receipt" -> Rc(e, no, e.status.ifBlank { "ادائیگی" }, e.karat.ifBlank { "دیگر" }, d, true)
        else -> null
    }
}.sortedWith(compareByDescending<Rc> { it.date }.thenByDescending { it.e.id })

private fun rxNext(): String {
    val y = LocalDate.now().year
    var n = Store.entries.count { it.type == "receipt" } + 1
    while (Store.entries.any { it.bill == "R-" + y + "-" + n.toString().padStart(3, '0') }) n++
    return "R-" + y + "-" + n.toString().padStart(3, '0')
}

private fun rxPickRange(ctx: Context, a: LocalDate, b: LocalDate, done: (LocalDate, LocalDate) -> Unit) {
    DatePickerDialog(ctx, { _, y, m, d ->
        val f = LocalDate.of(y, m + 1, d)
        DatePickerDialog(ctx, { _, y2, m2, d2 ->
            val t = LocalDate.of(y2, m2 + 1, d2)
            if (t.isBefore(f)) done(t, f) else done(f, t)
        }, b.year, b.monthValue - 1, b.dayOfMonth).apply { setTitle("آخری تاریخ"); show() }
    }, a.year, a.monthValue - 1, a.dayOfMonth).apply { setTitle("شروع کی تاریخ"); show() }
}

private fun rxShareText(r: Rc) = (Store.prefs["shop"] ?: "") + "\nرسید نمبر: " + r.no + "\nتاریخ: " + fmtD(r.date) +
    "\nقسم: " + r.kind + "\nزمرہ: " + r.cat + "\nتفصیل: " + r.detail + "\nکل رقم: " + money(r.amount) +
    "\nادا شدہ: " + money(r.paid) + "\nبقایا: " + money(r.rest) + "\nحالت: " + r.state + "\nشکریہ"

// ───────────────────────── Main screen ─────────────────────────

@Composable
fun Receipts(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val all = rxRows()
    val today = LocalDate.now()
    var q by remember { mutableStateOf("") }
    var kind by remember { mutableStateOf("تمام رسیدیں") }
    var cat by remember { mutableStateOf("تمام زمرے") }
    var from by remember { mutableStateOf(today.withDayOfMonth(1)) }
    var to by remember { mutableStateOf(today) }
    var allDates by remember { mutableStateOf(false) }
    var due by remember { mutableStateOf(false) }
    var lim by remember { mutableStateOf(10) }
    var dateMenu by remember { mutableStateOf(false) }
    var catMenu by remember { mutableStateOf(false) }
    var newForm by remember { mutableStateOf(false) }
    var editRc by remember { mutableStateOf<Rc?>(null) }
    var viewRc by remember { mutableStateOf<Rc?>(null) }
    var delRc by remember { mutableStateOf<Rc?>(null) }

    fun setRange(m: String) {
        val t = LocalDate.now()
        allDates = false
        when (m) {
            "آج" -> { from = t; to = t }
            "ہفتہ" -> { from = t.minusDays(6); to = t }
            "ماہ" -> { from = t.withDayOfMonth(1); to = t }
            "سال" -> { from = t.withDayOfYear(1); to = t }
            else -> allDates = true
        }
        lim = 10
    }

    val ds = from.toString()
    val de = to.toString()
    val rows = all.filter { r ->
        (allDates || (r.date >= ds && r.date <= de)) &&
            (kind == "تمام رسیدیں" || r.kind == kind) &&
            (cat == "تمام زمرے" || r.cat == cat) &&
            (!due || r.rest > 0.0) &&
            (q.isBlank() || (r.no + " " + r.detail + " " + r.kind + " " + r.cat).contains(q.trim(), ignoreCase = true))
    }
    val td = today.toString()
    val ym = td.take(7)
    val todayRows = all.filter { it.date == td }
    val monthRows = all.filter { it.date.startsWith(ym) }
    val cats = all.map { it.cat }.distinct()

    Column(Modifier.fillMaxSize().background(RcBody)) {
        MsfHeader2("🧾", "🧾", "Receipts", "رسیدیں", "تمام رسیدوں کا آسان اور منظم ریکارڈ",
            listOf("بکنگ", "خریداری", "ادائیگی", "روزمرہ معاملات"))
        MsfNav("receipts", listOf(Triple("settings", "⚙️", "سیٹنگز"), Triple("reports", "📊", "رپورٹس"),
            Triple("wage", "💵", "ادائیگی"), Triple("purchase", "🛒", "خریداری"),
            Triple("receipts", "🧾", "رسیدیں"), Triple("home", "🏠", "ہوم"))) { go(it) }

        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // چار کارڈ
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                GradCard("📅", "اس ماہ کی رسیدیں", monthRows.size.toString(), "", Color.White,
                    "(" + rxMonths[today.monthValue - 1] + " " + today.year + ")", Color(0xFFF08A1C), Color(0xFFC25E00), Modifier.weight(1f)) { setRange("ماہ") }
                GradCard("✅", "آج کی رسیدیں", todayRows.size.toString(), "", Color.White,
                    "(آج کی تاریخ)", Color(0xFF9C27B0), Color(0xFF5E1A8A), Modifier.weight(1f)) { setRange("آج") }
                GradCard("👛", "کل رقم", money(all.sumOf { it.amount }), "", Color.White,
                    "(مجموعی رقم)", Color(0xFF1E88E5), Color(0xFF0D47A1), Modifier.weight(1f)) { setRange("تمام") }
                GradCard("📄", "کل رسیدیں", all.size.toString(), "", Color.White,
                    "(تمام اقسام)", Color(0xFF2EA043), Color(0xFF0E6B2E), Modifier.weight(1f)) { setRange("تمام"); kind = "تمام رسیدیں"; cat = "تمام زمرے"; q = ""; due = false }
            }

            // تاریخ + تلاش
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(150.dp)) {
                    Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(10.dp)).background(Color.White)
                        .border(1.dp, RxLine, RoundedCornerShape(10.dp)).clickable { dateMenu = true }.padding(horizontal = 8.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("📅", fontSize = 15.sp)
                        if (allDates) T("تمام تاریخیں", 12, Color.Black, true, Modifier.weight(1f))
                        else Column(Modifier.weight(1f)) {
                            T(fmtD(ds), 10, Color.Black, true)
                            T(fmtD(de), 10, Color.Black, true)
                        }
                        T("▾", 13, Color.Black)
                    }
                    DropdownMenu(expanded = dateMenu, onDismissRequest = { dateMenu = false }) {
                        listOf("آج", "ہفتہ", "ماہ", "سال", "تمام").forEach { m ->
                            DropdownMenuItem(text = { Text(if (m == "تمام") "تمام تاریخیں" else m) }, onClick = { dateMenu = false; setRange(m) })
                        }
                        DropdownMenuItem(text = { Text("مرضی کی تاریخیں…") }, onClick = {
                            dateMenu = false
                            rxPickRange(ctx, from, to) { a, b -> from = a; to = b; allDates = false; lim = 10 }
                        })
                    }
                }
                LF(q, Modifier.weight(1f), ph = "رسید نمبر، نام یا تفصیل سے تلاش کریں…") { q = it; lim = 10 }
            }

            // فلٹر
            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                Box(Modifier.weight(1.15f)) {
                    val sel = cat != "تمام زمرے"
                    Row(Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(8.dp)).background(if (sel) RxGreen else Color.White)
                        .border(1.dp, if (sel) RxGreen else RxLine, RoundedCornerShape(8.dp)).clickable { catMenu = true }.padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.Center) {
                        Text("🔻", fontSize = 11.sp); Spacer(Modifier.width(3.dp))
                        T(cat, 11, if (sel) Color.White else Color.DarkGray, true)
                    }
                    DropdownMenu(expanded = catMenu, onDismissRequest = { catMenu = false }) {
                        (listOf("تمام زمرے") + cats).forEach { c ->
                            DropdownMenuItem(text = { Text(c) }, onClick = { cat = c; catMenu = false; lim = 10 })
                        }
                    }
                }
                listOf("ادائیگی", "فروخت", "خریداری", "تمام رسیدیں").forEach { k ->
                    val sel = kind == k
                    Box(Modifier.weight(if (k == "تمام رسیدیں") 1.15f else 1f).height(40.dp).clip(RoundedCornerShape(8.dp))
                        .background(if (sel) RxGreen else Color.White).border(1.dp, if (sel) RxGreen else RxLine, RoundedCornerShape(8.dp))
                        .clickable { kind = k; lim = 10 }, contentAlignment = Alignment.Center) {
                        T(k, 11, if (sel) Color.White else Color.DarkGray, true)
                    }
                }
            }

            // فہرست کا ہیڈر
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(GreenD).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text("📄", fontSize = 20.sp)
                Spacer(Modifier.width(6.dp))
                T("رسیدوں کی فہرست", 17, Color.White, true, Modifier.weight(1f))
                Box(Modifier.clip(RoundedCornerShape(8.dp)).background(RxGreen).border(1.dp, Color(0xFF7CCFA6), RoundedCornerShape(8.dp))
                    .clickable { newForm = true }.padding(horizontal = 10.dp, vertical = 8.dp)) { T("➕ نئی رسید بنائیں", 12, Color.White, true) }
            }

            if (due) Row(Modifier.clip(RoundedCornerShape(8.dp)).background(Color(0xFFFFF3CD)).clickable { due = false }.padding(horizontal = 10.dp, vertical = 6.dp)) {
                T("صرف بقایا رسیدیں دکھائی جا رہی ہیں  ✕", 12, Color(0xFF7A5B00), true)
            }

            // ٹیبل
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color.White).border(1.dp, RxLine, RoundedCornerShape(8.dp))
                .horizontalScroll(rememberScrollState())) {
                Row(Modifier.width(548.dp).background(GreenD).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RxC("#", 24, Color.White, true); RxC("تاریخ", 62, Color.White, true); RxC("رسید نمبر", 72, Color.White, true)
                    RxC("قسم", 58, Color.White, true); RxC("تفصیل", 96, Color.White, true); RxC("رقم", 66, Color.White, true)
                    RxC("ادائیگی کی حالت", 84, Color.White, true); RxC("ایکشن", 86, Color.White, true)
                }
                rows.take(lim).forEachIndexed { ix, r ->
                    Row(Modifier.width(548.dp).background(if (ix % 2 == 0) Color.White else Color(0xFFF7FAF8)).padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        RxC((ix + 1).toString(), 24)
                        RxC(fmtD(r.date), 62)
                        RxC(r.no, 72)
                        Box(Modifier.width(58.dp), contentAlignment = Alignment.Center) {
                            RxPill(r.kind, when (r.kind) { "خریداری" -> RxBlue; "فروخت" -> RxPurple; else -> RxTeal })
                        }
                        RxC(r.detail, 96)
                        RxC("Rs. " + mny(r.amount), 66)
                        Box(Modifier.width(84.dp), contentAlignment = Alignment.Center) {
                            RxPill(r.state, when (r.state) { "ادا ہو چکی" -> RxGreen; "جزوی ادائیگی" -> RxOrange; else -> RxRed })
                        }
                        Row(Modifier.width(86.dp), horizontalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterHorizontally)) {
                            RxAct("👁", RxGreen) { viewRc = r }
                            RxAct("✏️", RxBlue) {
                                if (r.manual) editRc = r else go(when (r.e.type) { "sale" -> "sale"; "purchase" -> "purchase"; else -> "wage" })
                            }
                            RxAct("🗑", RxRed) { delRc = r }
                        }
                    }
                    Box(Modifier.width(548.dp).height(1.dp).background(RxLine))
                }
            }
            if (rows.isEmpty()) T("کوئی رسید نہیں ملی۔ «نئی رسید بنائیں» دبائیں۔", 13, Color.Gray, al = TextAlign.Center, m = Modifier.fillMaxWidth())
            if (rows.size > lim) Btn("مزید دکھائیں (" + (rows.size - lim) + ")", GreenM, Modifier.fillMaxWidth()) { lim += 10 }

            // نیچے کے خلاصہ کارڈ
            val pale = Color(0xFFE8F7EC)
            val bd = Color(0xFFB9E2C4)
            Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                PaleCard("📅", "اس ماہ کی کل رقم", money(monthRows.sumOf { it.amount }), "", RxGreen, pale, bd, Modifier.weight(1f)) { setRange("ماہ") }
                PaleCard("💰", "کل بقایا رقم", money(all.sumOf { it.rest }), if (due) "فلٹر فعال" else "", RxRed, pale, bd, Modifier.weight(1f)) { due = !due; lim = 10 }
                PaleCard("🛒", "آج کی رسیدیں", todayRows.size.toString(), "", RxGreen, pale, bd, Modifier.weight(1f)) { setRange("آج") }
                PaleCard("📄", "آج کی کل رقم", money(todayRows.sumOf { it.amount }), "", RxGreen, pale, bd, Modifier.weight(1f)) { setRange("آج") }
            }
            Spacer(Modifier.height(8.dp))
        }
    }

    if (newForm) RxForm(null) { newForm = false }
    editRc?.let { RxForm(it) { editRc = null } }
    viewRc?.let { r -> RxView(r, { editRc = r; viewRc = null }) { viewRc = null } }
    delRc?.let { r ->
        AlertDialog(onDismissRequest = { delRc = null }, containerColor = Color.White,
            title = { T("رسید حذف کریں؟", 18, GreenD, true) },
            text = {
                T(if (r.manual) "رسید " + r.no + " مستقل طور پر حذف ہو جائے گی۔"
                else "یہ رسید اصل ریکارڈ (" + r.kind + ") سے بنی ہے۔ حذف کرنے سے وہ ریکارڈ بھی ختم ہو جائے گا۔", 14, Color.Black)
            },
            confirmButton = {
                Btn("حذف کریں", RxRed, Modifier.width(96.dp)) {
                    Store.entries.removeAll { it.id == r.e.id }; Store.save(); delRc = null
                    Toast.makeText(ctx, "رسید حذف ہو گئی", Toast.LENGTH_SHORT).show()
                }
            },
            dismissButton = { Btn("منسوخ", Color.Gray, Modifier.width(84.dp)) { delRc = null } })
    }
}

// ───────────────────────── Pieces ─────────────────────────

@Composable
private fun RxC(s: String, w: Int, c: Color = Color.Black, b: Boolean = false) =
    T(s, 10, c, b, Modifier.width(w.dp).padding(horizontal = 3.dp), TextAlign.Center)

@Composable
private fun RxPill(t: String, c: Color) =
    Box(Modifier.clip(RoundedCornerShape(10.dp)).background(c).padding(horizontal = 6.dp, vertical = 3.dp)) { T(t, 10, Color.White, true) }

@Composable
private fun RxAct(t: String, c: Color, on: () -> Unit) =
    Box(Modifier.size(24.dp).clip(RoundedCornerShape(6.dp)).background(c).clickable(onClick = on), contentAlignment = Alignment.Center) {
        Text(t, fontSize = 12.sp)
    }

@Composable
private fun RxKV(label: String, value: String, vc: Color = Color.Black, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T(label, 13, Color(0xFF444444))
        T(value, 13, vc, bold, Modifier.padding(start = 12.dp))
    }
}

@Composable
private fun RxView(r: Rc, onEdit: () -> Unit, close: () -> Unit) {
    val ctx = LocalContext.current
    AlertDialog(onDismissRequest = close, containerColor = Color.White,
        title = { T("رسید " + r.no, 18, GreenD, true) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RxKV("تاریخ", fmtD(r.date))
                RxKV("قسم", r.kind, RxInk, true)
                RxKV("زمرہ", r.cat)
                RxKV("تفصیل", r.detail)
                RxKV("کل رقم", money(r.amount), Color.Black, true)
                RxKV("ادا شدہ", money(r.paid), RxGreen)
                RxKV("بقایا", money(r.rest), if (r.rest > 0) RxRed else RxGreen, true)
                RxKV("حالت", r.state, when (r.state) { "ادا ہو چکی" -> RxGreen; "جزوی ادائیگی" -> RxOrange; else -> RxRed }, true)
                if (r.manual && r.rest > 0.0) Btn("✅ مکمل ادا شدہ کریں", RxGreen, Modifier.fillMaxWidth()) {
                    val ix = Store.entries.indexOfFirst { it.id == r.e.id }
                    if (ix >= 0) { Store.entries[ix] = r.e.copy(paid = r.e.amount); Store.save() }
                    close()
                }
                if (r.manual) Btn("✏️ ترمیم کریں", RxBlue, Modifier.fillMaxWidth()) { onEdit() }
            }
        },
        confirmButton = { Btn("🖨 شیئر / پرنٹ", GreenM, Modifier.width(120.dp)) { share(ctx, rxShareText(r)) } },
        dismissButton = { Btn("بند کریں", Color.Gray, Modifier.width(84.dp)) { close() } })
}

@Composable
private fun RxForm(init: Rc?, close: () -> Unit) {
    val ctx = LocalContext.current
    val e0 = init?.e
    var kind by remember { mutableStateOf(init?.kind ?: "خریداری") }
    var cat by remember { mutableStateOf(init?.cat ?: rxCats[0]) }
    var party by remember { mutableStateOf(e0?.name ?: "") }
    var detail by remember { mutableStateOf(e0?.note ?: "") }
    var amt by remember { mutableStateOf(if (e0 != null && e0.amount > 0.0) fmtW(e0.amount) else "") }
    var paid by remember { mutableStateOf(if (e0 != null && e0.paid > 0.0) fmtW(e0.paid) else "") }
    var date by remember { mutableStateOf(e0?.date ?: LocalDate.now().toString()) }
    val no = remember { if (e0 != null && e0.bill.isNotBlank()) e0.bill else rxNext() }
    AlertDialog(onDismissRequest = close, containerColor = Color.White,
        title = { T(if (e0 == null) "نئی رسید بنائیں" else "رسید میں ترمیم", 18, GreenD, true) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                T("رسید نمبر: " + no, 14, RxInk, true)
                Cap("قسم")
                Drop(kind, rxKinds, Modifier.fillMaxWidth()) { kind = it }
                Cap("زمرہ")
                Drop(cat, (rxCats + cat).distinct(), Modifier.fillMaxWidth()) { cat = it }
                Cap("نام / پارٹی")
                LF(party, Modifier.fillMaxWidth()) { party = it }
                Cap("تفصیل")
                LF(detail, Modifier.fillMaxWidth()) { detail = it }
                Cap("کل رقم (Rs.)")
                LF(amt, Modifier.fillMaxWidth(), true) { amt = it }
                Cap("ادا شدہ رقم (Rs.)")
                LF(paid, Modifier.fillMaxWidth(), true) { paid = it }
                Cap("تاریخ")
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp))
                    .clickable { pickDate(ctx, date) { date = it } }.padding(14.dp)) { T("📅  " + fmtD(date), 14, Color.Black) }
            }
        },
        confirmButton = {
            Btn("محفوظ کریں", GreenM, Modifier.width(110.dp)) {
                val a = num(amt)
                if (party.isBlank() || a <= 0.0) Toast.makeText(ctx, "نام اور درست رقم لکھیں", Toast.LENGTH_SHORT).show()
                else {
                    val ne = (e0 ?: Entry(System.currentTimeMillis(), "receipt", "", 0.0, 0.0, "", date))
                        .copy(name = party.trim(), amount = a, paid = num(paid), note = detail.trim(), date = date, bill = no, status = kind, karat = cat)
                    if (e0 == null) Store.entries.add(ne) else {
                        val ix = Store.entries.indexOfFirst { it.id == e0.id }
                        if (ix >= 0) Store.entries[ix] = ne
                    }
                    Store.save(); close()
                    Toast.makeText(ctx, "رسید محفوظ ہو گئی ✅", Toast.LENGTH_SHORT).show()
                }
            }
        },
        dismissButton = { Btn("منسوخ", Color.Gray, Modifier.width(84.dp)) { close() } })
}
