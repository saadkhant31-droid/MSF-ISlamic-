package com.msf.goldrecord

import android.app.DatePickerDialog
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate
import java.time.temporal.ChronoUnit

private val RpLineC = Color(0xFFE3E3DE)
private val RpRed = Color(0xFFC62828)
private val RpGreen = Color(0xFF1E8E3E)
private val RpBlue = Color(0xFF1565C0)
private val RpOrange = Color(0xFFF59E0B)
private val RpInk = Color(0xFF1B3A1F)

private val rpMonths = listOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون",
    "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")

private class RpRng(val from: LocalDate, val to: LocalDate) {
    fun has(e: Entry): Boolean {
        val d = e.date
        return d >= from.toString() && d <= to.toString()
    }
}

private class RpWRow(val name: String, val worked: Boolean, val gold: Double, val wage: Double,
                     val paid: Double, val hours: Double, val days: Int) {
    val bal get() = wage - paid
}

private class RpStats(
    val rows: List<RpWRow>, val worked: Int, val notWorked: Int,
    val received: Double, val finished: Double,
    val wage: Double, val paid: Double, val sales: Double, val purchases: Double, val wGold: Double
) {
    val total get() = rows.size
    val diff get() = received - finished
    val balance get() = wage - paid
    val profit get() = sales - purchases - wage
}

private fun rpStats(r: RpRng): RpStats {
    val all = Store.entries.toList()
    val inR = all.filter { r.has(it) }
    val names = (all.filter { it.type == "worker" }.map { it.name.trim() } +
            all.filter { it.type == "wage" || it.type == "hours" }.map { it.name.trim() })
        .filter { it.isNotBlank() }.distinct()
    val rows = names.map { n ->
        val wg = inR.filter { it.type == "wage" && it.name.trim() == n }
        val hr = inR.filter { it.type == "hours" && it.name.trim() == n }
        RpWRow(n, wg.isNotEmpty() || hr.isNotEmpty(), wg.sumOf { it.weight }, wg.sumOf { it.amount },
            wg.sumOf { it.paid }, hr.sumOf { it.weight }, (wg + hr).map { it.date }.distinct().size)
    }
    val worked = rows.count { it.worked }
    return RpStats(rows, worked, rows.size - worked,
        inR.filter { it.type == "purchase" }.sumOf { it.weight },
        inR.filter { it.type == "sale" }.sumOf { it.weight },
        inR.filter { it.type == "wage" }.sumOf { it.amount },
        inR.filter { it.type == "wage" }.sumOf { it.paid },
        inR.filter { it.type == "sale" }.sumOf { it.amount },
        inR.filter { it.type == "purchase" }.sumOf { it.amount },
        inR.filter { it.type == "wage" }.sumOf { it.weight })
}

private fun rpNice(v: Double): Double {
    if (v <= 0.0) return 4.0
    val p = Math.pow(10.0, Math.floor(Math.log10(v)))
    val n = v / p
    val f = when { n <= 1.0 -> 1.0; n <= 2.0 -> 2.0; n <= 4.0 -> 4.0; n <= 5.0 -> 5.0; else -> 10.0 }
    return f * p
}

private fun rpK(x: Double): String = when {
    x >= 1_000_000 -> "%.1fM".format(x / 1_000_000)
    x >= 1000 -> if (x % 1000.0 == 0.0) "%.0fk".format(x / 1000) else "%.1fk".format(x / 1000)
    else -> "%.0f".format(x)
}

private fun rpType(t: String) = when (t) {
    "purchase" -> "خریداری"; "sale" -> "فروخت"; "wage" -> "مزدوری"
    "hours" -> "گھنٹے"; "stock" -> "اسٹاک"; "worker" -> "کاریگر"; "customer" -> "گاہک"; else -> t
}

// ───────────────────────── Main screen ─────────────────────────

@Composable
fun Reports(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var sub by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableStateOf("ماہ") }
    var from by remember { mutableStateOf(LocalDate.now().withDayOfMonth(1)) }
    var to by remember { mutableStateOf(LocalDate.now()) }
    BackHandler(sub != null) { sub = null }

    val rng = RpRng(from, to)
    val st = rpStats(rng)
    val rate = num(Store.prefs["rate"] ?: "0")
    val perG = rate / TOLA
    val lbl = when (mode) { "آج" -> "(آج)"; "ہفتہ" -> "(ہفتہ)"; "ماہ" -> "(ماہ)"; "سال" -> "(سال)"; else -> "(منتخب)" }
    val pf = if (mode == "آج") "آج " else ""

    fun pick(m: String) {
        val t = LocalDate.now()
        mode = m
        when (m) {
            "آج" -> { from = t; to = t }
            "ہفتہ" -> { from = t.minusDays(6); to = t }
            "ماہ" -> { from = t.withDayOfMonth(1); to = t }
            "سال" -> { from = t.withDayOfYear(1); to = t }
        }
    }

    fun pickRange() {
        val a = from
        DatePickerDialog(ctx, { _, y, m, d ->
            val f = LocalDate.of(y, m + 1, d)
            DatePickerDialog(ctx, { _, y2, m2, d2 ->
                val t2 = LocalDate.of(y2, m2 + 1, d2)
                if (t2.isBefore(f)) { from = t2; to = f } else { from = f; to = t2 }
                mode = "مرضی"
            }, to.year, to.monthValue - 1, to.dayOfMonth).apply { setTitle("آخری تاریخ"); show() }
        }, a.year, a.monthValue - 1, a.dayOfMonth).apply { setTitle("شروع کی تاریخ"); show() }
    }

    val tx = rpTx(rng)
    val days = ChronoUnit.DAYS.between(from, to).toInt() + 1
    val txP = rpTx(RpRng(from.minusDays(days.toLong()), from.minusDays(1)))
    var addDlg by remember { mutableStateOf(false) }
    var txDlg by remember { mutableStateOf<RpTx?>(null) }
    var tick by remember { mutableStateOf(0) }
    val newUi = sub == null || sub == "finance" || sub == "list" || sub == "graph"

    key(tick) {
        Column(Modifier.fillMaxSize().background(Brush.verticalGradient(if (newUi) listOf(RcBody, RcBody) else listOf(GreenD, Color(0xFF062412))))) {
            if (newUi) {
                MsfHeader2("📊", "📊", "Reports", "رپورٹس", "اپنے کاروبار کی مکمل رپورٹ ایک نظر میں",
                    listOf("آمدن", "خرچ", "منافع", "تفصیلی رپورٹس"))
                MsfNav(sub ?: "reports", listOf(Triple("settings", "⚙️", "سیٹنگز"), Triple("graph", "📈", "گراف"),
                    Triple("list", "📋", "فہرست"), Triple("finance", "👛", "مالی رپورٹ"),
                    Triple("reports", "📄", "رپورٹس"), Triple("home", "🏠", "ہوم"))) { k ->
                    when (k) { "home", "settings" -> go(k); "reports" -> sub = null; else -> sub = k }
                }
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (sub) {
                        "finance" -> RpFinance(rng, tx) { sub = it }
                        "list" -> RpListPage(tx, { addDlg = true }, { sub = it }) { txDlg = it }
                        "graph" -> RpGraph(rng, tx)
                        else -> RpMain(mode, from, to, tx, txP, { pick(it) }, { pickRange() },
                            { tick++; Toast.makeText(ctx, "ڈیٹا تازہ ہو گیا ✅", Toast.LENGTH_SHORT).show() },
                            go, { sub = it }, { addDlg = true }, { txDlg = it })
                    }
                    Spacer(Modifier.height(8.dp))
                }
            } else {
                val title = when (sub) {
                    "monthly" -> "ماہانہ رپورٹ"; "worker" -> "کاریگر کی رپورٹ"; "gold" -> "سونے کی رپورٹ"
                    "wage" -> "مزدوری کی رپورٹ"; else -> "پچھلے ریکارڈ"
                }
                Header(title, "مکمل حساب، مکمل اعتماد", { sub = null })
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                    Column(Modifier.padding(8.dp).clip(RoundedCornerShape(14.dp)).background(Color.White).padding(10.dp),
                        verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        when (sub) {
                            "monthly" -> RpMonthly(rng)
                            "worker" -> RpWorkers(rng, st, go)
                            "gold" -> RpGold(rng, st, rate, go)
                            "wage" -> RpWages(rng, st, go)
                            else -> RpHistory()
                        }
                    }
                }
            }
        }
    }
    if (addDlg) RpExpenseDialog { addDlg = false }
    txDlg?.let { RpTxDialog(it) { txDlg = null } }
}

// ───────────────────────── Pieces ─────────────────────────

@Composable
private fun RpTabs(go: (String) -> Unit) {
    val items = listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "کاریگر"), Triple("sale", "🛒", "فروخت"),
        Triple("customer", "👥", "گاہک"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز"))
    Row(Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.reversed().forEach { (k, i, l) ->
            val sel = k == "reports"
            Column(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(8.dp))
                .background(if (sel) Gold else Color(0xFF0F3A24)).border(1.dp, GoldD, RoundedCornerShape(8.dp))
                .clickable { go(k) }, horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (sel) Color.Black else Color.White, true)
            }
        }
    }
}

private class RpCardData(val icon: String, val title: String, val value: String, val sub: String,
                         val c1: Color, val c2: Color, val on: () -> Unit)

@Composable
private fun RpCard(c: RpCardData, m: Modifier) {
    Column(m.height(108.dp).clip(RoundedCornerShape(10.dp)).background(Brush.verticalGradient(listOf(c.c1, c.c2)))
        .clickable(onClick = c.on).padding(2.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(c.icon, fontSize = 22.sp)
        T(c.title, 10, Color.White, al = TextAlign.Center)
        Text(c.value, color = Color.White, fontSize = (if (c.value.length > 8) 10 else 14).sp,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, textAlign = TextAlign.Center)
        T(c.sub, 9, Color(0xFFEEEEEE), al = TextAlign.Center)
    }
}

@Composable
private fun RpBox(title: String, icon: String, m: Modifier = Modifier, right: (@Composable () -> Unit)? = null,
                  content: @Composable ColumnScope.() -> Unit) {
    Column(m.clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, RpLineC, RoundedCornerShape(12.dp)).padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(icon, fontSize = 18.sp)
                T(title, 14, RpInk, true)
            }
            right?.invoke()
        }
        content()
    }
}

@Composable
private fun RpMini(t: String, on: () -> Unit) =
    Box(Modifier.clip(RoundedCornerShape(8.dp)).background(GreenM).clickable(onClick = on)
        .padding(horizontal = 10.dp, vertical = 6.dp)) { T(t, 12, Color.White, true) }

@Composable
private fun RpLine(icon: String, label: String, value: String, vc: Color = Color.Black) {
    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 18.sp)
        Spacer(Modifier.width(8.dp))
        T(label, 13, Color(0xFF333333), false, Modifier.weight(1f))
        T(value, 13, vc, true)
    }
    Box(Modifier.fillMaxWidth().height(1.dp).background(RpLineC))
}

@Composable
private fun RpGoldCard(st: RpStats, lbl: String) {
    val vals = listOf(st.received, st.finished, Math.abs(st.diff))
    val cols = listOf(RpGreen, RpBlue, RpOrange)
    val names = listOf("سونا ملا", "تیار سونا", "فرق")
    val shown = listOf(st.received, st.finished, st.diff)
    val tot = vals.sum()
    RpBox("سونے کی تفصیلات $lbl", "🪙") {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(120.dp), contentAlignment = Alignment.Center) {
                Canvas(Modifier.fillMaxSize()) {
                    val sw = 22.dp.toPx()
                    val sz = Size(size.width - sw, size.height - sw)
                    val tl = Offset(sw / 2, sw / 2)
                    if (tot <= 0.0) {
                        drawArc(Color(0xFFDDDDDD), 0f, 360f, false, tl, sz, style = Stroke(sw))
                    } else {
                        var start = -90f
                        vals.forEachIndexed { i, v ->
                            val sweep = (v / tot * 360.0).toFloat()
                            drawArc(cols[i], start, sweep, false, tl, sz, style = Stroke(sw))
                            start += sweep
                        }
                    }
                }
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    T("کل وزن", 11, Color.DarkGray)
                    T(fmtW(st.received) + " گرام", 13, Color.Black, true)
                }
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                names.forEachIndexed { i, n ->
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Box(Modifier.size(12.dp).background(cols[i]))
                        T(n, 13, Color.Black, false, Modifier.weight(1f))
                        T(fmtW(shown[i]) + "g", 13, Color.Black, true)
                    }
                }
            }
        }
    }
}

@Composable
private fun RpWageChart(st: RpStats, lbl: String, m: Modifier) {
    val vals = listOf(st.wage, st.paid, st.balance)
    val labels = listOf("کل مزدوری", "ادا شدہ", "باقی")
    val cols = listOf(RpGreen, RpBlue, RpRed)
    val mx = rpNice(vals.maxOrNull() ?: 0.0)
    RpBox("مزدوری کی تفصیلات $lbl", "💰", m) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Column(Modifier.height(100.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                (4 downTo 0).forEach { k -> T(rpK(mx * k / 4), 8, Color.Gray) }
            }
            Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Top) {
                vals.forEachIndexed { i, v ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(Modifier.height(100.dp), contentAlignment = Alignment.BottomCenter) {
                            Box(Modifier.width(24.dp).height((Math.max(v, 0.0) / mx * 100.0).dp).background(cols[i]))
                        }
                        T(labels[i], 9, Color.DarkGray, al = TextAlign.Center)
                        T(mny(v), 9, Color.Black, true, al = TextAlign.Center)
                    }
                }
            }
        }
    }
}

@Composable
private fun RpPrice(rate: Double, perG: Double, m: Modifier, open: () -> Unit) {
    RpBox("سونے کی قیمت (آج)", "🪙", m) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFFFFF3CD))
            .border(1.dp, Color(0xFFE6C458), RoundedCornerShape(8.dp)).clickable(onClick = open).padding(8.dp)) {
            T("فی تولہ", 12, Color.DarkGray, true)
            T(money(rate), 13, Color.Black, true)
        }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFFDFF5EA))
            .border(1.dp, Color(0xFF7CCFA6), RoundedCornerShape(8.dp)).clickable(onClick = open).padding(8.dp)) {
            T("فی گرام", 12, Color.DarkGray, true)
            T(money(perG), 13, Color.Black, true)
        }
        T("ریٹ بدلنے کے لیے دبائیں", 9, Color.Gray)
    }
}

@Composable
private fun RowScope.RpCell(s: String, w: Float, c: Color = Color.Black, b: Boolean = false, sz: Int = 11) =
    T(s, sz, c, b, Modifier.weight(w), TextAlign.Center)

@Composable
private fun RpWorkerTable(st: RpStats, mode: String, go: (String) -> Unit, open: () -> Unit) {
    RpBox("کاریگروں کی رپورٹ", "👥", right = { RpMini("مکمل فہرست ◂", open) }) {
        if (st.rows.isEmpty()) {
            T("ابھی کوئی کاریگر نہیں۔ کاریگر ٹیب میں نام شامل کریں۔", 12, Color.Gray)
            RpMini("➕ کاریگر شامل کریں") { go("worker") }
        } else {
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, RpLineC, RoundedCornerShape(6.dp))) {
                Row(Modifier.fillMaxWidth().background(GreenD).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    RpCell("نمبر", 0.6f, Color.White, true, 10)
                    RpCell("نام", 1.7f, Color.White, true, 10)
                    RpCell(if (mode == "آج") "آج کا کام" else "کام", 1f, Color.White, true, 10)
                    RpCell("سونا (گ)", 1f, Color.White, true, 10)
                    RpCell("مزدوری", 1.2f, Color.White, true, 10)
                    RpCell("ادا شدہ", 1.2f, Color.White, true, 10)
                    RpCell("بقایا", 1.1f, Color.White, true, 10)
                }
                st.rows.take(5).forEachIndexed { i, w ->
                    Row(Modifier.fillMaxWidth().background(if (i % 2 == 0) Color.White else Color(0xFFFAFAF7)).padding(vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        RpCell((i + 1).toString(), 0.6f)
                        RpCell(w.name, 1.7f)
                        RpCell(if (w.worked) "ہاں" else "نہیں", 1f, if (w.worked) RpGreen else RpRed, true)
                        RpCell(fmtW(w.gold), 1f)
                        RpCell(mny(w.wage), 1.2f)
                        RpCell(mny(w.paid), 1.2f)
                        RpCell(mny(w.bal), 1.1f, if (w.bal > 0) RpRed else Color.Black)
                    }
                }
                Row(Modifier.fillMaxWidth().background(Color(0xFFFFF1CC)).padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    RpCell("", 0.6f)
                    RpCell("کل", 1.7f, Color.Black, true)
                    RpCell("", 1f)
                    RpCell(fmtW(st.wGold), 1f, Color.Black, true)
                    RpCell(mny(st.wage), 1.2f, Color.Black, true)
                    RpCell(mny(st.paid), 1.2f, Color.Black, true)
                    RpCell(mny(st.balance), 1.1f, Color.Black, true)
                }
            }
            if (st.rows.size > 5) T("باقی ${st.rows.size - 5} کاریگر دیکھنے کے لیے \"مکمل فہرست\" دبائیں", 10, Color.Gray)
        }
    }
}

// ───────────────────────── Sub reports ─────────────────────────

@Composable
private fun RpSubTop(title: String, note: String, text: String) {
    val ctx = LocalContext.current
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { T(title, 17, GreenD, true); T(note, 12, Color.Gray) }
        Btn("📤 شیئر", GreenM, Modifier.width(96.dp)) { share(ctx, text) }
    }
}

@Composable
private fun RpKV(label: String, value: String, vc: Color = Color.Black, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        T(label, 13, Color(0xFF444444))
        T(value, 13, vc, bold)
    }
}

@Composable
private fun RpCardBox(content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Light)
        .border(1.dp, RpLineC, RoundedCornerShape(10.dp)).padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) { content() }
}

private class RpMon(val m: Int, val s: Double, val p: Double, val w: Double, val sg: Double, val pg: Double, val has: Boolean) {
    val profit get() = s - p - w
}

@Composable
private fun RpMonthly(rng: RpRng) {
    var yr by remember { mutableStateOf(rng.to.year) }
    val ents = Store.entries.toList()
    val rows = (1..12).map { m ->
        val pre = "%04d-%02d".format(yr, m)
        val x = ents.filter { it.date.startsWith(pre) }
        val s = x.filter { it.type == "sale" }
        val p = x.filter { it.type == "purchase" }
        val w = x.filter { it.type == "wage" }
        RpMon(m, s.sumOf { it.amount }, p.sumOf { it.amount }, w.sumOf { it.amount },
            s.sumOf { it.weight }, p.sumOf { it.weight }, (s + p + w).isNotEmpty())
    }
    val ts = rows.sumOf { it.s }; val tp = rows.sumOf { it.p }; val tw = rows.sumOf { it.w }
    val sb = StringBuilder("${Store.prefs["shop"]}\nماہانہ رپورٹ $yr\n")
    rows.filter { it.has }.forEach {
        sb.append("\n${rpMonths[it.m - 1]}: فروخت ${money(it.s)} | خریداری ${money(it.p)} | مزدوری ${money(it.w)} | منافع ${money(it.profit)}")
    }
    sb.append("\n\nکل فروخت: ${money(ts)}\nکل خریداری: ${money(tp)}\nکل مزدوری: ${money(tw)}\nکل منافع: ${money(ts - tp - tw)}")
    RpSubTop("ماہانہ رپورٹ — مکمل حساب", "سال کے ہر مہینے کا حساب", sb.toString())
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        RpMini("◂") { yr -= 1 }
        T(yr.toString(), 18, GreenD, true)
        RpMini("▸") { yr += 1 }
    }
    RpCardBox {
        T("سال $yr کا کل", 15, GreenD, true)
        RpKV("فروخت", money(ts)); RpKV("خریداری", money(tp)); RpKV("مزدوری", money(tw))
        RpKV("منافع", money(ts - tp - tw), if (ts - tp - tw < 0) RpRed else RpGreen, true)
    }
    val shown = rows.filter { it.has }
    if (shown.isEmpty()) T("اس سال کا کوئی ریکارڈ نہیں۔", 13, Color.Gray)
    shown.forEach {
        RpCardBox {
            T(rpMonths[it.m - 1], 15, GreenD, true)
            RpKV("فروخت", money(it.s) + "  (${fmtW(it.sg)} گرام)")
            RpKV("خریداری", money(it.p) + "  (${fmtW(it.pg)} گرام)")
            RpKV("مزدوری", money(it.w))
            RpKV("منافع", money(it.profit), if (it.profit < 0) RpRed else RpGreen, true)
        }
    }
}

@Composable
private fun RpWorkers(rng: RpRng, st: RpStats, go: (String) -> Unit) {
    val period = fmtD(rng.from.toString()) + " تا " + fmtD(rng.to.toString())
    val sb = StringBuilder("${Store.prefs["shop"]}\nکاریگر کی رپورٹ ($period)\n")
    st.rows.forEachIndexed { i, w ->
        sb.append("\n${i + 1}. ${w.name} — ${if (w.worked) "کام کیا" else "کام نہیں"} | سونا ${fmtW(w.gold)}g | مزدوری ${mny(w.wage)} | ادا ${mny(w.paid)} | بقایا ${mny(w.bal)}")
    }
    sb.append("\n\nکل مزدوری: ${money(st.wage)}\nادا شدہ: ${money(st.paid)}\nبقایا: ${money(st.balance)}")
    RpSubTop("کاریگر کی رپورٹ — تفصیلی ریکارڈ", "مدت: $period", sb.toString())
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Box(Modifier.weight(1f)) { Btn("➕ کاریگر شامل کریں", GreenM, Modifier.fillMaxWidth()) { go("worker") } }
        Box(Modifier.weight(1f)) { Btn("💰 مزدوری درج کریں", RpBlue, Modifier.fillMaxWidth()) { go("wage") } }
    }
    RpCardBox {
        RpKV("کل کاریگر", st.total.toString()); RpKV("کام کرنے والے", st.worked.toString())
        RpKV("کام نہ کرنے والے", st.notWorked.toString())
        RpKV("کل مزدوری", money(st.wage)); RpKV("ادا شدہ", money(st.paid))
        RpKV("بقایا", money(st.balance), if (st.balance > 0) RpRed else Color.Black, true)
    }
    if (st.rows.isEmpty()) T("ابھی کوئی کاریگر نہیں۔", 13, Color.Gray)
    st.rows.forEach { w ->
        RpCardBox {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T(w.name, 15, GreenD, true)
                T(if (w.worked) "ہاں ✅" else "نہیں ⛔", 13, if (w.worked) RpGreen else RpRed, true)
            }
            RpKV("کام کے دن", w.days.toString())
            RpKV("کام کے گھنٹے", fmtW(w.hours))
            RpKV("سونا (گرام)", fmtW(w.gold))
            RpKV("مزدوری", money(w.wage)); RpKV("ادا شدہ", money(w.paid))
            RpKV("بقایا", money(w.bal), if (w.bal > 0) RpRed else Color.Black, true)
        }
    }
}

@Composable
private fun RpGold(rng: RpRng, st: RpStats, rate: Double, go: (String) -> Unit) {
    val perG = rate / TOLA
    val period = fmtD(rng.from.toString()) + " تا " + fmtD(rng.to.toString())
    val ents = Store.entries.filter { rng.has(it) && (it.type == "purchase" || it.type == "sale") }
    val days = ents.map { it.date }.distinct().sortedDescending()
    val stock = stockG()
    val sb = StringBuilder("${Store.prefs["shop"]}\nسونے کی رپورٹ ($period)\n")
    days.forEach { d ->
        val p = ents.filter { it.date == d && it.type == "purchase" }.sumOf { it.weight }
        val s = ents.filter { it.date == d && it.type == "sale" }.sumOf { it.weight }
        sb.append("\n${fmtD(d)}: خریداری ${fmtW(p)}g | فروخت ${fmtW(s)}g")
    }
    sb.append("\n\nسونا ملا: ${fmtW(st.received)}g\nتیار/فروخت: ${fmtW(st.finished)}g\nفرق: ${fmtW(st.diff)}g\nموجودہ اسٹاک: ${fmtW(stock)}g (${money(stock * perG)})")
    RpSubTop("سونے کی رپورٹ — وزن اور قیمت", "مدت: $period", sb.toString())
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.weight(1f)) { Btn("🛒 خریداری", RpBlue, Modifier.fillMaxWidth()) { go("purchase") } }
        Box(Modifier.weight(1f)) { Btn("🧾 فروخت", RpGreen, Modifier.fillMaxWidth()) { go("sale") } }
        Box(Modifier.weight(1f)) { Btn("🪙 اسٹاک", Color(0xFF9A7200), Modifier.fillMaxWidth()) { go("stock") } }
    }
    RpCardBox {
        RpKV("سونا ملا (خریداری)", fmtW(st.received) + " گرام")
        RpKV("تیار / فروخت", fmtW(st.finished) + " گرام")
        RpKV("فرق", fmtW(st.diff) + " گرام", Color.Black, true)
        RpKV("سونا ملا کی قیمت", money(st.received * perG))
        RpKV("موجودہ اسٹاک", fmtW(stock) + " گرام", Color.Black, true)
        RpKV("اسٹاک کی قیمت", money(stock * perG), RpGreen, true)
        RpKV("فی تولہ / فی گرام", mny(rate) + " / " + mny(perG))
    }
    if (days.isEmpty()) T("اس مدت میں خریداری یا فروخت کا ریکارڈ نہیں۔", 13, Color.Gray)
    days.forEach { d ->
        val p = ents.filter { it.date == d && it.type == "purchase" }.sumOf { it.weight }
        val s = ents.filter { it.date == d && it.type == "sale" }.sumOf { it.weight }
        RpCardBox {
            T(fmtD(d), 14, GreenD, true)
            RpKV("خریداری", fmtW(p) + " گرام"); RpKV("فروخت", fmtW(s) + " گرام")
            RpKV("قیمت (فروخت)", money(s * perG))
        }
    }
}

@Composable
private fun RpWages(rng: RpRng, st: RpStats, go: (String) -> Unit) {
    val period = fmtD(rng.from.toString()) + " تا " + fmtD(rng.to.toString())
    val list = Store.entries.filter { it.type == "wage" && rng.has(it) }
        .sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
    val sb = StringBuilder("${Store.prefs["shop"]}\nمزدوری کی رپورٹ ($period)\n")
    list.forEach { sb.append("\n${fmtD(it.date)} ${it.name}: ${mny(it.amount)} | ادا ${mny(it.paid)} | بقایا ${mny(it.amount - it.paid)}") }
    sb.append("\n\nکل: ${money(st.wage)}\nادا شدہ: ${money(st.paid)}\nبقایا: ${money(st.balance)}")
    RpSubTop("مزدوری کی رپورٹ — ادائیگیوں کا ریکارڈ", "مدت: $period", sb.toString())
    Btn("➕ نئی مزدوری درج کریں", GreenM, Modifier.fillMaxWidth()) { go("wage") }
    RpCardBox {
        RpKV("کل مزدوری", money(st.wage)); RpKV("ادا شدہ", money(st.paid))
        RpKV("بقایا", money(st.balance), if (st.balance > 0) RpRed else Color.Black, true)
    }
    if (list.isEmpty()) T("اس مدت میں مزدوری کا ریکارڈ نہیں۔", 13, Color.Gray)
    list.forEach {
        RpCardBox {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T(it.name, 15, GreenD, true); T(fmtD(it.date), 12, Color.Gray)
            }
            RpKV("مزدوری", money(it.amount)); RpKV("ادا شدہ", money(it.paid))
            RpKV("بقایا", money(it.amount - it.paid), if (it.amount - it.paid > 0) RpRed else Color.Black, true)
            if (it.weight > 0) RpKV("سونا", fmtW(it.weight) + " گرام")
            if (it.note.isNotBlank()) T(it.note, 11, Color.Gray)
        }
    }
}

@Composable
private fun RpHistory() {
    var f by remember { mutableStateOf("سب") }
    val filters = listOf("سب", "خریداری", "فروخت", "مزدوری", "کاریگر", "گاہک")
    val all = Store.entries.filter {
        when (f) {
            "سب" -> true
            "کاریگر" -> it.type == "worker" || it.type == "hours"
            else -> rpType(it.type) == f
        }
    }.sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
    fun line(e: Entry): String {
        val parts = mutableListOf(fmtD(e.date), rpType(e.type), e.name)
        if (e.weight > 0) parts.add(fmtW(e.weight) + if (e.type == "hours") " گھنٹے" else " گرام")
        if (e.amount > 0) parts.add(money(e.amount))
        return parts.joinToString(" • ")
    }
    val text = "${Store.prefs["shop"]}\nپچھلے ریکارڈ ($f)\n\n" + all.take(500).joinToString("\n") { line(it) }
    RpSubTop("پچھلے ریکارڈ — تاریخی ڈیٹا", "کل ${all.size} اندراج", text)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        filters.forEach { k ->
            val sel = f == k
            Box(Modifier.clip(RoundedCornerShape(8.dp)).background(if (sel) RpGreen else Light)
                .border(1.dp, if (sel) RpGreen else RpLineC, RoundedCornerShape(8.dp))
                .clickable { f = k }.padding(horizontal = 14.dp, vertical = 8.dp)) {
                T(k, 13, if (sel) Color.White else Color.DarkGray, true)
            }
        }
    }
    if (all.isEmpty()) T("کوئی ریکارڈ نہیں۔", 13, Color.Gray)
    all.take(150).forEach { e ->
        RpCardBox {
            T(e.name, 14, GreenD, true)
            T(line(e), 11, Color.DarkGray)
            if (e.note.isNotBlank()) T(e.note, 11, Color.Gray)
        }
    }
    if (all.size > 150) T("پہلے 150 اندراج دکھائے گئے ہیں۔ سب کے لیے شیئر دبائیں۔", 11, Color.Gray)
}

// ───────────────────────── نیا ڈیزائن: ڈیٹا ─────────────────────────

private class RpTx(val id: Long, val type: String, val date: String, val income: Boolean, val amount: Double,
                   val title: String, val cat: String, val note: String)

private val rpExpCats = listOf("بجلی / پانی", "کرایہ / بل", "دیگر اخراجات")

private fun rpTx(r: RpRng): List<RpTx> = Store.entries.filter { r.has(it) }.mapNotNull { e ->
    when (e.type) {
        "sale" -> RpTx(e.id, e.type, e.date, true, e.amount, e.name + " سے فروخت", "فروخت", e.note)
        "purchase" -> RpTx(e.id, e.type, e.date, false, e.amount, "خریداری: " + e.name, "خام مال", e.note)
        "wage" -> RpTx(e.id, e.type, e.date, false, e.amount, "مزدوری: " + e.name, "مزدوری", e.note)
        "expense" -> RpTx(e.id, e.type, e.date, false, e.amount, e.note.ifBlank { e.name },
            if (e.name in rpExpCats) e.name else "دیگر اخراجات", e.note)
        else -> null
    }
}.sortedWith(compareByDescending<RpTx> { it.date }.thenByDescending { it.id })

private fun rpInc(l: List<RpTx>) = l.filter { it.income }.sumOf { it.amount }
private fun rpExp(l: List<RpTx>) = l.filter { !it.income }.sumOf { it.amount }
private fun rpPct(c: Double, p: Double): Double = if (p == 0.0) (if (c > 0) 100.0 else 0.0) else (c - p) / Math.abs(p) * 100.0
private fun pctLine(c: Double, p: Double) = (if (c >= p) "↑ " else "↓ ") + "%.1f%%".format(Math.abs(rpPct(c, p)))
private fun pctDark(c: Double, p: Double) = if (c >= p) Color(0xFFB9F6CA) else Color(0xFFFFE082)
private fun pctPale(c: Double, p: Double) = if (c >= p) RpGreen else RpRed

private class RpBk(val label: String, val inc: Double, val exp: Double)

private fun rpBuckets(rng: RpRng, tx: List<RpTx>): List<RpBk> {
    val days = ChronoUnit.DAYS.between(rng.from, rng.to).toInt() + 1
    val n = Math.min(days, 6).coerceAtLeast(1)
    val size = Math.ceil(days / n.toDouble()).toInt().coerceAtLeast(1)
    val out = mutableListOf<RpBk>()
    var s = rng.from
    while (!s.isAfter(rng.to)) {
        val e0 = s.plusDays((size - 1).toLong())
        val e = if (e0.isAfter(rng.to)) rng.to else e0
        val a = s.toString()
        val b = e.toString()
        val part = tx.filter { it.date >= a && it.date <= b }
        out.add(RpBk(fmtD(a).take(5), rpInc(part), rpExp(part)))
        s = e.plusDays(1)
    }
    return out
}

private class RpSlice(val name: String, val v: Double, val c: Color)

private fun rpSlices(tx: List<RpTx>): List<RpSlice> {
    val names = listOf("خام مال" to RpBlue, "بجلی / پانی" to RpOrange, "مزدوری" to RpGreen,
        "کرایہ / بل" to Color(0xFF8E24AA), "دیگر اخراجات" to Color(0xFFE53935))
    return names.map { n -> RpSlice(n.first, tx.filter { !it.income && it.cat == n.first }.sumOf { it.amount }, n.second) }
}

// ───────────────────────── نیا ڈیزائن: چارٹ ─────────────────────────

@Composable
private fun RpBars(b: List<RpBk>, h: Int) {
    val mx = rpNice(b.maxOfOrNull { Math.max(it.inc, it.exp) } ?: 0.0)
    val bw = if (h > 140) 10 else 6
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column {
            Row(Modifier.fillMaxWidth().padding(bottom = 4.dp), horizontalArrangement = Arrangement.End, verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(9.dp).clip(CircleShape).background(RpGreen)); Spacer(Modifier.width(3.dp)); T("آمدن", 10, Color.DarkGray)
                Spacer(Modifier.width(10.dp))
                Box(Modifier.size(9.dp).clip(CircleShape).background(RpBlue)); Spacer(Modifier.width(3.dp)); T("خرچ", 10, Color.DarkGray)
            }
            Row(Modifier.fillMaxWidth()) {
                Column(Modifier.height(h.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                    (4 downTo 0).forEach { k -> T(rpK(mx * k / 4), 8, Color.Gray) }
                }
                Spacer(Modifier.width(4.dp))
                Column(Modifier.weight(1f)) {
                    Box(Modifier.fillMaxWidth().height(h.dp)) {
                        Canvas(Modifier.fillMaxSize()) {
                            for (k in 0..4) {
                                val y = size.height * k / 4f
                                drawLine(Color(0xFFE6E6E6), Offset(0f, y), Offset(size.width, y), 1f)
                            }
                        }
                        Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                            b.forEach { x ->
                                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                                    Box(Modifier.width(bw.dp).height((x.inc / mx * h).dp).background(RpGreen))
                                    Box(Modifier.width(bw.dp).height((x.exp / mx * h).dp).background(RpBlue))
                                }
                            }
                        }
                    }
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                        b.forEach { T(it.label, 8, Color.DarkGray) }
                    }
                }
            }
        }
    }
}

@Composable
private fun RpPie(sl: List<RpSlice>, size: Int) {
    val tot = sl.sumOf { it.v }
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            sl.forEach { s ->
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Box(Modifier.size(9.dp).clip(CircleShape).background(s.c))
                        T(s.name, 10, Color.Black, true)
                    }
                    T("Rs. " + mny(s.v) + " (" + (if (tot > 0) "%.0f".format(s.v / tot * 100) else "0") + "%)", 8, Color.DarkGray)
                }
            }
        }
        Canvas(Modifier.size(size.dp)) {
            if (tot <= 0.0) drawCircle(Color(0xFFE0E0E0)) else {
                var st = -90f
                sl.forEach { s ->
                    val sw = (s.v / tot * 360.0).toFloat()
                    drawArc(s.c, st, sw, true)
                    st += sw
                }
            }
        }
    }
}

@Composable
private fun RpLineChart(b: List<RpBk>, h: Int) {
    var acc = 0.0
    val pts = b.map { acc += it.inc - it.exp; acc }
    val lo = Math.min(0.0, pts.minOrNull() ?: 0.0)
    val hi = rpNice(Math.max(1.0, pts.maxOrNull() ?: 1.0))
    val low = if (lo < 0) -rpNice(-lo) else 0.0
    val range = hi - low
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Row(Modifier.fillMaxWidth()) {
            Column(Modifier.height(h.dp), verticalArrangement = Arrangement.SpaceBetween, horizontalAlignment = Alignment.End) {
                (4 downTo 0).forEach { k -> T(rpK(low + range * k / 4), 8, Color.Gray) }
            }
            Spacer(Modifier.width(4.dp))
            Column(Modifier.weight(1f)) {
                Canvas(Modifier.fillMaxWidth().height(h.dp)) {
                    for (k in 0..4) {
                        val y = size.height * k / 4f
                        drawLine(Color(0xFFE6E6E6), Offset(0f, y), Offset(size.width, y), 1f)
                    }
                    val n = pts.size
                    fun px(i: Int): Float = if (n <= 1) size.width / 2f else size.width * i / (n - 1).toFloat()
                    fun py(v: Double): Float = (size.height * (1.0 - (v - low) / range)).toFloat()
                    val path = Path()
                    val area = Path()
                    pts.forEachIndexed { i, v ->
                        val x = px(i)
                        val y = py(v)
                        if (i == 0) { path.moveTo(x, y); area.moveTo(x, size.height); area.lineTo(x, y) }
                        else { path.lineTo(x, y); area.lineTo(x, y) }
                    }
                    area.lineTo(px(n - 1), size.height)
                    area.close()
                    drawPath(area, RpGreen.copy(alpha = 0.15f))
                    drawPath(path, RpGreen, style = Stroke(3f))
                    pts.forEachIndexed { i, v -> drawCircle(RpGreen, 5f, Offset(px(i), py(v))) }
                }
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    b.forEach { T(it.label, 8, Color.DarkGray) }
                }
            }
        }
    }
}

// ───────────────────────── نیا ڈیزائن: ٹیبل اور صفحات ─────────────────────────

@Composable
private fun RpTxTable(tx: List<RpTx>, limit: Int, onRow: (RpTx) -> Unit) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, RpLineC, RoundedCornerShape(6.dp))) {
        Row(Modifier.fillMaxWidth().background(Color(0xFF0B3D1F)).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            RpCell("تاریخ", 1.25f, Color.White, true, 9)
            RpCell("قسم", 0.7f, Color.White, true, 9)
            RpCell("تفصیل", 1.6f, Color.White, true, 9)
            RpCell("رقم", 1.2f, Color.White, true, 9)
        }
        tx.take(limit).forEach { t ->
            Row(Modifier.fillMaxWidth().clickable { onRow(t) }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                RpCell(fmtD(t.date), 1.25f, Color.Black, false, 9)
                RpCell(if (t.income) "آمدن" else "خرچ", 0.7f, if (t.income) RpGreen else RpRed, false, 9)
                RpCell(t.title, 1.6f, Color.Black, false, 9)
                RpCell("Rs. " + mny(t.amount), 1.2f, if (t.income) RpGreen else RpRed, true, 9)
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(RpLineC))
        }
    }
}

@Composable
private fun RpMoreRow(open: (String) -> Unit) {
    val more = listOf(Triple("worker", "👷", "کاریگر رپورٹ"), Triple("gold", "🪙", "سونے کی رپورٹ"),
        Triple("wage", "💰", "مزدوری رپورٹ"), Triple("history", "📋", "پچھلے ریکارڈ"))
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        T("مزید رپورٹس", 14, RpInk, true)
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            more.forEach { (k, i, l) ->
                Column(Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(10.dp)).background(GreenD).clickable { open(k) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text(i, fontSize = 18.sp)
                    T(l, 10, Color.White, true, al = TextAlign.Center)
                }
            }
        }
    }
}

@Composable
private fun RpMain(mode: String, from: LocalDate, to: LocalDate, tx: List<RpTx>, txP: List<RpTx>,
                   onPick: (String) -> Unit, onRange: () -> Unit, refresh: () -> Unit, go: (String) -> Unit,
                   setSub: (String) -> Unit, addExp: () -> Unit, onRow: (RpTx) -> Unit) {
    var menu by remember { mutableStateOf(false) }
    val i = rpInc(tx); val x = rpExp(tx); val pi = rpInc(txP); val px = rpExp(txP)
    val b = rpBuckets(RpRng(from, to), tx)
    val ref = "پچھلی مدت کے مقابلے میں"

    // تاریخ + تازہ کریں
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Row(Modifier.clip(RoundedCornerShape(10.dp)).background(GreenM).clickable { refresh() }.padding(horizontal = 12.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            T("تازہ کریں", 13, Color.White, true); Text("🔄", fontSize = 16.sp)
        }
        Box(Modifier.weight(1f)) {
            Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, RpLineC, RoundedCornerShape(10.dp))
                .clickable { menu = true }.padding(horizontal = 10.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("📅", fontSize = 16.sp)
                T(fmtD(from.toString()) + "  تا  " + fmtD(to.toString()), 12, Color.Black, true, Modifier.weight(1f))
                T("▾", 14, Color.Black)
            }
            DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                listOf("آج", "ہفتہ", "ماہ", "سال").forEach { m ->
                    DropdownMenuItem(text = { Text(m) }, onClick = { menu = false; onPick(m) })
                }
                DropdownMenuItem(text = { Text("مرضی کی تاریخیں…") }, onClick = { menu = false; onRange() })
            }
        }
    }

    // چار رنگین کارڈ
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        GradCard("📄", "کل لین دین", tx.size.toString(), pctLine(tx.size.toDouble(), txP.size.toDouble()),
            pctDark(tx.size.toDouble(), txP.size.toDouble()), ref, Color(0xFFEF5350), Color(0xFFC62828), Modifier.weight(1f)) { setSub("list") }
        GradCard("📈", "خالص منافع", money(i - x), pctLine(i - x, pi - px), pctDark(i - x, pi - px), ref,
            Color(0xFFAB47BC), Color(0xFF6A1B9A), Modifier.weight(1f)) { setSub("finance") }
        GradCard("👛", "کل خرچ", money(x), pctLine(x, px), pctDark(x, px), ref,
            Color(0xFF1E88E5), Color(0xFF0D47A1), Modifier.weight(1f)) { go("purchase") }
        GradCard("🪙", "کل آمدن", money(i), pctLine(i, pi), pctDark(i, pi), ref,
            Color(0xFF2EA043), Color(0xFF0E6B2E), Modifier.weight(1f)) { go("sale") }
    }

    // خرچ کی تقسیم + آمدن و خرچ کا گراف
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RpBox("خرچ کی تقسیم", "🥧", Modifier.weight(1f), right = { RpMini("➕ خرچ") { addExp() } }) { RpPie(rpSlices(tx), 78) }
        RpBox("آمدن و خرچ کا گراف", "📊", Modifier.weight(1f).clickable { setSub("graph") }) { RpBars(b, 120) }
    }

    // منافع کا رجحان + ٹرانزیکشنز
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        RpBox("منافع کا رجحان", "📈", Modifier.weight(1f).clickable { setSub("graph") }) { RpLineChart(b, 120) }
        RpBox(if (mode == "آج") "آج کی ٹرانزیکشنز" else "حالیہ ٹرانزیکشنز", "📋", Modifier.weight(1f),
            right = { RpMini("مزید ◂") { setSub("list") } }) {
            if (tx.isEmpty()) T("کوئی لین دین نہیں", 11, Color.Gray) else RpTxTable(tx, 5, onRow)
        }
    }

    // نیچے کے چار خلاصہ کارڈ
    val sa = rpInc(tx); val saP = rpInc(txP)
    val pu = tx.filter { it.type == "purchase" }.sumOf { it.amount }
    val puP = txP.filter { it.type == "purchase" }.sumOf { it.amount }
    val wg = tx.filter { it.type == "wage" }.sumOf { it.amount }
    val wgP = txP.filter { it.type == "wage" }.sumOf { it.amount }
    val cust = Store.entries.filter { it.type == "customer" }
    val pr = RpRng(from.minusDays((ChronoUnit.DAYS.between(from, to).toInt() + 1).toLong()), from.minusDays(1))
    val rg = RpRng(from, to)
    val newC = cust.count { rg.has(it) }.toDouble()
    val newCP = cust.count { pr.has(it) }.toDouble()
    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
        PaleCard("👷", "کل مزدوری", money(wg), pctLine(wg, wgP), pctPale(wg, wgP), Color(0xFFFDF1E3), Color(0xFFF2D3A8), Modifier.weight(1f)) { go("wage") }
        PaleCard("👤", "کل گاہک", cust.size.toString(), pctLine(newC, newCP), pctPale(newC, newCP), Color(0xFFEFE9F8), Color(0xFFD0C2EA), Modifier.weight(1f)) { go("customer") }
        PaleCard("🛒", "کل خریداری", money(pu), pctLine(pu, puP), pctPale(pu, puP), Color(0xFFE7F1FB), Color(0xFFBBD6F0), Modifier.weight(1f)) { go("purchase") }
        PaleCard("📈", "کل فروخت", money(sa), pctLine(sa, saP), pctPale(sa, saP), Color(0xFFE8F7EC), Color(0xFFB9E2C4), Modifier.weight(1f)) { go("sale") }
    }

    RpMoreRow(setSub)
}

@Composable
private fun RpGraph(rng: RpRng, tx: List<RpTx>) {
    val b = rpBuckets(rng, tx)
    RpBox("آمدن و خرچ کا گراف", "📊") { RpBars(b, 170) }
    RpBox("خرچ کی تقسیم", "🥧") { RpPie(rpSlices(tx), 140) }
    RpBox("منافع کا رجحان", "📈") { RpLineChart(b, 170) }
}

@Composable
private fun RpFinance(rng: RpRng, tx: List<RpTx>, open: (String) -> Unit) {
    val i = rpInc(tx); val x = rpExp(tx); val p = i - x
    val sl = rpSlices(tx)
    val inR = Store.entries.filter { rng.has(it) }
    fun amt(t: String) = inR.filter { it.type == t }.sumOf { it.amount }
    fun pd(t: String) = inR.filter { it.type == t }.sumOf { it.paid }
    val period = fmtD(rng.from.toString()) + " تا " + fmtD(rng.to.toString())
    val lines = listOf("کل آمدن: " + money(i), "کل خرچ: " + money(x), "خالص منافع: " + money(p)) +
        sl.map { it.name + ": " + money(it.v) }
    val text = (Store.prefs["shop"] ?: "") + "\nمالی رپورٹ (" + period + ")\n\n" + lines.joinToString("\n")
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        RpSubTop("مالی رپورٹ", period, text)
        RpCardBox {
            RpKV("کل آمدن", money(i), RpGreen, true)
            RpKV("کل خرچ", money(x), RpRed, true)
            RpKV("خالص منافع", money(p), if (p < 0) RpRed else RpGreen, true)
        }
        T("خرچ کی تقسیم", 14, RpInk, true)
        RpCardBox { sl.forEach { RpKV(it.name, money(it.v)) } }
        T("وصولی اور ادائیگی", 14, RpInk, true)
        RpCardBox {
            RpKV("فروخت کی کل رقم", money(amt("sale")))
            RpKV("وصول شدہ", money(pd("sale")), RpGreen)
            RpKV("باقی وصولی", money(amt("sale") - pd("sale")), RpRed, true)
        }
        RpCardBox {
            RpKV("خریداری کی کل رقم", money(amt("purchase")))
            RpKV("ادا شدہ", money(pd("purchase")), RpGreen)
            RpKV("باقی ادائیگی", money(amt("purchase") - pd("purchase")), RpRed, true)
        }
        RpCardBox {
            RpKV("مزدوری کی کل رقم", money(amt("wage")))
            RpKV("ادا شدہ", money(pd("wage")), RpGreen)
            RpKV("باقی مزدوری", money(amt("wage") - pd("wage")), RpRed, true)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Btn("📊 ماہانہ رپورٹ", GreenM, Modifier.weight(1f)) { open("monthly") }
            Btn("💰 مزدوری رپورٹ", RpBlue, Modifier.weight(1f)) { open("wage") }
            Btn("🪙 سونے کی رپورٹ", GoldD, Modifier.weight(1f)) { open("gold") }
        }
    }
}

@Composable
private fun RpListPage(tx: List<RpTx>, addExp: () -> Unit, open: (String) -> Unit, onRow: (RpTx) -> Unit) {
    var f by remember { mutableStateOf("تمام") }
    var q by remember { mutableStateOf("") }
    var lim by remember { mutableStateOf(30) }
    val rows = tx.filter { (f == "تمام" || (f == "آمدن") == it.income) && (q.isBlank() || (it.title + it.note + it.cat).contains(q.trim())) }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            T("فہرست — " + rows.size + " اندراج", 15, RpInk, true, Modifier.weight(1f))
            RpMini("➕ خرچ شامل کریں") { addExp() }
        }
        LF(q, Modifier.fillMaxWidth(), ph = "تلاش کریں…") { q = it; lim = 30 }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("تمام", "آمدن", "خرچ").forEach { k ->
                val sel = f == k
                Box(Modifier.weight(1f).clip(RoundedCornerShape(8.dp)).background(if (sel) RpGreen else Light)
                    .border(1.dp, if (sel) RpGreen else RpLineC, RoundedCornerShape(8.dp))
                    .clickable { f = k; lim = 30 }.padding(vertical = 10.dp), contentAlignment = Alignment.Center) {
                    T(k, 13, if (sel) Color.White else Color.DarkGray, true)
                }
            }
        }
        if (rows.isEmpty()) T("کوئی لین دین نہیں۔", 13, Color.Gray) else RpTxTable(rows, lim, onRow)
        if (rows.size > lim) Btn("مزید دکھائیں (" + (rows.size - lim) + ")", GreenM, Modifier.fillMaxWidth()) { lim += 30 }
        RpMoreRow(open)
    }
}

// ───────────────────────── نیا ڈیزائن: ڈائیلاگ ─────────────────────────

@Composable
private fun RpExpenseDialog(close: () -> Unit) {
    val ctx = LocalContext.current
    var cat by remember { mutableStateOf(rpExpCats[0]) }
    var amt by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    AlertDialog(onDismissRequest = close, containerColor = Color.White,
        title = { T("خرچ شامل کریں", 18, GreenD, true) },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Cap("زمرہ")
                Drop(cat, rpExpCats, Modifier.fillMaxWidth()) { cat = it }
                Cap("رقم (Rs.)")
                LF(amt, Modifier.fillMaxWidth(), true) { amt = it }
                Cap("تفصیل")
                LF(note, Modifier.fillMaxWidth()) { note = it }
                Cap("تاریخ")
                Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(4.dp)).border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp))
                    .clickable { pickDate(ctx, date) { date = it } }.padding(14.dp)) { T("📅  " + fmtD(date), 14, Color.Black) }
            }
        },
        confirmButton = {
            Btn("محفوظ کریں", GreenM, Modifier.width(110.dp)) {
                if (num(amt) <= 0.0) Toast.makeText(ctx, "درست رقم لکھیں", Toast.LENGTH_SHORT).show()
                else {
                    Store.entries.add(Entry(System.currentTimeMillis(), "expense", cat, 0.0, num(amt), note.trim(), date))
                    Store.save(); close()
                }
            }
        },
        dismissButton = { Btn("منسوخ", Color.Gray, Modifier.width(80.dp)) { close() } })
}

@Composable
private fun RpTxDialog(t: RpTx, close: () -> Unit) {
    val ctx = LocalContext.current
    val kind = if (t.income) "آمدن" else "خرچ (" + t.cat + ")"
    AlertDialog(onDismissRequest = close, containerColor = Color.White,
        title = { T(t.title, 17, GreenD, true) },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                RpKV("تاریخ", fmtD(t.date))
                RpKV("قسم", kind, if (t.income) RpGreen else RpRed, true)
                RpKV("رقم", money(t.amount), Color.Black, true)
                if (t.note.isNotBlank()) RpKV("تفصیل", t.note)
                if (t.type == "expense") Btn("🗑 حذف کریں", RpRed, Modifier.fillMaxWidth()) {
                    Store.entries.removeAll { it.id == t.id }; Store.save(); close()
                }
            }
        },
        confirmButton = {
            Btn("📤 شیئر", GreenM, Modifier.width(96.dp)) {
                share(ctx, (Store.prefs["shop"] ?: "") + "\n" + t.title + "\nتاریخ: " + fmtD(t.date) + "\n" + kind + "\nرقم: " + money(t.amount))
            }
        },
        dismissButton = { Btn("بند کریں", Color.Gray, Modifier.width(90.dp)) { close() } })
}
