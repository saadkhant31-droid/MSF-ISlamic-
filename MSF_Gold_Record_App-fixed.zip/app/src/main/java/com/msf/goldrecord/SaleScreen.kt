package com.msf.goldrecord

import androidx.compose.foundation.*
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

val goldItems = listOf("سونے کی انگوٹھی", "بالیاں", "ہار", "بازو بند", "ہار سیٹ", "چین", "کڑا", "بریسلٹ", "سونے کی ڈلی", "دیگر")
val statuses = listOf("نقد", "ادھار", "بقایا")
val saleW = listOf(36, 92, 100, 92, 56, 72, 84, 84, 70, 120)

fun statusOf(e: Entry) = if (e.status.isNotBlank()) e.status else if (e.paid >= e.amount) "نقد" else "بقایا"
fun statusColor(s: String) = when (s) { "نقد" -> Color(0xFF2E7D32); "ادھار" -> Color(0xFF1565C0); else -> Color(0xFFC62828) }

fun profitAll(): Double {
    val pu = Store.entries.filter { it.type == "purchase" }
    val pw = pu.sumOf { it.weight }
    val avg = if (pw > 0) pu.sumOf { it.amount } / pw else 0.0
    val sa = Store.entries.filter { it.type == "sale" }
    return sa.sumOf { it.amount } - sa.sumOf { it.weight } * avg
}

@Composable
fun SCard(icon: String, title: String, value: String, sub: String, bg: Long, m: Modifier) {
    Row(m.height(78.dp).clip(RoundedCornerShape(10.dp)).background(Color(bg)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 30.sp)
        Spacer(Modifier.width(8.dp))
        Column {
            T(title, 12, Color.White)
            T(value, 15, Color.White, true)
            if (sub.isNotEmpty()) T(sub, 11, Color(0xFFE0E0E0))
        }
    }
}


private val suW = listOf(44, 92, 116, 124, 72, 76, 104, 84, 132)
private val suPie = listOf(0xFF1E88E5, 0xFF2E9E4F, 0xFFFB8C00, 0xFF8E24AA, 0xFFE53935)
private const val SU_ALL_FROM = "2000-01-01"
private const val SU_ALL_TO = "2100-12-31"

fun suPay(e: Entry): String = when { e.paid >= e.amount -> "ادا"; e.paid > 0 -> "جزوی"; else -> "بقایا" }
private fun suPayColor(s: String) = when (s) { "ادا" -> Color(0xFF2E7D32); "جزوی" -> Color(0xFFEF6C00); else -> Color(0xFFD32F2F) }
private fun suK(v: Double): String = when { v >= 1000000 -> "%.1fM".format(v / 1000000); v >= 1000 -> "${(v / 1000).toInt()}K"; else -> v.toInt().toString() }
private fun suTop(mx: Double): Double {
    var p = 1.0
    while (p * 10 <= mx) p *= 10
    for (s in listOf(1.0, 2.0, 2.5, 5.0, 10.0)) if (s * p >= mx) return s * p
    return 10 * p
}
private fun suText(e: Entry): String =
    "${Store.prefs["shop"]}\nفروخت رسید\nتاریخ: ${fmtD(e.date)}\nگاہک: ${e.name}\nآئٹم: ${e.karat}\nوزن: ${fmtW(e.weight)} گرام\n" +
            "فی گرام ریٹ: ${mny(e.rate)}\nکل قیمت: ${money(e.amount)}\nوصول: ${money(e.paid)}\nبقایا: ${money(e.amount - e.paid)}\n" +
            "حالت: ${suPay(e)}\n${e.note}\nشکریہ"

@Composable
private fun SuStat(icon: String, title: String, value: String, sub: String, bg: Long, m: Modifier) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(Color(bg)).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 24.sp)
        T(title, 11, Color.White, true, al = TextAlign.Center)
        T(value, 14, Color.White, true, al = TextAlign.Center)
        T(sub, 10, Color(0xFFE0E0E0), al = TextAlign.Center)
    }
}

@Composable
private fun SuBars(days: List<LocalDate>, vals: List<Double>) {
    val top = suTop((vals.maxOrNull() ?: 0.0).coerceAtLeast(1.0))
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().height(150.dp)) {
                Column(Modifier.fillMaxHeight().padding(end = 4.dp), verticalArrangement = Arrangement.SpaceBetween) {
                    listOf(top, top * 0.75, top * 0.5, top * 0.25, 0.0).forEach { T(suK(it), 9, Color.DarkGray) }
                }
                Canvas(Modifier.weight(1f).fillMaxHeight()) {
                    val n = vals.size
                    if (n > 0) {
                        val bw = size.width / n
                        vals.forEachIndexed { i, v ->
                            val h = (v / top).toFloat() * size.height
                            drawRect(Color(0xFF1B7A3A), topLeft = Offset(i * bw + bw * 0.2f, size.height - h), size = Size(bw * 0.6f, h))
                        }
                    }
                }
            }
            if (days.isNotEmpty()) {
                val f = { d: LocalDate -> "%02d-%02d".format(d.dayOfMonth, d.monthValue) }
                Row(Modifier.fillMaxWidth().padding(start = 28.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T(f(days.first()), 10, Color.DarkGray); T(f(days[days.size / 2]), 10, Color.DarkGray); T(f(days.last()), 10, Color.DarkGray)
                }
            }
        }
    }
}

@Composable
private fun SuPieBox(rows: List<Entry>) {
    val groups = rows.groupBy { it.karat.ifBlank { "دیگر" } }.map { it.key to it.value.sumOf { x -> x.amount } }.sortedByDescending { it.second }
    val slices = if (groups.size > 5) groups.take(4) + ("دیگر" to groups.drop(4).sumOf { it.second }) else groups
    val tot = slices.sumOf { it.second }
    if (tot <= 0) { T("ڈیٹا موجود نہیں", 13, Color.Gray, m = Modifier.padding(16.dp)); return }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Canvas(Modifier.size(120.dp)) {
            var start = -90f
            slices.forEachIndexed { i, s ->
                val sw = (s.second / tot * 360).toFloat()
                drawArc(color = Color(suPie[i % suPie.size]), startAngle = start, sweepAngle = sw, useCenter = true)
                start += sw
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            slices.forEachIndexed { i, s ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(suPie[i % suPie.size])))
                    Spacer(Modifier.width(6.dp))
                    T(s.first, 12, Color.Black, m = Modifier.weight(1f))
                    T("%.0f%%".format(s.second / tot * 100), 12, Color.Black, true)
                }
            }
        }
    }
}

@Composable
private fun SuSum(icon: String, label: String, value: String, m: Modifier) {
    Row(m.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(icon, fontSize = 24.sp)
        Spacer(Modifier.width(6.dp))
        Column { T(label, 11, Color.DarkGray); T(value, 13, Color.Black, true) }
    }
}

@Composable
fun SaleScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now()
    val td = today.toString()
    var from by remember { mutableStateOf(today.withDayOfMonth(1).toString()) }
    var to by remember { mutableStateOf(td) }
    var mode by remember { mutableStateOf("اس مہینے") }
    var q by remember { mutableStateOf("") }
    var custF by remember { mutableStateOf("تمام گاہک") }
    var payF by remember { mutableStateOf("سب") }
    var dlg by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }
    var pay by remember { mutableStateOf<Entry?>(null) }
    var delAll by remember { mutableStateOf(false) }
    var newCust by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }

    fun setRange(m: String, f: String, t: String) { mode = m; from = f; to = t }

    val all = Store.entries.filter { it.type == "sale" }
    val inRange = all.filter { it.date >= from && it.date <= to }
    val rows = inRange.filter {
        (custF == "تمام گاہک" || it.name == custF) && (payF == "سب" || suPay(it) == payF) &&
                (q.isBlank() || it.name.contains(q) || it.karat.contains(q) || it.date.contains(q) ||
                        fmtD(it.date).contains(q) || it.id.toString().endsWith(q))
    }.sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
    val total = rows.sumOf { it.amount }
    val custCount = rows.map { it.name }.distinct().size
    val rangeLbl = if (from == SU_ALL_FROM) "تمام ریکارڈ" else "${fmtD(from)} تا ${fmtD(to)}"
    val sub = "(" + (if (mode == "آج") "آج" else "اس مدت") + ")"
    val names = (Store.entries.filter { it.type == "customer" }.map { it.name } + all.map { it.name }).distinct()
    val endD = if (from == SU_ALL_FROM || to > td) today else LocalDate.parse(to)
    val startD = (if (from == SU_ALL_FROM) endD.minusDays(15) else LocalDate.parse(from)).let { if (it.isBefore(endD.minusDays(15))) endD.minusDays(15) else it }
    val days = generateSequence(startD) { it.plusDays(1) }.takeWhile { !it.isAfter(endD) }.toList()
    val dayVals = days.map { d -> rows.filter { it.date == d.toString() }.sumOf { it.amount } }

    Column(Modifier.fillMaxSize().background(Light)) {
        MsfHeader("🛒", "فروخت کا ریکارڈ", "آپ کے کاروبار کی فروخت کا مکمل ریکارڈ", "آج کی فروخت، کل کی ترقی")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            MsfNav("sale", listOf(Triple("home", "🏠", "ہوم"), Triple("customer", "👥", "گاہک"), Triple("sale", "🛒", "فروخت"),
                Triple("stock", "🪙", "اسٹاک"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")), go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SuStat("💰", "کل فروخت", money(total), sub, 0xFF1B7A3A, Modifier.weight(1f))
                    SuStat("🧾", "کل آرڈرز", rows.size.toString(), sub, 0xFF1565C0, Modifier.weight(1f))
                    SuStat("👤", "کل گاہک", custCount.toString(), sub, 0xFF6A1B9A, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    SuStat("⚖️", "فروخت شدہ وزن", fmtW(rows.sumOf { it.weight }) + " گرام", sub, 0xFFEF6C00, Modifier.weight(1f))
                    SuStat("📈", "اوسط آرڈر ویلیو", money(if (rows.isEmpty()) 0.0 else total / rows.size), sub, 0xFFC62828, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    LF(q, Modifier.weight(1f), ph = "🔍 گاہک کا نام، آئٹم یا نمبر...") { q = it }
                    Row(Modifier.width(150.dp).height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp)).clickable {
                            pickDate(ctx, if (from == SU_ALL_FROM) td else from) { f ->
                                pickDate(ctx, if (to == SU_ALL_TO) td else to) { t -> if (f <= t) setRange("custom", f, t) else setRange("custom", t, f) }
                            }
                        }.padding(horizontal = 6.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        T("📅 $rangeLbl", 10, Color.Black, true, Modifier.weight(1f)); T("▾", 14, Color.Black)
                    }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    MChip("تمام فروخت", Color(0xFF1B7A3A), mode == "تمام") { setRange("تمام", SU_ALL_FROM, SU_ALL_TO) }
                    MChip("آج", Color(0xFF455A64), mode == "آج") { setRange("آج", td, td) }
                    MChip("اس ہفتے", Color(0xFF1565C0), mode == "اس ہفتے") { setRange("اس ہفتے", today.minusDays((today.dayOfWeek.value - 1).toLong()).toString(), td) }
                    MChip("اس مہینے", Color(0xFF6A1B9A), mode == "اس مہینے") { setRange("اس مہینے", today.withDayOfMonth(1).toString(), td) }
                    Drop(if (custF == "تمام گاہک") "👤 گاہک کے حساب سے" else custF, listOf("تمام گاہک") + names, Modifier.width(180.dp)) { custF = it }
                    Drop(if (payF == "سب") "🔽 فلٹر" else payF, listOf("سب", "ادا", "جزوی", "بقایا"), Modifier.width(120.dp)) { payF = it }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    T("📊 فروخت کا گراف (Rs.)", 15, Color.Black, true)
                    SuBars(days, dayVals)
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp)).padding(10.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    T("🥧 فروخت شدہ آئٹمز کی تقسیم", 15, Color.Black, true)
                    SuPieBox(rows)
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, Color(0xFFE0E0E0), RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(GreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("🛒 فروخت کی تفصیل", 17, Color.White, true, Modifier.weight(1f))
                        Btn("＋ نئی فروخت درج کریں", Color(0xFF1B7A3A), Modifier.width(150.dp)) { editing = null; dlg = true }
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        Row(Modifier.background(GreenD).padding(vertical = 10.dp)) {
                            listOf("#", "تاریخ", "گاہک کا نام", "آئٹم", "وزن (گرام)", "فی گرام", "کل رقم", "ادائیگی کی حالت", "ایکشن")
                                .forEachIndexed { i, h -> Cell(h, suW[i], Color.White, true) }
                        }
                        rows.forEachIndexed { i, e ->
                            val st = suPay(e)
                            Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF3F6F9)).padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                                Cell((i + 1).toString(), suW[0]); Cell(fmtD(e.date), suW[1]); Cell(e.name, suW[2]); Cell(e.karat, suW[3])
                                Cell(fmtW(e.weight), suW[4]); Cell(mny(e.rate), suW[5]); Cell("Rs. " + mny(e.amount), suW[6])
                                Box(Modifier.width(suW[7].dp), contentAlignment = Alignment.Center) {
                                    Text(st, color = Color.White, fontSize = 11.sp, textAlign = TextAlign.Center,
                                        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(suPayColor(st))
                                            .clickable { if (st != "ادا") pay = e }.padding(horizontal = 14.dp, vertical = 4.dp))
                                }
                                Row(Modifier.width(suW[8].dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                    Act("👁", Color(0xFF2E7D32)) { view = e }
                                    Act("✏️", Color(0xFF1565C0)) { editing = e; dlg = true }
                                    Act("🗑", Color(0xFFC62828)) { del = e }
                                }
                            }
                        }
                        if (rows.isEmpty()) T("اس مدت میں کوئی فروخت نہیں", 13, Color.Gray, m = Modifier.padding(16.dp))
                    }
                    Row(Modifier.fillMaxWidth().background(Color(0xFFFBF3D6)).padding(vertical = 8.dp)) {
                        SuSum("🪙", "کل رقم", money(total), Modifier.weight(1.3f))
                        SuSum("📦", "کل آرڈرز", rows.size.toString(), Modifier.weight(1f))
                        SuSum("👤", "کل گاہک", custCount.toString(), Modifier.weight(1f))
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("👤 گاہک شامل کریں", Color(0xFF6A1B9A), Modifier.weight(1f)) { newCust = true }
                    Btn("📤 فہرست شیئر کریں", Color(0xFF1565C0), Modifier.weight(1f)) {
                        share(ctx, "تاریخ,گاہک,آئٹم,وزن,فی گرام,کل رقم,وصول,حالت\n" +
                                rows.joinToString("\n") { listOf(fmtD(it.date), it.name, it.karat, fmtW(it.weight), mny(it.rate), mny(it.amount), mny(it.paid), suPay(it)).joinToString(",") })
                    }
                    Btn("🗑 فہرست حذف کریں", Color(0xFFC62828), Modifier.weight(1f)) { delAll = true }
                }
                if (msg.isNotEmpty()) T(msg, 13, GreenM, true)
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (dlg) SuDialog(editing, names) { saved -> dlg = false; editing = null; if (saved) msg = "فروخت محفوظ ہو گئی ✅" }
    view?.let { e ->
        AlertDialog(onDismissRequest = { view = null }, title = { Text(e.name) }, text = { Text(suText(e)) },
            confirmButton = { TextButton(onClick = { share(ctx, suText(e)) }) { Text("🧾 رسید شیئر") } },
            dismissButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } })
    }
    pay?.let { e ->
        AlertDialog(onDismissRequest = { pay = null }, title = { Text("بقایا وصول کریں") },
            text = { Text("${e.name} سے بقایا ${money(e.amount - e.paid)} مکمل وصول ہو گئے؟") },
            confirmButton = {
                TextButton(onClick = {
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e.copy(paid = e.amount)
                    Store.save(); pay = null
                }) { Text("ہاں، وصول ہو گئے") }
            },
            dismissButton = { TextButton(onClick = { pay = null }) { Text("منسوخ") } })
    }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("فروخت حذف کریں") },
            text = { Text("${e.name} کی ${money(e.amount)} کی فروخت حذف کر دیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); Store.save(); del = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
    if (delAll) {
        AlertDialog(onDismissRequest = { delAll = false }, title = { Text("فروخت حذف کریں") },
            text = { Text("موجودہ فہرست کے ${rows.size} ریکارڈ حذف ہو جائیں گے۔ کیا آپ یقین رکھتے ہیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.removeAll(rows.toSet()); Store.save(); delAll = false }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { delAll = false }) { Text("منسوخ") } })
    }
    if (newCust) {
        var cn by remember { mutableStateOf("") }
        var cp by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newCust = false }, title = { Text("نیا گاہک") },
            confirmButton = {
                TextButton(onClick = {
                    if (cn.isNotBlank()) {
                        Store.entries.add(Entry(id = System.currentTimeMillis(), type = "customer", name = cn.trim(), weight = 0.0, amount = 0.0,
                            note = "", date = LocalDate.now().toString(), phone = cp.trim(), status = "فعال"))
                        Store.save(); newCust = false
                    }
                }) { Text("محفوظ کریں") }
            },
            dismissButton = { TextButton(onClick = { newCust = false }) { Text("منسوخ") } },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    F("گاہک کا نام", cn) { cn = it }
                    F("موبائل نمبر", cp) { cp = it }
                }
            })
    }
}

@Composable
private fun SuDialog(init: Entry?, names: List<String>, close: (Boolean) -> Unit) {
    val ctx = LocalContext.current
    var d by remember { mutableStateOf(init?.date ?: LocalDate.now().toString()) }
    var n by remember { mutableStateOf(init?.name ?: "") }
    var item by remember { mutableStateOf(init?.karat?.ifBlank { goldItems[0] } ?: goldItems[0]) }
    var w by remember { mutableStateOf(init?.let { fmtW(it.weight) } ?: "") }
    var r by remember { mutableStateOf(if (init == null || init.rate == 0.0) "" else fmtW(init.rate)) }
    var pd by remember { mutableStateOf(init?.let { fmtW(it.paid) } ?: "") }
    var nt by remember { mutableStateOf(init?.note ?: "") }
    var err by remember { mutableStateOf("") }
    val total = num(w) * num(r)
    AlertDialog(onDismissRequest = { close(false) }, title = { Text(if (init == null) "نئی فروخت درج کریں" else "فروخت ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (n.isBlank() || num(w) <= 0) err = "گاہک کا نام اور وزن درج کریں ⚠️" else {
                    val base = init ?: Entry(id = System.currentTimeMillis(), type = "sale", name = "", weight = 0.0, amount = 0.0, note = "", date = d)
                    val e = base.copy(name = n.trim(), weight = num(w), amount = total, note = nt.trim(), date = d, karat = item,
                        rate = num(r), paid = num(pd), status = "")
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    Store.save(); close(true)
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = { close(false) }) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { pickDate(ctx, d) { d = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("📅 تاریخ", 13, Color.LightGray); T(fmtD(d), 14, Color.White, true)
                }
                F("گاہک کا نام", n) { n = it }
                if (names.isNotEmpty()) Drop("▾ موجودہ گاہک منتخب کریں", names) { n = it }
                Drop(item, goldItems) { item = it }
                F("وزن (گرام)", w, true) { w = it }
                F("فی گرام قیمت (Rs.)", r, true) { r = it }
                T("کل قیمت: " + money(total), 15, Gold, true)
                F("وصول شدہ رقم (Rs.)", pd, true) { pd = it }
                TextButton(onClick = { pd = fmtW(total) }) { Text("✔ مکمل رقم وصول") }
                T("بقایا: " + money(total - num(pd)), 13, Color(0xFFEF9A9A), true)
                F("نوٹ (اختیاری)", nt) { nt = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}
