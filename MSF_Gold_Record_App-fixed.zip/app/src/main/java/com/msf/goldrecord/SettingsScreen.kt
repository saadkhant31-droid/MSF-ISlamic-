package com.msf.goldrecord

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

private fun stGet(k: String): String = Store.prefs[k] ?: ""
private fun stSet(k: String, v: String) { Store.prefs[k] = v; Store.save() }

private val StLine = Color(0xFFDDE3DD)

/** اسکرین کی چمک لاگو کریں ("auto" = سسٹم کی چمک) */
fun applyBrightness(act: Activity?) {
    if (act == null) return
    val b = Store.prefs["bright"]
    val v = if (b.isNullOrBlank() || b == "auto") -1f else (b.toFloatOrNull() ?: 0.6f).coerceIn(0.05f, 1f)
    val at = act.window.attributes
    at.screenBrightness = v
    act.window.attributes = at
}

private fun openSys(ctx: Context, action: String, pkgData: Boolean = false, extraPkg: Boolean = false) {
    try {
        val i = Intent(action)
        if (pkgData) i.data = Uri.parse("package:" + ctx.packageName)
        if (extraPkg) i.putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        ctx.startActivity(i)
    } catch (e: Exception) {
        Toast.makeText(ctx, "یہ سیٹنگ کھل نہیں سکی", Toast.LENGTH_SHORT).show()
    }
}

@Composable
private fun SPass(label: String, v: String, on: (String) -> Unit) =
    OutlinedTextField(v, on, label = { Text(label) }, singleLine = true, modifier = Modifier.fillMaxWidth(),
        visualTransformation = PasswordVisualTransformation(),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black,
            focusedContainerColor = Color.White, unfocusedContainerColor = Color.White,
            focusedBorderColor = GreenM, unfocusedBorderColor = Color(0xFFB0B0B0), cursorColor = GreenM,
            focusedLabelColor = Color.DarkGray, unfocusedLabelColor = Color.DarkGray))

// ───────────────────────── Lock / login screen ─────────────────────────

@Composable
fun LockScreen(onOpen: () -> Unit) {
    var p by remember { mutableStateOf("") }
    var err by remember { mutableStateOf("") }
    val pass = stGet("pass")
    Column(Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(GreenD, Color.Black))).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp, Alignment.CenterVertically)) {
        Image(painterResource(R.drawable.logo), null, Modifier.size(140.dp).clip(CircleShape))
        T("MSF Gold Business Record", 18, Gold, true)
        T(stGet("admin"), 16)
        if (pass.isNotEmpty()) SPass("پاس ورڈ", p) { p = it; err = "" }
        Btn(if (pass.isEmpty()) "داخل ہوں" else "کھولیں", GreenM, Modifier.fillMaxWidth()) {
            if (pass.isEmpty() || p == pass) onOpen() else err = "پاس ورڈ غلط ہے"
        }
        T(err, 13, Color(0xFFFF8A80))
    }
}

// ───────────────────────── Main settings ─────────────────────────

private class StItem(val icon: String, val c1: Color, val c2: Color, val title: String, val sub: String, val key: String)

private val stItems = listOf(
    StItem("📶", Color(0xFF29A0FF), Color(0xFF0B6BE0), "نیٹ ورک اور انٹرنیٹ", "وائی فائی، موبائل ڈیٹا، ہاٹ اسپاٹ", "network"),
    StItem("🔔", Color(0xFFB45CE6), Color(0xFF7B1FA2), "اطلاعات", "نوٹیفکیشن کی ترتیبات", "notif"),
    StItem("🔊", Color(0xFF34B866), Color(0xFF1B8A3F), "آواز اور وائبریشن", "رنگ ٹون، والیم، وائبریشن", "sound"),
    StItem("🔆", Color(0xFFFFB02E), Color(0xFFF57C00), "ڈسپلے", "چمک، ڈارک موڈ، فونٹ سائز", "display"),
    StItem("🛡️", Color(0xFF2E8BFF), Color(0xFF0B5ED7), "رازداری اور سیکیورٹی", "ایپ لاک، پاس ورڈ، ڈیٹا کی حفاظت", "privacy"),
    StItem("▦", Color(0xFF8E5CE6), Color(0xFF5E35B1), "ایپس", "ایپ مینجمنٹ، ڈیفالٹ ایپس", "apps"),
    StItem("💾", Color(0xFF26B5A5), Color(0xFF00796B), "اسٹوریج", "اسٹوریج کا استعمال اور خالی جگہ", "storage"),
    StItem("🌐", Color(0xFFF2545B), Color(0xFFD32F2F), "زبان اور کی بورڈ", "اردو / انگریزی، کی بورڈ کی ترتیبات", "lang"),
    StItem("ℹ", Color(0xFF6C7BE0), Color(0xFF3949AB), "ایپ کے بارے میں", "ورژن، لائسنس، اپ ڈیٹس", "about"))

@Composable
private fun StHeader(title: String, sub: String, back: (() -> Unit)?) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(bottomStart = 22.dp, bottomEnd = 22.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF04331A), Color(0xFF0B5A2C), Color(0xFF0A4A25))))) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(64.dp).clip(CircleShape).background(Color(0xFF0B2A17)).border(2.dp, Gold, CircleShape)
                    .then(if (back != null) Modifier.clickable { back() } else Modifier), contentAlignment = Alignment.Center) {
                    Text(if (back != null) "←" else "⚙", fontSize = 34.sp, color = Color.White)
                }
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    T(title, 30, Color.White, true, al = TextAlign.Center)
                    T(sub, 14, Color.White, al = TextAlign.Center)
                }
                Text("🌿", fontSize = 26.sp)
                Column(Modifier.width(48.dp).height(70.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFFEFF5F1))
                    .border(2.dp, Color(0xFF1B3A28), RoundedCornerShape(10.dp)).padding(7.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    repeat(3) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Box(Modifier.size(7.dp).clip(CircleShape).background(GreenM))
                            Box(Modifier.weight(1f).height(4.dp).clip(RoundedCornerShape(2.dp)).background(Color(0xFFB8C4BC)))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun SChev(dark: Boolean) = Text("›", fontSize = 28.sp, color = if (dark) Color(0xFF9DB5A5) else Color(0xFF1B3A1F))

@Composable
private fun SRow(item: StItem, dark: Boolean, on: () -> Unit, trailing: @Composable () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable(onClick = on).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(item.c1, item.c2))),
            contentAlignment = Alignment.Center) { Text(item.icon, fontSize = 24.sp, color = Color.White) }
        Column(Modifier.weight(1f)) {
            T(item.title, 17, if (dark) Color.White else Color(0xFF14261A), true, Modifier.fillMaxWidth(), TextAlign.Left)
            T(item.sub, 12, if (dark) Color(0xFF9DB5A5) else Color.Gray, false, Modifier.fillMaxWidth(), TextAlign.Left)
        }
        trailing()
    }
}

@Composable
fun SettingsScreen(go: (String) -> Unit, onLock: () -> Unit) {
    val ctx = LocalContext.current
    var page by remember { mutableStateOf<String?>(null) }
    var dlg by remember { mutableStateOf<String?>(null) }
    BackHandler(page != null) { page = null }
    val dark = stGet("theme") != "light"
    val lang = stGet("lang").ifBlank { "اردو" }
    val ver = try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0" } catch (e: Exception) { "1.0.0" }
    val cardBg = if (dark) Color(0xFF16291E) else Color.White
    val lineC = if (dark) Color(0xFF2B4636) else StLine

    Column(Modifier.fillMaxSize().background(if (dark) Color(0xFF0C1A12) else Color(0xFFF1F6F2))) {
        if (page == null) {
            StHeader("سیٹنگز", "ایپ کی ترتیبات کو اپنی مرضی کے مطابق بنائیں", null)
            CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
                Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    // پروفائل
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(if (dark) Color(0xFF123A24) else Color(0xFFE8F4EC))
                        .border(1.dp, lineC, RoundedCornerShape(16.dp)).clickable { page = "profile" }.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(62.dp).clip(CircleShape).background(Color(0xFF1E8E3E)), contentAlignment = Alignment.Center) {
                            Text("👤", fontSize = 30.sp, color = Color.White)
                        }
                        Column(Modifier.weight(1f)) {
                            T(stGet("admin").ifBlank { "ایڈمن" }, 22, if (dark) Color.White else Color(0xFF14261A), true, Modifier.fillMaxWidth(), TextAlign.Left)
                            T("پروفائل دیکھیں اور ترمیم کریں", 13, if (dark) Color(0xFF9DB5A5) else Color.DarkGray, false, Modifier.fillMaxWidth(), TextAlign.Left)
                        }
                        Row(Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFF0B6B35)).padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("›", fontSize = 22.sp, color = Color.White)
                            T("پروفائل", 15, Color.White, true)
                        }
                    }
                    // فہرست
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, lineC, RoundedCornerShape(16.dp))) {
                        stItems.forEachIndexed { idx, item ->
                            SRow(item, dark, {
                                when (item.key) {
                                    "network" -> openSys(ctx, Settings.ACTION_WIRELESS_SETTINGS)
                                    "apps" -> openSys(ctx, Settings.ACTION_APPLICATION_DETAILS_SETTINGS, pkgData = true)
                                    else -> page = item.key
                                }
                            }) {
                                if (item.key == "lang") T(lang, 14, if (dark) Color(0xFF9DB5A5) else Color.DarkGray)
                                SChev(dark)
                            }
                            if (idx < stItems.size - 1) Box(Modifier.fillMaxWidth().height(1.dp).background(lineC))
                        }
                    }
                    // ڈارک موڈ
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(cardBg).border(1.dp, lineC, RoundedCornerShape(16.dp))
                        .clickable { stSet("theme", if (dark) "light" else "dark") }.padding(horizontal = 12.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Box(Modifier.size(50.dp).clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(Color(0xFF78909C), Color(0xFF455A64)))),
                            contentAlignment = Alignment.Center) { Text("🌙", fontSize = 24.sp) }
                        Column(Modifier.weight(1f)) {
                            T("ڈارک موڈ", 17, if (dark) Color.White else Color(0xFF14261A), true, Modifier.fillMaxWidth(), TextAlign.Left)
                            T("رات کے لیے بہتر تجربہ", 12, if (dark) Color(0xFF9DB5A5) else Color.Gray, false, Modifier.fillMaxWidth(), TextAlign.Left)
                        }
                        Switch(checked = dark, onCheckedChange = { stSet("theme", if (it) "dark" else "light") },
                            colors = SwitchDefaults.colors(checkedTrackColor = GreenM, checkedThumbColor = Color.White))
                    }
                    Spacer(Modifier.height(4.dp))
                }
            }
        } else {
            val title = when (page) {
                "profile" -> "پروفائل"; "notif" -> "اطلاعات"; "sound" -> "آواز اور وائبریشن"; "display" -> "ڈسپلے"
                "privacy" -> "رازداری اور سیکیورٹی"; "storage" -> "اسٹوریج"; "lang" -> "زبان اور کی بورڈ"; else -> "ایپ کے بارے میں"
            }
            StHeader(title, "ایپ کی ترتیبات کو اپنی مرضی کے مطابق بنائیں") { page = null }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
                Column(Modifier.padding(8.dp).clip(RoundedCornerShape(14.dp)).background(Light).padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    when (page) {
                        "profile" -> AccountPage { page = null }
                        "notif" -> NotifPage()
                        "sound" -> SoundPage()
                        "display" -> DisplayPage()
                        "privacy" -> PrivacyPage(onLock) { dlg = "logout" }
                        "storage" -> StoragePage(go)
                        "lang" -> LangPage()
                        else -> AboutPage(ver)
                    }
                }
            }
        }
    }

    if (dlg == "logout") AlertDialog(onDismissRequest = { dlg = null }, title = { Text("لاگ آؤٹ") },
        text = { Text("کیا آپ واقعی لاگ آؤٹ کرنا چاہتے ہیں؟ آپ کا ڈیٹا محفوظ رہے گا۔") },
        confirmButton = { TextButton(onClick = { dlg = null; onLock() }) { Text("لاگ آؤٹ") } },
        dismissButton = { TextButton(onClick = { dlg = null }) { Text("منسوخ") } })
}

// ───────────────────────── Sub pages ─────────────────────────

@Composable
private fun AccountPage(done: () -> Unit) {
    var name by remember { mutableStateOf(stGet("admin")) }
    var phone by remember { mutableStateOf(stGet("phone")) }
    var p1 by remember { mutableStateOf("") }
    var p2 by remember { mutableStateOf("") }
    var shop by remember { mutableStateOf(stGet("shop")) }
    var rate by remember { mutableStateOf(stGet("rate")) }
    var open by remember { mutableStateOf(stGet("open")) }
    var msg by remember { mutableStateOf("") }
    T("ذاتی معلومات", 16, GreenD, true)
    Cap("صارف کا نام"); LF(name, Modifier.fillMaxWidth()) { name = it }
    Cap("موبائل نمبر"); LF(phone, Modifier.fillMaxWidth(), numb = true) { phone = it }
    Cap(if (stGet("pass").isEmpty()) "نیا پاس ورڈ (کم از کم 4 حروف)" else "نیا پاس ورڈ (خالی چھوڑیں تو پرانا رہے گا)")
    SPass("پاس ورڈ", p1) { p1 = it }
    SPass("پاس ورڈ دوبارہ لکھیں", p2) { p2 = it }
    T("کاروباری ترتیبات", 16, GreenD, true)
    Cap("دکان کا نام"); LF(shop, Modifier.fillMaxWidth()) { shop = it }
    Cap("آج سونے کا ریٹ (فی تولہ)"); LF(rate, Modifier.fillMaxWidth(), numb = true) { rate = it }
    Cap("ابتدائی اسٹاک (گرام)"); LF(open, Modifier.fillMaxWidth(), numb = true) { open = it }
    Btn("💾 محفوظ کریں", GreenM, Modifier.fillMaxWidth()) {
        if (p1.isNotEmpty() && p1.length < 4) msg = "پاس ورڈ کم از کم 4 حروف کا ہونا چاہیے"
        else if (p1 != p2) msg = "دونوں پاس ورڈ ایک جیسے نہیں ہیں"
        else {
            Store.prefs["admin"] = name.trim().ifBlank { "ایڈمن" }
            Store.prefs["phone"] = phone.trim()
            Store.prefs["shop"] = shop.trim()
            Store.prefs["rate"] = rate.trim()
            Store.prefs["open"] = open.trim()
            if (p1.isNotEmpty()) Store.prefs["pass"] = p1
            Store.save()
            msg = "محفوظ ہو گیا ✅"; p1 = ""; p2 = ""
        }
    }
    T(msg, 14, GreenM, true)
}

@Composable
private fun SSwitch(title: String, sub: String, checked: Boolean, on: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) { T(title, 15, Color(0xFF14261A), true); T(sub, 12, Color.Gray) }
        Switch(checked = checked, onCheckedChange = on,
            colors = SwitchDefaults.colors(checkedTrackColor = GreenM, checkedThumbColor = Color.White))
    }
}

@Composable
private fun PrivacyPage(onLock: () -> Unit, onLogout: () -> Unit) {
    var lock by remember { mutableStateOf(stGet("lock") == "1") }
    var msg by remember { mutableStateOf("") }
    var wipe by remember { mutableStateOf(false) }
    val hasPass = stGet("pass").isNotEmpty()
    SSwitch("ایپ لاک", "ایپ کھولتے وقت پاس ورڈ مانگیں", lock) { on ->
        if (on && !hasPass) msg = "پہلے \"پروفائل\" میں پاس ورڈ سیٹ کریں"
        else { lock = on; stSet("lock", if (on) "1" else "0"); msg = if (on) "ایپ لاک چالو ہو گیا ✅" else "ایپ لاک بند ہو گیا" }
    }
    if (hasPass) Btn("🔓 پاس ورڈ ہٹائیں", Color(0xFF9A7200), Modifier.fillMaxWidth()) {
        stSet("pass", ""); stSet("lock", "0"); lock = false; msg = "پاس ورڈ ہٹا دیا گیا"
    }
    Btn("🔒 ابھی ایپ لاک کریں", GreenM, Modifier.fillMaxWidth()) { onLock() }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp)).padding(10.dp)) {
        T("ڈیٹا کی حفاظت", 15, Color(0xFF14261A), true)
        T("آپ کا تمام ڈیٹا صرف آپ کے فون میں محفوظ ہے اور انٹرنیٹ پر نہیں بھیجا جاتا۔ کل اندراج: ${Store.entries.size}", 12, Color.Gray)
    }
    Btn("🚪 لاگ آؤٹ", RpBlueS, Modifier.fillMaxWidth()) { onLogout() }
    Btn("🗑 تمام ڈیٹا مٹائیں", Color(0xFFC62828), Modifier.fillMaxWidth()) { wipe = true }
    T(msg, 14, GreenM, true)
    if (wipe) AlertDialog(onDismissRequest = { wipe = false }, title = { Text("تمام ڈیٹا مٹائیں؟") },
        text = { Text("تمام خریداری، فروخت، کاریگر اور گاہکوں کا ریکارڈ ہمیشہ کے لیے مٹ جائے گا۔ پہلے بیک اپ ضرور لے لیں۔") },
        confirmButton = { TextButton(onClick = { Store.entries.clear(); Store.save(); wipe = false; msg = "تمام ڈیٹا مٹا دیا گیا" }) { Text("مٹا دیں") } },
        dismissButton = { TextButton(onClick = { wipe = false }) { Text("منسوخ") } })
}

@Composable
private fun NotifPage() {
    val ctx = LocalContext.current
    val items = listOf(
        Triple("n_due", "بقایا رقم کی یاد دہانی", "گاہکوں کے بقایا کی اطلاع"),
        Triple("n_daily", "روزانہ رپورٹ", "دن کے اختتام پر رپورٹ کی اطلاع"),
        Triple("n_rate", "سونے کے ریٹ کی یاد دہانی", "روزانہ ریٹ اپڈیٹ کرنے کی یاد دہانی"),
        Triple("n_backup", "بیک اپ کی یاد دہانی", "ہفتہ وار بیک اپ لینے کی یاد دہانی"))
    items.forEach { (k, t, s) ->
        var on by remember { mutableStateOf(stGet(k) != "0") }
        SSwitch(t, s, on) { on = it; stSet(k, if (it) "1" else "0") }
    }
    Btn("🔔 سسٹم نوٹیفکیشن سیٹنگز", GreenM, Modifier.fillMaxWidth()) {
        openSys(ctx, Settings.ACTION_APP_NOTIFICATION_SETTINGS, extraPkg = true)
    }
    T("آپ کی منتخب ترتیبات محفوظ ہو جاتی ہیں۔", 12, Color.Gray)
}

@Composable
private fun SoundPage() {
    val ctx = LocalContext.current
    SSwitch("بٹن کی آواز", "کیلکولیٹر کے بٹن دباتے وقت کلک آواز", stGet("snd") != "0") { stSet("snd", if (it) "1" else "0") }
    SSwitch("وائبریشن", "بٹن دبانے پر ہلکی وائبریشن", stGet("vib") != "0") { stSet("vib", if (it) "1" else "0") }
    Btn("🔊 فون کی آواز / رنگ ٹون سیٹنگز", GreenM, Modifier.fillMaxWidth()) { openSys(ctx, Settings.ACTION_SOUND_SETTINGS) }
    T("والیم اور رنگ ٹون فون کی اپنی سیٹنگز سے بدلتے ہیں۔", 12, Color.Gray)
}

@Composable
private fun DisplayPage() {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    val dark = stGet("theme") != "light"
    SSwitch("ڈارک موڈ", "رات کے لیے بہتر تجربہ", dark) { stSet("theme", if (it) "dark" else "light") }

    T("فونٹ", 16, GreenD, true)
    val curF = stGet("font").ifBlank { "jameel" }
    appFonts.forEach { (k, n, f) ->
        val sel = k == curF
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White)
            .border(if (sel) 2.dp else 1.dp, if (sel) GreenM else StLine, RoundedCornerShape(10.dp))
            .clickable { stSet("font", k) }.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(n + "  —  ۱۲۳ سونا", fontFamily = f, fontSize = 18.sp, color = Color.Black, modifier = Modifier.weight(1f))
            if (sel) Text("✔", fontSize = 18.sp, color = GreenM)
        }
    }

    T("فونٹ سائز", 16, GreenD, true)
    val curS = stGet("fscale").ifBlank { "1.0" }
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        listOf("0.9" to "چھوٹا", "1.0" to "درمیانہ", "1.15" to "بڑا", "1.3" to "بہت بڑا").forEach { (v, l) ->
            MChip(l, if (curS == v) GreenM else Color(0xFF7A8A80), curS == v, Modifier.weight(1f)) { stSet("fscale", v) }
        }
    }

    T("چمک", 16, GreenD, true)
    val b = stGet("bright")
    val auto = b.isBlank() || b == "auto"
    SSwitch("خودکار چمک", "فون کی سسٹم چمک استعمال کریں", auto) { on ->
        stSet("bright", if (on) "auto" else "0.6"); applyBrightness(act)
    }
    if (!auto) Slider(value = b.toFloatOrNull() ?: 0.6f, valueRange = 0.05f..1f,
        onValueChange = { Store.prefs["bright"] = String.format(Locale.US, "%.2f", it); applyBrightness(act) },
        onValueChangeFinished = { Store.save() },
        colors = SliderDefaults.colors(thumbColor = GreenM, activeTrackColor = GreenM))
}

private fun fmtB(b: Long): String =
    if (b >= 1_000_000_000L) String.format(Locale.US, "%.1f GB", b / 1e9) else String.format(Locale.US, "%.1f MB", b / 1e6)

@Composable
private fun StoragePage(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val st = remember {
        try { val s = android.os.StatFs(android.os.Environment.getDataDirectory().path); Pair(s.totalBytes, s.availableBytes) }
        catch (e: Exception) { Pair(0L, 0L) }
    }
    val used = (st.first - st.second).coerceAtLeast(0L)
    val frac = if (st.first > 0) (used.toFloat() / st.first.toFloat()).coerceIn(0.02f, 1f) else 0.02f
    val appKb = remember { Store.json().toByteArray().size / 1024.0 }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)) {
        T("فون کی اسٹوریج", 15, Color(0xFF14261A), true)
        Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFD5DDD7))) {
            Box(Modifier.fillMaxWidth(frac).fillMaxHeight().background(GreenM))
        }
        T("استعمال شدہ: " + fmtB(used) + "   |   خالی: " + fmtB(st.second) + "   |   کل: " + fmtB(st.first), 12, Color.DarkGray)
    }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        T("ایپ کا ڈیٹا", 15, Color(0xFF14261A), true)
        T("کل اندراج: ${Store.entries.size}", 13, Color.DarkGray)
        T("ڈیٹا کا سائز: " + String.format(Locale.US, "%.1f KB", appKb), 13, Color.DarkGray)
    }
    Btn("☁️ بیک اپ اور ریسٹور", GreenM, Modifier.fillMaxWidth()) { go("backup") }
    Btn("💾 فون کی اسٹوریج سیٹنگز", RpBlueS, Modifier.fillMaxWidth()) { openSys(ctx, Settings.ACTION_INTERNAL_STORAGE_SETTINGS) }
}

@Composable
private fun LangPage() {
    val ctx = LocalContext.current
    val lang = stGet("lang").ifBlank { "اردو" }
    T("ایپ کی زبان", 16, GreenD, true)
    listOf("اردو", "English").forEach { l ->
        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White)
            .border(if (lang == l) 2.dp else 1.dp, if (lang == l) GreenM else StLine, RoundedCornerShape(10.dp))
            .clickable {
                stSet("lang", l)
                if (l == "English") Toast.makeText(ctx, "English ترجمہ جلد شامل ہوگا، فی الحال ایپ اردو میں ہے", Toast.LENGTH_LONG).show()
            }.padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
            RadioButton(selected = lang == l, onClick = null, colors = RadioButtonDefaults.colors(selectedColor = GreenM))
            Spacer(Modifier.width(8.dp))
            T(l, 16, Color.Black, true)
        }
    }
    Btn("⌨️ کی بورڈ کی ترتیبات", GreenM, Modifier.fillMaxWidth()) { openSys(ctx, Settings.ACTION_INPUT_METHOD_SETTINGS) }
}

@Composable
private fun AboutPage(ver: String) {
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp)) {
        T("MSF Gold Business Record", 16, GreenD, true)
        T("ورژن: $ver", 13, Color.DarkGray)
        T("دکان: " + stGet("shop"), 13, Color.DarkGray)
        T("کل اندراج: ${Store.entries.size}", 13, Color.DarkGray)
        T("لائسنس: © MSF Gold Business Record — جملہ حقوق محفوظ ہیں۔", 12, Color.Gray)
        T("اپ ڈیٹس: نیا ورژن آنے پر نیا APK انسٹال کریں؛ آپ کا ڈیٹا محفوظ رہتا ہے۔", 12, Color.Gray)
    }
    HelpPage()
}

@Composable
private fun HelpPage() {
    val ctx = LocalContext.current
    val faqs = listOf(
        "فروخت کیسے درج کریں؟" to "نیچے \"فروخت\" دبائیں، گاہک کا نام، وزن اور ریٹ لکھیں، پھر محفوظ کریں۔",
        "سونے کا ریٹ کہاں بدلیں؟" to "سیٹنگز ← پروفائل ← \"آج سونے کا ریٹ\" بدل کر محفوظ کریں۔",
        "کاریگر اور مزدوری کیسے درج کریں؟" to "\"کاریگر\" میں نام شامل کریں، پھر ہوم کے فنکشنز سے \"مزدوری کا حساب\" میں رقم، سونا اور ادا شدہ رقم لکھیں۔",
        "بیک اپ کیسے لیں؟" to "سیٹنگز ← اسٹوریج ← بیک اپ اور ریسٹور ← \"بیک اپ شیئر کریں\" دبائیں اور فائل محفوظ جگہ بھیج دیں۔",
        "پاس ورڈ کیسے لگائیں؟" to "پروفائل میں پاس ورڈ لکھیں، پھر رازداری اور سیکیورٹی میں \"ایپ لاک\" چالو کریں۔")
    T("اکثر پوچھے گئے سوالات", 16, GreenD, true)
    faqs.forEach { (q, a) ->
        var open by remember { mutableStateOf(false) }
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, StLine, RoundedCornerShape(10.dp))
            .clickable { open = !open }.padding(10.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                T(q, 14, Color(0xFF14261A), true, Modifier.weight(1f)); T(if (open) "▴" else "▾", 14, Color.Gray)
            }
            if (open) T(a, 13, Color.DarkGray, m = Modifier.padding(top = 6.dp))
        }
    }
    Btn("📧 رائے / مسئلہ بھیجیں", GreenM, Modifier.fillMaxWidth()) {
        try {
            val i = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:")).apply {
                putExtra(Intent.EXTRA_SUBJECT, "MSF Gold Record - رائے / مسئلہ")
            }
            ctx.startActivity(Intent.createChooser(i, null))
        } catch (e: Exception) { Toast.makeText(ctx, "ای میل ایپ نہیں ملی", Toast.LENGTH_SHORT).show() }
    }
    Btn("📤 ایپ دوست کو شیئر کریں", RpBlueS, Modifier.fillMaxWidth()) {
        share(ctx, "MSF Gold Business Record — سونے کے کاروبار کا مکمل حساب کتاب ایپ")
    }
}

private val RpBlueS = Color(0xFF1565C0)
