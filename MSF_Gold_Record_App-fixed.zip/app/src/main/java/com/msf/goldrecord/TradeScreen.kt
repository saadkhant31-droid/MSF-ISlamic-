package com.msf.goldrecord

import android.app.DatePickerDialog
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import java.time.LocalDate

val GreenD = Color(0xFF0B3D1F)
val GreenM = Color(0xFF1B7A3A)
val Light = Color(0xFFF4F4F2)
val karats = listOf("24 قیراط", "22 قیراط", "21 قیراط", "18 قیراط")
val colW = listOf(36, 92, 100, 76, 56, 72, 84, 84, 84, 120)

fun fmtD(iso: String) = iso.split("-").reversed().joinToString("-")
fun fmtW(d: Double) = if (d == Math.floor(d)) "%.0f".format(d) else "%.2f".format(d)

@Composable
fun Header(title: String, sub: String, go: (String) -> Unit, crumb: String? = null) {
    Row(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(GreenD, Color(0xFF123A22), Color(0xFF3A2A00)))).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Text("🏠", fontSize = 26.sp, modifier = Modifier.clickable { go("home") })
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            T(title, 32, Gold, true)
            T(sub, 14, Color.White)
            if (crumb != null) T(crumb, 12, Gold)
        }
        Image(painterResource(R.drawable.logo), null, Modifier.size(64.dp).clip(CircleShape))
        Spacer(Modifier.width(8.dp))
        T("←", 28, Gold, true, Modifier.clickable { go("home") })
    }
}

@Composable
fun Tabs(cur: String, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        (listOf(Triple("purchase", "🛒", "خریداری"), Triple("sale", "📥", "فروخت"), Triple("worker", "👷", "کاریگر"),
            Triple("customer", "👥", "گاہک"), Triple("stock", "🪙", "اسٹاک"), Triple("reports", "📊", "رپورٹس")).let { t -> if (cur == "sale") listOf(t[1], t[0]) + t.drop(2) else t }).forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) Gold else CardBg).border(1.dp, GoldD, RoundedCornerShape(8.dp)).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (k == cur) Color.Black else Color.White)
            }
        }
    }
}

@Composable
fun Cap(s: String) = T(s, 12, Color(0xFF222222), true)

@Composable
fun LF(v: String, mod: Modifier = Modifier, numb: Boolean = false, ro: Boolean = false, ph: String = "",
       trailing: @Composable (() -> Unit)? = null, on: (String) -> Unit) {
    val bgc = if (ro) Color(0xFFE6E6E6) else Color.White
    OutlinedTextField(v, on, modifier = mod, singleLine = true, readOnly = ro, trailingIcon = trailing,
        textStyle = TextStyle(fontSize = 14.sp),
        placeholder = { if (ph.isNotEmpty()) Text(ph, fontSize = 12.sp, color = Color.Gray) },
        keyboardOptions = KeyboardOptions(keyboardType = if (numb) KeyboardType.Decimal else KeyboardType.Text),
        colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.Black, unfocusedTextColor = Color.Black,
            focusedContainerColor = bgc, unfocusedContainerColor = bgc, focusedBorderColor = GreenM,
            unfocusedBorderColor = Color(0xFFB0B0B0), cursorColor = GreenM))
}

@Composable
fun Drop(v: String, opts: List<String>, mod: Modifier = Modifier, on: (String) -> Unit) {
    var o by remember { mutableStateOf(false) }
    Box(mod) {
        Row(Modifier.fillMaxWidth().height(56.dp).clip(RoundedCornerShape(4.dp)).background(Color.White)
            .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(4.dp)).clickable { o = true }.padding(horizontal = 10.dp),
            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
            T(v, 14, Color.Black); T("▾", 14, Color.Black)
        }
        DropdownMenu(expanded = o, onDismissRequest = { o = false }) {
            opts.forEach { x -> DropdownMenuItem(text = { Text(x) }, onClick = { on(x); o = false }) }
        }
    }
}

@Composable
fun Btn(t: String, c: Color, m: Modifier, on: () -> Unit) =
    Button(on, m.height(48.dp), shape = RoundedCornerShape(8.dp), contentPadding = PaddingValues(2.dp),
        colors = ButtonDefaults.buttonColors(containerColor = c, contentColor = Color.White)) {
        Text(t, fontSize = 12.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold)
    }

@Composable
fun Act(t: String, c: Color, on: () -> Unit) =
    Box(Modifier.size(30.dp).clip(RoundedCornerShape(6.dp)).background(c).clickable(onClick = on), contentAlignment = Alignment.Center) {
        Text(t, fontSize = 14.sp)
    }

@Composable
fun Cell(s: String, w: Int, c: Color = Color.Black, b: Boolean = false) =
    T(s, 12, c, b, Modifier.width(w.dp).padding(horizontal = 3.dp), TextAlign.Center)

@Composable
fun TradeScreen(type: String, go: (String) -> Unit) {
    val ctx = LocalContext.current
    val buy = type == "purchase"
    val sc = rememberScrollState()
    val scope = rememberCoroutineScope()
    var editId by remember { mutableStateOf<Long?>(null) }
    var date by remember { mutableStateOf(LocalDate.now().toString()) }
    var name by remember { mutableStateOf("") }
    var phone by remember { mutableStateOf("") }
    var karat by remember { mutableStateOf(karats[0]) }
    var w by remember { mutableStateOf("") }
    var r by remember { mutableStateOf("") }
    var paid by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var msg by remember { mutableStateOf("") }
    var q by remember { mutableStateOf("") }
    var fk by remember { mutableStateOf("سب") }
    var view by remember { mutableStateOf<Entry?>(null) }
    var newCust by remember { mutableStateOf(false) }
    var dd by remember { mutableStateOf(false) }
    val total = num(w) * num(r)
    val bal = total - num(paid)

    fun clear() {
        editId = null; date = LocalDate.now().toString(); name = ""; phone = ""; karat = karats[0]
        w = ""; r = ""; paid = ""; note = ""; msg = ""
    }
    fun edit(e: Entry) {
        editId = e.id; date = e.date; name = e.name; phone = e.phone; karat = e.karat.ifBlank { karats[0] }
        w = fmtW(e.weight); r = if (e.rate == 0.0) "" else fmtW(e.rate); paid = fmtW(e.paid); note = e.note
        msg = "ایڈٹ موڈ: تبدیلی کے بعد محفوظ کریں ✏️"
        scope.launch { sc.animateScrollTo(0) }
    }
    fun save() {
        if (name.isBlank() || num(w) <= 0) { msg = "نام اور وزن درج کریں ⚠️"; return }
        val e = Entry(editId ?: System.currentTimeMillis(), type, name.trim(), num(w), total, note.trim(), date,
            karat, num(r), num(paid), phone.trim())
        val i = Store.entries.indexOfFirst { it.id == e.id }
        if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
        Store.save(); clear(); msg = "محفوظ ہو گیا ✅"
    }

    val names = (Store.entries.filter { it.type == "customer" }.map { it.name } +
            Store.entries.filter { it.type == type }.map { it.name }).distinct()
    val rows = Store.entries.filter { it.type == type }
        .sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
        .filter { (fk == "سب" || it.karat == fk) &&
                (q.isBlank() || it.name.contains(q) || it.phone.contains(q) || it.date.contains(q) || fmtD(it.date).contains(q)) }

    Column(Modifier.fillMaxSize()) {
        Header(if (buy) "خریداری" else "فروخت", if (buy) "سونے کی خریداری کا مکمل ریکارڈ" else "سونے کی فروخت کا مکمل ریکارڈ", go)
        Column(Modifier.weight(1f).verticalScroll(sc)) {
            Tabs(type, go)
            Column(Modifier.padding(horizontal = 8.dp).clip(RoundedCornerShape(14.dp)).background(Light).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween,
                    modifier = Modifier.fillMaxWidth()) {
                    T((if (buy) "📄 نئی خریداری" else "📄 نئی فروخت") + " کا اندراج", 17, Color.Black, true)
                    Column(Modifier.clip(RoundedCornerShape(8.dp)).background(Color.White).border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(8.dp))
                        .clickable {
                            val d = LocalDate.parse(date)
                            DatePickerDialog(ctx, { _, y, m, dy -> date = LocalDate.of(y, m + 1, dy).toString() },
                                d.year, d.monthValue - 1, d.dayOfMonth).show()
                        }.padding(8.dp)) {
                        T("📅 تاریخ ▾", 11, Color.DarkGray); T(fmtD(date), 14, Color.Black, true)
                    }
                }
                Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f)) {
                        Cap(if (buy) "گاہک / فروخت کنندہ کا نام" else "گاہک کا نام")
                        Box {
                            LF(name, Modifier.fillMaxWidth(), trailing = { Text("▾", color = Color.Black, modifier = Modifier.clickable { dd = true }.padding(8.dp)) }) { name = it }
                            DropdownMenu(expanded = dd, onDismissRequest = { dd = false }) {
                                if (names.isEmpty()) DropdownMenuItem(text = { Text("کوئی نام نہیں") }, onClick = { dd = false })
                                names.forEach { n ->
                                    DropdownMenuItem(text = { Text(n) }, onClick = {
                                        name = n
                                        Store.entries.firstOrNull { it.type == "customer" && it.name == n }?.let { c -> phone = c.phone.ifBlank { c.note } }
                                        dd = false
                                    })
                                }
                            }
                        }
                    }
                    Btn("＋ نیا گاہک", GreenM, Modifier.width(92.dp).padding(bottom = 4.dp)) { newCust = true }
                }
                Cap("📞 موبائل نمبر")
                LF(phone, Modifier.fillMaxWidth(), ph = "0300-1234567") { phone = it }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f)) { Cap("🪙 سونے کی قسم"); Drop(karat, karats) { karat = it } }
                    Column(Modifier.weight(1f)) { Cap("⚖️ وزن (گرام)"); LF(w, Modifier.fillMaxWidth(), true) { w = it } }
                    Column(Modifier.weight(1f)) { Cap("فی گرام ریٹ (روپے)"); LF(r, Modifier.fillMaxWidth(), true) { r = it } }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Column(Modifier.weight(1f)) { Cap("💰 کل قیمت (روپے)"); LF(mny(total), Modifier.fillMaxWidth(), ro = true) {} }
                    Column(Modifier.weight(1f)) { Cap("ادائیگی کی گئی رقم"); LF(paid, Modifier.fillMaxWidth(), true) { paid = it } }
                    Column(Modifier.weight(1f)) { Cap("بقایا رقم (روپے)"); LF(mny(bal), Modifier.fillMaxWidth(), ro = true) {} }
                }
                Cap("📝 نوٹ / تفصیل")
                LF(note, Modifier.fillMaxWidth(), ph = "تفصیل لکھیں") { note = it }
                if (msg.isNotEmpty()) T(msg, 13, GreenM, true)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("💾 محفوظ کریں", Color(0xFF1B7A3A), Modifier.weight(1f)) { save() }
                    Btn("🧮 حساب لگائیں", Color(0xFF1565C0), Modifier.weight(1f)) {
                        if (paid.isBlank()) paid = "0"
                        msg = "کل قیمت: ${money(total)}  |  بقایا: ${money(num(paid).let { total - it })}"
                    }
                    Btn("🧾 رسید بنائیں", Color(0xFF7B1FA2), Modifier.weight(1f)) {
                        if (name.isBlank() || num(w) <= 0) { msg = "پہلے نام اور وزن درج کریں ⚠️" } else {
                            share(ctx, "${Store.prefs["shop"]}\n${if (buy) "خریداری" else "فروخت"} رسید\nتاریخ: ${fmtD(date)}\nنام: $name\nموبائل: $phone\nقسم: $karat\nوزن: ${fmtW(num(w))} گرام\nفی گرام ریٹ: ${mny(num(r))}\nکل قیمت: ${money(total)}\nادائیگی: ${money(num(paid))}\nبقایا: ${money(bal)}\n$note\nشکریہ")
                        }
                    }
                    Btn("🗑 خالی کریں", Color(0xFFC62828), Modifier.weight(1f)) { clear() }
                }
            }
            Row(Modifier.padding(8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                LF(q, Modifier.weight(1f), ph = "🔍 تلاش کریں (نام، تاریخ یا نمبر)") { q = it }
                Drop(fk, listOf("سب") + karats, Modifier.width(110.dp)) { fk = it }
            }
            Column(Modifier.padding(horizontal = 8.dp, vertical = 4.dp).clip(RoundedCornerShape(10.dp)).background(Light)) {
                Column(Modifier.horizontalScroll(rememberScrollState())) {
                    Row(Modifier.background(GreenD).padding(vertical = 8.dp)) {
                        listOf("نمبر", "تاریخ", "نام", "قسم", "وزن", "فی گرام ریٹ", "کل قیمت", "ادائیگی", "بقایا", "ایکشن")
                            .forEachIndexed { i, h -> Cell(h, colW[i], Color.White, true) }
                    }
                    rows.forEachIndexed { i, e ->
                        Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF1F1EE)).padding(vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically) {
                            Cell((i + 1).toString(), colW[0]); Cell(fmtD(e.date), colW[1]); Cell(e.name, colW[2])
                            Cell(e.karat, colW[3]); Cell(fmtW(e.weight) + "g", colW[4]); Cell(mny(e.rate), colW[5])
                            Cell(mny(e.amount), colW[6]); Cell(mny(e.paid), colW[7])
                            Cell(mny(e.amount - e.paid), colW[8], Color(0xFFB71C1C), true)
                            Row(Modifier.width(colW[9].dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                                Act("👁", Color(0xFF2E7D32)) { view = e }
                                Act("✏️", Color(0xFF1565C0)) { edit(e) }
                                Act("🗑", Color(0xFFC62828)) { Store.entries.remove(e); Store.save() }
                            }
                        }
                    }
                    if (rows.isEmpty()) T("کوئی ریکارڈ نہیں", 13, Color.Gray, m = Modifier.padding(16.dp))
                    Row(Modifier.background(Color(0xFFFBE9C0)).padding(vertical = 8.dp)) {
                        Cell("Σ", colW[0], Color.Black, true); Cell("کل جات", colW[1] + colW[2] + colW[3], Color.Black, true)
                        Cell(fmtW(rows.sumOf { it.weight }) + "g", colW[4], Color.Black, true); Cell("", colW[5])
                        Cell(mny(rows.sumOf { it.amount }), colW[6], Color.Black, true)
                        Cell(mny(rows.sumOf { it.paid }), colW[7], Color.Black, true)
                        Cell(mny(rows.sumOf { it.amount - it.paid }), colW[8], Color(0xFFB71C1C), true)
                        Cell("", colW[9])
                    }
                }
            }
            Spacer(Modifier.height(12.dp))
        }
    }

    view?.let { e ->
        AlertDialog(onDismissRequest = { view = null }, title = { Text(e.name) },
            confirmButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } },
            text = {
                Column {
                    Text("تاریخ: ${fmtD(e.date)}\nموبائل: ${e.phone}\nقسم: ${e.karat}\nوزن: ${fmtW(e.weight)} گرام\n" +
                            "فی گرام ریٹ: ${mny(e.rate)}\nکل قیمت: ${money(e.amount)}\nادائیگی: ${money(e.paid)}\n" +
                            "بقایا: ${money(e.amount - e.paid)}\nنوٹ: ${e.note}")
                }
            })
    }
    if (newCust) {
        var cn by remember { mutableStateOf("") }
        var cp by remember { mutableStateOf("") }
        AlertDialog(onDismissRequest = { newCust = false }, title = { Text("نیا گاہک") },
            confirmButton = {
                TextButton(onClick = {
                    if (cn.isNotBlank()) {
                        Store.entries.add(Entry(System.currentTimeMillis(), "customer", cn.trim(), 0.0, 0.0, "", LocalDate.now().toString(), phone = cp.trim(), status = "فعال"))
                        Store.save(); name = cn.trim(); phone = cp.trim(); newCust = false
                    }
                }) { Text("محفوظ کریں") }
            },
            dismissButton = { TextButton(onClick = { newCust = false }) { Text("منسوخ") } },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    F("گاہک کا نام", cn) { cn = it }
                    F("موبائل نمبر", cp) { cp = it }
                }
            })
    }
}
