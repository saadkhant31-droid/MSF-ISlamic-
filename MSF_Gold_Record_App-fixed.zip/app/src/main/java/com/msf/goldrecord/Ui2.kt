package com.msf.goldrecord

import android.app.DatePickerDialog
import android.content.Context
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

val NavBg = Color(0xFF062B14)
val NavBtn = Color(0xFF0B3D1F)

@Composable
fun MsfHeader(icon: String, title: String, sub: String, tag: String) {
    Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF062B14), Color(0xFF0E4A25), Color(0xFF4A3500))))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 30.sp)
                    Spacer(Modifier.width(6.dp))
                    T(title, 32, Gold, true)
                }
                T(sub, 16, Color.White, true)
                T(tag, 11, Color(0xFFFFD866))
            }
            Image(painterResource(R.drawable.logo), null, Modifier.size(78.dp).clip(CircleShape).border(2.dp, Gold, CircleShape))
        }
    }
}

@Composable
fun MsfNav(cur: String, items: List<Triple<String, String, String>>, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(NavBg).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(54.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) Gold else NavBtn).border(1.dp, GoldD, RoundedCornerShape(8.dp)).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (k == cur) Color.Black else Color.White, true)
            }
        }
    }
}

@Composable
fun MChip(t: String, c: Color, sel: Boolean, m: Modifier = Modifier, on: () -> Unit) {
    Box(m.height(40.dp).clip(RoundedCornerShape(8.dp)).background(c)
        .border(if (sel) 3.dp else 0.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(8.dp))
        .clickable(onClick = on).padding(horizontal = 14.dp), contentAlignment = Alignment.Center) {
        T(t, 13, Color.White, true)
    }
}

fun pickDate(ctx: Context, iso: String, on: (String) -> Unit) {
    val d = try { LocalDate.parse(iso) } catch (e: Exception) { LocalDate.now() }
    DatePickerDialog(ctx, { _, y, m, dy -> on(LocalDate.of(y, m + 1, dy).toString()) },
        d.year, d.monthValue - 1, d.dayOfMonth).show()
}
