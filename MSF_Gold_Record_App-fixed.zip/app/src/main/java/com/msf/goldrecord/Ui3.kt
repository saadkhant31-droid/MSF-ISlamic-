package com.msf.goldrecord

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

val RcBody = Color(0xFFEFF4F0)

/** رپورٹس / رسیدیں کا نیا ہیڈر (لوگو بائیں، عنوان درمیان، تصویر دائیں) */
@Composable
fun MsfHeader2(art: String, logoIcon: String, logoText: String, title: String, sub: String, tags: List<String>) {
    Box(Modifier.fillMaxWidth().background(Brush.horizontalGradient(listOf(Color(0xFF062B14), Color(0xFF0E4A25), Color(0xFF123A22))))) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(art, fontSize = 40.sp, modifier = Modifier.width(64.dp), textAlign = TextAlign.Center)
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                T(title, 34, Gold, true)
                T(sub, 14, Color.White, true, al = TextAlign.Center)
                T(tags.joinToString("  •  "), 12, Color(0xFFFFD866), al = TextAlign.Center)
            }
            Column(Modifier.size(76.dp).clip(CircleShape).background(Color(0xFF0A2A12)).border(2.dp, Gold, CircleShape),
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(logoIcon, fontSize = 20.sp)
                T("MSF", 16, Gold, true)
                T(logoText, 9, Color.White)
            }
        }
    }
}

/** نچلی نیویگیشن بار (رپورٹس اور رسیدیں کے لیے) */
@Composable
fun RcBottomBar(cur: String, go: (String) -> Unit) {
    val items = listOf(Triple("home", "🏠", "ہوم"), Triple("customer", "👤", "گاہک"), Triple("receipts", "🧾", "رسیدیں"),
        if (cur == "receipts") Triple("purchase", "🛒", "خریداری") else Triple("sale", "🛒", "فروخت"),
        Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")).reversed()
    Row(Modifier.fillMaxWidth().background(Color(0xFF062B14)).padding(horizontal = 4.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        items.forEach { (k, i, l) ->
            val sel = k == cur
            Column(Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(10.dp))
                .background(if (sel) Color(0x33FFC107) else Color.Transparent)
                .border(1.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(10.dp)).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 20.sp)
                T(l, 11, if (sel) Gold else Color.White, true)
            }
        }
    }
}

/** رنگین گریڈینٹ کارڈ: عنوان + آئیکن، قدر، فیصد، ذیلی سطر */
@Composable
fun GradCard(icon: String, title: String, value: String, line: String, lineColor: Color, sub: String,
             c1: Color, c2: Color, m: Modifier, on: () -> Unit) {
    Column(m.clip(RoundedCornerShape(12.dp)).background(Brush.verticalGradient(listOf(c1, c2)))
        .clickable(onClick = on).padding(horizontal = 6.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
            T(title, 11, Color.White, true, Modifier.weight(1f))
            Text(icon, fontSize = 20.sp)
        }
        Text(value, color = Color.White, fontSize = (if (value.length > 10) 10 else if (value.length > 8) 12 else 15).sp,
            fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, modifier = Modifier.fillMaxWidth(), textAlign = TextAlign.Center)
        if (line.isNotEmpty()) T(line, 11, lineColor, true, Modifier.fillMaxWidth(), TextAlign.Center)
        T(sub, 9, Color.White, false, Modifier.fillMaxWidth(), TextAlign.Center)
    }
}

/** ہلکے رنگ کا خلاصہ کارڈ: متن دائیں، آئیکن بائیں */
@Composable
fun PaleCard(icon: String, title: String, value: String, line: String, lineColor: Color,
             bg: Color, bd: Color, m: Modifier, on: () -> Unit) {
    Row(m.clip(RoundedCornerShape(12.dp)).background(bg).border(1.dp, bd, RoundedCornerShape(12.dp))
        .clickable(onClick = on).padding(8.dp), verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Column(Modifier.weight(1f)) {
            T(title, 11, Color(0xFF333333))
            Text(value, color = Color.Black, fontSize = (if (value.length > 10) 11 else 14).sp,
                fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
            if (line.isNotEmpty()) T(line, 10, lineColor, true)
        }
        Text(icon, fontSize = 22.sp)
    }
}
