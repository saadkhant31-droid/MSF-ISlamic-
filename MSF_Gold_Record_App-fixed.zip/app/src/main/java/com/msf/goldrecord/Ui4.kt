package com.msf.goldrecord

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** کیلکولیٹر اور سیٹنگز کی نچلی نیویگیشن بار: ہوم / مزدوری / ریپورٹس / کیلکولیٹر / سیٹنگز */
@Composable
fun NavBar5(cur: String, go: (String) -> Unit) {
    val items = listOf(Triple("home", "🏠", "ہوم"), Triple("wage", "👷", "مزدوری"), Triple("reports", "📊", "ریپورٹس"),
        Triple("calc", "🧮", "کیلکولیٹر"), Triple("settings", "⚙️", "سیٹنگز")).reversed()
    Row(Modifier.fillMaxWidth().background(Color(0xFF04281A)).padding(horizontal = 6.dp, vertical = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (k, i, l) ->
            val sel = k == cur
            Column(Modifier.weight(1f).height(60.dp).clip(RoundedCornerShape(12.dp))
                .background(if (sel) Color(0x44FFC107) else Color.Transparent)
                .border(1.5.dp, if (sel) Gold else Color.Transparent, RoundedCornerShape(12.dp)).clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 22.sp)
                T(l, 12, Color.White, true)
            }
        }
    }
}
