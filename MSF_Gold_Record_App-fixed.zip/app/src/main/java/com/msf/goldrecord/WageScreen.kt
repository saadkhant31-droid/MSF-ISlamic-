package com.msf.goldrecord

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.time.LocalDate

private val WgGreenD = Color(0xFF0B3B1A)
private val WgGreen = Color(0xFF1E8E3E)
private val WgGold = Color(0xFFFFC928)
private val WgBg = Color(0xFFF1F5F1)
private val WgRed = Color(0xFFE53935)
private val WgBlue = Color(0xFF1565D8)
private val WgPurple = Color(0xFF7B1FA2)
private val WgOrange = Color(0xFFD9820A)
private val WgLine = Color(0xFFDDE3DD)
private val WgW = listOf(24, 44, 80, 74, 62, 56, 68, 82, 74, 98)
private val WgMonths = listOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")

private val WgNavItems = listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "مزدور"), Triple("wage", "🧮", "حساب"),
    Triple("wagehist", "📅", "تاریخ"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز"))

// ---------------- data helpers ----------------
private fun wgWorkers() = Store.entries.filter { it.type == "worker" }.sortedBy { it.id }

private fun wgIsWork(e: Entry) = e.status != "nothing" && (e.amount > 0 || e.weight > 0 || e.mins > 0 || e.ready > 0 || e.paid > 0)

/** wage logs of one worker in a month (yyyy-MM) */
private fun wgLogs(n: String, month: String) =
    Store.entries.filter { it.type == "wage" && it.name.trim() == n.trim() && it.date.startsWith(month) && it.status != "nothing" }

private fun wgHours(n: String, month: String): Double =
    Store.entries.filter { it.type == "hours" && it.name.trim() == n.trim() && it.date.startsWith(month) }.sumOf { it.weight } +
            wgLogs(n, month).sumOf { it.mins } / 60.0

private fun wgDays(n: String, month: String): Int =
    (Store.entries.filter { it.type == "hours" && it.name.trim() == n.trim() && it.date.startsWith(month) }.map { it.date } +
            wgLogs(n, month).filter { wgIsWork(it) }.map { it.date }).distinct().size

private fun wgWage(n: String, month: String) = wgLogs(n, month).sumOf { it.amount }
private fun wgPaid(n: String, month: String) = wgLogs(n, month).sumOf { it.paid }

private fun wgRate(w: Entry, month: String): Double {
    if (w.rate > 0) return w.rate
    val h = wgHours(w.name, month)
    return if (h > 0) wgWage(w.name, month) / h else 0.0
}

private fun wgMonthLbl(m: String) = WgMonths[m.substring(5, 7).toInt() - 1] + " " + m.substring(0, 4)
private fun wgShiftMonth(m: String, d: Int): String = LocalDate.parse("$m-01").plusMonths(d.toLong()).toString().take(7)
private fun wgH(h: Double) = if (h == Math.floor(h)) "%.0f".format(h) else "%.1f".format(h)

/** pay `amount` against the unpaid logs of the month, oldest first */
private fun wgPay(n: String, month: String, amount: Double) {
    var rem = amount
    val ids = wgLogs(n, month).sortedWith(compareBy<Entry> { it.date }.thenBy { it.id }).map { it.id }
    for (id in ids) {
        if (rem <= 0) break
        val i = Store.entries.indexOfFirst { it.id == id }
        if (i < 0) continue
        val e = Store.entries[i]
        val due = e.amount - e.paid
        if (due > 0) {
            val p = minOf(due, rem)
            Store.entries[i] = e.copy(paid = e.paid + p)
            rem -= p
        }
    }
    Store.save()
}

private fun wgSummary(w: Entry, month: String): String {
    val wage = wgWage(w.name, month); val paid = wgPaid(w.name, month)
    return "${w.name}\nمہینہ: ${wgMonthLbl(month)}\nکام کی قسم: ${wkRole(w).ifBlank { "—" }}\nملازمت کے دن: ${wgDays(w.name, month)}\n" +
            "کل گھنٹے: ${wgH(wgHours(w.name, month))}\nفی گھنٹہ ریٹ: ${money(wgRate(w, month))}\n" +
            "کل مزدوری: ${money(wage)}\nادا شدہ: ${money(paid)}\nباقی: ${money(wage - paid)}"
}

// ---------------- shared UI ----------------
@Composable
private fun WgHeader() {
    Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0B3B1A), Color(0xFF062B14))))) {
        Row(Modifier.fillMaxWidth().height(112.dp), verticalAlignment = Alignment.CenterVertically) {
            Image(painterResource(R.drawable.wg_logo), null,
                Modifier.padding(6.dp).size(88.dp).clip(CircleShape).border(2.dp, WgGold, CircleShape))
            Column(Modifier.weight(1f).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T("مزدوری کا حساب", 26, WgGold, true, al = TextAlign.Center)
                T("کام کے حساب سے مزدوری کا آسان اور درست حساب", 10, Color.White, true, al = TextAlign.Center)
                T("روزانہ کی مزدوری  •  ہفتہ وار حساب  •  ماہانہ رپورٹ", 9, WgGold, al = TextAlign.Center)
            }
            Box(Modifier.width(104.dp).fillMaxHeight()) {
                Image(painterResource(R.drawable.wg_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0.2f to Color.Transparent, 1f to Color(0xFF0B3B1A))))
            }
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(WgGold).align(Alignment.BottomCenter))
    }
}

@Composable
private fun WgNav(cur: String, go: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().background(WgGreenD).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        WgNavItems.reversed().forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(56.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) WgGold else Color(0xFF0F4D26)).border(1.dp, Color(0xFF8A6D00), RoundedCornerShape(8.dp))
                .clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (k == cur) Color.Black else Color.White, true, al = TextAlign.Center)
            }
        }
    }
}

@Composable
fun WgBottomBar(cur: String, go: (String) -> Unit) {
    NavigationBar(containerColor = WgGreenD) {
        WgNavItems.reversed().forEach { (k, i, l) ->
            NavigationBarItem(selected = cur == k, onClick = { go(k) },
                icon = { Text(i, fontSize = 20.sp) }, label = { Text(l, fontSize = 10.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(selectedTextColor = WgGold, unselectedTextColor = Color.White,
                    indicatorColor = Color(0xFF5A4300)))
        }
    }
}

@Composable
private fun WgCard(icon: String, title: String, value: String, sub: String, bg: Color, m: Modifier) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(bg).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 22.sp)
        T(title, 10, Color.White, true, al = TextAlign.Center)
        T(value, 15, Color.White, true, al = TextAlign.Center)
        T(sub, 9, Color(0xFFE8F5E9), al = TextAlign.Center)
    }
}

@Composable
private fun WgStat(icon: String, label: String, value: String, tint: Color, m: Modifier) {
    Row(m.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 22.sp, color = tint)
        Column { T(label, 10, Color.DarkGray); T(value, 12, Color.Black, true) }
    }
}

@Composable
private fun WgChip(t: String, sel: Boolean, m: Modifier, on: () -> Unit) {
    Box(m.height(44.dp).clip(RoundedCornerShape(6.dp)).background(if (sel) WgGreen else Color.White)
        .border(1.dp, if (sel) WgGreen else Color(0xFFCFD8CF), RoundedCornerShape(6.dp)).clickable(onClick = on).padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center) { T(t, 12, if (sel) Color.White else Color(0xFF1B3A1F), true, al = TextAlign.Center) }
}

@Composable
private fun WgStatusChip(wage: Double, paid: Double, on: () -> Unit) {
    val (txt, col) = when {
        wage <= 0 -> Pair("—", Color(0xFF9E9E9E))
        paid >= wage -> Pair("ادا ہو چکا", WgGreen)
        else -> Pair("باقی ہے", WgOrange)
    }
    Text(txt, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(col).clickable(onClick = on).padding(horizontal = 8.dp, vertical = 5.dp))
}

@Composable
private fun WgHead() {
    Row(Modifier.background(WgGreenD).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("#", "تصویر", "مزدور کا نام", "کام کی قسم", "ملازمت کے دن", "کل گھنٹے", "فی گھنٹہ ریٹ", "کل مزدوری", "حالت", "ایکشن").forEachIndexed { i, t ->
            T(t, 11, Color.White, true, Modifier.width(WgW[i].dp), TextAlign.Center)
        }
    }
}

@Composable
private fun WgRow(i: Int, w: Entry, month: String, onStatus: () -> Unit, onView: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val wage = wgWage(w.name, month); val paid = wgPaid(w.name, month)
    Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF4F9F4)).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Cell((i + 1).toString(), WgW[0])
        Box(Modifier.width(WgW[1].dp), contentAlignment = Alignment.Center) { WkAvatar(w.photo, w.gender, w.name, w.id, 36) }
        Cell(w.name, WgW[2], Color.Black, true)
        Cell(wkRole(w).ifBlank { "—" }, WgW[3])
        Cell(wgDays(w.name, month).toString(), WgW[4])
        Cell(wgH(wgHours(w.name, month)), WgW[5])
        Cell(wgRate(w, month).let { if (it > 0) money(it) else "—" }, WgW[6])
        Cell(if (wage > 0) money(wage) else "—", WgW[7], Color.Black, true)
        Box(Modifier.width(WgW[8].dp), contentAlignment = Alignment.Center) { WgStatusChip(wage, paid, onStatus) }
        Row(Modifier.width(WgW[9].dp), horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            Act("👁", WgGreen, onView); Act("✏️", WgBlue, onEdit); Act("🗑", WgRed, onDel)
        }
    }
}

// ---------------- Wage screen ----------------
@Composable
fun WageScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now().toString()
    var day by remember { mutableStateOf(today) }
    var q by remember { mutableStateOf("") }
    var gf by remember { mutableStateOf(0) }
    var dept by remember { mutableStateOf("") }
    var dMenu by remember { mutableStateOf(false) }
    var wDlg by remember { mutableStateOf(false) }
    var wEdit by remember { mutableStateOf<Entry?>(null) }
    var view by remember { mutableStateOf<Entry?>(null) }
    var delW by remember { mutableStateOf<Entry?>(null) }
    var logFor by remember { mutableStateOf<Entry?>(null) }
    var logEdit by remember { mutableStateOf<Entry?>(null) }
    var payFor by remember { mutableStateOf<Entry?>(null) }

    val month = day.take(7)
    val all = wgWorkers()
    val depts = all.map { wkRole(it) }.filter { it.isNotBlank() }.distinct()
    val rows = all.filter { w ->
        (gf == 0 || (gf == 1 && w.gender == "مرد") || (gf == 2 && w.gender == "عورت")) &&
                (dept.isBlank() || wkRole(w) == dept) &&
                (q.isBlank() || w.name.contains(q) || wkPhone(w).contains(q) || w.cnic.contains(q) || wkRole(w).contains(q))
    }
    val active = all.count { it.status != "leave" }
    val totWage = all.sumOf { wgWage(it.name, month) }
    val totPaid = all.sumOf { wgPaid(it.name, month) }
    val totHours = all.sumOf { wgHours(it.name, month) }
    val todayLogs = Store.entries.filter { it.type == "wage" && it.date == day && it.status != "nothing" }
    val todayWage = todayLogs.sumOf { it.amount }
    val todayPeople = todayLogs.filter { wgIsWork(it) }.map { it.name.trim() }.distinct().size
    val earners = all.count { wgWage(it.name, month) > 0 }
    val avg = if (earners == 0) 0.0 else totWage / earners
    val vw = view?.let { v -> Store.entries.firstOrNull { it.id == v.id } }
    val dayLbl = if (day == today) "آج" else fmtD(day)

    Column(Modifier.fillMaxSize().background(WgBg)) {
        WgHeader()
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            WgNav("wage", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WgCard("📅", if (day == today) "آج کی مزدوری" else "اس دن کی مزدوری", money(todayWage), "($todayPeople مزدور)", WgOrange, Modifier.weight(1f))
                    WgCard("🕐", "کل کام کے گھنٹے", wgH(totHours), "(${wgMonthLbl(month)})", WgPurple, Modifier.weight(1f))
                    WgCard("💵", "کل ادائیگی", money(totPaid), "(${wgMonthLbl(month)})", WgBlue, Modifier.weight(1f))
                    WgCard("👥", "کل مزدور", active.toString(), "(فعال)", WgGreen, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.height(56.dp).clip(RoundedCornerShape(6.dp)).background(WgGreen).clickable {
                        day = today; q = ""; gf = 0; dept = ""
                    }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("🔄", fontSize = 14.sp); T("تازہ کریں", 12, Color.White, true)
                    }
                    Row(Modifier.width(118.dp).height(56.dp).clip(RoundedCornerShape(6.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(6.dp)).clickable { pickDate(ctx, day) { day = it } }.padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        T("📅 " + fmtD(day), 11, Color.Black, true); T("▾", 12, Color.Black)
                    }
                    LF(q, Modifier.weight(1f), ph = "🔍 مزدور کا نام یا شناختی نمبر تلاش کریں...") { q = it }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.weight(2.2f)) {
                        WgChip((if (dept.isBlank()) "کام کی قسم" else dept) + " ▾", dept.isNotBlank(), Modifier.fillMaxWidth()) { dMenu = true }
                        DropdownMenu(expanded = dMenu, onDismissRequest = { dMenu = false }) {
                            DropdownMenuItem(text = { Text((if (dept.isBlank()) "✔ " else "") + "تمام اقسام") }, onClick = { dept = ""; dMenu = false })
                            depts.forEach { d -> DropdownMenuItem(text = { Text((if (d == dept) "✔ " else "") + d) }, onClick = { dept = d; dMenu = false }) }
                        }
                    }
                    WgChip("خواتین", gf == 2, Modifier.weight(1f)) { gf = 2 }
                    WgChip("مرد", gf == 1, Modifier.weight(1f)) { gf = 1 }
                    WgChip("تمام مزدور", gf == 0, Modifier.weight(1.3f)) { gf = 0 }
                }
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WgLine, RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(WgGreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("👥 مزدوروں کی فہرست", 16, Color.White, true)
                        Spacer(Modifier.weight(1f))
                        Text("＋ نیا مزدور شامل کریں", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(WgGreen).border(1.dp, Color(0xFF5BC27A), RoundedCornerShape(6.dp))
                                .clickable { wEdit = null; wDlg = true }.padding(horizontal = 12.dp, vertical = 9.dp))
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        WgHead()
                        rows.forEachIndexed { i, w ->
                            WgRow(i, w, month,
                                onStatus = {
                                    val wage = wgWage(w.name, month); val paid = wgPaid(w.name, month)
                                    when {
                                        wage <= 0 -> { logEdit = null; logFor = w }
                                        paid < wage -> payFor = w
                                        else -> { view = w }
                                    }
                                },
                                onView = { view = w }, onEdit = { wEdit = w; wDlg = true }, onDel = { delW = w })
                        }
                    }
                    if (rows.isEmpty()) T(if (all.isEmpty()) "ابھی کوئی مزدور نہیں۔ اوپر سے نیا مزدور شامل کریں۔" else "کوئی مزدور نہیں ملا",
                        14, Color.Gray, m = Modifier.padding(16.dp))
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WgLine, RoundedCornerShape(12.dp)).padding(vertical = 8.dp)) {
                    WgStat("🗄", "اوسط مزدوری", money(avg), WgGreen, Modifier.weight(1.25f))
                    WgStat("👥", "کل مزدور", all.size.toString(), WgBlue, Modifier.weight(1f))
                    WgStat("🕐", "کل گھنٹے", wgH(totHours), WgPurple, Modifier.weight(1f))
                    WgStat("💵", "کل ادائیگی", money(totPaid), WgGreen, Modifier.weight(1.25f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (wDlg) WkWorkerDialog(wEdit) { wDlg = false; wEdit = null }
    logFor?.let { w -> WkLogDialog(w, logEdit, day) { logFor = null; logEdit = null } }
    payFor?.let { w -> WgPayDialog(w, month) { payFor = null } }
    delW?.let { w ->
        AlertDialog(onDismissRequest = { delW = null }, title = { Text("مزدور حذف کریں") },
            text = { Text("${w.name} کو فہرست سے حذف کر دیں؟ (اس کی مزدوری کا ریکارڈ رپورٹس میں باقی رہے گا)") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(w); Store.save(); delW = null; view = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { delW = null }) { Text("منسوخ") } })
    }
    vw?.let { w ->
        val logs = wgLogs(w.name, month).sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
        val wage = wgWage(w.name, month); val paid = wgPaid(w.name, month)
        val summary = wgSummary(w, month)
        AlertDialog(onDismissRequest = { view = null }, title = { Text(w.name) },
            confirmButton = { TextButton(onClick = { logEdit = null; logFor = w }) { Text("＋ نئی مزدوری") } },
            dismissButton = { TextButton(onClick = { view = null }) { Text("بند کریں") } },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkAvatar(w.photo, w.gender, w.name, w.id, 56)
                        Text(summary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Btn("✏️ ایڈٹ", WgBlue, Modifier.weight(1f)) { wEdit = w; wDlg = true }
                        Btn("📤 شیئر", WgPurple, Modifier.weight(1f)) { share(ctx, "${Store.prefs["shop"]}\n$summary") }
                        Btn("🗑 حذف", WgRed, Modifier.weight(1f)) { delW = w }
                    }
                    if (wage > paid) Btn("💵 ادائیگی کریں (باقی ${money(wage - paid)})", WgGreen, Modifier.fillMaxWidth()) { payFor = w }
                    T("📋 ${wgMonthLbl(month)} کے اندراجات", 14, Gold, true)
                    if (logs.isEmpty()) T("اس مہینے کوئی اندراج نہیں", 12, Color.Gray)
                    logs.forEach { e ->
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                T(fmtD(e.date), 12, Color.White, true)
                                T("سونا ${fmtW(e.weight)}g • ${money(e.amount)} • ادا ${money(e.paid)} • ${(e.mins / 60).toInt()}:${"%02d".format(e.mins.toInt() % 60)}", 11, Color.LightGray)
                                if (e.note.isNotBlank()) T(e.note, 11, Color.Gray)
                            }
                            Text("✏️", fontSize = 20.sp, modifier = Modifier.clickable { logEdit = e; logFor = w }.padding(6.dp))
                            Text("🗑", fontSize = 20.sp, modifier = Modifier.clickable { Store.entries.remove(e); Store.save() }.padding(6.dp))
                        }
                    }
                }
            })
    }
}

@Composable
private fun WgPayDialog(w: Entry, month: String, close: () -> Unit) {
    val due = wgWage(w.name, month) - wgPaid(w.name, month)
    var a by remember { mutableStateOf(fmtW(due)) }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text("${w.name} — ادائیگی") },
        confirmButton = {
            TextButton(onClick = {
                val v = num(a)
                if (v <= 0) err = "رقم درج کریں ⚠️"
                else if (v > due) err = "رقم باقی رقم (${money(due)}) سے زیادہ ہے ⚠️"
                else { wgPay(w.name, month, v); close() }
            }) { Text("ادا کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                T("مہینہ: ${wgMonthLbl(month)}", 13, Color.LightGray)
                T("باقی رقم: ${money(due)}", 15, Gold, true)
                F("ادا کی جانے والی رقم (Rs.)", a, true) { a = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}

// ---------------- History (تاریخ) screen ----------------
@Composable
fun WageHistoryScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var month by remember { mutableStateOf(LocalDate.now().toString().take(7)) }
    var q by remember { mutableStateOf("") }
    var logFor by remember { mutableStateOf<Entry?>(null) }
    var logEdit by remember { mutableStateOf<Entry?>(null) }
    var del by remember { mutableStateOf<Entry?>(null) }

    val list = Store.entries.filter { it.type == "wage" && it.status != "nothing" && it.date.startsWith(month) && (q.isBlank() || it.name.contains(q)) }
        .sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
    val byDay = list.groupBy { it.date }
    val wage = list.sumOf { it.amount }; val paid = list.sumOf { it.paid }
    val text = "${Store.prefs["shop"]}\nمزدوری کی تاریخ — ${wgMonthLbl(month)}\n" +
            list.joinToString("\n") { "${fmtD(it.date)} | ${it.name} | ${money(it.amount)} | ادا ${money(it.paid)}" } +
            "\n\nکل مزدوری: ${money(wage)}\nادا شدہ: ${money(paid)}\nباقی: ${money(wage - paid)}"

    Column(Modifier.fillMaxSize().background(WgBg)) {
        WgHeader()
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            WgNav("wagehist", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, WgLine, RoundedCornerShape(10.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Act("▶", WgGreen) { month = wgShiftMonth(month, -1) }
                    Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { T("📅 " + wgMonthLbl(month), 16, WgGreenD, true) }
                    Act("◀", WgGreen) { month = wgShiftMonth(month, 1) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WgCard("⏳", "باقی", money(wage - paid), "(${wgMonthLbl(month)})", WgOrange, Modifier.weight(1f))
                    WgCard("💵", "ادا شدہ", money(paid), "(${wgMonthLbl(month)})", WgBlue, Modifier.weight(1f))
                    WgCard("💰", "کل مزدوری", money(wage), "(${list.size} اندراج)", WgGreen, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(Modifier.height(56.dp).clip(RoundedCornerShape(6.dp)).background(WgPurple).clickable {
                        if (list.isEmpty()) {} else share(ctx, text)
                    }.padding(horizontal = 10.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Text("📤", fontSize = 14.sp); T("شیئر", 12, Color.White, true)
                    }
                    LF(q, Modifier.weight(1f), ph = "🔍 مزدور کا نام تلاش کریں...") { q = it }
                }
                if (list.isEmpty()) T("اس مہینے کا کوئی ریکارڈ نہیں۔", 14, Color.Gray, m = Modifier.padding(16.dp))
                byDay.forEach { (d, items) ->
                    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WgLine, RoundedCornerShape(12.dp))) {
                        Row(Modifier.fillMaxWidth().background(WgGreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            T("📅 " + fmtD(d), 13, Color.White, true, Modifier.weight(1f))
                            T(money(items.sumOf { it.amount }), 13, WgGold, true)
                        }
                        items.forEach { e ->
                            val w = wgWorkers().firstOrNull { it.name.trim() == e.name.trim() }
                            Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                WkAvatar(w?.photo ?: "", w?.gender ?: "", e.name, w?.id ?: 0L, 36)
                                Column(Modifier.weight(1f)) {
                                    T(e.name, 14, Color.Black, true)
                                    T("مزدوری ${money(e.amount)} • ادا ${money(e.paid)}" + (if (e.weight > 0) " • سونا ${fmtW(e.weight)}g" else ""), 11, Color.DarkGray)
                                    if (e.note.isNotBlank()) T(e.note, 11, Color.Gray)
                                }
                                Act("✏️", WgBlue) {
                                    logEdit = e
                                    logFor = w ?: Entry(id = 0L, type = "worker", name = e.name, weight = 0.0, amount = 0.0, note = "", date = e.date)
                                }
                                Act("🗑", WgRed) { del = e }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    logFor?.let { w -> WkLogDialog(w, logEdit, LocalDate.now().toString()) { logFor = null; logEdit = null } }
    del?.let { e ->
        AlertDialog(onDismissRequest = { del = null }, title = { Text("اندراج حذف کریں") },
            text = { Text("${e.name} کا ${fmtD(e.date)} کا اندراج (${money(e.amount)}) حذف کر دیں؟") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(e); Store.save(); del = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { del = null }) { Text("منسوخ") } })
    }
}
