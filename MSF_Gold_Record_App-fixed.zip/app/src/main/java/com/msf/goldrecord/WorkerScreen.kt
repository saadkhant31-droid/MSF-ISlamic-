package com.msf.goldrecord

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.print.PrintManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.FileProvider
import java.io.File
import java.time.LocalDate

private val WkGreenD = Color(0xFF0B3B1A)
private val WkGreen = Color(0xFF1E8E3E)
private val WkGold = Color(0xFFE8B923)
private val WkBg = Color(0xFFEEF3EE)
private val WkRed = Color(0xFFE53935)
private val WkBlue = Color(0xFF1565C0)
private val WkPink = Color(0xFFC2187A)
private val WkOrange = Color(0xFFD9820A)
private val WkLine = Color(0xFFDDE3DD)
private val WkCols = listOf(0xFF1B7A3A, 0xFF1565C0, 0xFF6A1B9A, 0xFFEF6C00, 0xFF00838F, 0xFFAD1457)
private val WkW = listOf(30, 54, 96, 84, 104, 104, 78, 86, 70, 108)
private val WkMonths = listOf("جنوری", "فروری", "مارچ", "اپریل", "مئی", "جون", "جولائی", "اگست", "ستمبر", "اکتوبر", "نومبر", "دسمبر")
private val WkFilters = listOf("تمام", "حاضر", "غیر حاضر", "چھٹی", "مرد", "خواتین")

private var wkSeq = 0L
private fun wkNewId(): Long { wkSeq++; return System.currentTimeMillis() * 1000 + (wkSeq % 1000) }
private var wkPrintView: WebView? = null

// ---------------- data helpers ----------------
private fun wkWorkers() = Store.entries.filter { it.type == "worker" }.sortedBy { it.id }

private fun wkLogs(n: String, d: String?) =
    Store.entries.filter { it.type == "wage" && it.name.trim() == n.trim() && (d == null || it.date == d) }
private fun wkHrs(n: String, d: String?) =
    Store.entries.filter { it.type == "hours" && it.name.trim() == n.trim() && (d == null || it.date == d) }
private fun wkGold(n: String, d: String?) = wkLogs(n, d).sumOf { it.weight }
private fun wkReady(n: String, d: String?) = wkLogs(n, d).sumOf { it.ready }
private fun wkWage(n: String, d: String?) = wkLogs(n, d).sumOf { it.amount }
private fun wkPaid(n: String, d: String?) = wkLogs(n, d).sumOf { it.paid }
private fun wkMins(n: String, d: String?) = wkLogs(n, d).sumOf { it.mins } + wkHrs(n, d).sumOf { it.weight } * 60
private fun wkState(n: String, d: String): Int {
    val logs = wkLogs(n, d)
    if (logs.any { it.status != "nothing" } || wkHrs(n, d).isNotEmpty()) return 0
    return if (logs.any { it.status == "nothing" }) 2 else 1
}
internal fun wkPhone(e: Entry) = if (e.bill == "v2") e.phone else e.phone.ifBlank { e.note }
internal fun wkRole(e: Entry) = if (e.bill == "v2") e.note else if (e.phone.isNotBlank()) e.note else ""
private fun wkId(e: Entry): String =
    "%03d".format(Store.entries.filter { it.type == "worker" }.sortedBy { it.id }.indexOfFirst { it.id == e.id } + 1)
private fun wkG(g: Double): String = if (g >= 1000) "%.3f کلوگرام".format(g / 1000) else fmtW(g) + " گرام"
private fun wkGV(g: Double): String = money(g / TOLA * num(Store.prefs["rate"] ?: "0"))
private fun wkHM(m: Double): Pair<String, String> { val t = m.toInt(); return Pair("${t / 60} گھنٹے", "${t % 60} منٹ") }

// attendance: an explicit record wins, otherwise a day with work logged counts as present
private fun wkAtt(w: Entry, day: String): Boolean {
    val r = Store.entries.lastOrNull { it.type == "attend" && it.name.trim() == w.name.trim() && it.date == day }
    return if (r != null) r.status == "present" else wkState(w.name, day) == 0
}

private fun wkSetAtt(w: Entry, day: String, present: Boolean) {
    val n = w.name.trim()
    Store.entries.removeAll { it.type == "attend" && it.name.trim() == n && it.date == day }
    Store.entries.add(Entry(id = wkNewId(), type = "attend", name = w.name, weight = 0.0, amount = 0.0,
        note = "", date = day, status = if (present) "present" else "absent"))
    Store.save()
}

private fun wkAvg(day: String, ws: List<Entry>): Int {
    val d = LocalDate.parse(day)
    var p = 0; var t = 0
    for (i in 0..6) {
        val x = d.minusDays(i.toLong()).toString()
        val el = ws.filter { it.date <= x }
        p += el.count { wkAtt(it, x) }; t += el.size
    }
    return if (t == 0) 0 else p * 100 / t
}

private fun wkMonthLbl(m: String) = WkMonths[m.substring(5, 7).toInt() - 1] + " " + m.substring(0, 4)
private fun wkSalPaid(w: Entry, m: String) =
    Store.entries.filter { it.type == "salpay" && it.name.trim() == w.name.trim() && it.date.startsWith(m) }.sumOf { it.amount }

private fun wkAttText(ws: List<Entry>, day: String): String {
    val pres = ws.count { wkAtt(it, day) }
    return "${Store.prefs["shop"]}\nحاضری رپورٹ (${fmtD(day)})\nکل: ${ws.size} | حاضر: $pres | غیر حاضر: ${ws.size - pres}\n" +
            ws.joinToString("\n") { "${it.name}: " + (if (wkAtt(it, day)) "حاضر" else "غیر حاضر") }
}

private fun wkSavePhoto(ctx: Context, uri: Uri, id: Long): String {
    return try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        var ss = 1
        while (o.outWidth / ss > 1024 || o.outHeight / ss > 1024) ss *= 2
        val o2 = BitmapFactory.Options().apply { inSampleSize = ss }
        val src = ctx.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o2) }
        if (src == null) "" else {
            val sc = 320f / maxOf(src.width, src.height)
            val bm = if (sc < 1f) Bitmap.createScaledBitmap(src, maxOf(1, (src.width * sc).toInt()), maxOf(1, (src.height * sc).toInt()), true) else src
            val f = File(ctx.filesDir, "wk_${id}_${System.currentTimeMillis()}.jpg")
            f.outputStream().use { bm.compress(Bitmap.CompressFormat.JPEG, 85, it) }
            f.absolutePath
        }
    } catch (e: Exception) { "" }
}

private fun csvq(s: String) = "\"" + s.replace("\"", "\"\"") + "\""
private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

private fun wkCsv(ctx: Context, ws: List<Entry>, day: String) {
    val sb = StringBuilder("\uFEFF")
    sb.append("نمبر,نام,عہدہ,شناختی نمبر,فون نمبر,جنس,حاضری,تنخواہ,حالت\n")
    ws.forEachIndexed { i, w ->
        sb.append(listOf((i + 1).toString(), w.name, wkRole(w), w.cnic, wkPhone(w), w.gender,
            if (wkAtt(w, day)) "حاضر" else "غیر حاضر", fmtW(w.amount), if (w.status == "leave") "چھٹی" else "مکمل")
            .joinToString(",") { csvq(it) }).append("\n")
    }
    val dir = File(ctx.cacheDir, "exports").apply { mkdirs() }
    val f = File(dir, "MSF_Working_People_$day.csv")
    f.writeText(sb.toString())
    val uri = FileProvider.getUriForFile(ctx, ctx.packageName + ".fileprovider", f)
    val i = Intent(Intent.ACTION_SEND).apply {
        type = "text/csv"; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
    }
    ctx.startActivity(Intent.createChooser(i, null))
}

private fun wkPrint(ctx: Context, ws: List<Entry>, day: String) {
    val body = ws.mapIndexed { i, w ->
        "<tr><td>${i + 1}</td><td>${esc(w.name)}</td><td>${esc(wkRole(w))}</td><td>${esc(w.cnic)}</td><td>${esc(wkPhone(w))}</td>" +
                "<td>${if (wkAtt(w, day)) "حاضر" else "غیر حاضر"}</td><td>${if (w.amount > 0) money(w.amount) else "-"}</td>" +
                "<td>${if (w.status == "leave") "چھٹی" else "مکمل"}</td></tr>"
    }.joinToString("")
    val html = "<html dir='rtl'><head><meta charset='utf-8'><style>body{font-family:sans-serif}" +
            "table{width:100%;border-collapse:collapse}th,td{border:1px solid #888;padding:6px;text-align:center;font-size:13px}" +
            "th{background:#0b3b1a;color:#fff}</style></head><body><h2 style='text-align:center'>${esc(Store.prefs["shop"] ?: "")} - کام کرنے والے افراد کی فہرست</h2>" +
            "<p>تاریخ: ${fmtD(day)} &nbsp;&nbsp; کل افراد: ${ws.size}</p><table><tr><th>#</th><th>نام</th><th>عہدہ</th><th>شناختی نمبر</th>" +
            "<th>فون نمبر</th><th>حاضری</th><th>تنخواہ</th><th>حالت</th></tr>$body</table></body></html>"
    val wv = WebView(ctx)
    wkPrintView = wv
    wv.webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
            if (view == null) return
            val pm = ctx.getSystemService(Context.PRINT_SERVICE) as PrintManager
            pm.print("MSF Working People", view.createPrintDocumentAdapter("MSF Working People"), null)
        }
    }
    wv.loadDataWithBaseURL(null, html, "text/HTML", "UTF-8", null)
}

// ---------------- shared UI pieces ----------------
@Composable
private fun WkHeader(title: String, sub: String, tags: String) {
    Box(Modifier.fillMaxWidth().background(Brush.verticalGradient(listOf(Color(0xFF0B3B1A), Color(0xFF062B14))))) {
        Row(Modifier.fillMaxWidth().height(110.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.width(96.dp).fillMaxHeight()) {
                Image(painterResource(R.drawable.wk_banner), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                Box(Modifier.fillMaxSize().background(Brush.horizontalGradient(0f to Color(0xFF0B3B1A), 0.8f to Color.Transparent)))
            }
            Column(Modifier.weight(1f).padding(horizontal = 4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                T("👷 $title", 20, WkGold, true, al = TextAlign.Center)
                T(sub, 10, Color.White, true, al = TextAlign.Center)
                T(tags, 9, WkGold, al = TextAlign.Center)
            }
            Image(painterResource(R.drawable.wk_logo), null,
                Modifier.padding(6.dp).size(84.dp).clip(CircleShape).border(2.dp, WkGold, CircleShape))
        }
        Box(Modifier.fillMaxWidth().height(2.dp).background(WkGold).align(Alignment.BottomCenter))
    }
}

@Composable
private fun WkNav(cur: String, go: (String) -> Unit) {
    val items = listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "کام کرنے والی"), Triple("attendance", "📅", "حاضری"),
        Triple("salary", "💵", "تنخواہ"), Triple("reports", "📊", "کارکردگی"), Triple("settings", "⚙️", "سیٹنگز")).reversed()
    Row(Modifier.fillMaxWidth().background(WkGreenD).padding(6.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        items.forEach { (k, i, l) ->
            Column(Modifier.weight(1f).height(58.dp).clip(RoundedCornerShape(8.dp))
                .background(if (k == cur) WkGold else Color(0xFF0F4D26)).border(1.dp, Color(0xFF8A6D00), RoundedCornerShape(8.dp))
                .clickable { go(k) },
                horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                Text(i, fontSize = 18.sp)
                T(l, 10, if (k == cur) Color.Black else Color.White, true, al = TextAlign.Center)
            }
        }
    }
}

@Composable
fun WkBottomBar(cur: String, go: (String) -> Unit) {
    NavigationBar(containerColor = WkGreenD) {
        listOf(Triple("home", "🏠", "ہوم"), Triple("worker", "👷", "کام کرنے والے"), Triple("attendance", "📅", "حاضری"),
            Triple("salary", "💵", "تنخواہ"), Triple("reports", "📊", "رپورٹس"), Triple("settings", "⚙️", "سیٹنگز")).reversed().forEach { (k, i, l) ->
            NavigationBarItem(selected = cur == k, onClick = { go(k) },
                icon = { Text(i, fontSize = 20.sp) }, label = { Text(l, fontSize = 9.sp, maxLines = 1) },
                colors = NavigationBarItemDefaults.colors(selectedTextColor = WkGold, unselectedTextColor = Color.White,
                    indicatorColor = Color(0xFF5A4300)))
        }
    }
}

@Composable
internal fun WkAvatar(photo: String, gender: String, name: String, seed: Long, size: Int) {
    val bmp = remember(photo) {
        if (photo.isBlank()) null else try { BitmapFactory.decodeFile(photo)?.asImageBitmap() } catch (e: Exception) { null }
    }
    Box(Modifier.size(size.dp).clip(CircleShape).background(Color(WkCols[(seed % WkCols.size).toInt()])), contentAlignment = Alignment.Center) {
        if (bmp != null) Image(bmp, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        else Text(if (gender == "عورت") "👩" else if (gender == "مرد") "👨" else name.take(1), fontSize = (size / 2).sp, color = Color.White)
    }
}

@Composable
private fun WkChip(t: String, bg: Color, on: () -> Unit) =
    Text(t, color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.clip(RoundedCornerShape(12.dp)).background(bg).clickable(onClick = on).padding(horizontal = 10.dp, vertical = 4.dp))

@Composable
private fun WkCard(icon: String, title: String, value: Int, bg: Color, sel: Boolean, m: Modifier, on: () -> Unit) {
    Column(m.height(104.dp).clip(RoundedCornerShape(12.dp)).background(bg)
        .border(if (sel) 3.dp else 0.dp, if (sel) WkGold else Color.Transparent, RoundedCornerShape(12.dp))
        .clickable(onClick = on).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text(icon, fontSize = 24.sp)
        T(title, 11, Color.White, true, al = TextAlign.Center)
        T(value.toString(), 22, Color.White, true, al = TextAlign.Center)
        T("کام کرنے والے", 9, Color(0xFFE8F5E9), al = TextAlign.Center)
    }
}

@Composable
private fun WkMoney(title: String, value: String, bg: Color, m: Modifier) {
    Column(m.height(76.dp).clip(RoundedCornerShape(12.dp)).background(bg).padding(4.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        T(title, 12, Color.White, true, al = TextAlign.Center)
        T(value, 14, Color.White, true, al = TextAlign.Center)
    }
}

@Composable
private fun WkAction(icon: String, t: String, filled: Boolean, on: () -> Unit) {
    Row(Modifier.height(44.dp).clip(RoundedCornerShape(6.dp)).background(if (filled) WkGreen else Color.White)
        .border(1.dp, if (filled) WkGreen else Color(0xFFCFD8CF), RoundedCornerShape(6.dp))
        .clickable(onClick = on).padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(icon, fontSize = 16.sp)
        T(t, 12, if (filled) Color.White else Color(0xFF1B3A1F), true)
    }
}

@Composable
private fun WkStatCell(icon: String, label: String, value: String, m: Modifier) {
    Row(m.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 20.sp)
        Column { T(label, 10, Color.DarkGray); T(value, 12, Color.Black, true) }
    }
}

@Composable
private fun WkHead() {
    Row(Modifier.background(WkGreenD).padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        listOf("#", "تصویر", "نام", "عہدہ", "شناختی نمبر", "فون نمبر", "حاضری", "تنخواہ", "حالت", "ایکشن").forEachIndexed { i, t ->
            T(t, 12, Color.White, true, Modifier.width(WkW[i].dp), TextAlign.Center)
        }
    }
}

@Composable
private fun WkRow(i: Int, w: Entry, day: String, onAtt: () -> Unit, onStatus: () -> Unit, onView: () -> Unit, onEdit: () -> Unit, onDel: () -> Unit) {
    val att = wkAtt(w, day)
    val leave = w.status == "leave"
    Row(Modifier.background(if (i % 2 == 0) Color.White else Color(0xFFF4F9F4)).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Cell((i + 1).toString(), WkW[0])
        Box(Modifier.width(WkW[1].dp), contentAlignment = Alignment.Center) { WkAvatar(w.photo, w.gender, w.name, w.id, 40) }
        Cell(w.name, WkW[2], Color.Black, true)
        Cell(wkRole(w).ifBlank { "—" }, WkW[3])
        Cell(w.cnic.ifBlank { "—" }, WkW[4])
        Cell(wkPhone(w).ifBlank { "—" }, WkW[5])
        Box(Modifier.width(WkW[6].dp), contentAlignment = Alignment.Center) { WkChip(if (att) "حاضر" else "غیر حاضر", if (att) WkGreen else WkRed, onAtt) }
        Cell(if (w.amount > 0) money(w.amount) else "—", WkW[7])
        Box(Modifier.width(WkW[8].dp), contentAlignment = Alignment.Center) { WkChip(if (leave) "چھٹی" else "مکمل", if (leave) WkOrange else WkGreen, onStatus) }
        Row(Modifier.width(WkW[9].dp), horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally), verticalAlignment = Alignment.CenterVertically) {
            Act("🗑", WkRed, onDel); Act("✏️", WkBlue, onEdit); Act("👁", WkGreen, onView)
        }
    }
}

// ---------------- Working People screen ----------------
@Composable
fun WorkerScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now().toString()
    var day by remember { mutableStateOf(today) }
    var q by remember { mutableStateOf("") }
    var flt by remember { mutableStateOf("تمام") }
    var fMenu by remember { mutableStateOf(false) }
    var msg by remember { mutableStateOf("") }
    var wDlg by remember { mutableStateOf(false) }
    var wEdit by remember { mutableStateOf<Entry?>(null) }
    var detail by remember { mutableStateOf<Entry?>(null) }
    var logFor by remember { mutableStateOf<Entry?>(null) }
    var logEdit by remember { mutableStateOf<Entry?>(null) }
    var delW by remember { mutableStateOf<Entry?>(null) }

    val all = wkWorkers()
    val rows = all.filter { w ->
        val att = wkAtt(w, day)
        (flt == "تمام" || (flt == "حاضر" && att) || (flt == "غیر حاضر" && !att) || (flt == "چھٹی" && w.status == "leave") ||
                (flt == "مرد" && w.gender == "مرد") || (flt == "خواتین" && w.gender == "عورت")) &&
                (q.isBlank() || w.name.contains(q) || wkPhone(w).contains(q) || w.cnic.contains(q) || wkRole(w).contains(q))
    }
    val male = all.count { it.gender == "مرد" }
    val female = all.count { it.gender == "عورت" }
    val onDuty = all.count { wkAtt(it, day) && it.status != "leave" }
    val presentN = all.count { wkAtt(it, day) }
    val dw = detail?.let { d -> Store.entries.firstOrNull { it.id == d.id } }

    Column(Modifier.fillMaxSize().background(WkBg)) {
        WkHeader("کام کرنے والے افراد", "آپ کے ادارے کے تمام کام کرنے والے افراد کا ریکارڈ", "حاضری  •  تنخواہ  •  کام کی تفصیلات  •  کارکردگی")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            WkNav("worker", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WkCard("💼", "موجودہ ڈیوٹی پر", onDuty, WkOrange, flt == "حاضر", Modifier.weight(1f)) { flt = "حاضر" }
                    WkCard("👩", "خواتین", female, WkPink, flt == "خواتین", Modifier.weight(1f)) { flt = "خواتین" }
                    WkCard("👨", "مرد", male, WkBlue, flt == "مرد", Modifier.weight(1f)) { flt = "مرد" }
                    WkCard("👥", "کل افراد", all.size, WkGreen, flt == "تمام", Modifier.weight(1f)) { flt = "تمام" }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box {
                        Row(Modifier.height(56.dp).clip(RoundedCornerShape(6.dp)).background(WkGreen).clickable { fMenu = true }.padding(horizontal = 10.dp),
                            verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            Text("🔻", fontSize = 12.sp); T("فلٹر", 12, Color.White, true)
                        }
                        DropdownMenu(expanded = fMenu, onDismissRequest = { fMenu = false }) {
                            WkFilters.forEach { f ->
                                DropdownMenuItem(text = { Text((if (f == flt) "✔ " else "") + f) }, onClick = { flt = f; fMenu = false })
                            }
                        }
                    }
                    Row(Modifier.width(118.dp).height(56.dp).clip(RoundedCornerShape(6.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFB0B0B0), RoundedCornerShape(6.dp)).clickable { pickDate(ctx, day) { day = it } }.padding(horizontal = 6.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                        T("📅 " + fmtD(day), 11, Color.Black, true); T("▾", 12, Color.Black)
                    }
                    LF(q, Modifier.weight(1f), ph = "🔍 نام، شناختی نمبر یا عہدے سے تلاش کریں...") { q = it }
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WkAction("＋", "نیا ملازم شامل کریں", true) { wEdit = null; wDlg = true }
                    WkAction("💵", "تنخواہ کی فہرست", false) { go("salary") }
                    WkAction("📅", "حاضری رپورٹ", false) { share(ctx, wkAttText(all, day)) }
                    WkAction("📗", "ایکسل ایکسپورٹ", false) {
                        msg = if (all.isEmpty()) "ابھی کوئی ملازم نہیں" else try { wkCsv(ctx, rows, day); "" } catch (e: Exception) { "ایکسپورٹ نہیں ہو سکا" }
                    }
                    WkAction("🖨", "پرنٹ", false) {
                        msg = if (all.isEmpty()) "ابھی کوئی ملازم نہیں" else try { wkPrint(ctx, rows, day); "" } catch (e: Exception) { "پرنٹ نہیں ہو سکا" }
                    }
                }
                if (msg.isNotEmpty()) T(msg, 13, Color(0xFFC62828), true)
                Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(12.dp))) {
                    Row(Modifier.fillMaxWidth().background(WkGreenD).padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        T("👥 کام کرنے والے افراد کی فہرست", 15, Color.White, true, Modifier.weight(1f))
                        Text("کل افراد: ${rows.size}", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(6.dp)).background(WkGreen).padding(horizontal = 10.dp, vertical = 5.dp))
                    }
                    Column(Modifier.horizontalScroll(rememberScrollState())) {
                        WkHead()
                        rows.forEachIndexed { i, w ->
                            WkRow(i, w, day,
                                onAtt = { wkSetAtt(w, day, !wkAtt(w, day)) },
                                onStatus = {
                                    val ix = Store.entries.indexOfFirst { it.id == w.id }
                                    if (ix >= 0) { Store.entries[ix] = w.copy(status = if (w.status == "leave") "" else "leave"); Store.save() }
                                },
                                onView = { detail = w }, onEdit = { wEdit = w; wDlg = true }, onDel = { delW = w })
                        }
                    }
                    if (rows.isEmpty()) T(if (all.isEmpty()) "ابھی کوئی ملازم نہیں۔ اوپر سے نیا ملازم شامل کریں۔" else "کوئی ملازم نہیں ملا",
                        14, Color.Gray, m = Modifier.padding(16.dp))
                }
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(12.dp)).padding(vertical = 8.dp)) {
                    WkStatCell("📅", if (day == today) "آج کی حاضری" else "اس دن کی حاضری", presentN.toString(), Modifier.weight(1f))
                    WkStatCell("🕐", "حاضری اوسط", wkAvg(day, all).toString() + "%", Modifier.weight(1f))
                    WkStatCell("💰", "کل تنخواہ", money(all.sumOf { it.amount }), Modifier.weight(1.3f))
                    WkStatCell("👥", "کل ملازمین", all.size.toString(), Modifier.weight(1f))
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }

    if (wDlg) WkWorkerDialog(wEdit) { wDlg = false; wEdit = null }
    logFor?.let { w -> WkLogDialog(w, logEdit, day) { logFor = null; logEdit = null } }
    delW?.let { w ->
        AlertDialog(onDismissRequest = { delW = null }, title = { Text("ملازم حذف کریں") },
            text = { Text("${w.name} کو فہرست سے حذف کر دیں؟ (اس کی مزدوری/سونے کا ریکارڈ رپورٹس میں باقی رہے گا)") },
            confirmButton = { TextButton(onClick = { Store.entries.remove(w); Store.save(); delW = null; detail = null }) { Text("ہاں، حذف کریں") } },
            dismissButton = { TextButton(onClick = { delW = null }) { Text("منسوخ") } })
    }
    dw?.let { w ->
        val n = w.name
        val logs = wkLogs(n, null).filter { it.status != "nothing" }
            .sortedWith(compareByDescending<Entry> { it.date }.thenByDescending { it.id })
        val hm = wkHM(wkMins(n, null))
        val summary = "${w.name} (ID: ${wkId(w)})\nعہدہ: ${wkRole(w).ifBlank { "—" }}\nشناختی نمبر: ${w.cnic.ifBlank { "—" }}\n" +
                "موبائل: ${wkPhone(w).ifBlank { "—" }}\nماہانہ تنخواہ: ${if (w.amount > 0) money(w.amount) else "—"}\n" +
                "کل سونا ملا: ${wkG(wkGold(n, null))}\nکل تیار سونا: ${wkG(wkReady(n, null))}\n" +
                "کل مزدوری: ${money(wkWage(n, null))}\nادا شدہ: ${money(wkPaid(n, null))}\nبقایا: ${money(wkWage(n, null) - wkPaid(n, null))}\nکل وقت: ${hm.first} ${hm.second}"
        AlertDialog(onDismissRequest = { detail = null }, title = { Text(w.name) },
            confirmButton = { TextButton(onClick = { logEdit = null; logFor = w }) { Text("＋ نیا اندراج") } },
            dismissButton = { TextButton(onClick = { detail = null }) { Text("بند کریں") } },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkAvatar(w.photo, w.gender, w.name, w.id, 56)
                        Text(summary)
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        Btn("✏️ ایڈٹ", WkBlue, Modifier.weight(1f)) { wEdit = w; wDlg = true }
                        Btn("📤 شیئر", Color(0xFF6A1B9A), Modifier.weight(1f)) { share(ctx, "${Store.prefs["shop"]}\n$summary") }
                        Btn("🗑 حذف", WkRed, Modifier.weight(1f)) { delW = w }
                    }
                    T("📋 پچھلے اندراجات", 14, Gold, true)
                    if (logs.isEmpty()) T("کوئی اندراج نہیں", 12, Color.Gray)
                    logs.take(40).forEach { e ->
                        val t = wkHM(e.mins)
                        Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFF222222)).padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                T(fmtD(e.date), 12, Color.White, true)
                                T("سونا ${fmtW(e.weight)}g • تیار ${fmtW(e.ready)}g • ${money(e.amount)} • ${t.first} ${t.second}", 11, Color.LightGray)
                                if (e.note.isNotBlank()) T(e.note, 11, Color.Gray)
                            }
                            Text("✏️", fontSize = 20.sp, modifier = Modifier.clickable { logEdit = e; logFor = w }.padding(6.dp))
                            Text("🗑", fontSize = 20.sp, modifier = Modifier.clickable { Store.entries.remove(e); Store.save() }.padding(6.dp))
                        }
                    }
                }
            })
    }
}

// ---------------- Attendance screen ----------------
@Composable
fun AttendanceScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    var day by remember { mutableStateOf(LocalDate.now().toString()) }
    val all = wkWorkers()
    val pres = all.count { wkAtt(it, day) }
    Column(Modifier.fillMaxSize().background(WkBg)) {
        WkHeader("حاضری", "روزانہ حاضری کا مکمل ریکارڈ", "حاضر  •  غیر حاضر  •  رپورٹ")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            WkNav("attendance", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(10.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Act("▶", WkGreen) { day = LocalDate.parse(day).minusDays(1).toString() }
                    T("📅 " + fmtD(day), 16, Color.Black, true, Modifier.weight(1f).clickable { pickDate(ctx, day) { day = it } }, TextAlign.Center)
                    Act("◀", WkGreen) { day = LocalDate.parse(day).plusDays(1).toString() }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WkMoney("کل افراد", all.size.toString(), WkGreen, Modifier.weight(1f))
                    WkMoney("حاضر", pres.toString(), WkBlue, Modifier.weight(1f))
                    WkMoney("غیر حاضر", (all.size - pres).toString(), WkRed, Modifier.weight(1f))
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Btn("✅ سب حاضر", WkGreen, Modifier.weight(1f)) { all.forEach { wkSetAtt(it, day, true) } }
                    Btn("❌ سب غیر حاضر", WkRed, Modifier.weight(1f)) { all.forEach { wkSetAtt(it, day, false) } }
                    Btn("📤 رپورٹ", Color(0xFF6A1B9A), Modifier.weight(1f)) { share(ctx, wkAttText(all, day)) }
                }
                if (all.isEmpty()) T("ابھی کوئی ملازم نہیں۔ پہلے \"کام کرنے والی\" میں ملازم شامل کریں۔", 14, Color.Gray, m = Modifier.padding(16.dp))
                all.forEach { w ->
                    val att = wkAtt(w, day)
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(12.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkAvatar(w.photo, w.gender, w.name, w.id, 44)
                        Column(Modifier.weight(1f)) {
                            T(w.name, 15, Color.Black, true)
                            T(wkRole(w).ifBlank { "—" }, 11, Color.Gray)
                        }
                        Text("حاضر", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (att) WkGreen else Color(0xFFB0BEC5))
                                .clickable { wkSetAtt(w, day, true) }.padding(horizontal = 12.dp, vertical = 8.dp))
                        Text("غیر حاضر", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.clip(RoundedCornerShape(8.dp)).background(if (!att) WkRed else Color(0xFFB0BEC5))
                                .clickable { wkSetAtt(w, day, false) }.padding(horizontal = 12.dp, vertical = 8.dp))
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

// ---------------- Salary screen ----------------
@Composable
fun SalaryScreen(go: (String) -> Unit) {
    val ctx = LocalContext.current
    val today = LocalDate.now().toString()
    var month by remember { mutableStateOf(today.take(7)) }
    var payFor by remember { mutableStateOf<Entry?>(null) }
    var edit by remember { mutableStateOf<Entry?>(null) }
    val all = wkWorkers()
    val total = all.sumOf { it.amount }
    val paid = all.sumOf { wkSalPaid(it, month) }
    Column(Modifier.fillMaxSize().background(WkBg)) {
        WkHeader("تنخواہ", "ماہانہ تنخواہ اور ادائیگی کا ریکارڈ", "تنخواہ  •  ادا شدہ  •  بقایا")
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState())) {
            WkNav("salary", go)
            Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(10.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Act("▶", WkGreen) { month = LocalDate.parse("$month-01").minusMonths(1).toString().take(7) }
                    T("📅 " + wkMonthLbl(month), 16, Color.Black, true, Modifier.weight(1f), TextAlign.Center)
                    Act("◀", WkGreen) { month = LocalDate.parse("$month-01").plusMonths(1).toString().take(7) }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    WkMoney("کل تنخواہ", money(total), WkBlue, Modifier.weight(1f))
                    WkMoney("ادا شدہ", money(paid), WkGreen, Modifier.weight(1f))
                    WkMoney("بقایا", money((total - paid).coerceAtLeast(0.0)), WkRed, Modifier.weight(1f))
                }
                Btn("📤 تنخواہ کی فہرست شیئر کریں", Color(0xFF6A1B9A), Modifier.fillMaxWidth()) {
                    share(ctx, "${Store.prefs["shop"]}\nتنخواہ کی فہرست (${wkMonthLbl(month)})\n" + all.joinToString("\n") {
                        val p = wkSalPaid(it, month)
                        "${it.name}: تنخواہ ${money(it.amount)} | ادا ${money(p)} | بقایا ${money((it.amount - p).coerceAtLeast(0.0))}"
                    } + "\nکل تنخواہ: ${money(total)} | ادا شدہ: ${money(paid)}")
                }
                if (all.isEmpty()) T("ابھی کوئی ملازم نہیں۔ پہلے \"کام کرنے والی\" میں ملازم شامل کریں۔", 14, Color.Gray, m = Modifier.padding(16.dp))
                all.forEach { w ->
                    val p = wkSalPaid(w, month)
                    val due = (w.amount - p).coerceAtLeast(0.0)
                    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White).border(1.dp, WkLine, RoundedCornerShape(12.dp)).padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        WkAvatar(w.photo, w.gender, w.name, w.id, 44)
                        Column(Modifier.weight(1f)) {
                            T(w.name, 15, Color.Black, true)
                            T(wkRole(w).ifBlank { "—" }, 11, Color.Gray)
                            T("تنخواہ: " + (if (w.amount > 0) money(w.amount) else "مقرر نہیں"), 12, Color.Black)
                            T("ادا: ${money(p)}  •  بقایا: ${money(due)}", 11, if (due > 0) WkRed else WkGreen, true)
                        }
                        Column(Modifier.width(96.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                            if (w.amount <= 0) Btn("✏️ تنخواہ مقرر", WkBlue, Modifier.fillMaxWidth()) { edit = w }
                            else if (due > 0) Btn("💵 ادا کریں", WkGreen, Modifier.fillMaxWidth()) { payFor = w }
                            else T("✅ مکمل ادا", 12, WkGreen, true, Modifier.fillMaxWidth(), TextAlign.Center)
                            if (p > 0) Text("↩ آخری ادائیگی ہٹائیں", color = WkRed, fontSize = 10.sp, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().clickable {
                                    val last = Store.entries.lastOrNull { it.type == "salpay" && it.name.trim() == w.name.trim() && it.date.startsWith(month) }
                                    if (last != null) { Store.entries.remove(last); Store.save() }
                                })
                        }
                    }
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
    edit?.let { w -> WkWorkerDialog(w) { edit = null } }
    payFor?.let { w ->
        val due = (w.amount - wkSalPaid(w, month)).coerceAtLeast(0.0)
        var amt by remember(w.id) { mutableStateOf(if (due > 0) fmtW(due) else "") }
        AlertDialog(onDismissRequest = { payFor = null }, title = { Text("${w.name} — تنخواہ ادا کریں") },
            text = { Column(verticalArrangement = Arrangement.spacedBy(6.dp)) { Text("بقایا: ${money(due)}"); F("رقم (Rs.)", amt, true) { amt = it } } },
            confirmButton = {
                TextButton(onClick = {
                    if (num(amt) > 0) {
                        Store.entries.add(Entry(id = wkNewId(), type = "salpay", name = w.name, weight = 0.0, amount = num(amt), note = "تنخواہ",
                            date = if (month == today.take(7)) today else "$month-01"))
                        Store.save(); payFor = null
                    }
                }) { Text("محفوظ کریں") }
            },
            dismissButton = { TextButton(onClick = { payFor = null }) { Text("منسوخ") } })
    }
}

// ---------------- add / edit dialog ----------------
@Composable
internal fun WkWorkerDialog(init: Entry?, close: () -> Unit) {
    val ctx = LocalContext.current
    var n by remember { mutableStateOf(init?.name ?: "") }
    var role by remember { mutableStateOf(init?.let { wkRole(it) } ?: "") }
    var cnic by remember { mutableStateOf(init?.cnic ?: "") }
    var p by remember { mutableStateOf(init?.let { wkPhone(it) } ?: "") }
    var sal by remember { mutableStateOf(init?.let { if (it.amount > 0) fmtW(it.amount) else "" } ?: "") }
    var gender by remember { mutableStateOf(init?.gender ?: "") }
    var photo by remember { mutableStateOf(init?.photo ?: "") }
    var rt by remember { mutableStateOf(init?.let { if (it.rate > 0) fmtW(it.rate) else "" } ?: "") }
    var err by remember { mutableStateOf("") }
    val newId = remember { init?.id ?: System.currentTimeMillis() }
    val pick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) { val f = wkSavePhoto(ctx, uri, newId); if (f.isNotEmpty()) photo = f }
    }
    AlertDialog(onDismissRequest = close, title = { Text(if (init == null) "نیا ملازم شامل کریں" else "ملازم ایڈٹ کریں") },
        confirmButton = {
            TextButton(onClick = {
                if (n.isBlank()) err = "نام درج کریں ⚠️" else {
                    val old = init?.name
                    val base = init ?: Entry(id = newId, type = "worker", name = "", weight = 0.0, amount = 0.0,
                        note = "", date = LocalDate.now().toString())
                    val e = base.copy(name = n.trim(), note = role.trim(), phone = p.trim(), cnic = cnic.trim(), amount = num(sal), rate = num(rt),
                        gender = gender, photo = photo, bill = "v2")
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else Store.entries.add(e)
                    if (old != null && old.trim() != n.trim()) {
                        for (ix in Store.entries.indices) {
                            val x = Store.entries[ix]
                            if ((x.type == "wage" || x.type == "hours" || x.type == "attend" || x.type == "salpay") && x.name.trim() == old.trim())
                                Store.entries[ix] = x.copy(name = n.trim())
                        }
                    }
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    WkAvatar(photo, gender, n.ifBlank { "؟" }, newId, 64)
                    Btn("📷 تصویر منتخب کریں", WkBlue, Modifier.weight(1f)) { pick.launch("image/*") }
                    if (photo.isNotEmpty()) Btn("✖", WkRed, Modifier.width(48.dp)) { photo = "" }
                }
                F("نام", n) { n = it }
                F("عہدہ", role) { role = it }
                F("شناختی نمبر", cnic) { cnic = it }
                F("فون نمبر", p) { p = it }
                F("ماہانہ تنخواہ (Rs.)", sal, true) { sal = it }
                F("فی گھنٹہ ریٹ (Rs.)", rt, true) { rt = it }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    MChip("👨 مرد", WkBlue, gender == "مرد", Modifier.weight(1f)) { gender = "مرد" }
                    MChip("👩 عورت", WkPink, gender == "عورت", Modifier.weight(1f)) { gender = "عورت" }
                }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}

@Composable
internal fun WkLogDialog(w: Entry, init: Entry?, day: String, close: () -> Unit) {
    val ctx = LocalContext.current
    var d by remember { mutableStateOf(init?.date ?: day) }
    var g by remember { mutableStateOf(init?.let { fmtW(it.weight) } ?: "") }
    var rd by remember { mutableStateOf(init?.let { fmtW(it.ready) } ?: "") }
    var wg by remember { mutableStateOf(init?.let { fmtW(it.amount) } ?: "") }
    var pd by remember { mutableStateOf(init?.let { fmtW(it.paid) } ?: "") }
    var h by remember { mutableStateOf(init?.let { (it.mins.toInt() / 60).toString() } ?: "") }
    var m by remember { mutableStateOf(init?.let { (it.mins.toInt() % 60).toString() } ?: "") }
    var nt by remember { mutableStateOf(init?.note ?: "") }
    var err by remember { mutableStateOf("") }
    AlertDialog(onDismissRequest = close, title = { Text(w.name + " — " + (if (init == null) "نیا اندراج" else "اندراج ایڈٹ")) },
        confirmButton = {
            TextButton(onClick = {
                if (num(g) <= 0 && num(rd) <= 0 && num(wg) <= 0 && num(h) <= 0 && num(m) <= 0) err = "کم از کم ایک رقم / وزن / وقت درج کریں ⚠️" else {
                    val base = init ?: Entry(id = System.currentTimeMillis(), type = "wage", name = w.name, weight = 0.0, amount = 0.0,
                        note = "", date = d)
                    val mins = num(h) * 60 + num(m)
                    val amt = if (num(wg) <= 0 && w.rate > 0 && mins > 0) Math.round(mins / 60.0 * w.rate).toDouble() else num(wg)
                    val e = base.copy(name = w.name, weight = num(g), ready = num(rd), amount = amt,
                        paid = if (pd.isBlank()) amt else num(pd), mins = mins, note = nt.trim(), date = d, status = "")
                    val i = Store.entries.indexOfFirst { it.id == e.id }
                    if (i >= 0) Store.entries[i] = e else {
                        Store.entries.removeAll { it.type == "wage" && it.status == "nothing" && it.name.trim() == w.name.trim() && it.date == d }
                        Store.entries.add(e)
                    }
                    Store.save(); close()
                }
            }) { Text("محفوظ کریں") }
        },
        dismissButton = { TextButton(onClick = close) { Text("منسوخ") } },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).border(1.dp, Color.Gray, RoundedCornerShape(6.dp))
                    .clickable { pickDate(ctx, d) { d = it } }.padding(12.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    T("📅 تاریخ", 13, Color.LightGray); T(fmtD(d), 14, Color.White, true)
                }
                F("سونا ملا (گرام)", g, true) { g = it }
                F("تیار سونا واپس (گرام)", rd, true) { rd = it }
                F(if (w.rate > 0) "مزدوری (Rs.) — خالی = گھنٹے × ریٹ" else "مزدوری (Rs.)", wg, true) { wg = it }
                F("ادا شدہ مزدوری (خالی = پوری)", pd, true) { pd = it }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Box(Modifier.weight(1f)) { F("گھنٹے", h, true) { h = it } }
                    Box(Modifier.weight(1f)) { F("منٹ", m, true) { m = it } }
                }
                F("نوٹ", nt) { nt = it }
                if (err.isNotEmpty()) T(err, 12, Color(0xFFEF5350))
            }
        })
}
