package com.example.pdfreader

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import android.os.Bundle
import android.os.ParcelFileDescriptor
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class MainActivity : AppCompatActivity() {

    private lateinit var list: RecyclerView
    private lateinit var hint: TextView
    private var renderer: PdfRenderer? = null
    private var pfd: ParcelFileDescriptor? = null
    private var currentUri: Uri? = null

    private val picker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            if (uri != null) {
                try {
                    contentResolver.takePersistableUriPermission(
                        uri, Intent.FLAG_GRANT_READ_URI_PERMISSION
                    )
                } catch (_: Exception) {
                }
                openPdf(uri)
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        title = "PDF Reader"

        val root = FrameLayout(this)
        list = RecyclerView(this)
        list.layoutManager = LinearLayoutManager(this)
        hint = TextView(this).apply {
            text = "اوپر ⋮ مینیو سے PDF کھولیں"
            gravity = Gravity.CENTER
            textSize = 18f
        }
        root.addView(list, FrameLayout.LayoutParams(-1, -1))
        root.addView(hint, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        val i = intent
        if (i?.action == Intent.ACTION_VIEW) {
            i.data?.let { openPdf(it) }
        }
    }

    private fun toast(msg: String) {
        Toast.makeText(this, msg, Toast.LENGTH_LONG).show()
    }

    private fun openPdf(uri: Uri) {
        try {
            renderer?.close()
            pfd?.close()
            val d = contentResolver.openFileDescriptor(uri, "r") ?: return
            pfd = d
            val r = PdfRenderer(d)
            renderer = r
            currentUri = uri
            list.adapter = PageAdapter(r, resources.displayMetrics.widthPixels)
            hint.visibility = View.GONE
            title = fileName(uri)
        } catch (e: Exception) {
            toast("PDF نہیں کھل سکی")
        }
    }

    private fun fileName(uri: Uri): String {
        try {
            contentResolver.query(uri, null, null, null, null)?.use { c ->
                if (c.moveToFirst()) {
                    val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                    if (idx >= 0) return c.getString(idx)
                }
            }
        } catch (_: Exception) {
        }
        return uri.lastPathSegment ?: "PDF"
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menu.add(0, 1, 0, "📂 PDF کھولیں")
        menu.add(0, 2, 1, "🏠 PDF کو Home Screen پر شامل کریں")
        menu.add(0, 3, 2, "📤 PDF شیئر کریں")
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            1 -> picker.launch(arrayOf("application/pdf"))
            2 -> addShortcut()
            3 -> sharePdf()
        }
        return true
    }

    private fun addShortcut() {
        val uri = currentUri
        if (uri == null) {
            toast("پہلے PDF کھولیں")
            return
        }
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toast("آپ کا لانچر شارٹ کٹ کی سپورٹ نہیں کرتا")
            return
        }
        val intent = Intent(this, MainActivity::class.java).apply {
            action = Intent.ACTION_VIEW
            data = uri
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        val info = ShortcutInfoCompat.Builder(this, "pdf_" + uri.toString().hashCode())
            .setShortLabel(fileName(uri).take(25))
            .setIcon(makeIcon())
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
    }

    private fun makeIcon(): IconCompat {
        val bmp = Bitmap.createBitmap(192, 192, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.parseColor("#D32F2F"))
        val p = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 70f
            textAlign = Paint.Align.CENTER
            typeface = Typeface.DEFAULT_BOLD
        }
        c.drawText("PDF", 96f, 120f, p)
        return IconCompat.createWithBitmap(bmp)
    }

    private fun sharePdf() {
        val uri = currentUri
        if (uri == null) {
            toast("پہلے PDF کھولیں")
            return
        }
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(send, "شیئر کریں"))
    }

    override fun onDestroy() {
        super.onDestroy()
        renderer?.close()
        pfd?.close()
    }
}

class PageAdapter(
    private val r: PdfRenderer,
    private val w: Int
) : RecyclerView.Adapter<PageAdapter.VH>() {

    class VH(val img: ImageView) : RecyclerView.ViewHolder(img)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val iv = ImageView(parent.context)
        iv.layoutParams = RecyclerView.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        iv.adjustViewBounds = true
        iv.setBackgroundColor(Color.WHITE)
        return VH(iv)
    }

    override fun getItemCount(): Int = r.pageCount

    override fun onBindViewHolder(holder: VH, position: Int) {
        synchronized(r) {
            val page = r.openPage(position)
            val h = (w.toFloat() * page.height / page.width).toInt()
            val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(Color.WHITE)
            page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            page.close()
            holder.img.setImageBitmap(bmp)
        }
    }
}
