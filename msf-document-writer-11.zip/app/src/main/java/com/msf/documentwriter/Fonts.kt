package com.msf.documentwriter

import android.content.Context
import android.graphics.Typeface
import android.text.TextPaint
import android.text.style.TypefaceSpan
import androidx.compose.runtime.mutableStateListOf
import java.io.File

/**
 * Custom fonts: bundled ones live in assets/fonts, fonts added by the user are copied to filesDir/fonts.
 * A font is referenced everywhere (spans, docx, Doc.font) by its label, which doubles as its family name.
 */
object Fonts {
    private val builtIn = listOf(
        "Default" to "sans-serif", "Serif" to "serif", "Monospace" to "monospace", "Casual" to "casual",
        "Cursive" to "cursive", "Noto Naskh Arabic" to "Noto Naskh Arabic", "Noto Nastaliq Urdu" to "Noto Nastaliq Urdu"
    )
    private val bundled = listOf(
        "Jameel Noori Nastaleeq" to "jameel_noori_nastaleeq.ttf",
        "Jameel Noori Kasheeda" to "jameel_noori_kasheeda.ttf",
        "Al Qalam Quran" to "al_qalam_quran.ttf",
        "Al Qalam Quran 2" to "al_qalam_quran_2.ttf",
        "Al Qalam Quran 2A" to "al_qalam_quran_2a.ttf",
        "Al Qalam Quran Majeed" to "al_qalam_quran_majeed.ttf",
        "Al Qalam Quran Majeed 2" to "al_qalam_quran_majeed_2.ttf",
        "Al Qalam Kolkata Quranic" to "al_qalam_kolkata.ttf",
        "Al Majeed Quranic" to "al_majeed_quranic.ttf",
        "Al Mushaf Quran" to "al_mushaf.ttf",
        "Aayat Quraan 031" to "aayat_quraan_031.ttf"
    )

    private lateinit var app: Context
    private val cache = HashMap<String, Typeface?>()
    private val files = HashMap<String, File>()
    /** Observable so the font menu refreshes after a font is added. */
    private val extra = mutableStateListOf<String>()

    fun init(c: Context) {
        if (this::app.isInitialized) return
        app = c.applicationContext
        reloadUserFonts()
    }

    private fun dir(): File = File(app.filesDir, "fonts").also { it.mkdirs() }

    private fun reloadUserFonts() {
        files.clear(); extra.clear()
        dir().listFiles()?.filter { it.isFile && it.name.lowercase().let { n -> n.endsWith(".ttf") || n.endsWith(".otf") } }
            ?.sortedBy { it.name.lowercase() }?.forEach {
                val label = it.nameWithoutExtension
                files[label] = it
                extra.add(label)
            }
    }

    /** (label, family) pairs for the font menu. */
    fun all(): List<Pair<String, String>> =
        builtIn + bundled.map { it.first to it.first } + extra.map { it to it }

    /** Typeface for a custom font family, or null when the family is a system one. */
    fun custom(family: String?): Typeface? {
        if (family == null || !this::app.isInitialized) return null
        if (cache.containsKey(family)) return cache[family]
        val tf = try {
            val asset = bundled.firstOrNull { it.first == family }?.second
            when {
                asset != null -> Typeface.createFromAsset(app.assets, "fonts/$asset")
                files[family] != null -> Typeface.createFromFile(files[family])
                else -> null
            }
        } catch (e: Throwable) { null }
        if (tf != null) cache[family] = tf
        return tf
    }

    /** Any font (custom or system) by family name. */
    fun typeface(family: String?): Typeface =
        custom(family) ?: Typeface.create(family ?: "sans-serif", Typeface.NORMAL)

    /** Copy a font picked by the user into the app. Returns the label, or null when it isn't a usable font. */
    fun add(c: Context, uri: android.net.Uri, displayName: String?): String? {
        init(c)
        val raw = (displayName ?: "font").substringAfterLast('/')
        var ext = raw.substringAfterLast('.', "").lowercase()
        if (ext != "ttf" && ext != "otf") {
            // the picker may hide the real file name: look at the file header instead
            val head = ByteArray(4)
            val n = try { c.contentResolver.openInputStream(uri)?.use { it.read(head) } ?: 0 } catch (e: Throwable) { 0 }
            val tag = String(head, Charsets.ISO_8859_1)
            ext = when {
                n < 4 -> return null
                tag == "OTTO" -> "otf"
                tag == "true" || (head[0].toInt() == 0 && head[1].toInt() == 1 && head[2].toInt() == 0 && head[3].toInt() == 0) -> "ttf"
                else -> return null
            }
        }
        val base = if (raw.contains('.')) raw.substringBeforeLast('.') else raw
        var label = base.replace(Regex("[^\\p{L}\\p{N} ._-]"), "_").trim().ifBlank { "Font ${System.currentTimeMillis() % 10000}" }
        if (builtIn.any { it.first == label } || bundled.any { it.first == label }) label += " (custom)"
        // replace an older copy of the same font regardless of its extension
        File(dir(), "$label.ttf").delete(); File(dir(), "$label.otf").delete()
        val dst = File(dir(), "$label.$ext")
        return try {
            c.contentResolver.openInputStream(uri)!!.use { i -> dst.outputStream().use { o -> i.copyTo(o) } }
            Typeface.createFromFile(dst)
            cache.remove(label)
            reloadUserFonts()
            label
        } catch (e: Throwable) { dst.delete(); null }
    }
}

/** TypefaceSpan that also understands custom font families (works from API 24 and in PDF/Image rendering). */
class FontSpan(family: String) : TypefaceSpan(family) {
    override fun updateDrawState(ds: TextPaint) { if (!applyFont(ds)) super.updateDrawState(ds) }
    override fun updateMeasureState(paint: TextPaint) { if (!applyFont(paint)) super.updateMeasureState(paint) }

    private fun applyFont(p: TextPaint): Boolean {
        val base = Fonts.custom(family) ?: return false
        val old = p.typeface
        val style = old?.style ?: 0
        val tf = Typeface.create(base, style)
        val fake = style and tf.style.inv()
        if ((fake and Typeface.BOLD) != 0) p.isFakeBoldText = true
        if ((fake and Typeface.ITALIC) != 0) p.textSkewX = -0.25f
        p.typeface = tf
        return true
    }
}
