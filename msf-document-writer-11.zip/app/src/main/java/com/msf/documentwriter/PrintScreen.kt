@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.print.PrintAttributes
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream

// ───────────────────────── helpers ─────────────────────────

/** Renders one page of a PDF. Returns the bitmap and the total page count. */
fun renderPdfPage(f: File, index: Int, width: Int): Pair<Bitmap?, Int> {
    var pfd: ParcelFileDescriptor? = null
    var r: PdfRenderer? = null
    return try {
        pfd = ParcelFileDescriptor.open(f, ParcelFileDescriptor.MODE_READ_ONLY)
        r = PdfRenderer(pfd)
        val n = r.pageCount
        if (n == 0) return Pair(null, 0)
        val pg = r.openPage(index.coerceIn(0, n - 1))
        try {
            val h = (width.toFloat() * pg.height / pg.width).toInt().coerceAtLeast(1)
            val bmp = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            bmp.eraseColor(android.graphics.Color.WHITE)
            pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
            Pair(bmp, n)
        } finally { pg.close() }
    } catch (e: Exception) {
        Pair(null, 0)
    } finally {
        try { r?.close() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
    }
}

/** Builds a PDF that contains the pages of [src] repeated [copies] times (collated). */
fun repeatPdf(c: Context, src: File, copies: Int, scale: Float): File? {
    if (copies <= 1) return src
    val out = File(c.cacheDir, "copies_" + src.name)
    var pfd: ParcelFileDescriptor? = null
    var r: PdfRenderer? = null
    val doc = PdfDocument()
    return try {
        pfd = ParcelFileDescriptor.open(src, ParcelFileDescriptor.MODE_READ_ONLY)
        r = PdfRenderer(pfd)
        var n = 0
        for (copy in 0 until copies) {
            for (i in 0 until r.pageCount) {
                val pg = r.openPage(i)
                val w = pg.width
                val h = pg.height
                val bmp = Bitmap.createBitmap((w * scale).toInt(), (h * scale).toInt(), Bitmap.Config.ARGB_8888)
                bmp.eraseColor(android.graphics.Color.WHITE)
                pg.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_PRINT)
                pg.close()
                n++
                val page = doc.startPage(PdfDocument.PageInfo.Builder(w, h, n).create())
                page.canvas.drawBitmap(bmp, null, Rect(0, 0, w, h), Paint(Paint.FILTER_BITMAP_FLAG))
                doc.finishPage(page)
                bmp.recycle()
            }
        }
        FileOutputStream(out).use { doc.writeTo(it) }
        out
    } catch (e: Exception) {
        null
    } finally {
        try { doc.close() } catch (_: Exception) {}
        try { r?.close() } catch (_: Exception) {}
        try { pfd?.close() } catch (_: Exception) {}
    }
}

private fun buildAttrs(paper: Int, land: Boolean, quality: Int, color: Boolean, margins: Int, duplex: Boolean): PrintAttributes {
    var size = when (paper) {
        1 -> PrintAttributes.MediaSize.NA_LETTER
        2 -> PrintAttributes.MediaSize.NA_LEGAL
        else -> PrintAttributes.MediaSize.ISO_A4
    }
    size = if (land) size.asLandscape() else size.asPortrait()
    val dpi = when (quality) { 0 -> 150; 2 -> 600; else -> 300 }
    val m = if (margins == 0) PrintAttributes.Margins.NO_MARGINS else PrintAttributes.Margins(500, 500, 500, 500)
    return PrintAttributes.Builder()
        .setMediaSize(size)
        .setResolution(PrintAttributes.Resolution("msf", "MSF", dpi, dpi))
        .setMinMargins(m)
        .setColorMode(if (color) PrintAttributes.COLOR_MODE_COLOR else PrintAttributes.COLOR_MODE_MONOCHROME)
        .setDuplexMode(if (duplex) PrintAttributes.DUPLEX_MODE_LONG_EDGE else PrintAttributes.DUPLEX_MODE_NONE)
        .build()
}

@Composable
private fun DropField(label: String, icon: ImageVector, value: String, options: List<String>, onPick: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(8.dp))
        Column(Modifier.weight(1f)) {
            Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0A2A66))
            Box {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).background(Color(0xFFF4F8FF))
                        .border(1.dp, Color(0xFFCFDCF2), RoundedCornerShape(8.dp))
                        .clickable { open = true }.padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(value, Modifier.weight(1f), fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Icon(Icons.Filled.KeyboardArrowDown, null, tint = Color(0xFF334155), modifier = Modifier.size(18.dp))
                }
                DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
                    options.forEachIndexed { i, o -> DropdownMenuItem(text = { Text(o) }, onClick = { open = false; onPick(i) }) }
                }
            }
        }
    }
}

@Composable
private fun QuickTile(icon: ImageVector, tint: Color, title: String, sub: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.dp, Color(0xFFCFDCF2), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 4.dp, vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(36.dp))
        Spacer(Modifier.height(4.dp))
        Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, textAlign = TextAlign.Center, color = Color(0xFF0A2A66), maxLines = 2)
        Text(sub, fontSize = 10.sp, color = Color.Gray, textAlign = TextAlign.Center, maxLines = 2)
    }
}

@Composable
private fun PagePreview(pdf: File, index: Int) {
    val bmp by produceState<Bitmap?>(null, pdf, index) {
        value = withContext(Dispatchers.IO) { renderPdfPage(pdf, index, 1000).first }
    }
    val b = bmp
    if (b != null) Image(
        b.asImageBitmap(), null, Modifier.fillMaxWidth().padding(bottom = 10.dp).background(Color.White),
        contentScale = ContentScale.FillWidth
    ) else Box(Modifier.fillMaxWidth().height(220.dp), contentAlignment = Alignment.Center) { CircularProgressIndicator(color = Color.White) }
}

@Composable
private fun PreviewDialog(pdf: File, pages: Int, onClose: () -> Unit) {
    Dialog(onDismissRequest = onClose, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color(0xFF37474F)) {
            Column(Modifier.fillMaxSize().statusBarsPadding()) {
                Row(Modifier.fillMaxWidth().padding(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = onClose) { Icon(Icons.Filled.Close, null, tint = Color.White) }
                    Text("Preview / پری ویو  ($pages)", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                }
                LazyColumn(Modifier.fillMaxSize().padding(horizontal = 10.dp)) {
                    items(pages) { i -> PagePreview(pdf, i) }
                }
            }
        }
    }
}

// ───────────────────────── PRINT SCREEN ─────────────────────────
@Composable
fun PrintScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tick by remember { mutableIntStateOf(0) }
    val files = remember(tick) { Store.list(ctx) }
    var selected by remember { mutableStateOf<File?>(null) }
    val cur: File? = selected?.takeIf { it.exists() } ?: files.firstOrNull()

    var printer by remember { mutableIntStateOf(0) }
    var copies by remember { mutableIntStateOf(1) }
    var paper by remember { mutableIntStateOf(Prefs.paper(ctx)) }
    var land by remember { mutableStateOf(Prefs.landscape(ctx)) }
    var color by remember { mutableStateOf(true) }
    var qual by remember { mutableIntStateOf(Prefs.quality(ctx)) }
    var margins by remember { mutableIntStateOf(0) }
    var duplex by remember { mutableStateOf(false) }

    var pdf by remember { mutableStateOf<File?>(null) }
    var bmp by remember { mutableStateOf<Bitmap?>(null) }
    var page by remember { mutableIntStateOf(0) }
    var pages by remember { mutableIntStateOf(0) }
    var loading by remember { mutableStateOf(false) }
    var busy by remember { mutableStateOf(false) }
    var dlg by remember { mutableStateOf("") }

    val paperNames = listOf("A4 (210 × 297 mm)", "Letter (8.5 × 11 in)", "Legal (8.5 × 14 in)")
    val qualNames = listOf("Draft", "Normal", "High")
    val printerNames = listOf("System Print Service", "Save as PDF")

    LaunchedEffect(cur?.absolutePath, cur?.lastModified(), paper, land) {
        page = 0; pdf = null; pages = 0; bmp = null
        val f = cur
        if (f != null) {
            loading = true
            pdf = withContext(Dispatchers.IO) {
                if (f.extension.lowercase() == "pdf") f else Converter.toTempPdf(ctx, f, paper, land)
            }
            loading = false
        }
    }
    LaunchedEffect(pdf, page) {
        val p = pdf
        if (p == null) { bmp = null } else {
            val r = withContext(Dispatchers.IO) { renderPdfPage(p, page, 700) }
            bmp = r.first; pages = r.second
        }
    }

    val saveL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { u ->
        val p = pdf
        if (u != null && p != null) {
            toast(ctx, try {
                ctx.contentResolver.openOutputStream(u)?.use { o -> p.inputStream().use { it.copyTo(o) } }
                "PDF محفوظ ہو گئی / PDF saved"
            } catch (_: Exception) { "محفوظ نہیں ہو سکی / Save failed" })
        }
    }

    fun attrs() = buildAttrs(paper, land, qual, color, margins, duplex)

    fun saveAsPdf() {
        val f = cur
        if (f == null || pdf == null) { toast(ctx, "پہلے کوئی دستاویز منتخب کریں / Select a document first"); return }
        saveL.launch(f.nameWithoutExtension + ".pdf")
    }

    fun doPrint() {
        val f = cur
        val p = pdf
        if (f == null) { toast(ctx, "کوئی دستاویز نہیں / No document to print"); return }
        if (p == null) { toast(ctx, "دستاویز تیار ہو رہی ہے… / Preparing document…"); return }
        if (printer == 1) { saveAsPdf(); return }
        scope.launch {
            busy = true
            val scale = when (qual) { 0 -> 1.5f; 2 -> 3.5f; else -> 2.5f }
            val src = withContext(Dispatchers.IO) { repeatPdf(ctx, p, copies, scale) }
            busy = false
            if (src == null) toast(ctx, "پرنٹ تیار نہیں ہو سکا / Could not prepare print")
            else Actions.printPdf(ctx, f.name, src, attrs())
        }
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader(
                "اپنے دستاویزات کو پرنٹ کریں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) },
                menu = listOf(
                    "Select document / دستاویز منتخب کریں" to { dlg = "pick" },
                    "My Documents / میری فائلیں" to { goTo(nav, "docs/browse") },
                    "Settings / سیٹنگز" to { goTo(nav, "settings") }
                )
            )
        },
        bottomBar = { MainBar(nav, 3) }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.Top) {
                // ── preview card
                Card(
                    Modifier.weight(1f), shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFCFDCF2))
                ) {
                    Column(Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Box(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(6.dp)).background(Color(0xFFF4F8FF))
                                .border(1.dp, Color(0xFFCFDCF2), RoundedCornerShape(6.dp)).clickable { dlg = "pick" },
                            contentAlignment = Alignment.Center
                        ) {
                            val b = bmp
                            if (b != null) Image(b.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.FillWidth)
                            else Column(Modifier.fillMaxWidth().height(200.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                                if (loading) CircularProgressIndicator(color = Blue)
                                else {
                                    Icon(Icons.Filled.Description, null, tint = Blue, modifier = Modifier.size(40.dp))
                                    Text(
                                        if (cur == null) "کوئی دستاویز نہیں\nNo documents" else "پری ویو دستیاب نہیں\nNo preview",
                                        fontSize = 12.sp, textAlign = TextAlign.Center, color = Color.Gray
                                    )
                                }
                            }
                        }
                        Spacer(Modifier.height(8.dp))
                        Row(
                            Modifier.clip(RoundedCornerShape(20.dp)).background(Color(0xFFDCEBFF)).padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            IconButton(onClick = { if (page > 0) page-- }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Filled.ChevronLeft, null, tint = Blue)
                            }
                            Text("${if (pages == 0) 0 else page + 1} / $pages", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color(0xFF0A2A66))
                            IconButton(onClick = { if (page < pages - 1) page++ }, modifier = Modifier.size(34.dp)) {
                                Icon(Icons.Filled.ChevronRight, null, tint = Blue)
                            }
                        }
                        Spacer(Modifier.height(6.dp))
                        Text(
                            cur?.name ?: "—", fontSize = 11.sp, color = Blue, fontWeight = FontWeight.Bold, maxLines = 1,
                            overflow = TextOverflow.Ellipsis, modifier = Modifier.clickable { dlg = "pick" }
                        )
                    }
                }
                // ── print settings card
                Card(
                    Modifier.weight(1.2f), shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFCFDCF2))
                ) {
                    Column {
                        Row(Modifier.fillMaxWidth().background(Color(0xFFE3EEFF)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Filled.Print, null, tint = Blue, modifier = Modifier.size(26.dp))
                            Spacer(Modifier.width(8.dp))
                            Text("Print Settings", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF0A2A66))
                        }
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            DropField("Printer", Icons.Filled.Print, printerNames[printer], printerNames) { printer = it }
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Filled.FileCopy, null, tint = Blue, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.width(8.dp))
                                Column(Modifier.weight(1f)) {
                                    Text("Copies", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0A2A66))
                                    Row(
                                        Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).border(1.dp, Color(0xFFCFDCF2), RoundedCornerShape(8.dp)),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Text("$copies", Modifier.weight(1f).padding(start = 10.dp), fontSize = 14.sp)
                                        Box(
                                            Modifier.size(32.dp).background(Color(0xFFE3EEFF)).clickable { if (copies > 1) copies-- },
                                            contentAlignment = Alignment.Center
                                        ) { Icon(Icons.Filled.Remove, null, tint = Blue, modifier = Modifier.size(18.dp)) }
                                        Box(
                                            Modifier.size(32.dp).background(Color(0xFFD3E4FF)).clickable { if (copies < 50) copies++ },
                                            contentAlignment = Alignment.Center
                                        ) { Icon(Icons.Filled.Add, null, tint = Blue, modifier = Modifier.size(18.dp)) }
                                    }
                                }
                            }
                            DropField("Paper Size", Icons.Filled.Description, paperNames[paper], paperNames) { paper = it }
                            DropField("Orientation", Icons.Filled.ScreenRotation, if (land) "Landscape" else "Portrait", listOf("Portrait", "Landscape")) { land = it == 1 }
                            DropField("Color Mode", Icons.Filled.Palette, if (color) "Color" else "Black & White", listOf("Color", "Black & White")) { color = it == 0 }
                            DropField("Print Quality", Icons.Filled.Settings, qualNames[qual], qualNames) { qual = it }
                            Button(
                                onClick = { doPrint() }, modifier = Modifier.fillMaxWidth().height(48.dp), shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F6BEA))
                            ) {
                                Icon(Icons.Filled.Print, null)
                                Spacer(Modifier.width(8.dp))
                                Text(if (printer == 1) "Save PDF" else "Print", fontWeight = FontWeight.Bold, fontSize = 17.sp)
                            }
                        }
                    }
                }
            }

            // ── quick actions
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFCFDCF2))
            ) {
                Column {
                    Row(Modifier.fillMaxWidth().background(Color(0xFFE3EEFF)).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.FlashOn, null, tint = Blue, modifier = Modifier.size(24.dp))
                        Spacer(Modifier.width(8.dp))
                        Text("Quick Actions", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF0A2A66))
                    }
                    Row(Modifier.padding(10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QuickTile(Icons.Filled.PictureAsPdf, Color(0xFF1E5CD6), "Save as PDF", "Save document as PDF file", Modifier.weight(1f)) { saveAsPdf() }
                        QuickTile(Icons.Filled.Share, Color(0xFF1E5CD6), "Share", "Share with others", Modifier.weight(1f)) {
                            val f = cur
                            if (f == null) toast(ctx, "کوئی دستاویز نہیں / No document") else Actions.share(ctx, f)
                        }
                        QuickTile(Icons.Filled.Visibility, Color(0xFF1E5CD6), "Preview", "View before printing", Modifier.weight(1f)) {
                            if (pdf == null) toast(ctx, "کوئی دستاویز نہیں / No document to preview") else dlg = "preview"
                        }
                        QuickTile(Icons.Filled.Settings, Color(0xFF1E5CD6), "Advanced Settings", "More print options", Modifier.weight(1f)) { dlg = "adv" }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
        }
    }

    when (dlg) {
        "pick" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Select document / دستاویز منتخب کریں") },
            text = {
                if (files.isEmpty()) Text("کوئی دستاویز نہیں ملی / No documents found")
                else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    files.forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp))
                                .background(if (f.absolutePath == cur?.absolutePath) Color(0xFFE3EEFF) else Color.Transparent)
                                .clickable { selected = f; dlg = "" }.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            KindIcon(kindOf(f.name) ?: DocKind.TEXT, 34.dp)
                            Spacer(Modifier.width(10.dp))
                            Column(Modifier.weight(1f)) {
                                Text(f.name, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${fmtSize(f.length())}  •  ${fmtDate(f.lastModified())}", fontSize = 11.sp, color = Color.Gray)
                            }
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
        "adv" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Advanced Settings") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Margins / حاشیہ", fontWeight = FontWeight.Bold)
                    listOf("None", "Normal (0.5 in)").forEachIndexed { i, l ->
                        Row(Modifier.fillMaxWidth().clickable { margins = i }, verticalAlignment = Alignment.CenterVertically) {
                            RadioButton(selected = margins == i, onClick = { margins = i })
                            Text(l)
                        }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text("Two-sided / دو طرفہ", fontWeight = FontWeight.Bold)
                            Text("Print on both sides (if printer supports)", fontSize = 12.sp, color = Color.Gray)
                        }
                        Switch(checked = duplex, onCheckedChange = { duplex = it })
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } }
        )
        "preview" -> pdf?.let { PreviewDialog(it, pages) { dlg = "" } }
    }
    if (busy) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(color = Blue)
                Spacer(Modifier.width(16.dp))
                Text("پرنٹ تیار ہو رہا ہے… / Preparing print…")
            }
        }
    )
}
