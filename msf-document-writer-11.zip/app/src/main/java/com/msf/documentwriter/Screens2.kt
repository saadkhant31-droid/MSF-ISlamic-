@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

// ───────────────────────── MY DOCUMENTS / WORD DOCUMENTS ─────────────────────────
@Composable
fun DocsScreen(nav: NavController, mode: String, words: Boolean) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var q by remember { mutableStateOf("") }
    var fsel by remember { mutableIntStateOf(0) }
    var sort by remember { mutableIntStateOf(0) }
    var sortMenu by remember { mutableStateOf(false) }
    val all = remember(tick) { Store.list(ctx) }
    val sharedSet = remember(tick) { Prefs.items(ctx, "shared") }
    val editedSet = remember(tick) { Prefs.items(ctx, "edited") }
    val base = if (words) all.filter { kindOf(it.name) == DocKind.WORD } else all
    val kinds = listOf<DocKind?>(null, DocKind.WORD, DocKind.PDF, DocKind.TEXT, DocKind.IMAGE)
    val weekMs = 7L * 24 * 3600 * 1000
    var list = base.filter { f ->
        (q.isBlank() || f.name.contains(q, ignoreCase = true)) && (
            if (words) when (fsel) {
                1 -> System.currentTimeMillis() - f.lastModified() < weekMs
                2 -> f.name in editedSet
                3 -> f.name in sharedSet
                else -> true
            } else kinds[fsel] == null || kindOf(f.name) == kinds[fsel]
        )
    }
    list = when (sort) {
        1 -> list.sortedBy { it.name.lowercase() }
        2 -> list.sortedByDescending { it.length() }
        else -> list
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) {
            val n = uris.count { Store.importUri(ctx, it) != null }
            tick++
            toast(ctx, if (n > 0) "$n فائل شامل ہو گئی / $n file(s) added" else "سپورٹڈ فائل نہیں ملی / No supported file found")
        }
    }
    val fr = remember { FocusRequester() }
    LaunchedEffect(Unit) { if (mode == "search") try { fr.requestFocus() } catch (_: Exception) {} }
    val onOpen: (File) -> Unit = { f ->
        when (mode) {
            "share" -> { Actions.share(ctx, f); tick++ }
            "print" -> Actions.print(ctx, f)
            else -> openFile(nav, ctx, f)
        }
    }
    val chipColors = FilterChipDefaults.filterChipColors(selectedContainerColor = Blue, selectedLabelColor = Color.White)
    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader(
                "آسان طریقے سے اپنی دستاویزات بنائیں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) },
                menu = listOf(
                    "Import files / فائلیں شامل کریں" to { importer.launch(arrayOf("*/*")) },
                    "Search / تلاش" to { nav.navigate("search") },
                    "Print / پرنٹ" to { goTo(nav, "print") }
                )
            )
        },
        bottomBar = {
            MainBar(nav, 1)
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
            Spacer(Modifier.height(8.dp))
            if (words) Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    KindIcon(DocKind.WORD, 60.dp)
                    Spacer(Modifier.width(14.dp))
                    Column {
                        Text("Word Documents", fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Color(0xFF0A2A66))
                        Text("ورڈ ذاکیومنٹس بنائیں اور ایڈٹ کریں", fontSize = 14.sp)
                    }
                }
            } else Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(48.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("My Documents", fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = Color(0xFF0A2A66))
                    Text("آپ کے محفوظ شدہ دستاویز", fontSize = 14.sp)
                }
                Column(Modifier.clip(RoundedCornerShape(14.dp)).background(Color(0xFFDCEBFF)).padding(horizontal = 14.dp, vertical = 8.dp)) {
                    Text("Total Files", fontSize = 12.sp); Text("${all.size}", fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                }
            }
            if (mode == "share" || mode == "print") {
                Spacer(Modifier.height(8.dp))
                Text(
                    if (mode == "share") "شیئر کرنے کے لیے فائل منتخب کریں / Tap a file to share"
                    else "پرنٹ کرنے کے لیے فائل منتخب کریں / Tap a file to print",
                    color = Blue, fontWeight = FontWeight.Bold
                )
            }
            Spacer(Modifier.height(8.dp))
            SearchBox(q, { q = it }, if (words) "Search Word documents..." else "Search documents...", Modifier.focusRequester(fr))
            Spacer(Modifier.height(8.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                val labels = if (words) listOf("All", "New", "Edited", "Shared") else listOf("All", "Word", "PDF", "Text", "Images")
                labels.forEachIndexed { i, l ->
                    FilterChip(selected = fsel == i, onClick = { fsel = i }, label = { Text(l) }, colors = chipColors)
                }
                if (words) Box {
                    FilterChip(selected = sort != 0, onClick = { sortMenu = true }, label = { Text("Sort") },
                        trailingIcon = { Icon(Icons.Filled.ArrowDropDown, null) }, colors = chipColors)
                    DropdownMenu(expanded = sortMenu, onDismissRequest = { sortMenu = false }) {
                        listOf("Date / تاریخ", "Name / نام", "Size / سائز").forEachIndexed { i, s ->
                            DropdownMenuItem(text = { Text(s) }, onClick = { sort = i; sortMenu = false })
                        }
                    }
                }
            }
            Spacer(Modifier.height(6.dp))
            LazyColumn(Modifier.weight(1f)) {
                if (list.isEmpty()) item {
                    Text("کوئی دستاویز نہیں ملی / No documents found", color = Color.Gray, modifier = Modifier.padding(24.dp))
                }
                items(list, key = { it.absolutePath }) { f ->
                    DocRow(f, onOpen = { onOpen(f) }, onChanged = { tick++ })
                }
                item { Spacer(Modifier.height(80.dp)) }
            }
        }
    }
}

// ───────────────────────── PDF MAKER ─────────────────────────
@Composable
fun PdfMakerScreen(nav: NavController) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var tab by remember { mutableIntStateOf(0) } // 0 home, 1 files, 2 bookmarks
    var tick by remember { mutableIntStateOf(0) }
    var busy by remember { mutableStateOf(false) }

    fun convert(uris: List<Uri>, merge: Boolean, mergeName: String) {
        if (uris.isEmpty()) return
        scope.launch {
            busy = true
            val res = withContext(Dispatchers.IO) {
                var made = 0
                var failed = 0
                try {
                    if (merge) {
                        val b = PdfBuilder(Prefs.paper(ctx), Prefs.landscape(ctx))
                        var ok = 0
                        uris.forEach { u -> if (Converter.append(ctx, u, Store.nameOf(ctx, u), b)) ok++ else failed++ }
                        if (ok > 0) { b.finish(Store.uniqueFile(ctx, mergeName + "_" + stamp(), "pdf")); made++ } else b.discard()
                    } else {
                        uris.forEach { u ->
                            val nm = Store.nameOf(ctx, u)
                            val b = PdfBuilder(Prefs.paper(ctx), Prefs.landscape(ctx))
                            if (Converter.append(ctx, u, nm, b)) {
                                b.finish(Store.uniqueFile(ctx, nm.substringBeforeLast('.'), "pdf")); made++
                            } else { b.discard(); failed++ }
                        }
                    }
                } catch (e: Exception) { failed++ }
                Pair(made, failed)
            }
            busy = false
            tick++
            tab = 1
            toast(
                ctx,
                (if (res.first > 0) "${res.first} پی ڈی ایف بن گئی / PDF created. " else "") +
                    (if (res.second > 0) "${res.second} فائل سپورٹڈ نہیں (صرف docx, xlsx, pptx, txt, rtf, تصاویر) / unsupported" else "")
            )
        }
    }

    val pWord = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, false, "") }
    val pXls = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, false, "") }
    val pPpt = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, false, "") }
    val pTxt = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, false, "") }
    val pImg = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, true, "Images") }
    val pAny = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { convert(it, true, "Merged") }

    val pdfs = remember(tick) { Store.list(ctx).filter { kindOf(it.name) == DocKind.PDF } }
    val marks = remember(tick, tab) { Prefs.items(ctx, "bookmarks") }

    val tools = listOf(
        TileData("Word to PDF", "DOCX / DOC", Color(0xFF1E5CD6), Color(0xFFE3EEFF), letter = "W") {
            pWord.launch(arrayOf("application/vnd.openxmlformats-officedocument.wordprocessingml.document", "application/msword"))
        },
        TileData("Excel to PDF", "XLSX / XLS", Color(0xFF16A34A), Color(0xFFE3F8EC), letter = "X") {
            pXls.launch(arrayOf("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "application/vnd.ms-excel"))
        },
        TileData("PowerPoint to PDF", "PPTX / PPT", Color(0xFFF97316), Color(0xFFFFEFE0), letter = "P") {
            pPpt.launch(arrayOf("application/vnd.openxmlformats-officedocument.presentationml.presentation", "application/vnd.ms-powerpoint"))
        },
        TileData("Image to PDF", "JPG / PNG / BMP", Color(0xFFE53935), Color(0xFFFFE8E8), icon = Icons.Filled.Image) { pImg.launch(arrayOf("image/*")) },
        TileData("Text to PDF", "TXT / RTF", Color(0xFF7C4DFF), Color(0xFFEFE9FF), icon = Icons.Filled.TextSnippet) {
            pTxt.launch(arrayOf("text/plain", "text/rtf", "application/rtf"))
        },
        TileData("Multiple Files to PDF", "Merge Files", Color(0xFF0EA5C6), Color(0xFFDDF6FB), icon = Icons.Filled.Layers) { pAny.launch(arrayOf("*/*")) }
    )

    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader("اپنی تحریر کو PDF میں تبدیل کریں", title1 = "MSF ", accent = "PDF", title2 = " Maker", onBack = { nav.popBackStack() }, onHome = { goHome(nav) })
        },
        bottomBar = {
            BottomBar(
                listOf(
                    Nav(Icons.Filled.Home, "Home") { tab = 0 },
                    Nav(Icons.Filled.Description, "My Files") { tab = 1 },
                    Nav(Icons.Filled.AddCircle, "Create PDF") { pAny.launch(arrayOf("*/*")) },
                    Nav(Icons.Filled.Bookmark, "Bookmarks") { tab = 2 },
                    Nav(Icons.Filled.Settings, "Settings") { nav.navigate("settings") }
                ), when (tab) { 0 -> 0; 1 -> 1; else -> 3 }
            )
        }
    ) { pad ->
        LazyColumn(Modifier.padding(pad).fillMaxSize().padding(horizontal = 12.dp)) {
            if (tab == 0) {
                item {
                    Spacer(Modifier.height(10.dp))
                    Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(72.dp).clip(RoundedCornerShape(14.dp)).background(Color(0xFFE53935)), contentAlignment = Alignment.Center) {
                                Text("PDF", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp)
                            }
                            Spacer(Modifier.width(14.dp))
                            Column {
                                Text("PDF Maker", fontWeight = FontWeight.ExtraBold, fontSize = 26.sp, color = Color(0xFF0A2A66))
                                Text("Convert your documents to PDF easily and quickly.", fontSize = 13.sp)
                                Text("اپنے دستاویزات کو آسانی سے PDF میں تبدیل کریں۔", fontSize = 13.sp)
                            }
                        }
                    }
                    Spacer(Modifier.height(12.dp))
                    TileGrid(tools, 112.dp)
                    SectionTitle("Recent Files", "", "View All") { tab = 1 }
                }
                if (pdfs.isEmpty()) item { Text("ابھی کوئی PDF نہیں / No PDF files yet", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                items(pdfs.take(4), key = { it.absolutePath }) { f ->
                    DocRow(f, onOpen = { Actions.open(ctx, f) }, onChanged = { tick++ })
                }
            } else {
                val shown = if (tab == 1) pdfs else pdfs.filter { it.name in marks }
                item { SectionTitle(if (tab == 1) "My PDF Files" else "Bookmarks", if (tab == 1) "میری فائلیں" else "بک مارکس") }
                if (shown.isEmpty()) item { Text("کوئی فائل نہیں / Nothing here yet", color = Color.Gray, modifier = Modifier.padding(16.dp)) }
                items(shown, key = { it.absolutePath }) { f ->
                    DocRow(f, onOpen = { Actions.open(ctx, f) }, onChanged = { tick++ })
                }
            }
            item { Spacer(Modifier.height(16.dp)) }
        }
    }
    if (busy) AlertDialog(
        onDismissRequest = {}, confirmButton = {},
        text = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(color = Blue)
                Spacer(Modifier.width(16.dp))
                Text("پی ڈی ایف بن رہی ہے… / Creating PDF…")
            }
        }
    )
}

// ───────────────────────── PROFILE / SETTINGS / INFO ─────────────────────────
@Composable
fun InfoScreen(nav: NavController, sub: String, icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, lines: List<String>) {
    Scaffold(
        containerColor = Bg,
        topBar = { AppHeader(sub, onBack = { nav.popBackStack() }, onHome = { goHome(nav) }) }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(icon, null, tint = Blue, modifier = Modifier.size(40.dp))
                Spacer(Modifier.width(10.dp))
                Text(title, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Color(0xFF0A2A66))
            }
            lines.forEach { Card(Modifier.fillMaxWidth(), colors = CardDefaults.cardColors(containerColor = Color.White)) { Text(it, Modifier.padding(14.dp), fontSize = 15.sp) } }
        }
    }
}
