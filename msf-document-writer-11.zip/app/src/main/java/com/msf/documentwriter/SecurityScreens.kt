@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.app.KeyguardManager
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.biometric.BiometricManager
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import java.io.File
import java.io.FileOutputStream
import java.util.Calendar

// ───────────────────────── App lock helper ─────────────────────────
object Lock {
    var unlocked by mutableStateOf(true)

    fun deviceSecure(c: Context): Boolean {
        val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.isDeviceSecure
    }

    fun canBiometric(c: Context): Boolean =
        BiometricManager.from(c).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS

    @Suppress("DEPRECATION")
    fun credentialIntent(c: Context): Intent? {
        val km = c.getSystemService(Context.KEYGUARD_SERVICE) as KeyguardManager
        return km.createConfirmDeviceCredentialIntent("MSF Document Writer", "Unlock to continue / جاری رکھنے کے لیے ان لاک کریں")
    }
}

@Composable
fun LockScreen(onUnlock: () -> Unit) {
    Column(
        Modifier.fillMaxSize().background(Blue).padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(84.dp))
        Spacer(Modifier.height(16.dp))
        Text("MSF Document Writer", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp)
        Text("ایپ لاک ہے / App is locked", color = Color.White.copy(alpha = 0.9f), fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        Button(
            onClick = onUnlock, shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1F6BEA)), modifier = Modifier.fillMaxWidth().height(52.dp)
        ) {
            Icon(Icons.Filled.LockOpen, null)
            Spacer(Modifier.width(8.dp))
            Text("Unlock / ان لاک کریں", fontWeight = FontWeight.Bold, fontSize = 17.sp)
        }
    }
}

// ───────────────────────── shared pieces ─────────────────────────
@Composable
private fun PRow(
    icon: ImageVector, tint: Color, title: String, sub: String, value: String? = null,
    trailing: (@Composable () -> Unit)? = null, onClick: (() -> Unit)? = null
) {
    Row(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color.White)
            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(14.dp))
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 12.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(46.dp).clip(CircleShape).background(tint.copy(alpha = 0.16f)), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = tint, modifier = Modifier.size(26.dp))
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = Color(0xFF0A2A66))
            Text(sub, fontSize = 12.sp, color = Color(0xFF475569))
        }
        if (value != null) { Text(value, fontSize = 13.sp, color = Blue); Spacer(Modifier.width(6.dp)) }
        if (trailing != null) trailing() else if (onClick != null) Icon(Icons.Filled.ChevronRight, null, tint = Color(0xFF334155))
    }
}

@Composable
private fun StatCell(icon: ImageVector, tint: Color, value: String, label: String, modifier: Modifier) {
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(30.dp))
        Text(value, fontWeight = FontWeight.ExtraBold, fontSize = 22.sp, color = Color(0xFF0A2A66))
        Text(label, fontSize = 11.sp, color = Color(0xFF475569), textAlign = TextAlign.Center, maxLines = 2)
    }
}

// ───────────────────────── PROFILE ─────────────────────────
@Composable
fun ProfileScreen(nav: NavController) {
    val ctx = LocalContext.current
    var dlg by remember { mutableStateOf("") }
    var name by remember { mutableStateOf(Prefs.name(ctx)) }
    var email by remember { mutableStateOf(Prefs.email(ctx)) }
    var avatar by remember { mutableStateOf<ImageBitmap?>(loadAvatar(ctx)) }
    var theme by remember { mutableIntStateOf(Prefs.theme(ctx)) }
    var editName by remember { mutableStateOf("") }
    var editMail by remember { mutableStateOf("") }
    val version = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName ?: "1.0.0" } catch (_: Exception) { "1.0.0" } }

    val files = remember { Store.list(ctx, true) }
    val today = remember {
        val c = Calendar.getInstance()
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0)
        c.timeInMillis
    }
    val createdToday = files.count { it.lastModified() >= today }
    val viewed = remember { Prefs.viewed(ctx) }
    val marks = remember { Prefs.items(ctx, "bookmarks").size }

    val avatarPick = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            decodeBitmap(ctx, u, 512)?.let { bm ->
                FileOutputStream(File(ctx.filesDir, "avatar.jpg")).use { bm.compress(Bitmap.CompressFormat.JPEG, 90, it) }
                avatar = loadAvatar(ctx)
            }
        }
    }
    fun editProfile() { editName = name; editMail = email; dlg = "profile" }

    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader(
                "آسان طریقے سے اپنی دستاویزات بنائیں", onBack = { nav.popBackStack() }, onHome = { goHome(nav) },
                menu = listOf("Edit Profile / پروفائل" to { editProfile() }, "Settings / سیٹنگز" to { goTo(nav, "settings") }),
                icon = Icons.Filled.Description
            )
        },
        bottomBar = { MainBar(nav, 4) }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(120.dp).clickable { avatarPick.launch("image/*") }) {
                    Box(
                        Modifier.fillMaxSize().clip(CircleShape).background(Color.White).padding(4.dp).clip(CircleShape).background(Blue),
                        contentAlignment = Alignment.Center
                    ) {
                        val a = avatar
                        if (a != null) Image(a, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                        else Icon(Icons.Filled.Person, null, tint = Color.White, modifier = Modifier.size(76.dp))
                    }
                    Box(
                        Modifier.align(Alignment.BottomEnd).size(38.dp).clip(CircleShape).background(Color(0xFF1F6BEA))
                            .border(2.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) { Icon(Icons.Filled.PhotoCamera, null, tint = Color.White, modifier = Modifier.size(20.dp)) }
                }
                Spacer(Modifier.width(16.dp))
                Column(Modifier.weight(1f)) {
                    Text(name, fontWeight = FontWeight.ExtraBold, fontSize = 24.sp, color = Color(0xFF0A2A66), maxLines = 2)
                    Text(email, fontSize = 15.sp, color = Color(0xFF475569), maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Spacer(Modifier.height(8.dp))
                    Row(
                        Modifier.clip(RoundedCornerShape(10.dp)).background(Color(0xFFDCEBFF)).clickable { editProfile() }
                            .padding(horizontal = 12.dp, vertical = 7.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Filled.WorkspacePremium, null, tint = Blue, modifier = Modifier.size(20.dp))
                        Spacer(Modifier.width(6.dp))
                        Text("MSF Premium User", color = Blue, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }

            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFD5E0F2))
            ) {
                Row(Modifier.padding(vertical = 12.dp)) {
                    StatCell(Icons.Filled.Description, Color(0xFF1E5CD6), "${files.size}", "Total Documents", Modifier.weight(1f).clickable { goTo(nav, "docs/browse") })
                    StatCell(Icons.Filled.Folder, Color(0xFF16A34A), "$createdToday", "Created Today", Modifier.weight(1f).clickable { goTo(nav, "docs/browse") })
                    StatCell(Icons.Filled.Schedule, Color(0xFF6D3BE0), "$viewed", "Files Viewed", Modifier.weight(1f))
                    StatCell(Icons.Filled.Star, Color(0xFFF5B000), "$marks", "Bookmarks", Modifier.weight(1f).clickable { nav.navigate("pdfmaker") })
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                PRow(Icons.Filled.Person, Color(0xFF1E6BE6), "Edit Profile", "Change your name and photo") { editProfile() }
                PRow(Icons.Filled.Shield, Color(0xFF16A34A), "Privacy & Security", "Manage your account security") { nav.navigate("security") }
                PRow(Icons.Filled.Notifications, Color(0xFF7C3AED), "Notifications", "App alerts and updates") {
                    val i = if (Build.VERSION.SDK_INT >= 26) Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                    else Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName))
                    try { ctx.startActivity(i) } catch (_: Exception) { toast(ctx, "Cannot open settings") }
                }
                PRow(Icons.Filled.Palette, Color(0xFFF97316), "Appearance", "Theme and color settings", Themes[theme].first) { dlg = "theme" }
                PRow(Icons.Filled.Info, Color(0xFF0D9488), "About App", "Version, terms and more", "v$version") { nav.navigate("about") }
            }

            Button(
                onClick = { dlg = "logout" }, modifier = Modifier.fillMaxWidth().height(52.dp), shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
            ) { Icon(Icons.Filled.Logout, null); Spacer(Modifier.width(8.dp)); Text("Log Out", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            Spacer(Modifier.height(6.dp))
        }
    }

    when (dlg) {
        "theme" -> ChoiceDialog("Theme / تھیم", Themes.map { it.first }, theme, {
            theme = it; Prefs.setInt(ctx, "theme", it); AppState.accent = Color(Themes[it].second)
        }) { dlg = "" }
        "profile" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Edit Profile") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(value = editName, onValueChange = { editName = it }, singleLine = true, label = { Text("Name / نام") })
                    OutlinedTextField(value = editMail, onValueChange = { editMail = it }, singleLine = true, label = { Text("Email") })
                    TextButton(onClick = { avatarPick.launch("image/*") }) {
                        Icon(Icons.Filled.PhotoCamera, null); Spacer(Modifier.width(6.dp)); Text("Change photo / تصویر بدلیں")
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    name = editName.trim().ifEmpty { "User" }; email = editMail.trim()
                    Prefs.setStr(ctx, "name", name); Prefs.setStr(ctx, "email", email); dlg = ""
                }) { Text("Save") }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
        "logout" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Log Out") },
            text = { Text("پروفائل کی معلومات صاف ہو جائیں گی (دستاویزات محفوظ رہیں گی)۔ / Profile info will be cleared (documents are kept).") },
            confirmButton = {
                TextButton(onClick = {
                    Prefs.setStr(ctx, "name", "Guest"); Prefs.setStr(ctx, "email", ""); File(ctx.filesDir, "avatar.jpg").delete()
                    name = "Guest"; email = ""; avatar = null; dlg = ""
                    goHome(nav)
                }) { Text("Log Out", color = Color(0xFFD32F2F)) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
    }
}

// ───────────────────────── PRIVACY & SECURITY ─────────────────────────
@Composable
fun SecurityScreen(nav: NavController) {
    val ctx = LocalContext.current
    var lock by remember { mutableStateOf(Prefs.appLock(ctx)) }
    var fp by remember { mutableStateOf(Prefs.fingerprint(ctx)) }
    var dlg by remember { mutableStateOf("") }
    var hidden by remember { mutableStateOf(Prefs.items(ctx, "hidden")) }

    val backupL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { u ->
        if (u != null) toast(ctx, try { "${Data.backup(ctx, u)} فائلیں بیک اپ ہوئیں / files backed up" } catch (_: Exception) { "Backup failed" })
    }
    val restoreL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u ->
        if (u != null) toast(ctx, try { "${Data.restore(ctx, u)} فائلیں بحال ہوئیں / files restored" } catch (_: Exception) { "Restore failed" })
    }

    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader(
                "Privacy & Security", onBack = { nav.popBackStack() }, onHome = { goHome(nav) },
                menu = listOf("Privacy Policy / پالیسی" to { nav.navigate("privacy") }, "Terms / شرائط" to { nav.navigate("terms") }),
                icon = Icons.Filled.Lock, sub2 = "آپ کی رازداری ہماری اولین ترجیح ہے"
            )
        },
        bottomBar = { MainBar(nav, 4) }
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFE3EEFF)), border = BorderStroke(1.dp, Color(0xFFBFD3F2))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(78.dp), contentAlignment = Alignment.Center) {
                        Box(Modifier.size(70.dp).clip(CircleShape).background(Color(0xFF1F6BEA)), contentAlignment = Alignment.Center) {
                            Icon(Icons.Filled.Lock, null, tint = Color.White, modifier = Modifier.size(40.dp))
                        }
                        Box(
                            Modifier.align(Alignment.BottomEnd).size(24.dp).clip(CircleShape).background(Color(0xFF22C55E)),
                            contentAlignment = Alignment.Center
                        ) { Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(16.dp)) }
                    }
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Your Privacy Matters", fontWeight = FontWeight.ExtraBold, fontSize = 19.sp, color = Color(0xFF0A2A66))
                        Text("Your files stay on your device. The app has no internet permission and never sends your data anywhere.", fontSize = 12.sp, color = Color(0xFF334155))
                    }
                }
            }

            PRow(Icons.Filled.Lock, Color(0xFF16A34A), "App Lock", "Use phone PIN, Pattern or Fingerprint to protect your app.", trailing = {
                Switch(checked = lock, onCheckedChange = { on ->
                    if (on && !Lock.deviceSecure(ctx)) toast(ctx, "پہلے فون کا اسکرین لاک سیٹ کریں / Set a phone screen lock first")
                    else {
                        lock = on; Prefs.setBool(ctx, "applock", on)
                        if (!on) { fp = false; Prefs.setBool(ctx, "fingerprint", false) }
                    }
                })
            })
            PRow(Icons.Filled.Fingerprint, Color(0xFF2563EB), "Fingerprint Authentication", "Quick and secure access with your fingerprint.", trailing = {
                Switch(checked = fp, onCheckedChange = { on ->
                    if (on && !Lock.canBiometric(ctx)) toast(ctx, "فنگر پرنٹ دستیاب نہیں / No fingerprint set up on this phone")
                    else if (on && !lock) toast(ctx, "پہلے App Lock آن کریں / Turn on App Lock first")
                    else { fp = on; Prefs.setBool(ctx, "fingerprint", on) }
                })
            })
            PRow(Icons.Filled.Apps, Color(0xFF6D4DE0), "Change PIN / Pattern", "Update your current security PIN or pattern.") {
                try { ctx.startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) } catch (_: Exception) { toast(ctx, "Cannot open settings") }
            }
            PRow(Icons.Filled.VisibilityOff, Color(0xFFE53935), "Hide Sensitive Files", "Keep your private documents hidden from others.", "${hidden.size}") { dlg = "hide" }
            PRow(Icons.Filled.VerifiedUser, Color(0xFF0D9488), "Data Encryption", "How your files are stored and protected.") { dlg = "enc" }
            PRow(Icons.Filled.CloudUpload, Color(0xFF2563EB), "Backup & Restore", "Keep your data safe with a backup file.") { dlg = "backup" }
            PRow(Icons.Filled.Description, Color(0xFF6D4DE0), "Privacy Policy", "Learn how we protect your data.") { nav.navigate("privacy") }
            PRow(Icons.Filled.Delete, Color(0xFF475569), "Clear Private Data", "Remove profile, photo, bookmarks and settings from the app.") { dlg = "clear" }

            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(Color(0xFFE3EEFF)).padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Filled.VerifiedUser, null, tint = Color(0xFF0B4DB8), modifier = Modifier.size(34.dp))
                Spacer(Modifier.width(10.dp))
                Column(Modifier.weight(1f)) {
                    Text("Your Data, Our Responsibility", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0A2A66))
                    Text("We never share your personal information with anyone.", fontSize = 11.sp, color = Color(0xFF334155))
                }
                Text("100% Private", fontSize = 12.sp, color = Color(0xFF0B4DB8), fontWeight = FontWeight.Bold)
            }
            Spacer(Modifier.height(6.dp))
        }
    }

    when (dlg) {
        "hide" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Hide Sensitive Files / فائلیں چھپائیں") },
            text = {
                val all = Store.list(ctx, true)
                if (all.isEmpty()) Text("کوئی دستاویز نہیں / No documents yet")
                else Column(Modifier.heightIn(max = 380.dp).verticalScroll(rememberScrollState())) {
                    Text("ٹک شدہ فائلیں My Documents اور Search میں نظر نہیں آئیں گی۔ / Ticked files are hidden from lists and search.", fontSize = 12.sp, color = Color.Gray)
                    all.forEach { f ->
                        Row(
                            Modifier.fillMaxWidth().clickable { Prefs.toggle(ctx, "hidden", f.name); hidden = Prefs.items(ctx, "hidden") },
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(checked = f.name in hidden, onCheckedChange = { Prefs.toggle(ctx, "hidden", f.name); hidden = Prefs.items(ctx, "hidden") })
                            Text(f.name, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("Done") } }
        )
        "enc" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Data Encryption") },
            text = {
                Text(
                    "آپ کی فائلیں ایپ کی نجی اسٹوریج میں رہتی ہیں جہاں دوسری ایپس نہیں پہنچ سکتیں، اور فون کی اپنی اسٹوریج انکرپشن بھی لاگو ہوتی ہے۔ بیک اپ زپ فائل پاس ورڈ سے محفوظ نہیں ہوتی، اسے محفوظ جگہ رکھیں۔\n\n" +
                        "Your files are kept in the app's private storage, which other apps cannot read, and your phone's own storage encryption applies. Backup ZIP files are not password protected, so keep them somewhere safe."
                )
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("OK") } }
        )
        "backup" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Backup & Restore") },
            text = {
                Column {
                    TextButton(onClick = { dlg = ""; backupL.launch("MSF_Backup_${stamp()}.zip") }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Filled.CloudUpload, null); Spacer(Modifier.width(8.dp)); Text("Backup now / بیک اپ بنائیں", modifier = Modifier.weight(1f))
                    }
                    TextButton(
                        onClick = { dlg = ""; restoreL.launch(arrayOf("application/zip", "application/x-zip-compressed", "application/octet-stream")) },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Filled.CloudDownload, null); Spacer(Modifier.width(8.dp)); Text("Restore / بحال کریں", modifier = Modifier.weight(1f))
                    }
                }
            },
            confirmButton = {},
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
        "clear" -> AlertDialog(
            onDismissRequest = { dlg = "" }, title = { Text("Clear Private Data") },
            text = { Text("پروفائل، تصویر، بک مارکس، چھپی فائلوں کی فہرست، ایپ لاک اور سیٹنگز صاف ہو جائیں گی۔ دستاویزات حذف نہیں ہوں گی۔\n\nProfile, photo, bookmarks, hidden list, app lock and settings will be cleared. Your documents are NOT deleted.") },
            confirmButton = {
                TextButton(onClick = {
                    Data.clearCache(ctx); Prefs.clearAll(ctx); File(ctx.filesDir, "avatar.jpg").delete()
                    AppState.accent = Color(Themes[0].second); AppState.urdu = true
                    lock = false; fp = false; hidden = emptySet(); dlg = ""
                    toast(ctx, "ڈیٹا صاف ہو گیا / Private data cleared")
                    goHome(nav)
                }) { Text("Clear", color = Color(0xFFD32F2F)) }
            },
            dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
        )
    }
}
