package com.msf.documentwriter

/**
 * Tables are stored in the text as lines of the form  |cell|cell|cell|
 * An optional line like  |---|---|  right after the first row marks it as a header row.
 * On export (PDF / Word / image) these lines become real tables.
 */
sealed class Block
class TextBlock(val a: Int, val b: Int) : Block()
/** rows -> cells -> (start, end) offsets in the full text (spaces already trimmed). */
class TableBlock(val rows: List<List<Pair<Int, Int>>>, val header: Boolean) : Block()

object Tables {
    fun isRow(line: String): Boolean {
        val t = line.trim()
        return t.length >= 2 && t.startsWith("|") && t.endsWith("|")
    }

    fun isSeparator(line: String): Boolean {
        val t = line.trim()
        return isRow(t) && t.contains('-') && t.all { it == '|' || it == '-' || it == ':' || it == ' ' }
    }

    /** Cell ranges of the line s[ps, pe). */
    private fun cells(s: String, ps: Int, pe: Int): List<Pair<Int, Int>> {
        val first = s.indexOf('|', ps)
        val last = s.lastIndexOf('|', pe - 1)
        val out = ArrayList<Pair<Int, Int>>()
        if (first < 0 || last <= first) return out
        var p = first
        while (p < last) {
            val q = s.indexOf('|', p + 1)
            var a = p + 1
            var b = q
            while (a < b && s[a] == ' ') a++
            while (b > a && s[b - 1] == ' ') b--
            out.add(Pair(a, b))
            p = q
        }
        return out
    }

    /** Splits s[from, to) into plain-text blocks and table blocks. */
    fun split(s: String, from: Int, to: Int): List<Block> {
        val out = ArrayList<Block>()
        var textStart = from
        var ps = from
        var rows = ArrayList<List<Pair<Int, Int>>>()
        var header = false
        var inTable = false
        while (ps <= to) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0 || nl > to) to else nl
            val line = s.substring(ps, pe)
            if (isRow(line)) {
                if (!inTable) {
                    inTable = true
                    val b = if (ps > textStart && s[ps - 1] == '\n') ps - 1 else ps
                    if (b > textStart) out.add(TextBlock(textStart, b))
                }
                if (isSeparator(line)) { if (rows.size == 1) header = true } else rows.add(cells(s, ps, pe))
            } else if (inTable) {
                if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
                rows = ArrayList(); header = false; inTable = false
                textStart = ps
            }
            if (pe >= to) break
            ps = pe + 1
        }
        if (inTable) {
            if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
        } else if (textStart < to) out.add(TextBlock(textStart, to))
        return out
    }

    fun any(s: String): Boolean = split(s, 0, s.length).any { it is TableBlock }

    /** Text lines for a new empty table. */
    fun template(rows: Int, cols: Int, header: Boolean): String {
        val row = "|" + "   |".repeat(cols)
        val sep = "|" + "---|".repeat(cols)
        val sb = StringBuilder()
        for (r in 0 until rows) {
            sb.append(row).append('\n')
            if (r == 0 && header) sb.append(sep).append('\n')
        }
        return sb.toString()
    }
}
