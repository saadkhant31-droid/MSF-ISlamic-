package com.msf.documentwriter

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LineHeightSpan
import android.text.style.ReplacementSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.text.style.UpdateLayout
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.FormatAlignLeft
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Redo
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val BarDark = Color(0xFF151515)
private val BarGrey = Color(0xFF2B2B2B)
private val IconGrey = Color(0xFFBDBDBD)

/** Small paper (A5, A6) gets narrower margins so the writing area stays usable. */
private fun blankMargin(paper: Int): Float = if (Paper.get(paper).wPt < 450) 40f else 72f

/** The page-break character is shown as nothing: the next page itself is the visual cue. */
class PageMarkSpan : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = 0
    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {}
}

/**
 * Pushes the line that starts at this span's first character down by [d] pixels, so that the text jumps over
 * the bottom margin, the gap and the top margin of the next page sheet.
 */
class PagePushSpan(val d: Int, private val mult: Float) : LineHeightSpan, UpdateLayout {
    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt) {
        if (text is Spanned && text.getSpanStart(this) == start) {
            // the editor multiplies the line height by [mult] afterwards, so ask for d / mult here
            val e = (d / mult).roundToInt()
            fm.ascent -= e
            fm.top -= e
        }
    }
}

/** Re-draws the invisible page-break markers and table-row backgrounds of the Blank Page editor. */
fun decorateBlank(e: Editable) {
    for (s in e.getSpans(0, e.length, PageBreakSpan::class.java)) e.removeSpan(s)
    for (s in e.getSpans(0, e.length, PageMarkSpan::class.java)) e.removeSpan(s)
    for (s in e.getSpans(0, e.length, TableRowSpan::class.java)) e.removeSpan(s)
    val str = e.toString()
    for (i in str.indices) {
        if (str[i] == PAGE_BREAK) e.setSpan(PageMarkSpan(), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    var ps = 0
    while (ps <= str.length) {
        val nl = str.indexOf('\n', ps)
        val pe = if (nl < 0) str.length else nl
        if (pe > ps && Tables.isRow(str.substring(ps, pe))) e.setSpan(TableRowSpan(), ps, pe, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        if (nl < 0) break
        ps = nl + 1
    }
}

fun cleanCopy(src: CharSequence): SpannableStringBuilder {
    val b = SpannableStringBuilder(src)
    for (s in b.getSpans(0, b.length, PagePushSpan::class.java)) b.removeSpan(s)
    for (s in b.getSpans(0, b.length, PageMarkSpan::class.java)) b.removeSpan(s)
    return b
}

private fun countChars(t: CharSequence): Int {
    var n = 0
    for (ch in t) if (!ch.isWhitespace() && ch != PAGE_BREAK) n++
    return n
}

/**
 * The paper: a column of white page sheets (with corner marks at the margins) and the editor on top of them.
 * Text size and margins are scaled so that one point of the PDF is [pgScale] pixels here; text that would run into the
 * bottom margin is pushed to the next sheet, so what you see is the page layout of the PDF / Word file.
 */
class PageSheets(c: Context) : FrameLayout(c) {
    var pageW = 612
    var pageH = 792
    var marginPt = 72f
    var numbers = true
    var baseSize = 16
    var pages = 2
        private set
    var contentPages = 1
        private set
    var pgScale = 1f
        private set
    var onState: (() -> Unit)? = null
    lateinit var et: SelEditText
    var landscape = false
        private set
    private var bg: android.graphics.Bitmap? = null
    private var spec: PageDesigns.Spec? = null
    private val bmpP = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    /** Different design per page: design id of page i (0 = plain); empty = the same [bg] on every page. */
    private var designIds: List<Int> = emptyList()
    var bmpOf: (Int) -> android.graphics.Bitmap? = { null }
    private var fx = 0f
    private var ft = 0f
    private var fb = 0f

    private fun recomputeFractions() {
        val specs = listOfNotNull(spec) + designIds.mapNotNull { PageDesigns.spec(it) }
        fx = specs.maxOfOrNull { it.mx } ?: 0f
        ft = specs.maxOfOrNull { it.mt } ?: 0f
        fb = specs.maxOfOrNull { it.mb } ?: 0f
    }

    fun setDesigns(list: List<Int>) {
        if (list == designIds) return
        designIds = list
        recomputeFractions()
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    private val density = resources.displayMetrics.density
    private val gapPx = max(4, (6 * density).roundToInt())
    private val sheet = Paint()
    private val markP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val numP = Paint(Paint.ANTI_ALIAS_FLAG)
    private var pending = false
    private var extraPasses = 0
    /** Character offsets where a new page starts (after the last measuring). */
    var breakStarts: List<Int> = emptyList()
    private var lastW = 0

    init {
        setBackgroundColor(0xFFEDEDED.toInt())
        sheet.color = android.graphics.Color.WHITE
        markP.color = 0xFFBDBDBD.toInt()
        markP.style = Paint.Style.STROKE
        markP.strokeWidth = max(1f, 1.2f * density)
        numP.color = 0xFF333333.toInt()
        numP.textAlign = Paint.Align.CENTER
    }

    private fun pageHpx(): Int = (pageH * pgScale).roundToInt()

    private fun designOn(): Boolean = bg != null && spec != null && !landscape
    private fun mxPx(): Float = if (designOn()) fx * pageW * pgScale else marginPt * pgScale
    private fun mtPx(): Float = if (designOn()) ft * pageHpx() else marginPt * pgScale
    private fun mbPx(): Float = if (designOn()) fb * pageHpx() else marginPt * pgScale

    /** A page border design: every sheet shows it and the text stays inside its frame (null = plain white sheets). */
    fun setDesign(b: android.graphics.Bitmap?, s: PageDesigns.Spec?) {
        if (b === bg && s === spec) return
        bg = b
        spec = s
        recomputeFractions()
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    fun setPaper(p: Int, land: Boolean) {
        val d = Paper.pt(p, land)
        val landChanged = landscape != land
        landscape = land
        if (d.first == pageW && d.second == pageH && !landChanged) return
        pageW = d.first
        pageH = d.second
        if (width > 0) { pgScale = width.toFloat() / pageW; applyScale(width) }
        requestLayout()
        invalidate()
        schedule()
    }

    fun setMargin(m: Float) {
        if (m == marginPt) return
        marginPt = m
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    fun setBase(sz: Int) {
        baseSize = sz
        if (pgScale > 0f) et.setTextSize(TypedValue.COMPLEX_UNIT_PX, baseSize * pgScale)
        schedule()
    }

    private fun applyScale(w: Int) {
        if (w <= 0) return
        pgScale = w.toFloat() / pageW
        val px = mxPx().roundToInt()
        et.setPadding(px, mtPx().roundToInt(), px, mbPx().roundToInt())
        et.paint.density = pgScale
        et.setTextSize(TypedValue.COMPLEX_UNIT_PX, baseSize * pgScale)
        lastW = w
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        pgScale = if (w > 0) w.toFloat() / pageW else 1f
        val total = pages * pageHpx() + (pages - 1) * gapPx
        setMeasuredDimension(w, total)
        val cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec(total, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) getChildAt(i).measure(cw, ch)
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != lastW) { applyScale(w); schedule() }
    }

    override fun dispatchDraw(canvas: Canvas) {
        val w = width.toFloat()
        val ph = pageHpx().toFloat()
        val m = marginPt * pgScale
        val design = designOn()
        val len = max(8f * density, 0.024f * w)
        numP.textSize = 11f * pgScale
        for (i in 0 until pages) {
            val top = i * (ph + gapPx)
            val bottom = top + ph
            if (design) {
                val pb = if (designIds.isEmpty()) bg else designIds[min(i, designIds.size - 1)].let { if (it == 0) null else bmpOf(it) }
                if (pb != null) canvas.drawBitmap(pb, null, android.graphics.RectF(0f, top, w, bottom), bmpP)
                else canvas.drawRect(0f, top, w, bottom, sheet)
            } else {
                canvas.drawRect(0f, top, w, bottom, sheet)
                val l = m
                val r = w - m
                val t = top + m
                val b = bottom - m
                // top-left, top-right, bottom-left, bottom-right corner marks (outside the text area)
                canvas.drawLine(l, t - len, l, t, markP); canvas.drawLine(l - len, t, l, t, markP)
                canvas.drawLine(r, t - len, r, t, markP); canvas.drawLine(r, t, r + len, t, markP)
                canvas.drawLine(l, b, l, b + len, markP); canvas.drawLine(l - len, b, l, b, markP)
                canvas.drawLine(r, b, r, b + len, markP); canvas.drawLine(r, b, r + len, b, markP)
            }
            if (numbers && i < contentPages) canvas.drawText((i + 1).toString(), w / 2f, bottom - (if (design) mbPx() else m) + 24f * pgScale, numP)
        }
        super.dispatchDraw(canvas)
    }

    fun schedule() {
        if (pending) return
        pending = true
        post { pending = false; repaginate() }
    }

    fun currentPage(): Int {
        val lay = et.layout ?: return 1
        val off = et.selectionStart.coerceIn(0, et.text.length)
        val y = et.paddingTop + lay.getLineTop(lay.getLineForOffset(off))
        return (y / (pageHpx() + gapPx)).coerceIn(0, pages - 1) + 1
    }

    private fun repaginate() {
        val lay = et.layout
        if (lay == null || width <= 0 || pgScale <= 0f) return
        try {
            val ed = et.text
            val str = ed.toString()
            val len = str.length
            val ph = pageHpx()
            val room = ph - mtPx() - mbPx()
            val oldSpans = ed.getSpans(0, len, PagePushSpan::class.java)
            val old = HashMap<Int, Int>()
            for (sp in oldSpans) old[ed.getSpanStart(sp)] = sp.d
            val want = LinkedHashMap<Int, Int>()
            var used = 0f
            var pg = 0
            var force = false
            for (i in 0 until lay.lineCount) {
                val st = lay.getLineStart(i)
                val en = lay.getLineEnd(i)
                val nat = max(1, lay.getLineBottom(i) - lay.getLineTop(i) - (old[st] ?: 0)).toFloat()
                if (force || (used > 0f && used + nat > room)) {
                    val d = (ph + gapPx - used).roundToInt()
                    if (st < len && d > 0 && d <= ph + gapPx) want[st] = d
                    used = 0f
                    pg++
                    force = false
                }
                used += nat
                val seg = str.substring(min(st, len), min(en, len))
                if (seg.length <= 3 && seg.contains(PAGE_BREAK) && seg.all { it == PAGE_BREAK || it == '\n' || it == ' ' }) force = true
            }
            breakStarts = want.keys.toList()
            var same = want.size == oldSpans.size
            if (same) {
                for ((k, v) in want) {
                    val o = old[k]
                    if (o == null || abs(o - v) > 2) { same = false; break }
                }
            }
            if (!same) {
                for (sp in oldSpans) ed.removeSpan(sp)
                for ((k, v) in want) ed.setSpan(PagePushSpan(v, 1.25f), k, k + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                // the pushes change the layout: measure once more (a few times at most) so the page breaks settle
                if (extraPasses < 3) { extraPasses++; schedule() }
            } else extraPasses = 0
            contentPages = pg + 1 + (if (force) 1 else 0)
            val np = max(2, contentPages)
            if (np != pages) { pages = np; requestLayout() }
            invalidate()
            onState?.invoke()
        } catch (e: Throwable) {
            // never let the page preview crash the editor
        }
    }
}

class BlankHolder {
    var et: SelEditText? = null
    var sheets: PageSheets? = null
}

fun makeBlankEditor(c: Context, onChange: () -> Unit, onSel: () -> Unit, schedule: () -> Unit): SelEditText {
    val et = SelEditText(c)
    et.background = null
    et.gravity = Gravity.TOP
    et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    et.setTextColor(android.graphics.Color.BLACK)
    et.setLineSpacing(0f, 1.25f)
    et.paintFlags = et.paintFlags or Paint.LINEAR_TEXT_FLAG or Paint.SUBPIXEL_TEXT_FLAG
    et.isVerticalScrollBarEnabled = false
    et.overScrollMode = View.OVER_SCROLL_NEVER
    if (Doc.font != null) et.typeface = Fonts.typeface(Doc.font)
    et.setText(Doc.text, TextView.BufferType.EDITABLE)
    decorateBlank(et.text)
    var sig = PageBreaks.signature(et.text)
    et.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            if (s != null) {
                val g = PageBreaks.signature(s)
                if (g != sig) { sig = g; decorateBlank(s) }
            }
            onChange()
            schedule()
        }
    })
    et.onSel = onSel
    return et
}

private fun applyBlankDir(et: EditText, rtl: Boolean, justify: Boolean) {
    et.textDirection = if (rtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_FIRST_STRONG_LTR
    if (Build.VERSION.SDK_INT >= 26) {
        et.justificationMode = if (justify) Layout.JUSTIFICATION_MODE_INTER_WORD else Layout.JUSTIFICATION_MODE_NONE
    }
}

@Composable
private fun BarBtn(icon: ImageVector, desc: String, tint: Color = IconGrey, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(49.dp)) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun PanelChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).background(if (on) Color(0xFF4A4A4A) else Color.Transparent, RoundedCornerShape(8.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun BlankPageScreen(nav: NavController) {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    val holder = remember { BlankHolder() }
    remember { Doc.margin = blankMargin(Doc.paper); Doc.pageDesign = 0; true }

    var paper by remember { mutableIntStateOf(Doc.paper) }
    var land by remember { mutableStateOf(Doc.landscape) }
    var rtl by remember { mutableStateOf(Doc.rtl) }
    var justify by remember { mutableStateOf(Doc.justify) }
    var numbers by remember { mutableStateOf(Doc.pageNumbers) }
    var dirty by remember { mutableStateOf(Doc.dirty) }
    var chars by remember { mutableIntStateOf(0) }
    var curPage by remember { mutableIntStateOf(1) }
    var menu by remember { mutableStateOf("") }
    var panel by remember { mutableStateOf(false) }
    var showSize by remember { mutableStateOf(false) }
    var showExit by remember { mutableStateOf(false) }
    var showTable by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var tRows by remember { mutableIntStateOf(3) }
    var tCols by remember { mutableIntStateOf(3) }
    var tHeader by remember { mutableStateOf(true) }
    var redoOn by remember { mutableStateOf(false) }
    var stBold by remember { mutableStateOf(false) }
    var stItalic by remember { mutableStateOf(false) }
    var stUnder by remember { mutableStateOf(false) }
    var sizeNow by remember { mutableIntStateOf(Doc.baseSize) }
    var fontLabel by remember { mutableStateOf(defaultFontLabel()) }
    var curColor by remember { mutableStateOf(Color.Black) }

    SideEffect { act?.window?.statusBarColor = BarDark.toArgb(); act?.window?.navigationBarColor = BarGrey.toArgb() }
    DisposableEffect(Unit) {
        onDispose {
            act?.window?.statusBarColor = Blue.toArgb()
            act?.window?.navigationBarColor = Blue.toArgb()
        }
    }

    fun refresh() {
        val et = holder.et ?: return
        val e = et.text
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        if (b > e.length) return
        val from = if (a == b) maxOf(a - 1, 0) else a
        stBold = e.getSpans(from, b, StyleSpan::class.java).any { (it.style and Typeface.BOLD) != 0 && (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        stItalic = e.getSpans(from, b, StyleSpan::class.java).any { (it.style and Typeface.ITALIC) != 0 && (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        stUnder = e.getSpans(from, b, UnderlineSpan::class.java).any { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        sizeNow = e.getSpans(from, b, AbsoluteSizeSpan::class.java).lastOrNull()?.size ?: Doc.baseSize
        val col = e.getSpans(from, b, ForegroundColorSpan::class.java).lastOrNull()
        curColor = if (col != null) Color(col.foregroundColor) else Color.Black
        val fam = e.getSpans(from, b, TypefaceSpan::class.java).lastOrNull()?.family
        fontLabel = Fonts.all().firstOrNull { it.second == fam }?.first ?: defaultFontLabel()
        holder.sheets?.let { curPage = it.currentPage() }
    }
    fun sync() {
        val et = holder.et ?: return
        Doc.text = cleanCopy(et.text)
        Doc.pageStarts = holder.sheets?.breakStarts ?: emptyList()
        Doc.rtl = rtl; Doc.justify = justify; Doc.dirty = dirty; Doc.pageNumbers = numbers
        Doc.paper = paper; Doc.landscape = land; Doc.margin = blankMargin(paper); Doc.pageDesign = 0
    }
    fun touch() { dirty = true; Doc.dirty = true; refresh(); holder.sheets?.schedule() }
    fun fmt(pending: ((Editable, Int) -> Unit)? = null, block: (Editable, Int, Int) -> Unit) {
        val et = holder.et ?: return
        val (a, b) = selRange(et)
        if (a == b) {
            // no selection: only the text typed from here on gets the format, the rest of the page stays as it is
            if (pending != null) { pending(et.text, a); touch() }
            else toast(ctx, "پہلے متن منتخب کریں / Select some text first")
            return
        }
        block(et.text, a, b)
        touch()
    }
    fun chooseFont(label: String, fam: String) {
        fontLabel = label
        val et = holder.et ?: return
        val (a, b) = selRange(et)
        if (a != b) {
            Rich.font(et.text, a, b, fam)
        } else if (et.text.isEmpty()) {
            Doc.font = fam
            et.typeface = Fonts.typeface(fam)
        } else {
            // cursor only: the new font is used for what is typed next; the text already written keeps its own fonts
            Rich.pendingFont(et.text, a, fam)
        }
        holder.sheets?.schedule()
        touch()
    }
    fun setSize(sz: Int) {
        sizeNow = sz
        val et = holder.et ?: return
        if (et.text.isEmpty()) {
            Doc.baseSize = sz
            holder.sheets?.setBase(sz)
            touch()
        } else fmt({ e, p -> Rich.pendingSize(e, p, sz) }) { e, s, en -> Rich.size(e, s, en, sz) }
    }
    fun quickSave(): java.io.File? {
        sync()
        return try {
            val f = Doc.saveTo(ctx, if (Doc.kind == DocKind.IMAGE) DocKind.WORD else Doc.kind, Doc.name.ifBlank { "Document" })
            dirty = false; Doc.dirty = false
            f
        } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed"); null }
    }
    fun pageBreakAction(blank: Boolean) {
        val et = holder.et ?: return
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val np = if (blank) PageBreaks.insertBlank(et.text, pos) else PageBreaks.insertAt(et.text, pos)
        decorateBlank(et.text)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
    }
    fun insertTable() {
        val et = holder.et ?: return
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val np = PageBreaks.insertBlock(et.text, pos, Tables.template(tRows, tCols, tHeader), 2)
        decorateBlank(et.text)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
        toast(ctx, "ٹیبل شامل ہو گیا، | کے درمیان خانوں میں لکھیں / Table added: type between the | bars")
    }
    fun toggleKeyboard() {
        val et = holder.et ?: return
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val vis = ViewCompat.getRootWindowInsets(et)?.isVisible(WindowInsetsCompat.Type.ime()) == true
        if (vis) imm.hideSoftInputFromWindow(et.windowToken, 0)
        else { et.requestFocus(); imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT) }
    }

    val imgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            Doc.image = u; dirty = true; Doc.dirty = true
            toast(ctx, "تصویر PDF/Image محفوظ کرنے پر شامل ہو گی / Image is added when saving as PDF or Image")
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            var name: String? = null
            try {
                ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { cur -> if (cur.moveToFirst()) name = cur.getString(0) }
            } catch (e: Exception) { }
            if (name == null) name = u.lastPathSegment
            val label = Fonts.add(ctx, u, name)
            if (label == null) toast(ctx, "یہ فونٹ شامل نہیں ہو سکا (.ttf یا .otf چاہیے) / Could not add font (.ttf or .otf needed)")
            else { toast(ctx, "فونٹ شامل ہو گیا / Font added: $label"); chooseFont(label, label) }
        }
    }

    DisposableEffect(Unit) { onDispose { sync() } }
    LaunchedEffect(Unit) { delay(150); holder.sheets?.schedule(); refresh() }
    BackHandler(enabled = dirty) { showExit = true }

    Column(Modifier.fillMaxSize().background(BarDark)) {
        // ───── top bar
        Row(Modifier.fillMaxWidth().height(56.dp).background(BarDark), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Done", color = Color(0xFFE6E6E6), fontSize = 17.sp,
                modifier = Modifier.clickable { sync(); nav.navigate("save") }.padding(horizontal = 16.dp, vertical = 14.dp)
            )
            BarBtn(Icons.Outlined.Save, "Save") { val f = quickSave(); if (f != null) toast(ctx, "محفوظ ہو گیا / Saved: ${f.name}") }
            BarBtn(Icons.Outlined.Undo, "Undo") { holder.et?.onTextContextMenuItem(android.R.id.undo); redoOn = true }
            BarBtn(Icons.Outlined.Redo, "Redo", if (redoOn) IconGrey else Color(0xFF6A6A6A)) { holder.et?.onTextContextMenuItem(android.R.id.redo) }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(34.dp).border(1.5.dp, IconGrey, RoundedCornerShape(3.dp)).clickable { showSize = true },
                contentAlignment = Alignment.Center
            ) { Text("$curPage", color = IconGrey, fontSize = 15.sp) }
            BarBtn(Icons.Outlined.Close, "Close") { if (dirty) showExit = true else nav.popBackStack() }
        }

        // ───── page canvas
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { c ->
                    val sv = ScrollView(c)
                    sv.setBackgroundColor(0xFFEDEDED.toInt())
                    sv.isFillViewport = false
                    val sheets = PageSheets(c)
                    sheets.baseSize = Doc.baseSize
                    sheets.marginPt = blankMargin(paper)
                    sheets.numbers = numbers
                    sheets.setPaper(paper, land)
                    val et = makeBlankEditor(
                        c,
                        onChange = { dirty = true; Doc.dirty = true; redoOn = false; chars = countChars(holder.et?.text ?: ""); refresh() },
                        onSel = { refresh() },
                        schedule = { holder.sheets?.schedule() }
                    )
                    sheets.et = et
                    holder.et = et
                    holder.sheets = sheets
                    sheets.onState = { curPage = sheets.currentPage(); chars = countChars(et.text) }
                    sheets.addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    sv.addView(sheets, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    sv
                },
                update = { _ ->
                    holder.et?.let { applyBlankDir(it, rtl, justify) }
                    holder.sheets?.let {
                        it.numbers = numbers
                        it.setMargin(blankMargin(paper))
                        it.setPaper(paper, land)
                        it.invalidate()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 12.dp)
                    .background(Color(0xFFF2F2F2), RoundedCornerShape(4.dp)).padding(horizontal = 10.dp, vertical = 5.dp)
            ) { Text("Full text: $chars", color = Color(0xFF9A9A9A), fontSize = 14.sp) }
        }

        // ───── text format panel (Aa)
        if (panel) {
            Row(
                Modifier.fillMaxWidth().background(Color(0xFF222222)).horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                PanelChip("B", stBold) { fmt({ e, p -> Rich.pendingStyle(e, p, Typeface.BOLD) }) { e, s, en -> Rich.bold(e, s, en) } }
                PanelChip("I", stItalic) { fmt({ e, p -> Rich.pendingStyle(e, p, Typeface.ITALIC) }) { e, s, en -> Rich.italic(e, s, en) } }
                PanelChip("U", stUnder) { fmt({ e, p -> Rich.pendingUnderline(e, p) }) { e, s, en -> Rich.underline(e, s, en) } }
                PanelChip("S", false) { fmt({ e, p -> Rich.pendingStrike(e, p) }) { e, s, en -> Rich.strike(e, s, en) } }
                Spacer(Modifier.width(6.dp))
                PanelChip("−", false) {
                    val i = SizeList.indexOfLast { it < sizeNow }
                    setSize(if (i >= 0) SizeList[i] else SizeList.first())
                }
                Text("$sizeNow", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, modifier = Modifier.width(34.dp))
                PanelChip("+", false) {
                    val i = SizeList.indexOfFirst { it > sizeNow }
                    setSize(if (i >= 0) SizeList[i] else SizeList.last())
                }
                Spacer(Modifier.width(6.dp))
                Box {
                    Box(
                        Modifier.height(40.dp).background(Color(0xFF3A3A3A), RoundedCornerShape(8.dp)).clickable { menu = "font" }.padding(horizontal = 12.dp),
                        contentAlignment = Alignment.Center
                    ) { Text(fontLabel, color = Color.White, fontSize = 14.sp, maxLines = 1) }
                    DropdownMenu(expanded = menu == "font", onDismissRequest = { menu = "" }) {
                        FontMenuItems(
                            onPick = { l, fam -> menu = ""; chooseFont(l, fam) },
                            onAdd = { menu = ""; safe(ctx) { fontPicker.launch("*/*") } }
                        )
                    }
                }
                Spacer(Modifier.width(6.dp))
                for (cl in TextColors) {
                    if (cl == null) continue
                    Box(
                        Modifier.size(30.dp).background(Color(cl), CircleShape)
                            .border(if (Color(cl) == curColor) 3.dp else 1.dp, if (Color(cl) == curColor) Color.White else Color(0xFF666666), CircleShape)
                            .clickable { fmt({ e, p -> Rich.pendingColor(e, p, cl) }) { e, s, en -> Rich.color(e, s, en, cl) } }
                    )
                }
            }
        }

        // ───── bottom toolbar
        Row(Modifier.fillMaxWidth().height(54.dp).background(BarGrey), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(8.dp))
            Box {
                BarBtn(Icons.Outlined.GridView, "Tools") { menu = "tools" }
                DropdownMenu(expanded = menu == "tools", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("Page size / پیج سائز  (" + Paper.get(paper).name + ")") }, onClick = { menu = ""; showSize = true })
                    DropdownMenuItem(text = { Text((if (numbers) "✓ " else "") + "Page numbers / صفحہ نمبر") }, onClick = { menu = ""; numbers = !numbers; touch() })
                    DropdownMenuItem(text = { Text((if (rtl) "✓ " else "") + "Right-to-left / دائیں سے بائیں") }, onClick = { menu = ""; rtl = !rtl; touch() })
                    DropdownMenuItem(text = { Text((if (justify) "✓ " else "") + "Justify / برابر") }, onClick = { menu = ""; justify = !justify; touch() })
                    DropdownMenuItem(text = { Text("Insert table / ٹیبل") }, onClick = { menu = ""; showTable = true })
                    DropdownMenuItem(text = { Text("Save as PDF / پی ڈی ایف") }, onClick = {
                        menu = ""
                        sync()
                        try {
                            val f = Doc.saveTo(ctx, DocKind.PDF, Doc.name.ifBlank { "Document" })
                            toast(ctx, "PDF بن گئی / PDF created\n${PublicSave.note(ctx)}")
                            Actions.open(ctx, f)
                        } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed") }
                    })
                    DropdownMenuItem(text = { Text("Save as… / محفوظ کریں") }, onClick = { menu = ""; sync(); nav.navigate("save") })
                    DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menu = ""; quickSave()?.let { Actions.share(ctx, it) } })
                    DropdownMenuItem(text = { Text("Clear all / سب مٹائیں", color = Color(0xFFD32F2F)) }, onClick = { menu = ""; showClear = true })
                }
            }
            Box(Modifier.width(1.dp).height(26.dp).background(Color(0xFF444444)))
            Spacer(Modifier.width(8.dp))
            BarBtn(Icons.Outlined.CropFree, "Page size") { showSize = true }
            Box(Modifier.size(49.dp).clickable { panel = !panel }, contentAlignment = Alignment.Center) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 24.sp)) { append("A") }
                        withStyle(SpanStyle(fontSize = 16.sp)) { append("a") }
                    },
                    color = if (panel) Color.White else IconGrey
                )
            }
            Box {
                BarBtn(Icons.Outlined.FormatAlignLeft, "Align") { menu = "align" }
                DropdownMenu(expanded = menu == "align", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("Left / بائیں") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 0); touch() } })
                    DropdownMenuItem(text = { Text("Center / درمیان") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 1); touch() } })
                    DropdownMenuItem(text = { Text("Right / دائیں") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 2); touch() } })
                    DropdownMenuItem(text = { Text((if (justify) "✓ " else "") + "Justify / برابر") }, onClick = { menu = ""; justify = !justify; touch() })
                }
            }
            BarBtn(Icons.Outlined.Image, "Image") { safe(ctx) { imgPicker.launch("image/*") } }
            Box {
                BarBtn(Icons.Outlined.Add, "Insert") { menu = "plus" }
                DropdownMenu(expanded = menu == "plus", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("New page / نیا صفحہ") }, onClick = { menu = ""; pageBreakAction(false) })
                    DropdownMenuItem(text = { Text("Blank page / خالی صفحہ") }, onClick = { menu = ""; pageBreakAction(true) })
                    DropdownMenuItem(text = { Text("Insert table / ٹیبل") }, onClick = { menu = ""; showTable = true })
                }
            }
            Spacer(Modifier.weight(1f))
            BarBtn(Icons.Outlined.Keyboard, "Keyboard") { toggleKeyboard() }
            Spacer(Modifier.width(6.dp))
        }
    }

    if (showSize) PageSizeDialog(
        paper, land,
        onApply = { p, l -> paper = p; land = l; Doc.paper = p; Doc.landscape = l; dirty = true; Doc.dirty = true; showSize = false },
        onDismiss = { showSize = false }
    )
    if (showExit) AlertDialog(
        onDismissRequest = { showExit = false },
        title = { Text("Save changes? / تبدیلیاں محفوظ کریں؟") },
        text = { Text("آپ نے دستاویز میں تبدیلی کی ہے۔\nYou have unsaved changes.") },
        confirmButton = { TextButton(onClick = { showExit = false; sync(); nav.navigate("save") }) { Text("Save / محفوظ") } },
        dismissButton = {
            Row {
                TextButton(onClick = { showExit = false }) { Text("Cancel") }
                TextButton(onClick = { showExit = false; dirty = false; Doc.dirty = false; nav.popBackStack() }) { Text("Discard", color = Color(0xFFD32F2F)) }
            }
        }
    )
    if (showClear) AlertDialog(
        onDismissRequest = { showClear = false },
        title = { Text("Clear all / سب مٹائیں") },
        text = { Text("پوری دستاویز مٹا دی جائے گی۔\nThe whole document will be cleared.") },
        confirmButton = { TextButton(onClick = { showClear = false; holder.et?.text?.clear(); touch() }) { Text("Clear", color = Color(0xFFD32F2F)) } },
        dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
    )
    if (showTable) AlertDialog(
        onDismissRequest = { showTable = false },
        title = { Text("Insert table / ٹیبل") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Rows / قطاریں", Modifier.weight(1f))
                    OutlinedButton(onClick = { if (tRows > 1) tRows-- }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("−", fontSize = 20.sp) }
                    Text("$tRows", Modifier.width(36.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                    OutlinedButton(onClick = { if (tRows < 30) tRows++ }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("+", fontSize = 20.sp) }
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Columns / کالم", Modifier.weight(1f))
                    OutlinedButton(onClick = { if (tCols > 1) tCols-- }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("−", fontSize = 20.sp) }
                    Text("$tCols", Modifier.width(36.dp), fontWeight = FontWeight.Bold, fontSize = 18.sp, textAlign = TextAlign.Center)
                    OutlinedButton(onClick = { if (tCols < 8) tCols++ }, contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp), modifier = Modifier.size(40.dp)) { Text("+", fontSize = 20.sp) }
                }
                Row(Modifier.clickable { tHeader = !tHeader }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = tHeader, onCheckedChange = { tHeader = it })
                    Text("Header row / پہلی قطار عنوان")
                }
                Text(
                    "ہر خانہ | کے نشانات کے درمیان لکھیں۔\nWrite each cell between the | bars.",
                    fontSize = 12.sp, color = Color.DarkGray, textDecoration = TextDecoration.None
                )
            }
        },
        confirmButton = { TextButton(onClick = { showTable = false; insertTable() }) { Text("Insert / شامل کریں") } },
        dismissButton = { TextButton(onClick = { showTable = false }) { Text("Cancel") } }
    )
}
