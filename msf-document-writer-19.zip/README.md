# MSF Document Writer (Android)

Kotlin + Jetpack Compose. Create / edit / share / print Word (.docx), PDF and Text documents with rich formatting, Urdu & Arabic (RTL) writing, search, PDF Maker, backup & restore.

## Screens
Home · Print (new) · New Document · Text Formatting · Urdu & Arabic Writing · Save Document · My Documents · Word Documents · Search · PDF Maker · Settings · Privacy · Terms · About

## Build
- **Android Studio**: open this folder, sync Gradle, Run.
- **GitHub**: push; Actions → *Build APK* produces a debug APK artifact.

## Notes
- Documents are stored privately in the app (no INTERNET permission). "Cloud" = copy saved through the system file picker (Drive etc.).
- Set your real support e-mail in `Settings.kt` (`SUPPORT_EMAIL`).
- Fonts use system fonts; `Noto Nastaliq Urdu` / `Noto Naskh Arabic` appear only if the device has them (otherwise default Arabic-script font is used).
- Legacy .doc/.xls/.ppt are not supported in PDF Maker.

## Update
- Text Formatting, Urdu & Arabic Writing and Save Document screens redesigned to match the new mock-ups.
- Urdu & Arabic: two ornate panels (Arabic text + Urdu translation); tap the Bismillah pill to insert it; Insert Template adds Surah Al-Fatiha with its Urdu translation. The translation is saved with the document.
- Style (B/I/U), size, colour and font indicators now follow the cursor/selection.

## Update 2 (mock-up redesign)
- New **Print** screen: page preview with pager, Printer / Copies / Paper Size / Orientation / Color Mode / Print Quality, Print button, and Quick Actions (Save as PDF, Share, Preview, Advanced Settings: margins & two-sided).
- Common bottom bar on all main screens: Home - My Documents - New - Print - Settings.
- Header now has a 3-dot menu (Home and shortcuts). Document rows and Search filter chips (with counts) match the mock-ups.
- Import files moved to the My Documents 3-dot menu.

## Update 3 (Profile and Privacy & Security)
- **Profile** screen: photo (tap to change), name/email, stats (Total Documents, Created Today, Files Viewed, Bookmarks), Edit Profile, Privacy & Security, Notifications (opens the phone's notification settings), Appearance (theme), About App, Log Out.
- **Privacy & Security** screen: App Lock (phone PIN/pattern/fingerprint at app start), Fingerprint Authentication, Change PIN/Pattern (opens phone security settings), Hide Sensitive Files, Data Encryption (information), Backup & Restore, Privacy Policy, Clear Private Data.
- New dependency: androidx.biometric:biometric:1.1.0 (the app still has no INTERNET permission).

## Update 4 (crash fix)
- Fixed: the app closed when tapping **Add Font** or any option in the 3-dot menu (Add image etc.). Cause: `biometric:1.1.0` pulled in an old `fragment` library that rejects Activity Result API request codes ("Can only use lower 16 bits for requestCode"). Added `androidx.fragment:fragment-ktx:1.6.2`. This also fixes every other picker (Save as, Import, Backup/Restore, profile photo).
- Picker launches in the editor are now wrapped in `safe { }` so a failure shows a message instead of closing the app.
- Version bumped to 1.0.1 (versionCode 2).

## Update 5 (pages)
- New **page designs** (assets/pages): Golden Border and Islamic Frame. Pick them in *New Document → Page Design*, or in the editor via ⋮ → *Page design*.
- New **New page / نیا صفحہ** (⋮ menu) inserts a page break (a line holding U+000C, drawn as a "New page" label). Text also flows to a new page automatically in PDF/Word/Image output.
- PDF, Word (.docx, border as a header background image) and Image exports draw the design on every page and respect page breaks. Portrait only (the border is ignored in landscape).
- The editor shows the chosen design as an A4 sheet when a design is selected.

## Update 6 (fonts)
- Choosing or adding a font with no text selected now sets the font for the whole document (and for new typing). Before, it did nothing on an empty document.
- Added fonts: file type is detected from the file header when the picker hides the name; re-adding a font replaces the old copy.

## Update 7 (blank page, separate pages, page numbers, tables)
- ⋮ menu: **New page**, **Blank page / خالی صفحہ**, **Insert table / ٹیبل**, **Page numbers / صفحہ نمبر** (on by default), **Page design**.
- Page breaks are drawn in the editor as a full-width band "Page N ends | Page N+1 starts", so every page is clearly separate.
- PDF / Word / Image-with-pages: every page is separate, with its own page number centred at the bottom (Word uses a real PAGE field in the footer).
- Tables are stored as `|cell|cell|` lines (a `|---|---|` line after the first row = header row) and exported as real tables in PDF and Word; Word tables are read back into this form when a .docx is opened again.

## Update 8 (keyboard + page fixes)
- Page-design editor (Golden Border / Islamic Frame): the sheet is now full width and scrolls, so it no longer shrinks to a tiny strip when the keyboard opens.
- While the keyboard is open the bottom navigation bar and the header / Font-Size-Style-Color cards are hidden to give the page more room; the line being typed is scrolled into view above the keyboard.
- Blank page editor: page-break calculation re-checks itself (up to 3 passes) and ignores impossible values, so lines of one paragraph are no longer pushed apart with big gaps.

## Update 9 (blank page fonts)
- Blank page: choosing a font with no selection now applies it to the whole text and re-measures the page, so every font in the list takes effect (not just one).

## Update 10 (design pages = real pages)
- Page-design editor (Golden Border etc.) now uses the same sheet-by-sheet editor as the Blank Page: when a page is full, the text continues on a new sheet below with the same design; "New page" also starts a new sheet. PDF / Word export already writes every page with the design.
- Blank page formatting (bold, size, font, colour) applies only to the selected text, or to what is typed next when nothing is selected.

## Update 11 (selection kept while using menus)
- Opening the Font / Size / Colour menu made Android collapse the text selection, so the format was not applied to the selected text. The editor now remembers the last real selection (until you tap the text or type) and applies fonts, sizes, bold, underline etc. to exactly that text. Different fonts/sizes/styles can now live on one page.
- Page-design editor: the Font / Size / Style / Color row stays visible while the keyboard is open. With nothing selected, a format change only affects the text typed next.

## Update 12 (saving: File Manager + same pages as on screen)
- Every saved file (PDF, Word, text, image) is also copied to a folder the phone's File Manager can see: Documents/MSF Document Writer by default, or any folder / SD card chosen in Settings → Save Location (also on the Save screen: "Save Folder → Change"). The "saved" message shows the real folder, or a warning if the copy failed.
- PDF now follows the page breaks of the editor (Blank Page and design pages): a page that is full on screen stays one page in the PDF instead of spilling onto the next page.

## Update 13 (add design pages with "+")
- Page-design editor: a round "+" button (bottom right of the pages, and menu → "+ Add design page") adds a new page after all the text with a design of your choice. Pages can now have different designs (e.g. page 1 Golden Border, page 2 Islamic Frame). "Page design" in the menu still changes the design of all pages.
- The text margins are the widest of the designs used, so text never touches any border. PDF export draws each page with its own design. Word (.docx) export keeps only the first page's design.
- Changing the design in the menu now also updates the pages already on screen.
