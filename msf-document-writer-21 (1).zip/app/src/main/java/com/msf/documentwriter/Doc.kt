package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import android.text.SpannableStringBuilder
import java.io.File
import java.io.FileInputStream

/** The document currently open in the editor (shared by editor, save and settings screens). */
object Doc {
    var text = SpannableStringBuilder()
    var trans = SpannableStringBuilder()
    var name = ""
    var kind = DocKind.WORD
    var rtl = false
    var justify = false
    var baseSize = 16
    var font: String? = null
    var image: Uri? = null
    var pickImage = false
    var dirty = false
    var lang = 0
    /** 0 = plain page, otherwise the id of a PageDesigns border. */
    var pageDesign = 0
    /** Print the page number at the bottom of every page (PDF / Word / Image-with-pages). */
    var pageNumbers = true
    /** Thin frame line around every page; page numbers then read "- 1 -". */
    var pageBorder = false
    /** Paper size index (see [Paper]) and orientation of the open document. */
    var paper = 0
    var landscape = false
    /** Page margins in points; null = the classic margins (40 pt in PDF, 1 inch in Word). The Blank Page editor uses 72 pt. */
    var mar: Mar? = null
    /** True when the user chose the margins in Page Setup (otherwise the Blank Page editor picks them from the paper size). */
    var marCustom = false
    /** Page number position / alignment / format / first number (see the Page Number dialog). */
    var pn = PageNumCfg()
    val saved = mutableMapOf<String, File>()
    /** Where the page editor started each new page (character offsets in [text]); used so the PDF has the same pages. */
    var pageStarts: List<Int> = emptyList()
    /** Design of each page (index = page number - 1; later pages keep the last one). Empty = [pageDesign] on every page. 0 = plain page. */
    var pageDesigns: List<Int> = emptyList()

    fun new(c: Context, kind: DocKind, title: String = "", body: String = "", rtl: Boolean = false) {
        text = SpannableStringBuilder(body); trans = SpannableStringBuilder(); name = title; this.kind = kind; this.rtl = rtl
        justify = false; baseSize = Prefs.fontSize(c); font = null; image = null
        pickImage = false; dirty = false; lang = 0; pageDesign = 0; pageNumbers = true; pageBorder = false; saved.clear()
        paper = Prefs.paper(c); landscape = Prefs.landscape(c); mar = null; marCustom = false; pn = PageNumCfg()
        pageStarts = emptyList(); pageDesigns = emptyList()
    }

    fun edit(c: Context, f: File) {
        new(c, kindOf(f.name) ?: DocKind.TEXT)
        name = f.nameWithoutExtension
        saved[f.extension.lowercase()] = f
        try {
            if (f.extension.lowercase() == "docx") {
                val r = FileInputStream(f).use { RichDocx.parse(it) }
                text = r.text; baseSize = r.size; rtl = r.rtl; justify = r.justify; font = r.font
                pageDesign = RichDocx.designOf(f)
                val cfg = RichDocx.numbersOf(f)
                pageNumbers = cfg != null
                if (cfg != null) pn = cfg
                if (pageDesign == 0) RichDocx.marginsOf(f)?.let { mar = it; marCustom = true }
                RichDocx.pageOf(f)?.let { paper = it.first; landscape = it.second }
            } else text = SpannableStringBuilder(f.readText())
        } catch (_: Exception) {}
    }

    /** Main text, plus the Urdu translation panel (if used) appended after it. */
    fun combined(): CharSequence {
        if (trans.isEmpty()) return text
        val b = SpannableStringBuilder(text)
        if (b.isNotEmpty()) b.append("\n\n")
        b.append("اردو ترجمہ\n")
        b.append(trans)
        return b
    }

    fun extOf(k: DocKind) = when (k) {
        DocKind.WORD -> "docx"; DocKind.PDF -> "pdf"; DocKind.TEXT -> "txt"; DocKind.IMAGE -> "jpg"
    }

    /** The page design that can actually be drawn (portrait pages only). */
    private fun designId(c: Context): Int = if (landscape || PageDesigns.spec(pageDesign) == null) 0 else pageDesign

    private fun writePdf(c: Context, t: CharSequence, target: File) {
        val d = designId(c)
        val ids = if (d != 0) pageDesigns.map { if (PageDesigns.spec(it) != null) it else 0 } else emptyList()
        val b = PdfBuilder(paper, landscape, if (d != 0) PageDesigns.bitmap(c, d) else null, PageDesigns.spec(d), pageNumbers, mar, ids.mapNotNull { PageDesigns.spec(it) }, pn)
        if (ids.isNotEmpty()) b.pageBg = { n ->
            val id = ids[minOf(n - 1, ids.size - 1).coerceAtLeast(0)]
            if (id == 0) null else PageDesigns.bitmap(c, id)
        }
        image?.let { u -> decodeBitmap(c, u, 1600)?.let { b.image(it) } }
        b.breaks = pageStarts.toSet()
        b.border = pageBorder
        b.rich(t, baseSize, font, rtl, justify)
        b.finish(target)
    }

    fun write(c: Context, k: DocKind, target: File) {
        val t: CharSequence = combined()
        when (k) {
            DocKind.WORD -> {
                val d = designId(c)
                RichDocx.write(target, t, baseSize, rtl, justify, font, paper, landscape, d, if (d != 0) PageDesigns.bytes(c, d) else null, pageNumbers, mar, pageBorder, pn)
            }
            DocKind.PDF -> writePdf(c, t, target)
            DocKind.TEXT -> target.writeText(t.toString())
            DocKind.IMAGE -> {
                if (designId(c) != 0 || t.indexOf(PAGE_BREAK) >= 0 || Tables.any(t.toString())) {
                    val tmp = File(c.cacheDir, "image_pages.pdf")
                    writePdf(c, t, tmp)
                    try { Render.pdfToJpeg(tmp, target) } finally { tmp.delete() }
                } else Render.toJpeg(t, baseSize, font, rtl, justify, image?.let { decodeBitmap(c, it, 1600) }, target)
            }
        }
    }

    fun saveTo(c: Context, k: DocKind, base: String): File {
        val ext = extOf(k)
        val clean = base.trim().ifEmpty { "Document" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val old = saved[ext]
        val target = if (old != null && old.nameWithoutExtension == clean) old else Store.uniqueFile(c, clean, ext)
        write(c, k, target)
        PublicSave.copy(c, target)   // visible in the phone's File Manager
        if (old != null && old != target) old.delete()
        saved[ext] = target
        name = target.nameWithoutExtension
        return target
    }
}
