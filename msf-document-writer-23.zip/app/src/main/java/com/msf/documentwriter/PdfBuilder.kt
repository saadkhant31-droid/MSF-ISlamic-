package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

fun decodeBitmap(c: Context, u: Uri, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    c.contentResolver.openInputStream(u)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
    }
} catch (e: Exception) { null }

object Render {
    fun layout(t: CharSequence, base: Float, font: String?, rtl: Boolean, justify: Boolean, width: Int, density: Float): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = base * density
        tp.density = density
        tp.color = Color.BLACK
        if (font != null) tp.typeface = Fonts.typeface(font)
        val b = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setLineSpacing(0f, 1.25f * Doc.lineSpacing)
        if (justify && Build.VERSION.SDK_INT >= 26) b.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
        return ParaFmtSpan.withScale(density) { b.build() }
    }

    /** First page preview (A4 @ 595x842). */
    fun page(t0: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, bg: Bitmap? = null, spec: PageDesigns.Spec? = null, numbers: Boolean = false, paper: Int = 0, land: Boolean = false, margin: Mar? = null, pn: PageNumCfg = PageNumCfg()): Bitmap {
        val t = withFontSpans(t0)
        val (pw, ph) = Paper.pt(paper, land)
        val PW = pw.toFloat(); val PH = ph.toFloat()
        val bmp = Bitmap.createBitmap(pw, ph, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        if (bg != null) c.drawBitmap(bg, null, RectF(0f, 0f, PW, PH), Paint(Paint.FILTER_BITMAP_FLAG))
        val useBg = spec != null && bg != null
        val ml = if (useBg) PW * spec!!.mx else (margin?.l ?: 40f)
        val mr = if (useBg) PW * spec!!.mx else (margin?.r ?: 40f)
        val mt = if (useBg) PH * spec!!.mt else (margin?.t ?: 40f)
        val mb = if (useBg) PH * spec!!.mb else (margin?.b ?: 40f)
        val cut = t.indexOf(PAGE_BREAK)
        val first = if (cut >= 0) t.subSequence(0, cut) else t
        val lay = layout(first, base.toFloat(), font, rtl, justify, (PW - ml - mr).toInt().coerceAtLeast(10), 1f)
        c.save()
        c.translate(ml, mt)
        c.clipRect(0f, 0f, PW - ml - mr, PH - mt - mb)
        ParaFmtSpan.withScale(1f) { lay.draw(c) }
        c.restore()
        if (numbers) drawPageNumber(c, PW, PH, ml, mr, mt, mb, PageNum.label(1, pn), pn)
        return bmp
    }

    /** Draws the page number (header or footer, left / centre / right) on a page canvas. */
    fun drawPageNumber(c: Canvas, pw: Float, ph: Float, ml: Float, mr: Float, mt: Float, mb: Float, text: String, pn: PageNumCfg) {
        val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
        p.textSize = 11f
        p.color = 0xFF333333.toInt()
        val x: Float
        when (pn.align) {
            0 -> { p.textAlign = Paint.Align.LEFT; x = ml }
            2 -> { p.textAlign = Paint.Align.RIGHT; x = pw - mr }
            else -> { p.textAlign = Paint.Align.CENTER; x = pw / 2f }
        }
        val y = if (pn.loc == 0) (mt - 24f).coerceAtLeast(16f) else ph - mb + 24f
        c.drawText(text, x, y, p)
    }

    /** Renders every page of a PDF (max 8) one below the other into a single JPEG. */
    fun pdfToJpeg(pdf: File, out: File, width: Int = 1000, maxPages: Int = 8) {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            val n = minOf(r.pageCount, maxPages).coerceAtLeast(1)
            val p0 = r.openPage(0)
            val h = (width.toFloat() * p0.height / p0.width).toInt()
            p0.close()
            val all = Bitmap.createBitmap(width, h * n, Bitmap.Config.ARGB_8888)
            val ac = Canvas(all)
            ac.drawColor(Color.WHITE)
            val one = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            for (i in 0 until n) {
                one.eraseColor(Color.WHITE)
                val pg = r.openPage(i)
                pg.render(one, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pg.close()
                ac.drawBitmap(one, 0f, (i * h).toFloat(), null)
            }
            one.recycle()
            FileOutputStream(out).use { all.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            all.recycle()
        } finally { r.close(); pfd.close() }
    }

    fun toJpeg(t: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, image: Bitmap?, out: File) {
        val scale = 2f
        val w = 1190
        val m = 80
        val lay = layout(t, base.toFloat(), font, rtl, justify, w - 2 * m, scale)
        val imgW = w - 2 * m
        val imgH = if (image != null) (image.height * (imgW.toFloat() / image.width)).toInt().coerceAtMost(1400) + 30 else 0
        val h = maxOf(1684, lay.height + imgH + 2 * m).coerceAtMost(16000)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        var y = m.toFloat()
        if (image != null) {
            c.drawBitmap(image, null, RectF(m.toFloat(), y, (m + imgW).toFloat(), y + imgH - 30), Paint(Paint.FILTER_BITMAP_FLAG))
            y += imgH
        }
        c.translate(m.toFloat(), y)
        ParaFmtSpan.withScale(scale) { lay.draw(c) }
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }
}

/** Copy of [t] in which every font span is a [FontSpan], so that bundled and user-added fonts are used in the PDF. */
fun withFontSpans(t: CharSequence): SpannableStringBuilder {
    val b = SpannableStringBuilder(t)
    for (sp in b.getSpans(0, b.length, android.text.style.TypefaceSpan::class.java)) {
        if (sp is FontSpan) continue
        val fam = sp.family ?: continue
        val s = b.getSpanStart(sp); val e = b.getSpanEnd(sp); val fl = b.getSpanFlags(sp)
        b.removeSpan(sp)
        b.setSpan(FontSpan(fam), s, e, fl)
    }
    return b
}

class PdfBuilder(paper: Int = 0, landscape: Boolean = false, private val bg: Bitmap? = null, spec: PageDesigns.Spec? = null, private val numbers: Boolean = false, margin: Mar? = null, extraSpecs: List<PageDesigns.Spec> = emptyList(), private val pn: PageNumCfg = PageNumCfg()) {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var n = 0
    private var y = 0f
    private var pending = false
    private val W: Int
    private val H: Int
    private val ml: Float
    private val mr: Float
    private val mt: Float
    private val mb: Float
    private val hasDesign: Boolean
    /** Character offsets where the page editor started a new page; the PDF follows them so pages look exactly like on screen. */
    var breaks: Set<Int> = emptySet()
    private val usedBreaks = HashSet<Int>()
    /** Thin frame around every page + page numbers as "- n -". */
    var border = false
    /** Background of page n (1-based) when pages have different designs; null = plain page. */
    var pageBg: ((Int) -> Bitmap?)? = null
    private val fresh: Boolean get() = y <= mt + 0.5f
    /** Column preset (see [Cols]); text flows down each column, then into the next one, then onto the next page. */
    var columns = 0
    private var colIdx = 0
    private var flowRtl = false
    private fun flow(): List<Pair<Float, Float>> {
        val l = Cols.layout(columns, W - ml - mr)
        return if (flowRtl) l.reversed() else l
    }
    private fun curX(): Float = ml + flow()[colIdx.coerceIn(0, flow().size - 1)].first
    private fun curW(): Int = flow()[colIdx.coerceIn(0, flow().size - 1)].second.toInt().coerceAtLeast(10)
    private fun nextColumn() {
        if (colIdx + 1 < flow().size) { colIdx++; y = mt } else newPage()
    }

    init {
        val (pw, ph) = Paper.pt(paper, landscape)
        W = pw; H = ph
        val useBg = bg != null && spec != null && !landscape
        val all = if (useBg) listOf(spec!!) + extraSpecs else emptyList()
        ml = if (useBg) W * all.maxOf { it.mx } else (margin?.l ?: 40f)
        mr = if (useBg) W * all.maxOf { it.mx } else (margin?.r ?: 40f)
        mt = if (useBg) H * all.maxOf { it.mt } else (margin?.t ?: 40f)
        mb = if (useBg) H * all.maxOf { it.mb } else (margin?.b ?: 40f)
        hasDesign = useBg
    }

    fun startNewPage() { pending = true }

    private fun closePage() {
        val pg = page ?: return
        if (numbers) Render.drawPageNumber(pg.canvas, W.toFloat(), H.toFloat(), ml, mr, mt, mb, PageNum.label(n, pn, border), pn)
        doc.finishPage(pg)
    }

    private fun newPage() {
        closePage()
        n++
        page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create())
        val pf = pageBg
        val pbg: Bitmap? = if (!hasDesign) null else if (pf != null) pf(n) else bg
        if (pbg != null) page!!.canvas.drawBitmap(pbg, null, RectF(0f, 0f, W.toFloat(), H.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        if (border) {
            val inset = minOf(minOf(ml, mr), minOf(mt, mb)) * 0.55f
            val bp = Paint(Paint.ANTI_ALIAS_FLAG)
            bp.color = Color.BLACK; bp.style = Paint.Style.STROKE; bp.strokeWidth = 1f
            page!!.canvas.drawRect(inset, inset, W - inset, H - inset, bp)
        }
        y = mt
        colIdx = 0
        pending = false
    }

    private fun ensure() { if (page == null || pending) newPage() }

    /** Draws a paragraph layout; returns the offset (inside the layout) where drawing has to continue with a new layout
     *  because the text moved to a column of a different width, or -1 when everything was drawn. */
    private fun drawLayout(lay: StaticLayout, off: Int = 0, shift: Float = 0f): Int {
        for (i in 0 until lay.lineCount) {
            val top = lay.getLineTop(i)
            val bot = lay.getLineBottom(i)
            val h = bot - top
            val ls = off + lay.getLineStart(i)
            val le = off + lay.getLineEnd(i)
            // the editor says: a new page starts here. The PDF wraps lines a little differently from the screen, so the
            // break is matched to the line that CONTAINS the offset (not only a line starting exactly there).
            var hit = -1
            if (breaks.isNotEmpty()) {
                for (b in breaks) if (b !in usedBreaks && b >= ls && (b < le || b == ls)) { hit = b; break }
            }
            if (hit >= 0) {
                usedBreaks.add(hit)
                if (!fresh) newPage()
            }
            // with the editor's page breaks known, allow a small overflow instead of creating an extra, almost empty page
            // just before the editor's own page break
            val limit = H - mb + (if (breaks.isNotEmpty()) h * 1.2f else 0f)
            if (!fresh && y + h > limit) {
                var nextBreak = Int.MAX_VALUE
                for (b in breaks) if (b !in usedBreaks && b >= ls && b < nextBreak) nextBreak = b
                val closeToBreak = nextBreak != Int.MAX_VALUE && nextBreak - ls < 160 && y + h <= H - 8f
                if (!closeToBreak) {
                    val before = curW()
                    nextColumn()
                    if (curW() != before) return lay.getLineStart(i)
                }
            }
            val c = page!!.canvas
            c.save()
            c.translate(curX() + shift, y - top)
            c.clipRect(0f, top.toFloat(), lay.width.toFloat(), bot.toFloat())
            ParaFmtSpan.withScale(1f) { lay.draw(c) }
            c.restore()
            y += (bot - top)
        }
        return -1
    }

    /** One paragraph t[ps, pe): honours the right indent and re-wraps when it continues in a column of another width. */
    private fun drawPara(t: CharSequence, ps: Int, pe: Int, base: Int, font: String?, rtl: Boolean, justify: Boolean) {
        val pf = if (pe > ps && t is Spanned) t.getSpans(ps, pe, ParaFmtSpan::class.java).firstOrNull() else null
        var from = ps
        var guard = 0
        while (true) {
            val cw = curW()
            val endInd = (pf?.right ?: 0f).coerceIn(0f, cw * 0.6f)
            val lay = Render.layout(t.subSequence(from, pe), base.toFloat(), font, rtl, justify, (cw - endInd).toInt().coerceAtLeast(10), 1f)
            val shift = if (endInd > 0f && lay.getParagraphDirection(0) == Layout.DIR_RIGHT_TO_LEFT) endInd else 0f
            val resume = drawLayout(lay, from, shift)
            if (resume < 0 || ++guard > 40) return
            from += resume
            if (from >= pe) return
        }
    }

    /** Rich (spanned) text. Spans such as bold, colour, size, alignment are honoured; page breaks and |tables| are handled. */
    fun rich(t0: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean) {
        ensure()
        flowRtl = rtl
        val t = withFontSpans(t0)
        val s = t.toString()
        var start = 0
        while (true) {
            val i = s.indexOf(PAGE_BREAK, start)
            val end = if (i < 0) s.length else i
            for (blk in Tables.split(s, start, end)) {
                when (blk) {
                    is TextBlock -> {
                        var ps = blk.a
                        while (true) {
                            val nl = s.indexOf('\n', ps)
                            val pe = if (nl < 0 || nl > blk.b) blk.b else nl
                            // the newline written before a page-break mark leaves an empty "paragraph" at the end of the block.
                            // The editor has no such line, and on a full page it would spill onto a new page and then the
                            // page break adds another one: a blank page in the middle of the PDF. Skip it.
                            if (i >= 0 && pe == ps && pe >= blk.b && ps > blk.a) break
                            drawPara(t, ps, pe, base, font, rtl, justify)
                            if (pe >= blk.b) break
                            ps = pe + 1
                        }
                    }
                    is TableBlock -> drawTable(t, blk, base, font, rtl, curW())
                }
            }
            if (i < 0) break
            newPage()
            start = i + 1
            if (start < s.length && s[start] == '\n') start++
        }
    }

    private fun drawTable(t: CharSequence, tb: TableBlock, base: Int, font: String?, rtl: Boolean, w: Int) {
        val cols = tb.rows.maxOf { it.size }.coerceAtLeast(1)
        val colW = w / cols.toFloat()
        val pad = 4f
        val x0 = curX()
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.color = Color.BLACK
        border.style = Paint.Style.STROKE
        border.strokeWidth = 0.8f
        val shade = Paint()
        shade.color = 0xFFE8EEF7.toInt()
        shade.style = Paint.Style.FILL
        for ((ri, row) in tb.rows.withIndex()) {
            val head = tb.header && ri == 0
            val lays = ArrayList<StaticLayout>()
            for (ci in 0 until cols) {
                val cell = row.getOrNull(ci)
                val txt: CharSequence = if (cell == null || cell.second <= cell.first) "" else t.subSequence(cell.first, cell.second)
                val shown: CharSequence = if (head && txt.isNotEmpty()) {
                    val sb = SpannableStringBuilder(txt)
                    sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb
                } else txt
                lays.add(Render.layout(shown, base.toFloat(), font, rtl, false, (colW - 2 * pad).toInt().coerceAtLeast(10), 1f))
            }
            var rowH = 0f
            for (l in lays) rowH = maxOf(rowH, l.height.toFloat())
            rowH += 2 * pad
            if (y + rowH > H - mb) newPage()
            val c = page!!.canvas
            for (ci in 0 until cols) {
                val x = x0 + (if (rtl) (cols - 1 - ci) * colW else ci * colW)
                val r = RectF(x, y, x + colW, y + rowH)
                if (head) c.drawRect(r, shade)
                c.drawRect(r, border)
                c.save()
                c.translate(x + pad, y + pad)
                c.clipRect(0f, 0f, colW - 2 * pad, rowH - 2 * pad)
                lays[ci].draw(c)
                c.restore()
            }
            y += rowH
        }
        y += 8f
    }

    fun text(t: String, f: Fmt) {
        ensure()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = f.size.toFloat()
            color = Color.BLACK
            typeface = Typeface.create(
                Typeface.DEFAULT,
                when { f.bold && f.italic -> Typeface.BOLD_ITALIC; f.bold -> Typeface.BOLD; f.italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
            )
        }
        val w = (W - ml - mr).toInt().coerceAtLeast(10)
        val al = when (f.align) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val dir = if (f.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR
        for (para in t.replace("\r", "").split("\n")) {
            val lay = StaticLayout.Builder.obtain(para, 0, para.length, tp, w)
                .setAlignment(al).setTextDirection(dir).setLineSpacing(0f, 1.25f * Doc.lineSpacing).build()
            drawLayout(lay)
        }
    }

    fun image(b: Bitmap) {
        ensure()
        val s = minOf((W - ml - mr) / b.width, (H - mt - mb) / b.height)
        val h = b.height * s
        if (y + h > H - mb) newPage()
        page!!.canvas.drawBitmap(b, null, RectF(ml, y, ml + b.width * s, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h + 12f
    }

    fun finish(out: File) {
        if (page == null) newPage()
        closePage()
        page = null
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    fun discard() { try { doc.close() } catch (_: Exception) {} }
}
