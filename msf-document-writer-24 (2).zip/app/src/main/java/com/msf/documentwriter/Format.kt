package com.msf.documentwriter

import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.Selection
import android.text.Spanned
import android.text.TextPaint
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.LeadingMarginSpan
import android.text.style.LineHeightSpan
import android.text.style.MetricAffectingSpan
import android.text.style.StyleSpan
import android.text.style.UpdateLayout
import android.widget.EditText
import kotlin.math.roundToInt

/**
 * Paragraph format: indents (points) and spacing before / after (points).
 * [left] is the "before text" indent (the start side, so it is on the right for Urdu / Arabic paragraphs),
 * [right] the "after text" indent, [first] a first-line (+) or hanging (-) indent.
 * The editor shows left / first-line indent and spacing; the right indent is applied in the saved PDF / Word file.
 */
class ParaFmtSpan(
    var left: Float = 0f, var right: Float = 0f, var first: Float = 0f, var before: Float = 0f, var after: Float = 0f
) : LeadingMarginSpan, LineHeightSpan, UpdateLayout {
    companion object {
        /** Pixels per point of the view that is currently measuring / drawing (the PDF uses 1). */
        @JvmField var scale = 1f
        inline fun <T> withScale(s: Float, block: () -> T): T {
            val o = scale
            scale = s
            try { return block() } finally { scale = o }
        }
    }

    fun copyOf() = ParaFmtSpan(left, right, first, before, after)
    fun isEmpty() = left <= 0f && right <= 0f && first == 0f && before <= 0f && after <= 0f

    override fun getLeadingMargin(isFirst: Boolean): Int =
        ((left + (if (isFirst) first else 0f)) * scale).roundToInt().coerceAtLeast(0)

    override fun drawLeadingMargin(
        c: Canvas, p: Paint, x: Int, dir: Int, top: Int, baseline: Int, bottom: Int,
        text: CharSequence, start: Int, end: Int, isFirst: Boolean, layout: Layout?
    ) {}

    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt) {
        if (text !is Spanned) return
        val mult = 1.25f * Doc.lineSpacing
        if (before > 0f && text.getSpanStart(this) == start) {
            val e = (before * scale / mult).roundToInt()
            fm.ascent -= e; fm.top -= e
        }
        if (after > 0f && text.getSpanEnd(this) <= end) {
            val e = (after * scale / mult).roundToInt()
            fm.descent += e; fm.bottom += e
        }
    }
}

/** Superscript / subscript (smaller and raised / lowered). */
class ScriptSpan(val up: Boolean) : MetricAffectingSpan() {
    override fun updateDrawState(tp: TextPaint) = shift(tp)
    override fun updateMeasureState(tp: TextPaint) = shift(tp)
    private fun shift(tp: TextPaint) {
        val s = (tp.ascent() / 2f).toInt()
        tp.baselineShift += if (up) s else -s
        tp.textSize = tp.textSize * 0.65f
    }
}

/** Marks letters that were turned into small capitals (capital shape, smaller size). */
class SmallCapSpan : MetricAffectingSpan() {
    override fun updateDrawState(tp: TextPaint) { tp.textSize = tp.textSize * 0.8f }
    override fun updateMeasureState(tp: TextPaint) { tp.textSize = tp.textSize * 0.8f }
}

/** Column presets: 0 One, 1 Two, 2 Three, 3 Left (narrow column on the left), 4 Right (narrow column on the right). */
object Cols {
    fun count(m: Int) = when (m) { 1, 3, 4 -> 2; 2 -> 3; else -> 1 }

    /** Physical columns from left to right: (x offset, width). */
    fun layout(m: Int, total: Float, gap: Float = 24f): List<Pair<Float, Float>> {
        val n = count(m)
        if (n == 1) return listOf(Pair(0f, total))
        val avail = total - gap * (n - 1)
        val ws: List<Float> = when (m) {
            3 -> listOf(avail * 0.33f, avail - avail * 0.33f)
            4 -> listOf(avail - avail * 0.33f, avail * 0.33f)
            else -> List(n) { avail / n }
        }
        var x = 0f
        val out = ArrayList<Pair<Float, Float>>()
        for (w in ws) { out.add(Pair(x, w)); x += w + gap }
        return out
    }
}

class ParaUi(
    val style: Int = 0, val list: Int = 0, val autoNum: Boolean = true, val columns: Int = 0,
    val sup: Boolean = false, val sub: Boolean = false
)

class FormatActions2(
    val onStyle: (Int) -> Unit = {}, val onList: (Int) -> Unit = {}, val onLevel: (Int) -> Unit = {},
    val onRestart: () -> Unit = {}, val onContinue: () -> Unit = {}, val onAutoNum: (Boolean) -> Unit = {},
    val onIndents: () -> Unit = {}, val onSmart: () -> Unit = {}, val onColumns: (Int) -> Unit = {},
    val onSuper: () -> Unit = {}, val onSub: () -> Unit = {}, val onSmallCaps: () -> Unit = {}, val onAllCaps: () -> Unit = {}
)

class ListInfo(val kind: Int, val len: Int, val num: String)

object Rich2 {
    // list kinds: 0 none, 1 bullet, 2 square, 3 1. 2. 3., 4 1.1. 1.2., 5 circle, 6 arrow, 7 tick, 8 dash, 9 a) b), 10 A. B.
    private val BUL = linkedMapOf(1 to "•", 2 to "▪", 5 to "○", 6 to "➤", 7 to "✓", 8 to "–")
    private val MULTI = Regex("^(\\d+(?:\\.\\d+)+)\\. ")
    private val NUM = Regex("^(\\d+)\\. ")
    private val ALO = Regex("^([a-z])\\) ")
    private val AUP = Regex("^([A-Z])\\. ")

    fun parse(line: String): ListInfo? {
        for ((k, ch) in BUL) if (line.startsWith("$ch ")) return ListInfo(k, 2, "")
        MULTI.find(line)?.let { return ListInfo(4, it.value.length, it.groupValues[1]) }
        NUM.find(line)?.let { return ListInfo(3, it.value.length, it.groupValues[1]) }
        ALO.find(line)?.let { return ListInfo(9, it.value.length, it.groupValues[1]) }
        AUP.find(line)?.let { return ListInfo(10, it.value.length, it.groupValues[1]) }
        return null
    }

    fun isNumbered(k: Int?) = k == 3 || k == 4 || k == 9 || k == 10

    fun allParas(e: CharSequence): List<Pair<Int, Int>> {
        val s = e.toString()
        val r = ArrayList<Pair<Int, Int>>()
        var ps = 0
        while (true) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0) s.length else nl
            r.add(Pair(ps, pe))
            if (nl < 0) break
            ps = nl + 1
        }
        return r
    }

    fun spanOf(e: Editable, ps: Int, pe: Int): ParaFmtSpan? {
        val end = if (pe < e.length) pe + 1 else pe
        if (end <= ps) return null
        return e.getSpans(ps, end, ParaFmtSpan::class.java).firstOrNull { e.getSpanStart(it) <= ps && e.getSpanEnd(it) > ps }
    }

    fun levelOf(e: Editable, ps: Int, pe: Int): Int = ((spanOf(e, ps, pe)?.left ?: 0f) / 36f).roundToInt().coerceIn(0, 8)

    fun putFmt(e: Editable, ps: Int, pe: Int, f: ParaFmtSpan?) {
        val end = if (pe < e.length) pe + 1 else pe
        if (end <= ps) return
        for (s in e.getSpans(ps, end, ParaFmtSpan::class.java)) e.removeSpan(s)
        if (f != null && !f.isEmpty()) e.setSpan(f, ps, end, Spanned.SPAN_PARAGRAPH)
    }

    fun fmtOf(et: EditText): ParaFmtSpan {
        val p = Rich.paragraphs(et).firstOrNull() ?: return ParaFmtSpan()
        return spanOf(et.text, p.first, p.second)?.copyOf() ?: ParaFmtSpan()
    }

    fun setFmtSel(et: EditText, f: ParaFmtSpan) {
        val e = et.text
        for ((a, b) in Rich.paragraphs(et)) putFmt(e, a, b, f.copyOf())
    }

    // ───────────── styles
    fun styleAt(et: EditText): Int {
        val e = et.text
        val (a, b) = Rich.paragraphs(et).firstOrNull() ?: return 0
        if (b <= a) return 0
        val sz = e.getSpans(a, b, AbsoluteSizeSpan::class.java).firstOrNull { e.getSpanStart(it) <= a && e.getSpanEnd(it) >= b }?.size
        when (sz) { 28 -> return 1; 22 -> return 2; 18 -> return 3; 36 -> return 4; 20 -> return 5 }
        val ital = e.getSpans(a, b, StyleSpan::class.java).any { it.style == Typeface.ITALIC && e.getSpanStart(it) <= a && e.getSpanEnd(it) >= b }
        val f = spanOf(e, a, b)
        return if (ital && f != null && f.left == 24f && f.right == 24f) 6 else 0
    }

    /** 0 Normal, 1-3 Heading 1-3, 4 Title, 5 Subtitle, 6 Quote. */
    fun setStyle(et: EditText, id: Int) {
        Rich.heading(et, id)
        val e = et.text
        for ((a, b) in Rich.paragraphs(et)) {
            val f = spanOf(e, a, b)
            if (id == 6) putFmt(e, a, b, (f?.copyOf() ?: ParaFmtSpan()).also { it.left = 24f; it.right = 24f })
            else if (f != null && f.left == 24f && f.right == 24f) putFmt(e, a, b, null)
        }
    }

    // ───────────── lists
    fun listKindAt(et: EditText): Int {
        val e = et.text
        val (a, b) = Rich.paragraphs(et).firstOrNull() ?: return 0
        return parse(e.subSequence(a, b).toString())?.kind ?: 0
    }

    private fun prefixFor(kind: Int, c: IntArray, lv: Int): String = when (kind) {
        3 -> "${c[lv].coerceAtLeast(1)}. "
        4 -> (0..lv).joinToString(".") { c[it].coerceAtLeast(1).toString() } + ". "
        9 -> "${'a' + (c[lv].coerceAtLeast(1) - 1) % 26}) "
        10 -> "${'A' + (c[lv].coerceAtLeast(1) - 1) % 26}. "
        else -> (BUL[kind] ?: "•") + " "
    }

    private fun bump(c: IntArray, lv: Int) {
        c[lv]++
        for (d in lv + 1 until c.size) c[d] = 0
    }

    /** Turns the selected paragraphs into a list of [kind] (0 = no list). Tapping the same kind again removes it. */
    fun applyList(et: EditText, kind: Int) {
        val e = et.text
        val ps = Rich.paragraphs(et)
        val infos = ps.map { (a, b) -> parse(e.subSequence(a, b).toString()) }
        val remove = kind == 0 || infos.all { it?.kind == kind }
        val c = IntArray(9)
        val pre = Array(ps.size) { "" }
        if (!remove) for (i in ps.indices) {
            val lv = levelOf(e, ps[i].first, ps[i].second)
            bump(c, lv)
            pre[i] = prefixFor(kind, c, lv)
        }
        for (i in ps.indices.reversed()) {
            val a = ps[i].first
            val old = infos[i]
            if (old != null) e.delete(a, a + old.len)
            if (!remove) e.insert(a, pre[i])
        }
    }

    fun changeLevel(et: EditText, d: Int) {
        val e = et.text
        for ((a, b) in Rich.paragraphs(et)) {
            val f = spanOf(e, a, b)?.copyOf() ?: ParaFmtSpan()
            f.left = (f.left + d * 36f).coerceIn(0f, 288f)
            putFmt(e, a, b, f)
        }
        renumber(et, 0)
    }

    /** mode 0 = renumber the list around the cursor, 1 = restart at 1 from this item, 2 = continue the list above. */
    fun renumber(et: EditText, mode: Int): Boolean {
        val e = et.text
        val all = allParas(e)
        val sel = Rich.paragraphs(et).firstOrNull() ?: return false
        val idx = all.indexOfFirst { it.first == sel.first }
        if (idx < 0) return false
        val kinds = all.map { parse(e.subSequence(it.first, it.second).toString())?.kind }
        if (!isNumbered(kinds[idx])) return false
        var r0 = idx
        while (r0 > 0 && isNumbered(kinds[r0 - 1])) r0--
        var r1 = idx
        while (r1 < all.size - 1 && isNumbered(kinds[r1 + 1])) r1++
        val c = IntArray(9)
        fun scan(from: Int, to: Int) {
            for (i in from..to) bump(c, levelOf(e, all[i].first, all[i].second))
        }
        var from = r0
        when (mode) {
            1 -> { if (idx > r0) scan(r0, idx - 1); from = idx; c[levelOf(e, all[idx].first, all[idx].second)] = 0 }
            2 -> {
                if (idx > r0) scan(r0, idx - 1)
                else {
                    var k = r0 - 1
                    while (k >= 0 && !isNumbered(kinds[k])) k--
                    if (k >= 0) {
                        var s = k
                        while (s > 0 && isNumbered(kinds[s - 1])) s--
                        scan(s, k)
                    }
                }
                from = idx
            }
        }
        val news = HashMap<Int, String>()
        for (i in from..r1) {
            val lv = levelOf(e, all[i].first, all[i].second)
            bump(c, lv)
            news[i] = prefixFor(kinds[i] ?: 3, c, lv)
        }
        for (i in r1 downTo from) {
            val a = all[i].first
            val old = parse(e.subSequence(a, all[i].second).toString()) ?: continue
            e.replace(a, a + old.len, news[i] ?: continue)
        }
        return true
    }

    fun nextPrefix(info: ListInfo): String = when (info.kind) {
        3 -> "${(info.num.toIntOrNull() ?: 0) + 1}. "
        4 -> {
            val p = info.num.split(".")
            (p.dropLast(1) + ((p.last().toIntOrNull() ?: 0) + 1).toString()).joinToString(".") + ". "
        }
        9 -> { val c = info.num[0]; "${if (c == 'z') 'a' else c + 1}) " }
        10 -> { val c = info.num[0]; "${if (c == 'Z') 'A' else c + 1}. " }
        else -> (BUL[info.kind] ?: "•") + " "
    }

    // ───────────── superscript / subscript
    fun scriptAt(e: Editable, from: Int, b: Int): Int {
        val l = e.getSpans(from, b, ScriptSpan::class.java)
        return if (l.isEmpty()) 0 else if (l.last().up) 1 else 2
    }

    fun script(e: Editable, s: Int, en: Int, up: Boolean) {
        val has = e.getSpans(s, en, ScriptSpan::class.java).any { it.up == up && e.getSpanStart(it) <= s && e.getSpanEnd(it) >= en }
        for (sp in e.getSpans(s, en, ScriptSpan::class.java)) {
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(ScriptSpan(sp.up), ss, s, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            if (se > en) e.setSpan(ScriptSpan(sp.up), en, se, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
        if (!has) e.setSpan(ScriptSpan(up), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    // ───────────── letter case
    private class Saved(val o: Any, val a: Int, val b: Int, val f: Int)

    /** Replaces single characters (same length) and puts every span back exactly where it was. */
    private fun replaceChars(e: Editable, s: Int, en: Int, f: (Int, Char) -> Char?): Int {
        val saved = e.getSpans(s, en, Any::class.java).map { Saved(it, e.getSpanStart(it), e.getSpanEnd(it), e.getSpanFlags(it)) }
        var n = 0
        for (i in s until en) {
            val ch = e[i]
            val r = f(i, ch)
            if (r != null && r != ch) { e.replace(i, i + 1, r.toString()); n++ }
        }
        for (sv in saved) if (sv.a >= 0 && sv.b >= 0) e.setSpan(sv.o, sv.a, sv.b, sv.f)
        return n
    }

    fun allCaps(e: Editable, s: Int, en: Int) {
        var lower = false
        for (i in s until en) if (e[i].isLowerCase()) { lower = true; break }
        replaceChars(e, s, en) { _, ch -> if (lower) ch.uppercaseChar() else ch.lowercaseChar() }
    }

    fun smallCaps(e: Editable, s: Int, en: Int) {
        val marks = e.getSpans(s, en, SmallCapSpan::class.java)
        if (marks.isNotEmpty()) {
            val cov = BooleanArray(en - s)
            for (m in marks) for (i in maxOf(s, e.getSpanStart(m)) until minOf(en, e.getSpanEnd(m))) cov[i - s] = true
            replaceChars(e, s, en) { i, ch -> if (cov[i - s]) ch.lowercaseChar() else null }
            for (m in marks) e.removeSpan(m)
            return
        }
        val low = BooleanArray(en - s) { e[s + it].isLowerCase() }
        replaceChars(e, s, en) { i, ch -> if (low[i - s]) ch.uppercaseChar() else null }
        var i = 0
        while (i < low.size) {
            if (!low[i]) { i++; continue }
            var j = i
            while (j < low.size && low[j]) j++
            e.setSpan(SmallCapSpan(), s + i, s + j, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            i = j
        }
    }

    // ───────────── smart typography: 0 quotes, 1 dashes, 2 ellipsis, 3 fractions, 4 all
    private fun replaceAll(e: Editable, s: Int, en: Int, from: String, to: String, guard: (String, Int) -> Boolean = { _, _ -> true }): Pair<Int, Int> {
        var end = en
        var count = 0
        var pos = end - from.length
        while (pos >= s) {
            val str = e.toString()
            val idx = str.lastIndexOf(from, pos)
            if (idx < s) break
            if (guard(str, idx)) {
                e.replace(idx, idx + from.length, to)
                end -= from.length - to.length
                count++
            }
            pos = idx - 1
        }
        return Pair(count, end)
    }

    fun smart(e: Editable, s0: Int, en0: Int, mode: Int): Int {
        var n = 0
        var s = s0
        var en = en0
        if (mode == 0 || mode == 4) {
            val str = e.toString()
            n += replaceChars(e, s, en) { i, ch ->
                val prev = if (i > 0) str[i - 1] else ' '
                when (ch) {
                    '"' -> if (prev.isWhitespace() || prev in "([{—–") '“' else '”'
                    '\'' -> if (prev.isLetterOrDigit()) '’' else '‘'
                    else -> null
                }
            }
        }
        if (mode == 1 || mode == 4) {
            var r = replaceAll(e, s, en, "---", "—"); n += r.first; en = r.second
            r = replaceAll(e, s, en, "--", "–"); n += r.first; en = r.second
        }
        if (mode == 2 || mode == 4) {
            val r = replaceAll(e, s, en, "...", "…"); n += r.first; en = r.second
        }
        if (mode == 3 || mode == 4) {
            for ((f, t) in listOf("1/2" to "½", "1/4" to "¼", "3/4" to "¾")) {
                val r = replaceAll(e, s, en, f, t) { str, i ->
                    (i == 0 || !str[i - 1].isDigit()) && (i + 3 >= str.length || !str[i + 3].isDigit())
                }
                n += r.first; en = r.second
            }
        }
        if (s > en) s = en
        return n
    }
}

/** Keeps a bullet / number list going when Enter is pressed (and ends it on an empty item). */
class AutoListWatcher : TextWatcher {
    private var nl = -1
    private var busy = false
    override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
    override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
        if (!busy && Doc.autoList && before == 0 && count == 1 && s != null && start < s.length && s[start] == '\n') nl = start else nl = -1
    }

    override fun afterTextChanged(s: Editable?) {
        val p = nl
        nl = -1
        if (s == null || p < 0 || p >= s.length || busy) return
        busy = true
        try {
            val str = s.toString()
            val st = str.lastIndexOf('\n', p - 1) + 1
            val line = str.substring(st, p)
            val info = Rich2.parse(line) ?: return
            if (line.length <= info.len) {
                s.delete(st, p + 1)
                Selection.setSelection(s, st.coerceIn(0, s.length))
            } else {
                val pre = Rich2.nextPrefix(info)
                val prev = Rich2.spanOf(s, st, p)?.copyOf()
                s.insert(p + 1, pre)
                if (prev != null) {
                    val str2 = s.toString()
                    val nx = str2.indexOf('\n', p + 1)
                    Rich2.putFmt(s, p + 1, if (nx < 0) str2.length else nx, prev)
                }
                Selection.setSelection(s, (p + 1 + pre.length).coerceIn(0, s.length))
            }
        } catch (_: Throwable) {
        } finally { busy = false }
    }
}
