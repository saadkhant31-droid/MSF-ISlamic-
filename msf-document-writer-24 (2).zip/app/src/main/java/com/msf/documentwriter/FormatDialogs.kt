package com.msf.documentwriter

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
private fun StepRow(label: String, value: Float, step: Float, min: Float, max: Float, onChange: (Float) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), fontSize = 14.sp)
        OutlinedButton(onClick = { onChange((value - step).coerceIn(min, max)) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(38.dp)) { Text("−", fontSize = 20.sp) }
        Text(
            String.format(java.util.Locale.US, "%.0f pt", value), Modifier.width(62.dp),
            fontWeight = FontWeight.Bold, fontSize = 15.sp, textAlign = TextAlign.Center
        )
        OutlinedButton(onClick = { onChange((value + step).coerceIn(min, max)) }, contentPadding = PaddingValues(0.dp), modifier = Modifier.size(38.dp)) { Text("+", fontSize = 20.sp) }
    }
}

/** Indents & Spacing: before / after text, first line or hanging, spacing before / after the paragraph. */
@Composable
fun IndentsDialog(init: ParaFmtSpan, onApply: (ParaFmtSpan) -> Unit, onDismiss: () -> Unit) {
    var left by remember { mutableFloatStateOf(init.left) }
    var right by remember { mutableFloatStateOf(init.right) }
    var mode by remember { mutableIntStateOf(if (init.first > 0f) 1 else if (init.first < 0f) 2 else 0) }
    var amt by remember { mutableFloatStateOf(if (init.first == 0f) 18f else kotlin.math.abs(init.first)) }
    var before by remember { mutableFloatStateOf(init.before) }
    var after by remember { mutableFloatStateOf(init.after) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Indents & Spacing / فاصلے") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                StepRow("Before text / متن سے پہلے", left, 6f, 0f, 300f) { left = it }
                StepRow("After text / متن کے بعد", right, 6f, 0f, 300f) { right = it }
                Text("Special / خصوصی", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("None", "First line", "Hanging").forEachIndexed { i, n ->
                        OutlinedButton(
                            onClick = { mode = i }, modifier = Modifier.weight(1f), contentPadding = PaddingValues(2.dp)
                        ) { Text(if (mode == i) "✓ $n" else n, fontSize = 12.sp, maxLines = 1) }
                    }
                }
                if (mode != 0) StepRow("By / مقدار", amt, 6f, 6f, 200f) { amt = it }
                StepRow("Spacing before / اوپر فاصلہ", before, 2f, 0f, 120f) { before = it }
                StepRow("Spacing after / نیچے فاصلہ", after, 2f, 0f, 120f) { after = it }
                TextButton(onClick = { left = 0f; right = 0f; mode = 0; before = 0f; after = 0f }) { Text("Reset / ری سیٹ") }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                onApply(ParaFmtSpan(left, right, when (mode) { 1 -> amt; 2 -> -amt; else -> 0f }, before, after))
            }) { Text("OK") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}

/** Smart Typography: quotes, dashes, ellipsis, fractions. */
@Composable
fun SmartDialog(onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Smart Typography") },
        text = {
            Column {
                listOf(
                    4 to "Apply all / سب لگائیں",
                    0 to "Smart quotes  \" \" → “ ”",
                    1 to "Dashes  --  → –   --- → —",
                    2 to "Ellipsis  ... → …",
                    3 to "Fractions  1/2 → ½"
                ).forEach { (m, n) ->
                    TextButton(onClick = { onPick(m) }, modifier = Modifier.fillMaxWidth()) {
                        Text(n, modifier = Modifier.fillMaxWidth(), color = Color(0xFF0A2A66))
                    }
                }
                Text("منتخب متن پر، یا کچھ منتخب نہ ہو تو پوری دستاویز پر۔\nOn the selected text, or the whole document if nothing is selected.", fontSize = 12.sp, color = Color.DarkGray)
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
