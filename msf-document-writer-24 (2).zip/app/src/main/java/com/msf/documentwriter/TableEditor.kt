package com.msf.documentwriter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.waitForUpOrCancellation
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.OpenWith
import androidx.compose.material.icons.filled.Redo
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDirection
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlinx.coroutines.withTimeoutOrNull

// ---------------------------------------------------------------------------------------------------------------------
// Table editor in the style of WPS Office: column letters (A B C) and row numbers (1 2 3) around the grid, drag the
// lines between them to make a column wider / a row taller, "+" buttons to add a column or a row, and a menu with
// Select / Select All / Table Properties.
// ---------------------------------------------------------------------------------------------------------------------

/** One point of the PDF is shown as 1/PT_PER_DP dp here, so a row of 40 dp becomes a 24 pt row in the file. */
private const val PT_PER_DP = 0.6f
private const val AUTO_ROW_DP = 40f
private const val MIN_ROW_DP = 28f
private const val MIN_COL = 0.06f

private data class TS(val rows: List<List<String>>, val widths: List<Float>, val heights: List<Float>, val header: Boolean)

private sealed class TSel {
    object None : TSel()
    object All : TSel()
    data class Cell(val r: Int, val c: Int) : TSel()
    data class Row(val r: Int) : TSel()
    data class Col(val c: Int) : TSel()
}

private class GuideRef(val pos: State<Offset>, val vertical: Boolean, val at: Float)

private fun toTS(d: TableData): TS {
    val cols = (d.rows.maxOfOrNull { it.size } ?: 1).coerceAtLeast(1)
    val rows = (if (d.rows.isEmpty()) listOf(emptyList()) else d.rows).map { r -> List(cols) { r.getOrNull(it) ?: "" } }
    val hs = rows.indices.map { i -> val pt = d.heights?.getOrNull(i) ?: 0f; if (pt > 0f) pt / PT_PER_DP else 0f }
    return TS(rows, Tables.fractions(d.widths, cols), hs, d.header)
}

private fun fromTS(s: TS): TableData {
    val cols = s.widths.size
    val equal = s.widths.all { kotlin.math.abs(it - 1f / cols) < 0.004f }
    val pts = s.heights.map { if (it > 0f) it * PT_PER_DP else 0f }
    return TableData(s.rows, s.header, if (equal) null else s.widths, if (pts.any { it > 0f }) pts else null)
}

private fun TS.withCell(r: Int, c: Int, t: String) =
    copy(rows = rows.mapIndexed { ri, row -> if (ri != r) row else row.mapIndexed { ci, v -> if (ci == c) t else v } })

private fun TS.insertCol(at: Int): TS {
    val n = widths.size
    val w = widths.map { it * n / (n + 1) }.toMutableList()
    val i = at.coerceIn(0, n)
    w.add(i, 1f / (n + 1))
    return copy(rows = rows.map { row -> row.toMutableList().also { it.add(i, "") } }, widths = w)
}

private fun TS.deleteCol(c: Int): TS {
    if (widths.size <= 1) return this
    val w = widths.toMutableList().also { it.removeAt(c) }
    val sum = w.sum()
    return copy(rows = rows.map { row -> row.toMutableList().also { it.removeAt(c) } }, widths = w.map { it / sum })
}

private fun TS.insertRow(at: Int): TS {
    val i = at.coerceIn(0, rows.size)
    return copy(
        rows = rows.toMutableList().also { it.add(i, List(widths.size) { "" }) },
        heights = heights.toMutableList().also { it.add(i, 0f) }
    )
}

private fun TS.deleteRow(r: Int): TS {
    if (rows.size <= 1) return this
    return copy(rows = rows.toMutableList().also { it.removeAt(r) }, heights = heights.toMutableList().also { it.removeAt(r) })
}

private val GridLine = Color(0xFF8A8A8A)
private val SelBlue = Color(0xFF1E88E5)
private val SelFill = Color(0x331E88E5)
private val HeadFill = Color(0xFFF1F1F1)
private val MenuBg = Color(0xFF2F2F2F)

@Composable
fun TableEditorDialog(initial: TableData, rtl: Boolean, onDone: (TableData) -> Unit, onDelete: () -> Unit, onCancel: () -> Unit) {
    var st by remember { mutableStateOf(toTS(initial)) }
    var ver by remember { mutableIntStateOf(0) }
    var sel by remember { mutableStateOf<TSel>(TSel.None) }
    var menuFor by remember { mutableStateOf("") }
    var showProps by remember { mutableStateOf(false) }
    var hist by remember { mutableIntStateOf(0) }
    val undo = remember { ArrayList<TS>() }
    val redo = remember { ArrayList<TS>() }
    var guide by remember { mutableStateOf<GuideRef?>(null) }
    var rootPos by remember { mutableStateOf(Offset.Zero) }
    val stNow = rememberUpdatedState(st)

    fun push() {
        if (undo.lastOrNull() != st) {
            undo.add(st)
            if (undo.size > 60) undo.removeAt(0)
        }
        redo.clear()
        hist++
    }
    fun change(structural: Boolean, f: (TS) -> TS) {
        push()
        st = f(st)
        if (structural) ver++
    }
    fun doUndo() {
        if (undo.isNotEmpty()) { redo.add(st); st = undo.removeAt(undo.size - 1); ver++; hist++ }
    }
    fun doRedo() {
        if (redo.isNotEmpty()) { undo.add(st); st = redo.removeAt(redo.size - 1); ver++; hist++ }
    }

    val canUndo = remember(hist) { undo.isNotEmpty() }
    val canRedo = remember(hist) { redo.isNotEmpty() }
    val cols = st.widths.size
    // left-to-right order of the columns on the screen (the first column is on the right in right-to-left documents)
    val order = if (rtl) (cols - 1 downTo 0).toList() else (0 until cols).toList()

    Dialog(onDismissRequest = onCancel, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Surface(Modifier.fillMaxSize(), color = Color.White) {
            Column(Modifier.fillMaxSize()) {
                // ---- dark top bar: Done, save, undo, redo ... close
                Row(
                    Modifier.fillMaxWidth().height(56.dp).background(Color(0xFF111111)).padding(horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "Done", color = Color.White, fontSize = 18.sp,
                        modifier = Modifier.clickable { onDone(fromTS(st)) }.padding(horizontal = 12.dp, vertical = 12.dp)
                    )
                    IconButton(onClick = { onDone(fromTS(st)) }) { Icon(Icons.Filled.Save, "Save", tint = Color.White) }
                    IconButton(onClick = { doUndo() }, enabled = canUndo) {
                        Icon(Icons.Filled.Undo, "Undo", tint = if (canUndo) Color.White else Color(0xFF777777))
                    }
                    IconButton(onClick = { doRedo() }, enabled = canRedo) {
                        Icon(Icons.Filled.Redo, "Redo", tint = if (canRedo) Color.White else Color(0xFF777777))
                    }
                    Spacer(Modifier.weight(1f))
                    IconButton(onClick = onCancel) { Icon(Icons.Filled.Close, "Close", tint = Color.White) }
                }

                BoxWithConstraints(Modifier.weight(1f).fillMaxWidth()) {
                    val hdrW = 32.dp
                    val gridW: Dp = (maxWidth - 12.dp - hdrW - 52.dp).coerceAtLeast(120.dp)
                    val gridWNow = rememberUpdatedState(gridW.value)

                    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(top = 16.dp, start = 12.dp, bottom = 120.dp)) {
                        Box(Modifier.onGloballyPositioned { rootPos = it.positionInRoot() }) {
                            Column {
                                // ---- column letters
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Box(
                                        Modifier.size(hdrW).border(1.dp, SelBlue, CircleShape).clickable { sel = TSel.All },
                                        contentAlignment = Alignment.Center
                                    ) { Icon(Icons.Filled.OpenWith, "Select all", tint = SelBlue, modifier = Modifier.size(20.dp)) }
                                    Box(Modifier.width(gridW).height(32.dp)) {
                                        Row {
                                            for (d in 0 until cols) {
                                                val c = order[d]
                                                val on = sel == TSel.All || sel == TSel.Col(c)
                                                Box(
                                                    Modifier.width((st.widths[c] * gridW.value).dp).fillMaxHeight()
                                                        .border(1.dp, GridLine, RoundedCornerShape(4.dp))
                                                        .background(if (on) SelFill else HeadFill, RoundedCornerShape(4.dp))
                                                        .clickable { sel = TSel.Col(c); menuFor = "col:$c" },
                                                    contentAlignment = Alignment.Center
                                                ) {
                                                    Text(if (cols <= 26) ('A' + d).toString() else "${d + 1}", fontSize = 17.sp, color = Color(0xFF222222))
                                                    DropdownMenu(expanded = menuFor == "col:$c", onDismissRequest = { menuFor = "" }, modifier = Modifier.background(MenuBg)) {
                                                        MenuItem("Select column / کالم منتخب") { menuFor = ""; sel = TSel.Col(c) }
                                                        MenuItem("Insert column left / بائیں کالم شامل") { menuFor = ""; change(true) { it.insertCol(if (rtl) cols - d else d) } }
                                                        MenuItem("Insert column right / دائیں کالم شامل") { menuFor = ""; change(true) { it.insertCol(if (rtl) cols - d - 1 else d + 1) } }
                                                        MenuItem("Delete column / کالم ہٹائیں") { menuFor = ""; sel = TSel.None; change(true) { it.deleteCol(c) } }
                                                    }
                                                }
                                            }
                                        }
                                        // draggable lines between the letters
                                        var acc = 0f
                                        for (d in 0 until cols - 1) {
                                            acc += st.widths[order[d]]
                                            val left = order[d]
                                            val right = order[d + 1]
                                            TblHandle(
                                                vertical = true, at = 14f,
                                                modifier = Modifier.offset(x = (acc * gridW.value).dp - 14.dp).width(28.dp).fillMaxHeight(),
                                                onStart = { push(); guide = it },
                                                onDelta = { dx ->
                                                    val cur = stNow.value
                                                    val f = dx / gridWNow.value
                                                    val total = cur.widths[left] + cur.widths[right]
                                                    val nl = (cur.widths[left] + f).coerceIn(MIN_COL, total - MIN_COL)
                                                    val w = cur.widths.toMutableList()
                                                    w[left] = nl
                                                    w[right] = total - nl
                                                    st = cur.copy(widths = w)
                                                },
                                                onEnd = { guide = null }
                                            )
                                        }
                                    }
                                    Spacer(Modifier.width(10.dp))
                                    // "+" at the end of the letters: add a column
                                    PlusButton { change(true) { it.insertCol(if (rtl) 0 else it.widths.size) } }
                                }
                                Spacer(Modifier.height(4.dp))

                                // ---- rows
                                for (r in 0 until st.rows.size) {
                                    val rowH = if (st.heights[r] <= 0f) AUTO_ROW_DP else st.heights[r]
                                    Row(Modifier.height(IntrinsicSize.Min)) {
                                        val rOn = sel == TSel.All || sel == TSel.Row(r)
                                        Box(
                                            Modifier.width(hdrW).fillMaxHeight()
                                                .border(1.dp, GridLine, RoundedCornerShape(4.dp))
                                                .background(if (rOn) SelFill else HeadFill, RoundedCornerShape(4.dp))
                                                .clickable { sel = TSel.Row(r); menuFor = "row:$r" },
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text("${r + 1}", fontSize = 17.sp, color = Color(0xFF222222))
                                            DropdownMenu(expanded = menuFor == "row:$r", onDismissRequest = { menuFor = "" }, modifier = Modifier.background(MenuBg)) {
                                                MenuItem("Select row / قطار منتخب") { menuFor = ""; sel = TSel.Row(r) }
                                                MenuItem("Insert row above / اوپر قطار شامل") { menuFor = ""; change(true) { it.insertRow(r) } }
                                                MenuItem("Insert row below / نیچے قطار شامل") { menuFor = ""; change(true) { it.insertRow(r + 1) } }
                                                MenuItem("Delete row / قطار ہٹائیں") { menuFor = ""; sel = TSel.None; change(true) { it.deleteRow(r) } }
                                            }
                                            TblHandle(
                                                vertical = false, at = 22f,
                                                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(22.dp),
                                                onStart = { push(); guide = it },
                                                onDelta = { dy ->
                                                    val cur = stNow.value
                                                    val base = if (cur.heights[r] <= 0f) AUTO_ROW_DP else cur.heights[r]
                                                    val h = cur.heights.toMutableList()
                                                    h[r] = (base + dy).coerceAtLeast(MIN_ROW_DP)
                                                    st = cur.copy(heights = h)
                                                },
                                                onEnd = { guide = null }
                                            )
                                        }
                                        for (d in 0 until cols) {
                                            val c = order[d]
                                            val head = st.header && r == 0
                                            val one = sel == TSel.Cell(r, c)
                                            val on = one || sel == TSel.All || sel == TSel.Row(r) || sel == TSel.Col(c)
                                            Box(Modifier.width((st.widths[c] * gridW.value).dp).fillMaxHeight()) {
                                                TblCell(
                                                    text = st.rows[r][c], key = Triple(ver, r, c), head = head, on = on, single = one, rtl = rtl, minH = rowH.dp,
                                                    onText = { t -> st = stNow.value.withCell(r, c, t) },
                                                    onFocus = { sel = TSel.Cell(r, c); push() },
                                                    onTap = { sel = TSel.Cell(r, c) },
                                                    onLong = { sel = TSel.Cell(r, c); menuFor = "cell:$r:$c" }
                                                )
                                                DropdownMenu(expanded = menuFor == "cell:$r:$c", onDismissRequest = { menuFor = "" }, modifier = Modifier.background(MenuBg)) {
                                                    MenuItem("Select") { menuFor = ""; sel = TSel.Cell(r, c) }
                                                    MenuItem("Select All") { menuFor = ""; sel = TSel.All }
                                                    MenuItem("Table Properties") { menuFor = ""; showProps = true }
                                                }
                                            }
                                        }
                                    }
                                }
                                Spacer(Modifier.height(8.dp))
                                // "+" under the numbers: add a row
                                Box(Modifier.width(hdrW), contentAlignment = Alignment.Center) { PlusButton { change(true) { it.insertRow(it.rows.size) } } }
                            }
                            // blue dashed guide line while a column / row line is being dragged
                            Canvas(Modifier.matchParentSize()) {
                                val g = guide
                                if (g != null) {
                                    val p = g.pos.value - rootPos
                                    val pe = PathEffect.dashPathEffect(floatArrayOf(16f, 10f))
                                    if (g.vertical) {
                                        val x = p.x + g.at * density
                                        drawLine(SelBlue, Offset(x, 0f), Offset(x, size.height), strokeWidth = 3f, pathEffect = pe)
                                    } else {
                                        val y = p.y + g.at * density
                                        drawLine(SelBlue, Offset(0f, y), Offset(size.width, y), strokeWidth = 3f, pathEffect = pe)
                                    }
                                }
                            }
                        }
                        Spacer(Modifier.height(18.dp))
                        Text(
                            "کالم یا قطار کو بڑا چھوٹا کرنے کے لیے A B C یا 1 2 3 کے درمیان کی لکیر کو کھینچیں۔\nDrag the line between A B C or 1 2 3 to resize. Press and hold a cell for the menu.",
                            fontSize = 12.sp, color = Color(0xFF666666), modifier = Modifier.padding(end = 16.dp)
                        )
                    }
                }
            }
        }
    }

    if (showProps) AlertDialog(
        onDismissRequest = { showProps = false },
        title = { Text("Table Properties / ٹیبل پراپرٹیز") },
        text = {
            Column {
                Row(Modifier.clickable { change(false) { it.copy(header = !it.header) } }, verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = st.header, onCheckedChange = { v -> change(false) { it.copy(header = v) } })
                    Text("Header row / پہلی قطار عنوان")
                }
                Text("${st.rows.size} × $cols", fontSize = 13.sp, color = Color.DarkGray, modifier = Modifier.padding(start = 12.dp, top = 4.dp))
                TextButton(onClick = { change(false) { it.copy(widths = List(it.widths.size) { 1f / it.widths.size }) } }) { Text("Equal column widths / برابر کالم") }
                TextButton(onClick = { change(false) { it.copy(heights = List(it.rows.size) { 0f }) } }) { Text("Automatic row height / خودکار اونچائی") }
                TextButton(onClick = { showProps = false; onDelete() }) { Text("Delete table / ٹیبل ہٹائیں", color = Color(0xFFD32F2F)) }
            }
        },
        confirmButton = { TextButton(onClick = { showProps = false }) { Text("OK") } }
    )
}

@Composable
private fun MenuItem(label: String, onClick: () -> Unit) {
    DropdownMenuItem(text = { Text(label, color = Color.White, fontSize = 15.sp) }, onClick = onClick)
}

@Composable
private fun PlusButton(onClick: () -> Unit) {
    Box(
        Modifier.size(36.dp).border(1.5.dp, Color(0xFF888888), CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Icon(Icons.Filled.Add, "Add", tint = SelBlue, modifier = Modifier.size(24.dp)) }
}

/** A draggable line between two column letters (vertical = true) or two row numbers. */
@Composable
private fun TblHandle(vertical: Boolean, at: Float, modifier: Modifier, onStart: (GuideRef) -> Unit, onDelta: (Float) -> Unit, onEnd: () -> Unit) {
    val hp = remember { mutableStateOf(Offset.Zero) }
    val density = LocalDensity.current.density
    val startNow = rememberUpdatedState(onStart)
    val deltaNow = rememberUpdatedState(onDelta)
    val endNow = rememberUpdatedState(onEnd)
    Box(
        modifier
            .onGloballyPositioned { hp.value = it.positionInRoot() }
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { startNow.value(GuideRef(hp, vertical, at)) },
                    onDragEnd = { endNow.value() },
                    onDragCancel = { endNow.value() },
                    onDrag = { change, amount ->
                        change.consume()
                        deltaNow.value((if (vertical) amount.x else amount.y) / density)
                    }
                )
            }
    ) {
        val grip = if (vertical) Modifier.width(4.dp).fillMaxHeight(0.6f) else Modifier.height(4.dp).fillMaxWidth(0.6f)
        Box(Modifier.align(if (vertical) Alignment.Center else Alignment.BottomCenter).then(grip).background(Color(0x661E88E5), RoundedCornerShape(2.dp)))
    }
}

@Composable
private fun TblCell(
    text: String, key: Any, head: Boolean, on: Boolean, single: Boolean, rtl: Boolean, minH: Dp,
    onText: (String) -> Unit, onFocus: () -> Unit, onTap: () -> Unit, onLong: () -> Unit
) {
    var value by remember(key) { mutableStateOf(text) }
    val tapNow = rememberUpdatedState(onTap)
    val longNow = rememberUpdatedState(onLong)
    val focusNow = rememberUpdatedState(onFocus)
    Box(
        Modifier.fillMaxSize().heightIn(min = minH)
            .background(if (on) SelFill else if (head) Color(0xFFE8EEF7) else Color.White)
            .border(if (on) 2.dp else 1.dp, if (on) SelBlue else GridLine)
            .drawBehind {
                if (single) {
                    drawCircle(Color(0xFF666666), 7.dp.toPx(), Offset(size.width, 0f))
                    drawCircle(Color(0xFF666666), 7.dp.toPx(), Offset(size.width, size.height))
                }
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Initial)
                    val up = withTimeoutOrNull(viewConfiguration.longPressTimeoutMillis) { waitForUpOrCancellation(PointerEventPass.Initial) }
                    if (up == null) {
                        longNow.value()
                        waitForUpOrCancellation(PointerEventPass.Initial)
                    } else tapNow.value()
                }
            }
    ) {
        BasicTextField(
            value = value,
            onValueChange = { value = it; onText(it) },
            textStyle = TextStyle(
                fontSize = 15.sp, color = Color.Black, fontWeight = if (head) FontWeight.Bold else FontWeight.Normal,
                textDirection = if (rtl) TextDirection.Rtl else TextDirection.Content,
                textAlign = TextAlign.Start
            ),
            modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp, vertical = 8.dp)
                .onFocusChanged { if (it.isFocused) focusNow.value() }
        )
    }
}
