package com.msf.documentwriter

/**
 * Tables are stored in the text as lines of the form  |cell|cell|cell|
 * An optional line like  |---|---|  right after the first row marks it as a header row.
 * On export (PDF / Word / image) these lines become real tables.
 */
sealed class Block
class TextBlock(val a: Int, val b: Int) : Block()
/** rows -> cells -> (start, end) offsets in the full text (spaces already trimmed). */
class TableBlock(
    val rows: List<List<Pair<Int, Int>>>, val header: Boolean,
    /** column widths as fractions of the text width (null = all equal) */
    val widths: List<Float>? = null,
    /** minimum row heights in points (0 = automatic, null = all automatic) */
    val heights: List<Float>? = null
) : Block()

/** The plain-text content of a table plus its sizes, as shown by the table editor. */
class TableData(val rows: List<List<String>>, val header: Boolean, val widths: List<Float>?, val heights: List<Float>?)

/** A table found in the editor text: the lines [a, b) hold it. */
class TableEditState(val et: android.widget.EditText, val a: Int, val b: Int, val data: TableData)

/** Lets the text editors tell the open screen that a table line was tapped. */
object TableHost {
    var handler: ((SelEditText, Int) -> Unit)? = null
}

object Tables {
    fun isRow(line: String): Boolean {
        val t = line.trim()
        return t.length >= 2 && t.startsWith("|") && t.endsWith("|")
    }

    fun isSeparator(line: String): Boolean {
        val t = line.trim()
        return isRow(t) && t.contains('-') && t.all { it == '|' || it == '-' || it == ':' || it == ' ' }
    }

    /** A hidden line  |~w=0.3,0.7;h=0,24|  keeps the column widths (fractions) and row heights (points) of the table above it. */
    fun isMeta(line: String): Boolean {
        val t = line.trim()
        return t.length >= 3 && t.startsWith("|~") && t.endsWith("|")
    }

    fun parseMeta(line: String): Pair<List<Float>?, List<Float>?> {
        var w: List<Float>? = null
        var h: List<Float>? = null
        val t = line.trim().removePrefix("|~").removeSuffix("|")
        for (part in t.split(';')) {
            val kv = part.split('=')
            if (kv.size != 2) continue
            val nums = kv[1].split(',').mapNotNull { it.trim().toFloatOrNull() }
            if (nums.isEmpty()) continue
            if (kv[0].trim() == "w") w = nums else if (kv[0].trim() == "h") h = nums
        }
        return Pair(w, h)
    }

    /** Column fractions that add up to 1 (equal columns when the stored widths do not fit). */
    fun fractions(w: List<Float>?, cols: Int): List<Float> {
        if (w == null || w.size != cols || w.any { it <= 0f }) return List(cols) { 1f / cols }
        val sum = w.sum()
        return w.map { it / sum }
    }

    /** Cell ranges of the line s[ps, pe). */
    private fun cells(s: String, ps: Int, pe: Int): List<Pair<Int, Int>> {
        val first = s.indexOf('|', ps)
        val last = s.lastIndexOf('|', pe - 1)
        val out = ArrayList<Pair<Int, Int>>()
        if (first < 0 || last <= first) return out
        var p = first
        while (p < last) {
            val q = s.indexOf('|', p + 1)
            var a = p + 1
            var b = q
            while (a < b && s[a] == ' ') a++
            while (b > a && s[b - 1] == ' ') b--
            out.add(Pair(a, b))
            p = q
        }
        return out
    }

    /** Splits s[from, to) into plain-text blocks and table blocks. */
    fun split(s: String, from: Int, to: Int): List<Block> {
        val out = ArrayList<Block>()
        var textStart = from
        var ps = from
        var rows = ArrayList<List<Pair<Int, Int>>>()
        var header = false
        var inTable = false
        var mw: List<Float>? = null
        var mh: List<Float>? = null
        while (ps <= to) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0 || nl > to) to else nl
            val line = s.substring(ps, pe)
            if (isRow(line) && (inTable || !isMeta(line))) {
                if (!inTable) {
                    inTable = true
                    val b = if (ps > textStart && s[ps - 1] == '\n') ps - 1 else ps
                    if (b > textStart) out.add(TextBlock(textStart, b))
                }
                if (isMeta(line)) { val m = parseMeta(line); mw = m.first; mh = m.second }
                else if (isSeparator(line)) { if (rows.size == 1) header = true } else rows.add(cells(s, ps, pe))
            } else if (inTable) {
                if (rows.isNotEmpty()) out.add(TableBlock(rows, header, mw, mh))
                rows = ArrayList(); header = false; inTable = false; mw = null; mh = null
                textStart = ps
            }
            if (pe >= to) break
            ps = pe + 1
        }
        if (inTable) {
            if (rows.isNotEmpty()) out.add(TableBlock(rows, header, mw, mh))
        } else if (textStart < to) out.add(TextBlock(textStart, to))
        return out
    }

    fun any(s: String): Boolean = split(s, 0, s.length).any { it is TableBlock }

    /** Text lines for a new empty table. */
    fun template(rows: Int, cols: Int, header: Boolean): String {
        val row = "|" + "   |".repeat(cols)
        val sep = "|" + "---|".repeat(cols)
        val sb = StringBuilder()
        for (r in 0 until rows) {
            sb.append(row).append('\n')
            if (r == 0 && header) sb.append(sep).append('\n')
        }
        return sb.toString()
    }

    /** The table whose line holds [pos] in the editor text, or null. */
    fun stateAt(et: android.widget.EditText, pos: Int): TableEditState? {
        val s = et.text.toString()
        val p = pos.coerceIn(0, s.length)
        fun lineStart(x: Int): Int = if (x <= 0) 0 else s.lastIndexOf('\n', x - 1) + 1
        fun lineEnd(x: Int): Int { val i = s.indexOf('\n', x); return if (i < 0) s.length else i }
        var ls = lineStart(p)
        var le = lineEnd(p)
        if (!isRow(s.substring(ls, le))) return null
        while (ls > 0) {
            val ps = lineStart(ls - 1)
            if (isRow(s.substring(ps, ls - 1))) ls = ps else break
        }
        while (le < s.length) {
            val ne = lineEnd(le + 1)
            if (isRow(s.substring(le + 1, ne))) le = ne else break
        }
        val tb = split(s, ls, le).firstOrNull { it is TableBlock } as? TableBlock ?: return null
        val rows = tb.rows.map { r -> r.map { s.substring(it.first, it.second) } }
        return TableEditState(et, ls, le, TableData(rows, tb.header, tb.widths, tb.heights))
    }

    private fun f3(v: Float): String = String.format(java.util.Locale.US, "%.3f", v)

    /** The text lines for a table (without the final newline). */
    fun serialize(d: TableData): String {
        val cols = d.rows.maxOfOrNull { it.size }?.coerceAtLeast(1) ?: 1
        val sb = StringBuilder()
        for ((i, r) in d.rows.withIndex()) {
            sb.append('|')
            for (c in 0 until cols) sb.append(' ').append((r.getOrNull(c) ?: "").replace("|", "¦").replace("\n", " ").trim()).append(" |")
            sb.append('\n')
            if (i == 0 && d.header) sb.append("|").append("---|".repeat(cols)).append('\n')
        }
        val w = d.widths
        val h = d.heights
        val wOk = w != null && w.size == cols
        val hOk = h != null && h.any { it > 0f }
        if (wOk || hOk) {
            val parts = ArrayList<String>()
            if (wOk) parts.add("w=" + w!!.joinToString(",") { f3(it) })
            if (hOk) parts.add("h=" + h!!.joinToString(",") { f3(it) })
            sb.append("|~").append(parts.joinToString(";")).append("|\n")
        }
        if (sb.isNotEmpty()) sb.setLength(sb.length - 1)
        return sb.toString()
    }

    /** Writes the edited table back into the editor text. [text] = "" removes the table. */
    fun apply(st: TableEditState, d: TableData?, decorate: (android.text.Editable) -> Unit) {
        val et = st.et
        val e = et.text
        val a = st.a.coerceIn(0, e.length)
        val b = st.b.coerceIn(a, e.length)
        if (d == null) {
            val end = if (b < e.length && e[b] == '\n') b + 1 else b
            e.delete(a, end)
            decorate(e)
            et.setSelection(a.coerceIn(0, e.length))
            return
        }
        val str = serialize(d)
        e.replace(a, b, str)
        val end = a + str.length
        if (end >= e.length) e.append("\n")
        decorate(e)
        et.setSelection((end + 1).coerceIn(0, e.length))
    }
}
