package com.msf.documentwriter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.ui.unit.TextUnit
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TpHead = Color(0xFF2B2B2B)
private val TpBody = Color(0xFF1E1E1E)
private val TpCard = Color(0xFF232323)
private val TpLine = Color(0xFF3C3C3C)
private val TpAcc = Color(0xFF4A8BEF)
private val TpGrey = Color(0xFF8E8E8E)
private val TpIcon = Color(0xFFD0D0D0)

/** Everything the Aa sheet can do; the editor fills these in. */
class FormatActions(
    val onSize: (Int) -> Unit, val onFont: (String, String) -> Unit, val onAddFont: () -> Unit,
    val onBold: () -> Unit, val onItalic: () -> Unit, val onUnder: () -> Unit, val onStrike: () -> Unit,
    val onColor: (Int?) -> Unit, val onHighlight: (Int?) -> Unit,
    val onSpacing: (Float) -> Unit, val onAlign: (Int) -> Unit, val onJustify: () -> Unit, val onRtl: () -> Unit,
    val onClose: () -> Unit, val onKeyboard: () -> Unit
)

private val GridColors = listOf(
    0xFF99CCFF, 0xFFCC99FF, 0xFFCCFFCC, 0xFFFFCC99, 0xFFFFE0E0, 0xFFFFFFFF,
    0xFF3399FF, 0xFF9933FF, 0xFF66FF66, 0xFFFFCC00, 0xFFD96666, 0xFFC0C0C0,
    0xFF0000FF, 0xFF6600CC, 0xFF99CC00, 0xFFFF9900, 0xFF993300, 0xFF808080,
    0xFF000099, 0xFF330066, 0xFF007F00, 0xFFFF6600, 0xFF800000, 0xFF000000
)
private val StdColors = listOf(
    0xFFC00000, 0xFFFFC000, 0xFF92D050, 0xFF00B0F0, 0xFF7030A0, 0xFFFFFFFF,
    0xFFFF0000, 0xFFFFFF00, 0xFF00B050, 0xFF0070C0, 0xFF002060, 0xFF000000
)
private val HiGrid = listOf(
    0xFFFFFF00, 0xFF00FF00, 0xFF008000, 0xFF800080, 0xFF00FFFF,
    0xFF000080, 0xFF008080, 0xFF800000, 0xFFFF0000, 0xFFFF00FF,
    0xFF808000, 0xFFD3D3D3, 0xFF000000, 0xFF0000FF, 0xFFA9A9A9
)
private val SpacingList = listOf(1.0f, 1.15f, 1.5f, 2.0f, 2.5f, 3.0f)

@Composable
private fun TpChevron(down: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(if (down) 20.dp else 12.dp, if (down) 12.dp else 20.dp)) {
            val w = 2.dp.toPx()
            if (down) {
                drawLine(TpIcon, Offset(0f, 0f), Offset(size.width / 2f, size.height), w)
                drawLine(TpIcon, Offset(size.width / 2f, size.height), Offset(size.width, 0f), w)
            } else {
                drawLine(TpIcon, Offset(size.width, 0f), Offset(0f, size.height / 2f), w)
                drawLine(TpIcon, Offset(0f, size.height / 2f), Offset(size.width, size.height), w)
            }
        }
    }
}

@Composable
private fun TpKeyboard(onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.Keyboard, "Keyboard", tint = TpIcon, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TpCardBox(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    var m = modifier.background(TpCard, RoundedCornerShape(12.dp)).border(1.dp, TpLine, RoundedCornerShape(12.dp))
    if (onClick != null) m = m.clickable { onClick() }
    Box(m, contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun TpDot(c: Long, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).background(Color(c), CircleShape)
            .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color(0xFF555555), CircleShape)
            .clickable { onClick() }
    )
}

@Composable
private fun TpLines(kind: Int, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp, 40.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(6.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (kind == 4) Text("RTL", color = if (on) TpAcc else TpIcon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        else Canvas(Modifier.size(22.dp)) {
            val col = if (on) TpAcc else TpIcon
            val w = 1.6.dp.toPx()
            val full = size.width
            val widths = if (kind == 3) listOf(full, full, full, full) else listOf(full, full * 0.6f, full, full * 0.6f)
            for (i in 0 until 4) {
                val y = size.height * (0.12f + 0.25f * i)
                val x0 = when (kind) { 1 -> (full - widths[i]) / 2f; 2 -> full - widths[i]; else -> 0f }
                drawLine(col, Offset(x0, y), Offset(x0 + widths[i], y), w)
            }
        }
    }
}

@Composable
fun FormatSheet(
    a: FormatActions, sizeNow: Int, fontLabel: String, bold: Boolean, italic: Boolean, under: Boolean,
    curColor: Color, spacing: Float, justify: Boolean, rtl: Boolean,
    file: List<Pair<String, () -> Unit>>, insert: List<Pair<String, () -> Unit>>, view: List<Pair<String, () -> Unit>>,
    x: FormatActions2 = FormatActions2(), u: ParaUi = ParaUi(),
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf("") }
    var alignSel by remember { mutableIntStateOf(-1) }
    var hiNone by remember { mutableStateOf(true) }
    val tabs = listOf("Home", "File", "Insert", "View")

    MaterialTheme(colorScheme = PsScheme) {
        Column(modifier.fillMaxWidth().background(TpBody)) {
            if (page == "") {
                Row(Modifier.fillMaxWidth().height(52.dp).background(TpHead), verticalAlignment = Alignment.CenterVertically) {
                    TpChevron(true) { a.onClose() }
                    Box(Modifier.width(1.dp).height(24.dp).background(Color(0xFF444444)))
                    Spacer(Modifier.width(8.dp))
                    Row(Modifier.weight(1f), horizontalArrangement = Arrangement.SpaceEvenly) {
                        tabs.forEachIndexed { i, t ->
                            Column(Modifier.clickable { tab = i }.padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Spacer(Modifier.height(15.dp))
                                Text(t, color = if (tab == i) TpAcc else Color(0xFFCFCFCF), fontSize = 17.sp)
                                Spacer(Modifier.height(11.dp))
                                Box(Modifier.width(44.dp).height(2.dp).background(if (tab == i) TpAcc else Color.Transparent))
                            }
                        }
                    }
                    TpKeyboard { a.onKeyboard() }
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    when (tab) {
                        0 -> HomeTab(a, sizeNow, fontLabel, bold, italic, under, curColor, spacing, justify, rtl, alignSel, { alignSel = it }, { page = it }, menu, { menu = it }, x, u)
                        1 -> ItemList(file)
                        2 -> ItemList(insert)
                        else -> ItemList(view)
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().height(52.dp).background(TpHead), verticalAlignment = Alignment.CenterVertically) {
                    TpChevron(false) { page = "" }
                    TpKeyboard { a.onKeyboard() }
                    Box(Modifier.width(1.dp).height(24.dp).background(Color(0xFF444444)))
                    Text(if (page == "hi") "Highlight" else "Text Color", color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(52.dp))
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp)) {
                    if (page == "hi") {
                        Row(
                            Modifier.fillMaxWidth().height(48.dp).border(1.dp, if (hiNone) TpAcc else TpLine, RoundedCornerShape(3.dp))
                                .clickable { hiNone = true; a.onHighlight(null) }.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            NoFillIcon()
                            Spacer(Modifier.width(12.dp))
                            Text("No Fill", color = TpAcc, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            if (hiNone) Text("✓", color = TpAcc, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(18.dp))
                        HiGrid.chunked(5).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { hiNone = false; a.onHighlight(Color(c).toArgb()) } }
                            }
                        }
                    } else {
                        GridColors.chunked(6).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { a.onColor(Color(c).toArgb()) } }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Standard Colors", color = TpGrey, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        StdColors.chunked(6).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { a.onColor(Color(c).toArgb()) } }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BigDot(c: Long, onClick: () -> Unit) {
    Box(Modifier.size(50.dp).background(Color(c), CircleShape).clickable { onClick() })
}

@Composable
private fun NoFillIcon() {
    Canvas(Modifier.size(26.dp)) {
        val w = 1.6.dp.toPx()
        drawCircle(TpIcon, radius = size.width / 2f - w, style = androidx.compose.ui.graphics.drawscope.Stroke(w))
        drawLine(TpIcon, Offset(size.width * 0.2f, size.height * 0.8f), Offset(size.width * 0.8f, size.height * 0.2f), w)
    }
}

@Composable
private fun ItemList(items: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxWidth()) {
        items.forEach { (label, act) ->
            Text(label, color = Color.White, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().clickable { act() }.padding(horizontal = 20.dp, vertical = 16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2E2E2E)))
        }
    }
}

@Composable
private fun HomeTab(
    a: FormatActions, sizeNow: Int, fontLabel: String, bold: Boolean, italic: Boolean, under: Boolean,
    curColor: Color, spacing: Float, justify: Boolean, rtl: Boolean, alignSel: Int, setAlign: (Int) -> Unit,
    setPage: (String) -> Unit, menu: String, setMenu: (String) -> Unit, x: FormatActions2, u: ParaUi
) {
    Column(Modifier.fillMaxWidth().padding(14.dp)) {
        Row(Modifier.fillMaxWidth().height(172.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(0.8f)) {
                TpCardBox(Modifier.fillMaxSize(), { setMenu("size") }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Size", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$sizeNow", color = TpAcc, fontSize = 26.sp)
                    }
                }
                DropdownMenu(expanded = menu == "size", onDismissRequest = { setMenu("") }) {
                    SizeList.forEach { z ->
                        DropdownMenuItem(text = { Text(if (z == sizeNow) "✓ $z" else "$z", color = Color.White) }, onClick = { setMenu(""); a.onSize(z) })
                    }
                }
            }
            Column(Modifier.weight(2.2f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    TpCardBox(Modifier.fillMaxSize(), { setMenu("font") }) {
                        Text(fontLabel, color = Color.White, fontSize = 20.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu == "font", onDismissRequest = { setMenu("") }) {
                        FontMenuItems(onPick = { l, f -> setMenu(""); a.onFont(l, f) }, onAdd = { setMenu(""); a.onAddFont() })
                    }
                }
                TpCardBox(Modifier.fillMaxWidth().weight(1f)) {
                    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        StyleBtn("B", bold, FontWeight.Normal, FontStyle.Normal, TextDecoration.None) { a.onBold() }
                        StyleBtn("I", italic, FontWeight.Normal, FontStyle.Italic, TextDecoration.None) { a.onItalic() }
                        StyleBtn("U", under, FontWeight.Normal, FontStyle.Normal, TextDecoration.Underline) { a.onUnder() }
                        StyleBtn("S", false, FontWeight.Normal, FontStyle.Normal, TextDecoration.LineThrough) { a.onStrike() }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Text Color", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(76.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TpCardBox(Modifier.weight(1f).fillMaxSize()) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    listOf(0xFF3A3A46, 0xFFC00000, 0xFFFFC000, 0xFF92D050, 0xFF00B0F0).forEach { c ->
                        TpDot(c, curColor == Color(c)) { a.onColor(Color(c).toArgb()) }
                    }
                    Text("···", color = TpIcon, fontSize = 22.sp, modifier = Modifier.clickable { setPage("color") }.padding(4.dp))
                }
            }
            Box(
                Modifier.width(110.dp).fillMaxSize().border(1.dp, TpAcc, RoundedCornerShape(12.dp)).clickable { a.onColor(null) },
                contentAlignment = Alignment.Center
            ) { Text("Automatic", color = TpAcc, fontSize = 16.sp) }
        }
        Spacer(Modifier.height(16.dp))
        Text("Highlight", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        TpCardBox(Modifier.fillMaxWidth().height(76.dp)) {
            Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                listOf(0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFFFF00FF, 0xFFFF0000).forEach { c ->
                    TpDot(c, false) { a.onHighlight(Color(c).toArgb()) }
                }
                Box(Modifier.size(34.dp).clickable { a.onHighlight(null) }, contentAlignment = Alignment.Center) { NoFillIcon() }
                Text("···", color = TpIcon, fontSize = 22.sp, modifier = Modifier.clickable { setPage("hi") }.padding(4.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().height(94.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                TpCardBox(Modifier.fillMaxSize(), { setMenu("sp") }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Multiple", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(String.format(java.util.Locale.US, "%.1f", spacing), color = TpAcc, fontSize = 24.sp)
                    }
                }
                DropdownMenu(expanded = menu == "sp", onDismissRequest = { setMenu("") }) {
                    SpacingList.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.'), color = Color.White) },
                            onClick = { setMenu(""); a.onSpacing(v) }
                        )
                    }
                }
            }
            TpCardBox(Modifier.weight(2.2f).fillMaxSize()) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TpLines(0, alignSel == 0) { setAlign(0); a.onAlign(0) }
                    TpLines(1, alignSel == 1) { setAlign(1); a.onAlign(1) }
                    TpLines(2, alignSel == 2) { setAlign(2); a.onAlign(2) }
                    TpLines(3, justify) { a.onJustify() }
                    TpLines(4, rtl) { a.onRtl() }
                }
            }
        }
        ParagraphSection(x, u, menu, setMenu)
        Spacer(Modifier.height(20.dp))
    }
}

@Composable
private fun StyleTile(sample: String, label: String, size: TextUnit, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.fillMaxHeight().border(1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(12.dp)).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text(sample, color = Color.White, fontSize = size, maxLines = 1)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
        Box(Modifier.fillMaxWidth().height(30.dp), contentAlignment = Alignment.Center) {
            Text(label, color = if (on) TpAcc else TpIcon, fontSize = 15.sp, maxLines = 1)
        }
    }
}

@Composable
private fun ListGlyph(markers: List<String>, on: Boolean) {
    val c = if (on) TpAcc else TpIcon
    Column(verticalArrangement = Arrangement.spacedBy(1.dp)) {
        markers.forEach { m ->
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(m, color = c, fontSize = 9.sp, modifier = Modifier.width(15.dp))
                Box(Modifier.width(18.dp).height(2.dp).background(c))
            }
        }
    }
}

@Composable
private fun ListBtn(on: Boolean, onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        Modifier.size(48.dp, 44.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(8.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun ColsIcon(mode: Int, on: Boolean) {
    Canvas(Modifier.size(30.dp)) {
        val col = if (on) TpAcc else TpIcon
        val w = 1.6.dp.toPx()
        val cs = Cols.layout(mode, size.width, size.width * 0.14f)
        for ((cx, cw) in cs) for (r in 0 until 5) {
            val y = size.height * (0.1f + 0.2f * r)
            drawLine(col, Offset(cx, y), Offset(cx + cw, y), w)
        }
    }
}

@Composable
private fun CellBtn(label: String, modifier: Modifier, on: Boolean = false, enabled: Boolean = true, size: TextUnit = 17.sp, onClick: () -> Unit) {
    Box(modifier.clickable(enabled = enabled) { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = if (!enabled) TpGrey else if (on) TpAcc else Color.White, fontSize = size)
    }
}

/** Style, Bullets & Numbers, Increase / Decrease, Auto Numbering, Indents & Spacing, Smart Typography, Columns, script and case buttons. */
@Composable
private fun ParagraphSection(x: FormatActions2, u: ParaUi, menu: String, setMenu: (String) -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        Spacer(Modifier.height(18.dp))
        Text("Style", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(70.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            StyleTile("AaBbCcDd", "Normal", 13.sp, u.style == 0, Modifier.weight(1f)) { x.onStyle(0) }
            StyleTile("AaBb", "Heading 1", 20.sp, u.style == 1, Modifier.weight(1f)) { x.onStyle(1) }
            StyleTile("AaBbC", "Heading 2", 17.sp, u.style == 2, Modifier.weight(1f)) { x.onStyle(2) }
            StyleTile("AaBbCcD", "Heading 3", 14.sp, u.style == 3, Modifier.weight(1f)) { x.onStyle(3) }
            Box(Modifier.width(44.dp).fillMaxHeight()) {
                Box(
                    Modifier.fillMaxSize().border(1.dp, if (u.style >= 4) TpAcc else TpLine, RoundedCornerShape(12.dp)).clickable { setMenu("styles") },
                    contentAlignment = Alignment.Center
                ) { Text("···", color = TpIcon, fontSize = 20.sp) }
                DropdownMenu(expanded = menu == "styles", onDismissRequest = { setMenu("") }) {
                    listOf(4 to "Title", 5 to "Subtitle", 6 to "Quote").forEach { (id, n) ->
                        DropdownMenuItem(text = { Text(if (u.style == id) "✓ $n" else n, color = Color.White) }, onClick = { setMenu(""); x.onStyle(id) })
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Bullets & Numbers", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        TpCardBox(Modifier.fillMaxWidth().height(70.dp)) {
            Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                ListBtn(u.list == 1, { x.onList(1) }) { ListGlyph(listOf("•", "•", "•"), u.list == 1) }
                ListBtn(u.list == 2, { x.onList(2) }) { ListGlyph(listOf("▪", "▪", "▪"), u.list == 2) }
                ListBtn(u.list == 3, { x.onList(3) }) { ListGlyph(listOf("1.", "2.", "3."), u.list == 3) }
                ListBtn(u.list == 4, { x.onList(4) }) { ListGlyph(listOf("1.", "1.1", "1.2"), u.list == 4) }
                ListBtn(false, { x.onList(0) }) { NoFillIcon() }
                Box {
                    ListBtn(u.list >= 5, { setMenu("lists") }) { Text("···", color = if (u.list >= 5) TpAcc else TpIcon, fontSize = 20.sp) }
                    DropdownMenu(expanded = menu == "lists", onDismissRequest = { setMenu("") }) {
                        listOf(5 to "○  Circle", 6 to "➤  Arrow", 7 to "✓  Tick", 8 to "–  Dash", 9 to "a)  b)  c)", 10 to "A.  B.  C.").forEach { (id, n) ->
                            DropdownMenuItem(text = { Text(if (u.list == id) "✓ $n" else n, color = Color.White) }, onClick = { setMenu(""); x.onList(id) })
                        }
                    }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        TpCardBox(Modifier.fillMaxWidth()) {
            Column(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().height(54.dp)) {
                    CellBtn("Increase", Modifier.weight(1f).fillMaxHeight()) { x.onLevel(1) }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(TpLine))
                    CellBtn("Decrease", Modifier.weight(1f).fillMaxHeight()) { x.onLevel(-1) }
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
                Row(Modifier.fillMaxWidth().height(54.dp)) {
                    CellBtn("Restart", Modifier.weight(1f).fillMaxHeight()) { x.onRestart() }
                    Box(Modifier.width(1.dp).fillMaxHeight().background(TpLine))
                    CellBtn("Continue", Modifier.weight(1f).fillMaxHeight()) { x.onContinue() }
                }
            }
        }

        Spacer(Modifier.height(12.dp))
        TpCardBox(Modifier.fillMaxWidth().height(60.dp)) {
            Row(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("1.", color = TpIcon, fontSize = 18.sp)
                Spacer(Modifier.width(14.dp))
                Text("Auto Numbering", color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
                Switch(
                    checked = u.autoNum, onCheckedChange = { x.onAutoNum(it) },
                    colors = SwitchDefaults.colors(checkedTrackColor = TpAcc, checkedThumbColor = Color.White)
                )
            }
        }

        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth().height(56.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TpCardBox(Modifier.weight(1f).fillMaxHeight(), { x.onIndents() }) { Text("Indents & Spacing", color = Color.White, fontSize = 16.sp) }
            TpCardBox(Modifier.weight(1f).fillMaxHeight(), { x.onSmart() }) { Text("Smart Typography", color = Color.White, fontSize = 16.sp) }
        }

        Spacer(Modifier.height(16.dp))
        Text("Columns", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        TpCardBox(Modifier.fillMaxWidth().height(84.dp)) {
            Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                listOf("One", "Two", "Three", "Left", "Right").forEachIndexed { i, n ->
                    Column(
                        Modifier.clickable { x.onColumns(i) }.padding(horizontal = 8.dp, vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        ColsIcon(i, u.columns == i)
                        Spacer(Modifier.height(4.dp))
                        Text(n, color = if (u.columns == i) TpAcc else Color.White, fontSize = 15.sp)
                    }
                }
            }
        }

        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().height(58.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TpCardBox(Modifier.weight(1f).fillMaxHeight()) {
                Row(Modifier.fillMaxSize()) {
                    CellBtn("T²", Modifier.weight(1f).fillMaxHeight(), u.sup, size = 24.sp) { x.onSuper() }
                    CellBtn("T₂", Modifier.weight(1f).fillMaxHeight(), u.sub, size = 24.sp) { x.onSub() }
                }
            }
            TpCardBox(Modifier.weight(1.7f).fillMaxHeight()) {
                Row(Modifier.fillMaxSize()) {
                    CellBtn("Small Caps", Modifier.weight(1f).fillMaxHeight(), size = 16.sp) { x.onSmallCaps() }
                    Box(Modifier.width(1.dp).fillMaxHeight().padding(vertical = 14.dp).background(TpLine))
                    CellBtn("All Caps", Modifier.weight(1f).fillMaxHeight(), size = 16.sp) { x.onAllCaps() }
                }
            }
        }
        Spacer(Modifier.height(22.dp))
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
            Text("— MSF DOCUMENT WRITER —", color = TpGrey, fontSize = 14.sp)
        }
    }
}

@Composable
private fun StyleBtn(label: String, on: Boolean, w: FontWeight, st: FontStyle, deco: TextDecoration, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp, 44.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(8.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = if (on) TpAcc else TpIcon, fontSize = 26.sp, fontWeight = if (label == "B") FontWeight.Medium else w,
            fontStyle = st, textDecoration = deco
        )
    }
}
