package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.Editable
import android.text.Spanned
import android.text.style.ReplacementSpan

/** Page border designs (assets/pages) and the "new page" marker used inside the text. */
object PageDesigns {
    /** mx / mt / mb = text margins as a fraction of the page width / height, chosen to stay inside the border. */
    class Spec(val id: Int, val en: String, val ur: String, val asset: String, val mx: Float, val mt: Float, val mb: Float)

    val all: List<Spec> = listOf(
        Spec(1, "Golden Border", "سنہری بارڈر", "pages/page_design_1.jpg", 0.105f, 0.125f, 0.125f),
        Spec(2, "Islamic Frame", "اسلامی فریم", "pages/page_design_2.jpg", 0.105f, 0.150f, 0.150f)
    )

    /** Width / height of the page sheet (A4). */
    const val RATIO = 0.7071f

    fun spec(id: Int): Spec? = all.firstOrNull { it.id == id }

    private val cache = HashMap<Int, Bitmap?>()

    fun bitmap(c: Context, id: Int): Bitmap? {
        val s = spec(id) ?: return null
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            c.applicationContext.assets.open(s.asset).use { BitmapFactory.decodeStream(it) }
        } catch (e: Throwable) { null }
        cache[id] = b
        return b
    }

    fun bytes(c: Context, id: Int): ByteArray? {
        val s = spec(id) ?: return null
        return try { c.applicationContext.assets.open(s.asset).use { it.readBytes() } } catch (e: Throwable) { null }
    }
}

/** Page break character (form feed). It sits alone on its own line and is drawn as a full-width "page ends / next page" band. */
const val PAGE_BREAK = '\u000C'

/** [n] = number of the page that ends here. */
class PageBreakSpan(private val n: Int = 1) : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int {
        if (fm != null) { fm.ascent = -46; fm.descent = 46; fm.top = -46; fm.bottom = 46 }
        return android.content.res.Resources.getSystem().displayMetrics.widthPixels
    }

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val cb = canvas.clipBounds
        val left = if (cb.width() > 10) cb.left.toFloat() else x
        val right = if (cb.width() > 10) cb.right.toFloat() else x + 600f
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFFD9E2F1.toInt()
        canvas.drawRect(left, top + 8f, right, bottom - 8f, p)
        p.color = 0xFF7F9CCB.toInt()
        p.strokeWidth = 3f
        canvas.drawLine(left, top + 8f, right, top + 8f, p)
        canvas.drawLine(left, bottom - 8f, right, bottom - 8f, p)
        p.color = 0xFF0B4DB8.toInt()
        p.textSize = paint.textSize * 0.8f
        p.textAlign = Paint.Align.CENTER
        canvas.drawText("▲ صفحہ $n ختم   |   ▼ صفحہ ${n + 1} شروع", (left + right) / 2f, (top + bottom) / 2f + p.textSize / 3f, p)
    }
}

/** Light background + rules for the lines of a table (editor only; never exported). */
class TableRowSpan(val fill: Int = 0xFFEAF1FF.toInt(), val rule: Int = 0xFF7F9CCB.toInt()) : android.text.style.LineBackgroundSpan {
    /** Width of the table in pixels (set by [TableGrid]); -1 = the whole text width. */
    var width = -1f

    override fun drawBackground(
        c: Canvas, p: Paint, left: Int, right: Int, top: Int, baseline: Int, bottom: Int,
        text: CharSequence, start: Int, end: Int, lnum: Int
    ) {
        var l = left.toFloat()
        var r = right.toFloat()
        if (width > 0f) {
            if (TableGrid.rtl) l = maxOf(l, r - width) else r = minOf(r, l + width)
        }
        val q = Paint()
        q.color = fill
        c.drawRect(l, top.toFloat(), r, bottom.toFloat(), q)
        q.color = rule
        q.strokeWidth = 2f
        c.drawLine(l, top.toFloat(), r, top.toFloat(), q)
        c.drawLine(l, bottom.toFloat(), r, bottom.toFloat(), q)
    }
}

object PageBreaks {
    /** Re-draws the page-break bands (numbered) and table-row backgrounds. Needed after loading text and after edits. */
    fun decorate(e: Editable) {
        for (s in e.getSpans(0, e.length, PageBreakSpan::class.java)) e.removeSpan(s)
        for (s in e.getSpans(0, e.length, TableRowSpan::class.java)) e.removeSpan(s)
        val str = e.toString()
        var n = 0
        for (i in 0 until str.length) {
            if (str[i] == PAGE_BREAK) { n++; e.setSpan(PageBreakSpan(n), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE) }
        }
        var ps = 0
        val deco = TableDeco(e)
        while (ps <= str.length) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            deco.line(ps, pe, str.substring(ps, pe))
            if (nl < 0) break
            ps = nl + 1
        }
    }

    /** Changes whenever the number of page breaks or table lines changes (so decorate() is only needed then). */
    fun signature(e: CharSequence): Int {
        val str = e.toString()
        var breaks = 0
        for (ch in str) if (ch == PAGE_BREAK) breaks++
        var rows = 0
        var ps = 0
        while (ps <= str.length) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            if (pe > ps && Tables.isRow(str.substring(ps, pe))) rows++
            if (nl < 0) break
            ps = nl + 1
        }
        return breaks * 100003 + rows
    }

    /** Inserts [text] at [pos] on its own lines; returns the new cursor position. */
    fun insertBlock(e: Editable, pos: Int, text: String, cursorInside: Int): Int {
        val p = pos.coerceIn(0, e.length)
        val pre = if (p > 0 && e[p - 1] != '\n') "\n" else ""
        e.insert(p, pre + text)
        decorate(e)
        return (p + pre.length + cursorInside).coerceIn(0, e.length)
    }

    fun insertAt(e: Editable, pos: Int): Int {
        val p = pos.coerceIn(0, e.length)
        e.insert(p, "\n$PAGE_BREAK\n")
        decorate(e)
        return p + 3
    }

    /** An empty page of its own between the previous and the next text. */
    fun insertBlank(e: Editable, pos: Int): Int {
        val p = pos.coerceIn(0, e.length)
        e.insert(p, "\n$PAGE_BREAK\n$PAGE_BREAK\n")
        decorate(e)
        return p + 5
    }
}
