package com.msf.documentwriter

import android.text.Editable
import android.text.Spanned

/** Where the cursor is inside a table: size, current row / column (0-based), header flag and colour style. */
class TblInfo(val rows: Int, val cols: Int, val row: Int, val col: Int, val header: Boolean, val style: Int)

/**
 * Table editing on the |cell|cell| text lines used by the editor.
 * All functions take the editor text and a cursor position inside the table.
 */
object TableOps {
    private fun lineStart(s: String, p: Int): Int = s.lastIndexOf('\n', p - 1) + 1
    private fun lineEnd(s: String, p: Int): Int {
        val n = s.indexOf('\n', p)
        return if (n < 0) s.length else n
    }

    private class Lines(val starts: List<Int>, val ends: List<Int>)

    private fun lines(s: String, pos: Int): Lines? {
        val p = pos.coerceIn(0, s.length)
        val ls0 = lineStart(s, p)
        if (!Tables.isRow(s.substring(ls0, lineEnd(s, ls0)))) return null
        var first = ls0
        while (first > 0) {
            val ps = lineStart(s, first - 1)
            if (Tables.isRow(s.substring(ps, first - 1))) first = ps else break
        }
        val starts = ArrayList<Int>()
        val ends = ArrayList<Int>()
        var cur = first
        while (cur <= s.length) {
            val e = lineEnd(s, cur)
            if (!Tables.isRow(s.substring(cur, e))) break
            starts.add(cur); ends.add(e)
            if (e >= s.length) break
            cur = e + 1
        }
        if (starts.isEmpty()) return null
        return Lines(starts, ends)
    }

    private fun pipes(s: String, a: Int, b: Int): List<Int> {
        val out = ArrayList<Int>()
        for (i in a until b) if (s[i] == '|') out.add(i)
        return out
    }

    private fun isSep(s: String, ls: Lines, i: Int): Boolean = Tables.isSeparator(s.substring(ls.starts[i], ls.ends[i]))

    /** Indexes (into the table lines) of the real rows, i.e. without the |---| header line. */
    private fun dataLines(s: String, ls: Lines): List<Int> = ls.starts.indices.filter { !isSep(s, ls, it) }

    private fun hasHeader(s: String, ls: Lines): Boolean = ls.starts.size > 1 && isSep(s, ls, 1)

    private fun template(cols: Int) = "|" + "   |".repeat(cols)
    private fun separator(cols: Int) = "|" + "---|".repeat(cols)

    fun info(e: Editable, pos: Int): TblInfo? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val data = dataLines(s, ls)
        if (data.isEmpty()) return null
        val p = pos.coerceIn(0, s.length)
        var li = ls.starts.indexOfLast { it <= p }
        if (li < 0) li = 0
        var row = data.indexOf(li)
        if (row < 0) row = 0
        val pl = pipes(s, ls.starts[li], ls.ends[li])
        val cols = (pipes(s, ls.starts[data[0]], ls.ends[data[0]]).size - 1).coerceAtLeast(1)
        var col = pl.count { it < p } - 1
        col = col.coerceIn(0, cols - 1)
        return TblInfo(data.size, cols, row, col, hasHeader(s, ls), TableStyles.at(e, ls.starts[0]))
    }

    /** Puts the colour style on the first line of the table that contains [pos]. */
    fun setStyle(e: Editable, pos: Int, style: Int) {
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val a = ls.starts[0]
        val b = ls.ends[ls.ends.size - 1]
        for (sp in e.getSpans(a, b, TableStyleSpan::class.java)) e.removeSpan(sp)
        if (style > 0) {
            val end = ls.ends[0]
            val spEnd = if (end < s.length) end + 1 else end
            if (spEnd > a) e.setSpan(TableStyleSpan(style), a, spEnd, Spanned.SPAN_PARAGRAPH)
        }
    }

    /** Cursor position inside cell (row, col) of the table that contains [pos]. */
    fun cellPos(e: Editable, pos: Int, row: Int, col: Int): Int {
        val r = cellRange(e, pos, row, col) ?: return pos
        return r.second
    }

    /** Text range of a cell; an empty cell gives the whole space between its two bars. */
    fun cellRange(e: Editable, pos: Int, row: Int, col: Int): Pair<Int, Int>? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        val data = dataLines(s, ls)
        val li = data.getOrNull(row.coerceIn(0, data.size - 1)) ?: return null
        val pl = pipes(s, ls.starts[li], ls.ends[li])
        if (pl.size < 2) return null
        val c = col.coerceIn(0, pl.size - 2)
        var a = pl[c] + 1
        var b = pl[c + 1]
        val fa = a
        val fb = b
        while (a < b && s[a] == ' ') a++
        while (b > a && s[b - 1] == ' ') b--
        return if (b > a) Pair(a, b) else Pair(fa, fb)
    }

    /** Range of the whole table. */
    fun tableRange(e: Editable, pos: Int): Pair<Int, Int>? {
        val s = e.toString()
        val ls = lines(s, pos) ?: return null
        return Pair(ls.starts[0], ls.ends[ls.ends.size - 1])
    }

    private fun restyle(e: Editable, style: Int, pos: Int) {
        val p = pos.coerceIn(0, e.length)
        setStyle(e, p, style)
    }

    /** Adds an empty row below (or above) the current row. Returns the cursor position of the new row. */
    fun addRow(e: Editable, pos: Int, below: Boolean): Int {
        val inf = info(e, pos) ?: return pos
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        val data = dataLines(s, ls)
        val li = data[inf.row]
        val tpl = template(inf.cols)
        val at: Int
        if (below) {
            var last = li
            if (inf.row == 0 && inf.header) last = li + 1
            at = ls.ends[last]
            e.insert(at, "\n" + tpl)
        } else {
            at = ls.starts[li]
            e.insert(at, tpl + "\n")
        }
        val first = ls.starts[0]
        restyle(e, inf.style, first)
        val np = if (below) at + 1 else at
        return (np + 2).coerceIn(0, e.length)
    }

    /** Adds an empty column to the right (or left) of the current column. */
    fun addCol(e: Editable, pos: Int, right: Boolean): Int {
        val inf = info(e, pos) ?: return pos
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        for (i in ls.starts.indices.reversed()) {
            val pl = pipes(s, ls.starts[i], ls.ends[i])
            if (pl.size < 2) continue
            val idx = minOf(inf.col + (if (right) 1 else 0), pl.size - 1)
            val txt = if (Tables.isSeparator(s.substring(ls.starts[i], ls.ends[i]))) "---|" else "   |"
            e.insert(pl[idx] + 1, txt)
        }
        restyle(e, inf.style, ls.starts[0])
        return cellPos(e, ls.starts[0], inf.row, if (right) inf.col + 1 else inf.col)
    }

    /** Deletes the current row; false when it is the only row. */
    fun deleteRow(e: Editable, pos: Int): Boolean {
        val inf = info(e, pos) ?: return false
        if (inf.rows <= 1) return false
        val s = e.toString()
        val ls = lines(s, pos) ?: return false
        val data = dataLines(s, ls)
        val first = data[inf.row]
        val last = if (inf.row == 0 && inf.header) first + 1 else first
        var a = ls.starts[first]
        var b = ls.ends[last]
        if (b < s.length) b += 1 else if (a > 0) a -= 1
        val tableStart = ls.starts[0]
        e.delete(a, b)
        restyle(e, inf.style, minOf(tableStart, e.length))
        return true
    }

    /** Deletes the current column; false when it is the only column. */
    fun deleteCol(e: Editable, pos: Int): Boolean {
        val inf = info(e, pos) ?: return false
        if (inf.cols <= 1) return false
        val s = e.toString()
        val ls = lines(s, pos) ?: return false
        for (i in ls.starts.indices.reversed()) {
            val pl = pipes(s, ls.starts[i], ls.ends[i])
            if (pl.size < 3) continue
            val c = minOf(inf.col, pl.size - 2)
            e.delete(pl[c], pl[c + 1])
        }
        restyle(e, inf.style, ls.starts[0])
        return true
    }

    /** Removes the whole table; returns where the cursor should go. */
    fun deleteTable(e: Editable, pos: Int): Int {
        val s = e.toString()
        val ls = lines(s, pos) ?: return pos
        var a = ls.starts[0]
        var b = ls.ends[ls.ends.size - 1]
        if (b < s.length) b += 1 else if (a > 0) a -= 1
        e.delete(a, b)
        return a.coerceIn(0, e.length)
    }

    /** Turns the header row (first row + |---| line) on or off. */
    fun setHeader(e: Editable, pos: Int, on: Boolean) {
        val inf = info(e, pos) ?: return
        val s = e.toString()
        val ls = lines(s, pos) ?: return
        val has = hasHeader(s, ls)
        if (on && !has) {
            e.insert(ls.ends[0], "\n" + separator(inf.cols))
        } else if (!on && has) {
            e.delete(ls.ends[0], ls.ends[1])
        }
        restyle(e, inf.style, ls.starts[0])
    }
}
