package com.msf.documentwriter

import android.text.Editable
import android.text.Spanned
import android.text.style.ParagraphStyle

/**
 * Tables are stored in the text as lines of the form  |cell|cell|cell|
 * An optional line like  |---|---|  right after the first row marks it as a header row.
 * On export (PDF / Word / image) these lines become real tables.
 */
sealed class Block
class TextBlock(val a: Int, val b: Int) : Block()
/** rows -> cells -> (start, end) offsets in the full text (spaces already trimmed). */
class TableBlock(val rows: List<List<Pair<Int, Int>>>, val header: Boolean) : Block()

object Tables {
    fun isRow(line: String): Boolean {
        val t = line.trim()
        return t.length >= 2 && t.startsWith("|") && t.endsWith("|")
    }

    fun isSeparator(line: String): Boolean {
        val t = line.trim()
        return isRow(t) && t.contains('-') && t.all { it == '|' || it == '-' || it == ':' || it == ' ' }
    }

    /** Cell ranges of the line s[ps, pe). */
    private fun cells(s: String, ps: Int, pe: Int): List<Pair<Int, Int>> {
        val first = s.indexOf('|', ps)
        val last = s.lastIndexOf('|', pe - 1)
        val out = ArrayList<Pair<Int, Int>>()
        if (first < 0 || last <= first) return out
        var p = first
        while (p < last) {
            val q = s.indexOf('|', p + 1)
            var a = p + 1
            var b = q
            while (a < b && s[a] == ' ') a++
            while (b > a && s[b - 1] == ' ') b--
            out.add(Pair(a, b))
            p = q
        }
        return out
    }

    /** Splits s[from, to) into plain-text blocks and table blocks. */
    fun split(s: String, from: Int, to: Int): List<Block> {
        val out = ArrayList<Block>()
        var textStart = from
        var ps = from
        var rows = ArrayList<List<Pair<Int, Int>>>()
        var header = false
        var inTable = false
        while (ps <= to) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0 || nl > to) to else nl
            val line = s.substring(ps, pe)
            if (isRow(line)) {
                if (!inTable) {
                    inTable = true
                    val b = if (ps > textStart && s[ps - 1] == '\n') ps - 1 else ps
                    if (b > textStart) out.add(TextBlock(textStart, b))
                }
                if (isSeparator(line)) { if (rows.size == 1) header = true } else rows.add(cells(s, ps, pe))
            } else if (inTable) {
                if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
                rows = ArrayList(); header = false; inTable = false
                textStart = ps
            }
            if (pe >= to) break
            ps = pe + 1
        }
        if (inTable) {
            if (rows.isNotEmpty()) out.add(TableBlock(rows, header))
        } else if (textStart < to) out.add(TextBlock(textStart, to))
        return out
    }

    fun any(s: String): Boolean = split(s, 0, s.length).any { it is TableBlock }

    /** Inserts a new empty table at [pos] with the colour style [style] (0-7, see [TableStyles]); returns the new cursor position. */
    fun insert(e: Editable, pos: Int, rows: Int, cols: Int, header: Boolean, style: Int): Int {
        val p = pos.coerceIn(0, e.length)
        val start = p + (if (p > 0 && e[p - 1] != '\n') 1 else 0)
        val np = PageBreaks.insertBlock(e, pos, template(rows, cols, header), 2)
        if (style > 0) {
            val end = (start + 2 + 4 * cols).coerceAtMost(e.length)
            if (end > start) e.setSpan(TableStyleSpan(style), start, end, Spanned.SPAN_PARAGRAPH)
            PageBreaks.decorate(e)
        }
        return np
    }

    /** Text lines for a new empty table. */
    fun template(rows: Int, cols: Int, header: Boolean): String {
        val row = "|" + "   |".repeat(cols)
        val sep = "|" + "---|".repeat(cols)
        val sb = StringBuilder()
        for (r in 0 until rows) {
            sb.append(row).append('\n')
            if (r == 0 && header) sb.append(sep).append('\n')
        }
        return sb.toString()
    }
}

/** Marks the first row of a table with its colour style (0 = plain). Not visible text. */
class TableStyleSpan(val id: Int) : ParagraphStyle

/** The eight table styles of the table picker: banded rows, the first row is the darker colour. */
object TableStyles {
    private fun c(v: Long): Int = v.toInt()
    val DARK = intArrayOf(c(0xFFFFFFFF), c(0xFF808080), c(0xFFA4BDE0), c(0xFFDDA5A5), c(0xFFCCDDAA), c(0xFFBFB2D6), c(0xFFA3D3E0), c(0xFFF9C99E))
    val LIGHT = intArrayOf(c(0xFFFFFFFF), c(0xFFBFBFBF), c(0xFFD3DFF0), c(0xFFEFD3D6), c(0xFFE6EED8), c(0xFFDFD9EB), c(0xFFD0E8EF), c(0xFFFDE3D3))

    /** Background colour of body/header row number [row] (0 = first row). */
    fun fill(style: Int, row: Int): Int {
        val s = style.coerceIn(0, DARK.size - 1)
        return if (row % 2 == 0) DARK[s] else LIGHT[s]
    }

    fun hex(color: Int): String = String.format("%06X", color and 0xFFFFFF)

    /** Style whose dark colour is [h] (RRGGBB), or 0. */
    fun fromHex(h: String): Int {
        for (i in 1 until DARK.size) if (hex(DARK[i]).equals(h, ignoreCase = true)) return i
        return 0
    }

    /** Style of the table whose first row starts at [ps]. */
    fun at(t: CharSequence, ps: Int): Int {
        if (t !is Spanned) return 0
        for (sp in t.getSpans(ps, ps, TableStyleSpan::class.java)) {
            if (t.getSpanStart(sp) <= ps && t.getSpanEnd(sp) > ps) return sp.id.coerceIn(0, DARK.size - 1)
        }
        return 0
    }

    fun of(t: CharSequence, tb: TableBlock): Int {
        val c0 = tb.rows.firstOrNull()?.firstOrNull()?.first ?: return 0
        var ps = c0.coerceIn(0, t.length)
        while (ps > 0 && t[ps - 1] != '\n') ps--
        return at(t, ps)
    }
}

/** Colours the table lines in the editor according to the table style. */
class TableDeco(private val e: Editable) {
    private var inTable = false
    private var row = 0
    private var style = 0

    fun line(ps: Int, pe: Int, line: String) {
        if (pe > ps && Tables.isRow(line)) {
            if (!inTable) { inTable = true; row = 0; style = TableStyles.at(e, ps) }
            val rule = if (style == 0) 0xFF444444.toInt() else 0xFF555555.toInt()
            if (Tables.isSeparator(line)) {
                e.setSpan(TableRowSpan(TableStyles.fill(style, 0), rule), ps, pe, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            } else {
                e.setSpan(TableRowSpan(TableStyles.fill(style, row), rule), ps, pe, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                row++
            }
        } else inTable = false
    }
}
