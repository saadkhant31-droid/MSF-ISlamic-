package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Small (down-sampled) previews of the page designs, so 24 full bitmaps are not held in memory. */
object DesignThumbs {
    private val cache = HashMap<Int, Bitmap?>()

    fun get(c: Context, id: Int): Bitmap? {
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            val s = PageDesigns.spec(id)!!
            c.applicationContext.assets.open(s.asset).use {
                BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = 4 })
            }
        } catch (e: Throwable) { null }
        cache[id] = b
        return b
    }
}

/** The "Page Design" gallery of the New Document screen, as a dialog for the Blank Page editor. */
@Composable
fun DesignPickerDialog(current: Int, addMode: Boolean, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val items: List<Triple<Int, String, String>> =
        (if (addMode) emptyList() else listOf(Triple(0, "Plain page", "سادہ صفحہ"))) +
            PageDesigns.all.map { Triple(it.id, it.en, it.ur) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (addMode) "Add design page\nڈیزائن والا صفحہ شامل کریں" else "Page Design\nپیج ڈیزائن منتخب کریں",
                fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (id, en, ur) ->
                            val sel = id == current && !addMode
                            Column(
                                Modifier.weight(1f)
                                    .background(if (sel) Color(0xFFDCEBFF) else Color(0xFFF7F9FD), RoundedCornerShape(14.dp))
                                    .border(if (sel) 2.dp else 1.dp, if (sel) Color(0xFF0B4DB8) else Color(0xFFD5E0F2), RoundedCornerShape(14.dp))
                                    .clickable { onPick(id) }
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val tb = if (id != 0) remember(id) { DesignThumbs.get(ctx, id) } else null
                                if (tb != null) Image(
                                    bitmap = tb.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(0.72f)
                                ) else Box(Modifier.fillMaxWidth().aspectRatio(0.72f).background(Color.White).border(1.dp, Color(0xFFBBC7DA)))
                                Spacer(Modifier.height(6.dp))
                                Text(en, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Color(0xFF10264F))
                                Text(ur, fontSize = 12.sp, textAlign = TextAlign.Center, color = Color(0xFF3A4A66))
                            }
                        }
                        if (row.size < 2) Spacer(Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
}
