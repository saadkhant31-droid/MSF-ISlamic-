# MSF Document Writer (Android)

Kotlin + Jetpack Compose. Create / edit / share / print Word (.docx), PDF and Text documents with rich formatting, Urdu & Arabic (RTL) writing, search, PDF Maker, backup & restore.

## Screens
Home · Print (new) · New Document · Text Formatting · Urdu & Arabic Writing · Save Document · My Documents · Word Documents · Search · PDF Maker · Settings · Privacy · Terms · About

## Build
- **Android Studio**: open this folder, sync Gradle, Run.
- **GitHub**: push; Actions → *Build APK* produces a debug APK artifact.

## Notes
- Documents are stored privately in the app (no INTERNET permission). "Cloud" = copy saved through the system file picker (Drive etc.).
- Set your real support e-mail in `Settings.kt` (`SUPPORT_EMAIL`).
- Fonts use system fonts; `Noto Nastaliq Urdu` / `Noto Naskh Arabic` appear only if the device has them (otherwise default Arabic-script font is used).
- Legacy .doc/.xls/.ppt are not supported in PDF Maker.

## Update
- Text Formatting, Urdu & Arabic Writing and Save Document screens redesigned to match the new mock-ups.
- Urdu & Arabic: two ornate panels (Arabic text + Urdu translation); tap the Bismillah pill to insert it; Insert Template adds Surah Al-Fatiha with its Urdu translation. The translation is saved with the document.
- Style (B/I/U), size, colour and font indicators now follow the cursor/selection.

## Update 2 (mock-up redesign)
- New **Print** screen: page preview with pager, Printer / Copies / Paper Size / Orientation / Color Mode / Print Quality, Print button, and Quick Actions (Save as PDF, Share, Preview, Advanced Settings: margins & two-sided).
- Common bottom bar on all main screens: Home - My Documents - New - Print - Settings.
- Header now has a 3-dot menu (Home and shortcuts). Document rows and Search filter chips (with counts) match the mock-ups.
- Import files moved to the My Documents 3-dot menu.

## Update 3 (Profile and Privacy & Security)
- **Profile** screen: photo (tap to change), name/email, stats (Total Documents, Created Today, Files Viewed, Bookmarks), Edit Profile, Privacy & Security, Notifications (opens the phone's notification settings), Appearance (theme), About App, Log Out.
- **Privacy & Security** screen: App Lock (phone PIN/pattern/fingerprint at app start), Fingerprint Authentication, Change PIN/Pattern (opens phone security settings), Hide Sensitive Files, Data Encryption (information), Backup & Restore, Privacy Policy, Clear Private Data.
- New dependency: androidx.biometric:biometric:1.1.0 (the app still has no INTERNET permission).

## Update 4 (crash fix)
- Fixed: the app closed when tapping **Add Font** or any option in the 3-dot menu (Add image etc.). Cause: `biometric:1.1.0` pulled in an old `fragment` library that rejects Activity Result API request codes ("Can only use lower 16 bits for requestCode"). Added `androidx.fragment:fragment-ktx:1.6.2`. This also fixes every other picker (Save as, Import, Backup/Restore, profile photo).
- Picker launches in the editor are now wrapped in `safe { }` so a failure shows a message instead of closing the app.
- Version bumped to 1.0.1 (versionCode 2).

## Update 5 (pages)
- New **page designs** (assets/pages): Golden Border and Islamic Frame. Pick them in *New Document → Page Design*, or in the editor via ⋮ → *Page design*.
- New **New page / نیا صفحہ** (⋮ menu) inserts a page break (a line holding U+000C, drawn as a "New page" label). Text also flows to a new page automatically in PDF/Word/Image output.
- PDF, Word (.docx, border as a header background image) and Image exports draw the design on every page and respect page breaks. Portrait only (the border is ignored in landscape).
- The editor shows the chosen design as an A4 sheet when a design is selected.

## Update 6 (fonts)
- Choosing or adding a font with no text selected now sets the font for the whole document (and for new typing). Before, it did nothing on an empty document.
- Added fonts: file type is detected from the file header when the picker hides the name; re-adding a font replaces the old copy.

## Update 7 (blank page, separate pages, page numbers, tables)
- ⋮ menu: **New page**, **Blank page / خالی صفحہ**, **Insert table / ٹیبل**, **Page numbers / صفحہ نمبر** (on by default), **Page design**.
- Page breaks are drawn in the editor as a full-width band "Page N ends | Page N+1 starts", so every page is clearly separate.
- PDF / Word / Image-with-pages: every page is separate, with its own page number centred at the bottom (Word uses a real PAGE field in the footer).
- Tables are stored as `|cell|cell|` lines (a `|---|---|` line after the first row = header row) and exported as real tables in PDF and Word; Word tables are read back into this form when a .docx is opened again.

## Update 8 (keyboard + page fixes)
- Page-design editor (Golden Border / Islamic Frame): the sheet is now full width and scrolls, so it no longer shrinks to a tiny strip when the keyboard opens.
- While the keyboard is open the bottom navigation bar and the header / Font-Size-Style-Color cards are hidden to give the page more room; the line being typed is scrolled into view above the keyboard.
- Blank page editor: page-break calculation re-checks itself (up to 3 passes) and ignores impossible values, so lines of one paragraph are no longer pushed apart with big gaps.

## Update 9 (blank page fonts)
- Blank page: choosing a font with no selection now applies it to the whole text and re-measures the page, so every font in the list takes effect (not just one).

## Update 10 (design pages = real pages)
- Page-design editor (Golden Border etc.) now uses the same sheet-by-sheet editor as the Blank Page: when a page is full, the text continues on a new sheet below with the same design; "New page" also starts a new sheet. PDF / Word export already writes every page with the design.
- Blank page formatting (bold, size, font, colour) applies only to the selected text, or to what is typed next when nothing is selected.

## Update 11 (selection kept while using menus)
- Opening the Font / Size / Colour menu made Android collapse the text selection, so the format was not applied to the selected text. The editor now remembers the last real selection (until you tap the text or type) and applies fonts, sizes, bold, underline etc. to exactly that text. Different fonts/sizes/styles can now live on one page.
- Page-design editor: the Font / Size / Style / Color row stays visible while the keyboard is open. With nothing selected, a format change only affects the text typed next.

## Update 12 (saving: File Manager + same pages as on screen)
- Every saved file (PDF, Word, text, image) is also copied to a folder the phone's File Manager can see: Documents/MSF Document Writer by default, or any folder / SD card chosen in Settings → Save Location (also on the Save screen: "Save Folder → Change"). The "saved" message shows the real folder, or a warning if the copy failed.
- PDF now follows the page breaks of the editor (Blank Page and design pages): a page that is full on screen stays one page in the PDF instead of spilling onto the next page.

## Update 13 (add design pages with "+")
- Page-design editor: a round "+" button (bottom right of the pages, and menu → "+ Add design page") adds a new page after all the text with a design of your choice. Pages can now have different designs (e.g. page 1 Golden Border, page 2 Islamic Frame). "Page design" in the menu still changes the design of all pages.
- The text margins are the widest of the designs used, so text never touches any border. PDF export draws each page with its own design. Word (.docx) export keeps only the first page's design.
- Changing the design in the menu now also updates the pages already on screen.

## Update 14 (blank / extra pages)
- Editor (Blank Page & design pages): a line that holds only the page-break mark no longer starts a sheet of its own when the previous sheet is full. Before, the break line was pushed to a new sheet and the forced break then pushed the following text to yet another sheet, which showed up as an extra empty page.
- PDF: the newline written before a page-break mark no longer creates an empty line at the end of the page. On a full page that line spilled onto a new page and the page break added another one, which left a blank page in the middle of the PDF.

## Update 15 (Page Setup + Page Number screens)
- **Page Setup** (bottom bar frame icon, or ⊞ menu → Page setup): dark full-screen page like the mock-up. Page Size (A3, A4, A5, B4, B5, Letter, Tabloid, Ledger, Legal, Statement, Executive, Folio, Quarto), Orientation (Portrait / Landscape) and Page Margins with a cm / inch switch. The page sketch has blue arrows on all four edges: tap an arrow = move that margin by 0.1, or drag it. "Default" restores the normal margins. Everything is applied at once to the editor, PDF, Word and Image export (each side can have its own margin; text size/wrapping follows).
- **Page Number** (the "1" box at the top right of the editor, or ⊞ menu → Page number…): Location (Header / Footer), Alignment (Left / Center / Right), Number Format (1,2,3 · I,II,III · i,ii,iii · A,B,C · a,b,c · 1st · One · First · ア · イロハ · 壱弐参 · ①②③ · １２３ · 甲乙丙 · 子丑寅 · 一二三 · 壹貳叁 · -1-) and Start Number (type it or use − / +). Shown on every sheet in the editor, in PDF and in Word (.docx: real PAGE field in the header/footer + `pgNumType` for format and start). The settings are read back when an app-made .docx is opened again.
- Editor 3-dot menu (design pages) also has "Page number…".
- New paper sizes added to the Paper list (B4, Ledger, Statement, Executive, Folio, Quarto). Version 1.0.13 (versionCode 14).
- Build note: this update was written without an Android SDK on hand, so please run the GitHub "Build APK" action once and tell me if the compiler reports anything.

## Update 16 (Aa format sheet)
- The **Aa** button now opens a dark bottom sheet with tabs **Home / File / Insert / View** (chevron = close, keyboard icon = show/hide keyboard).
- Home: Size, Font (with "Add font"), **B / I / U / S**, Text Color (5 quick colours, "···" opens the full Text Color page with Standard Colors, "Automatic" resets), Highlight (5 colours, No Fill, "···" opens the full Highlight page), line spacing "Multiple" (1.0 – 3.0) and alignment: left, centre, right, justify, right-to-left.
- File: Save, Save as…, Save as PDF, Share, Clear all. Insert: New page, Blank page, Table, Image, Page number…. View: Page setup, page numbers on/off, page border, RTL, Justify.
- Line spacing is applied in the editor and in PDF output (not yet written to Word files).
- As before this was written without an Android SDK; please run the GitHub build and send me any compiler message.

## Update 17 (Aa sheet: Style, Bullets & Numbers, Indents & Spacing, Smart Typography)
- **Style** row (Normal, Heading 1-3, and "···" for Title, Subtitle, Quote). Works on the paragraph(s) under the cursor/selection; on an empty line it styles what you type next. The current style is highlighted.
- **Bullets & Numbers**: bullet, dash, 1. 2. 3., multilevel 1.1.1., "no list" and "···" (7 bullet symbols; 1. / 1) / (1) / a. / A. / i. / I. / ۱۔). Numbers are renumbered automatically. **Increase / Decrease** change the list level (or the indent of normal paragraphs). **Restart / Continue** control the numbering of the item under the cursor. **Auto Numbering** switch: Enter continues the list, Enter on an empty item ends it.
- **Indents & Spacing**: left indent, first-line / hanging indent, space before / after paragraph, line spacing, reset. Written to PDF and Word (w:ind / w:spacing) and read back from Word files. Line spacing is now also written to Word.
- **Smart Typography**: smart quotes, dashes, ellipsis and Urdu punctuation (? , ; to ؟ ، ؛) while typing, plus "Apply now" for the selection or the whole document (table rows are skipped).
- New file `ParaFormat.kt`. Version 1.0.15 (versionCode 16).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me the compiler message if there is one.

## Update 18 (Insert Table page)
- New full-screen **Insert Table** page (Cancel / OK) like the mock-up: live preview of the table, row picker (up / down arrows, tap the numbers) and column picker (left / right arrows) with wrap-around, a Header row switch, and **Table Style**: eight styles (Plain, Gray, Blue, Red, Green, Purple, Teal, Orange) with banded rows.
- The style is kept with the table (editor row colours, PDF, Word and Image export). In Word the rows get the style colours and `w:tblLook firstRow`; an app-made .docx is read back with its style. Tables up to 50 rows x 10 columns.
- Used by the Blank Page editor and the older editor. New files: `TablePicker.kt` (page), style code in `Tables.kt`. Version 1.0.16 (versionCode 17).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 19 (table on the page, columns, Small Caps / All Caps, T² / T₂)
- **Tables on the page**: a table is now drawn as a real grid (equal, aligned columns with vertical and horizontal rules; the `|---|` header line is hidden). While the cursor is inside a table the handles sit on the page itself: column letters **A B C** above the table, row numbers **1 2 3** at its left, a round **+** at the right (add column) and below (add row), and the four-arrow button that opens the menu **Select / Select All / Table Properties** (plus Row above, Column left, Delete row / column / table). Tap a letter or a number to jump to that column / row. New file `TableGrid.kt`.
- **Aa sheet (Home tab)** now ends with: **Columns** (One, Two, Three, Left, Right), **T² / T₂** (superscript / subscript) and **Small Caps | All Caps** (toggles on the selected text), laid out like the mock-up.
- **Columns**: the page shows the text in 1-3 columns (first column on the right for right-to-left documents); typing, selecting and scrolling work as in one long column. PDF and Word (.docx, `w:cols`) follow the same columns and the setting is read back from an app-made .docx. Left / Right are two columns of equal width for now. New file `Columns.kt`.
- Superscript / subscript are written to Word (`w:vertAlign`) and read back; PDF shows them as well.
- Version 1.0.17 (versionCode 18).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update 20 (resizable table columns / rows, paragraph bar)
- **Drag to resize**: while the cursor is in a table, drag any inner **column border** left or right and any **row border** up or down. A blue dashed guide line with a two-way arrow ↔ (↕ for rows) shows where the border will land; the columns beside it grow / shrink (minimum width kept). Columns can now be unequal (e.g. A narrow, B wide, C narrow).
- The widths are stored with the table (`TableWidthSpan`, `RowHeightSpan` in `Tables.kt`), used by the editor grid (`TableGrid.fit`), the **PDF** (`drawTable`) and **Word** (`w:gridCol`, `w:tcW`, `w:trHeight`) and are read back from an app-made .docx. Adding / deleting a column resets that table to equal columns.
- **Floating paragraph bar**: tap the Align button in the bottom bar to show a dark bar above it with bullets, numbering, increase indent, decrease indent, align left, align centre and "•••" (right / justify). The Align icon is highlighted while the bar is open.
- Known limit: text in an editor cell does not wrap onto several lines (the cell widens instead); in PDF / Word long cell text wraps and rows grow.
- Version 1.0.18 (versionCode 19).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (File menu redesign)
- Editor → panel → **File** tab redesigned like the WPS mock-up (icons, grouped rows, footer) and every item works:
  Save · Save As · Export to PDF · Share as Options (E-mail, Cloud/Drive picker, WhatsApp, more) · Export Images (one JPG per page) ·
  Extract Pages (e.g. `1-3, 5` -> new PDF) · Merge Documents (this document + chosen PDF/DOCX/TXT/images -> one PDF) ·
  File Compressor (ZIP, before/after size) · Document Encryption (password asked when the document is opened in the app) ·
  Print (system print dialog) · File Info · Help & Feedback.
- New file: `FileMenu.kt`. Extract/Merge create image-based PDF pages (text is not selectable in those PDFs).

## Update (page designs in Blank Page)
- Blank Page editor now has all 24 **page designs** (same as New Document -> Page Design): bottom-left menu -> *Page design* / *+ Add design page*, the *+ Insert* menu -> *Design page*, and the Aa panel -> View tab.
- A design is shown on every sheet, text stays inside the frame, and it is used in PDF / Word / image export. *Add design page* adds a new page with a different design.
- New file: `DesignPicker.kt` (gallery dialog with small previews).

## Update (blank first / last page, design kept, own designs)
- **PDF: no more empty first or last page.** PdfBuilder now starts a page only when something is drawn on it. Page breaks / blank lines in front of the first text and after the last text are ignored (before, "Add design page" on an empty document, a trailing page break or trailing blank lines on a full page gave an empty page 1 / last page). Page breaks between texts and intentional blank pages in the middle are kept.
- **Design no longer disappears.** The Blank Page screen used to reset the design to "plain page" every time it was opened (e.g. coming back from Save / Done). It now restores the design and the extra design pages from `Doc`.
- "Add design page" on an empty document now just puts the design on page 1 (no empty page in front).
- New Document -> "Blank Document" now uses the Page Design chosen on that screen.
- **Own designs from Gallery / File Manager.** Page Design and "+ Add design page" (Blank Page editor, old editor, New Document screen) have a green "＋ Choose from Gallery / File Manager" button. The picture is cut to page shape (A4), saved inside the app, and the text margin (small / medium / large) is asked. Long-press an own design in the list to delete it. Own designs work in the editor, PDF, Word and Image export. New: `CustomDesigns` in `PageDesigns.kt`.
- Version 1.0.25 (versionCode 26).
- Build note: written without an Android SDK; please run the GitHub "Build APK" action and send me any compiler message.

## Update (crash report)
- Blank Page start hardened (design restore in try/catch); "Blank Document" no longer carries the chosen design (as in 1.0.24).
- New `CrashLog.kt`: if the app closes by itself, the next start shows the error text with Copy / Share buttons, to be sent to the developer.
- Version 1.0.26 (versionCode 27).
