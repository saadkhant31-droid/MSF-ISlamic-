package com.msf.documentwriter

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.style.BaselineShift
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TpHead = Color(0xFF2B2B2B)
private val TpBody = Color(0xFF1E1E1E)
private val TpCard = Color(0xFF232323)
private val TpLine = Color(0xFF3C3C3C)
private val TpAcc = Color(0xFF4A8BEF)
private val TpGrey = Color(0xFF8E8E8E)
private val TpIcon = Color(0xFFD0D0D0)

/** Everything the Aa sheet can do; the editor fills these in. */
class FormatActions(
    val onSize: (Int) -> Unit, val onFont: (String, String) -> Unit, val onAddFont: () -> Unit,
    val onBold: () -> Unit, val onItalic: () -> Unit, val onUnder: () -> Unit, val onStrike: () -> Unit,
    val onColor: (Int?) -> Unit, val onHighlight: (Int?) -> Unit,
    val onSpacing: (Float) -> Unit, val onAlign: (Int) -> Unit, val onJustify: () -> Unit, val onRtl: () -> Unit,
    val onClose: () -> Unit, val onKeyboard: () -> Unit,
    val onStyle: (Int) -> Unit, val onBullet: (Int) -> Unit, val onNumber: (Int) -> Unit, val onNoList: () -> Unit,
    val onIndent: (Int) -> Unit, val onRestart: () -> Unit, val onContinue: () -> Unit, val onAutoNum: (Boolean) -> Unit,
    val onParaFmt: (Float, Float, Float, Float) -> Unit, val onParaReset: () -> Unit,
    val onTypo: (Int, Boolean) -> Unit, val onTypoApply: () -> Unit,
    /** true = superscript, false = subscript */
    val onScript: (Boolean) -> Unit,
    /** true = All Caps, false = Small Caps */
    val onCaps: (Boolean) -> Unit,
    /** 0 One, 1 Two, 2 Three, 3 Left, 4 Right */
    val onColumns: (Int) -> Unit
)

private val GridColors = listOf(
    0xFF99CCFF, 0xFFCC99FF, 0xFFCCFFCC, 0xFFFFCC99, 0xFFFFE0E0, 0xFFFFFFFF,
    0xFF3399FF, 0xFF9933FF, 0xFF66FF66, 0xFFFFCC00, 0xFFD96666, 0xFFC0C0C0,
    0xFF0000FF, 0xFF6600CC, 0xFF99CC00, 0xFFFF9900, 0xFF993300, 0xFF808080,
    0xFF000099, 0xFF330066, 0xFF007F00, 0xFFFF6600, 0xFF800000, 0xFF000000
)
private val StdColors = listOf(
    0xFFC00000, 0xFFFFC000, 0xFF92D050, 0xFF00B0F0, 0xFF7030A0, 0xFFFFFFFF,
    0xFFFF0000, 0xFFFFFF00, 0xFF00B050, 0xFF0070C0, 0xFF002060, 0xFF000000
)
private val HiGrid = listOf(
    0xFFFFFF00, 0xFF00FF00, 0xFF008000, 0xFF800080, 0xFF00FFFF,
    0xFF000080, 0xFF008080, 0xFF800000, 0xFFFF0000, 0xFFFF00FF,
    0xFF808000, 0xFFD3D3D3, 0xFF000000, 0xFF0000FF, 0xFFA9A9A9
)
private val SpacingList = listOf(1.0f, 1.15f, 1.5f, 2.0f, 2.5f, 3.0f)

@Composable
private fun TpChevron(down: Boolean, onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(if (down) 20.dp else 12.dp, if (down) 12.dp else 20.dp)) {
            val w = 2.dp.toPx()
            if (down) {
                drawLine(TpIcon, Offset(0f, 0f), Offset(size.width / 2f, size.height), w)
                drawLine(TpIcon, Offset(size.width / 2f, size.height), Offset(size.width, 0f), w)
            } else {
                drawLine(TpIcon, Offset(size.width, 0f), Offset(0f, size.height / 2f), w)
                drawLine(TpIcon, Offset(0f, size.height / 2f), Offset(size.width, size.height), w)
            }
        }
    }
}

@Composable
private fun TpKeyboard(onClick: () -> Unit) {
    Box(Modifier.size(52.dp).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Icon(Icons.Outlined.Keyboard, "Keyboard", tint = TpIcon, modifier = Modifier.size(26.dp))
    }
}

@Composable
private fun TpCardBox(modifier: Modifier = Modifier, onClick: (() -> Unit)? = null, content: @Composable () -> Unit) {
    var m = modifier.background(TpCard, RoundedCornerShape(12.dp)).border(1.dp, TpLine, RoundedCornerShape(12.dp))
    if (onClick != null) m = m.clickable { onClick() }
    Box(m, contentAlignment = Alignment.Center) { content() }
}

@Composable
private fun TpDot(c: Long, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).background(Color(c), CircleShape)
            .border(if (selected) 3.dp else 1.dp, if (selected) Color.White else Color(0xFF555555), CircleShape)
            .clickable { onClick() }
    )
}

@Composable
private fun TpLines(kind: Int, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp, 40.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(6.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        if (kind == 4) Text("RTL", color = if (on) TpAcc else TpIcon, fontSize = 13.sp, fontWeight = FontWeight.Bold)
        else Canvas(Modifier.size(22.dp)) {
            val col = if (on) TpAcc else TpIcon
            val w = 1.6.dp.toPx()
            val full = size.width
            val widths = if (kind == 3) listOf(full, full, full, full) else listOf(full, full * 0.6f, full, full * 0.6f)
            for (i in 0 until 4) {
                val y = size.height * (0.12f + 0.25f * i)
                val x0 = when (kind) { 1 -> (full - widths[i]) / 2f; 2 -> full - widths[i]; else -> 0f }
                drawLine(col, Offset(x0, y), Offset(x0 + widths[i], y), w)
            }
        }
    }
}

@Composable
fun FormatSheet(
    a: FormatActions, sizeNow: Int, fontLabel: String, bold: Boolean, italic: Boolean, under: Boolean,
    curColor: Color, spacing: Float, justify: Boolean, rtl: Boolean,
    para: ParaState, autoNum: Boolean, typo: TypoCfg,
    capsNow: Int, supNow: Boolean, subNow: Boolean, columns: Int,
    file: FileActions, insert: List<Pair<String, () -> Unit>>, view: List<Pair<String, () -> Unit>>,
    modifier: Modifier = Modifier
) {
    var tab by remember { mutableIntStateOf(0) }
    var page by remember { mutableStateOf("") }
    var menu by remember { mutableStateOf("") }
    var alignSel by remember { mutableIntStateOf(-1) }
    var hiNone by remember { mutableStateOf(true) }
    val tabs = listOf("Home", "File", "Insert", "View", "Review", "Pen")

    MaterialTheme(colorScheme = PsScheme) {
        Column(modifier.fillMaxWidth().background(TpBody)) {
            if (page == "") {
                Row(Modifier.fillMaxWidth().height(52.dp).background(TpHead), verticalAlignment = Alignment.CenterVertically) {
                    TpChevron(true) { a.onClose() }
                    Box(Modifier.width(1.dp).height(24.dp).background(Color(0xFF444444)))
                    Spacer(Modifier.width(8.dp))
                    Row(Modifier.weight(1f).horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.SpaceEvenly) {
                        tabs.forEachIndexed { i, t ->
                            Column(Modifier.clickable { tab = i }.padding(horizontal = 10.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                Spacer(Modifier.height(15.dp))
                                Text(t, color = if (tab == i) TpAcc else Color(0xFFCFCFCF), fontSize = 17.sp)
                                Spacer(Modifier.height(11.dp))
                                Box(Modifier.width(44.dp).height(2.dp).background(if (tab == i) TpAcc else Color.Transparent))
                            }
                        }
                    }
                    TpKeyboard { a.onKeyboard() }
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState())) {
                    when (tab) {
                        0 -> HomeTab(a, sizeNow, fontLabel, bold, italic, under, curColor, spacing, justify, rtl, alignSel, { alignSel = it }, { page = it }, menu, { menu = it }, para, autoNum, capsNow, supNow, subNow, columns)
                        1 -> FileTab(file)
                        2 -> InsertPanel(insert + view)
                        3 -> ViewPanel(view)
                        4 -> ReviewPanel()
                        else -> PenPanel()
                    }
                }
            } else {
                Row(Modifier.fillMaxWidth().height(52.dp).background(TpHead), verticalAlignment = Alignment.CenterVertically) {
                    TpChevron(false) { page = "" }
                    TpKeyboard { a.onKeyboard() }
                    Box(Modifier.width(1.dp).height(24.dp).background(Color(0xFF444444)))
                    Text(pageTitle(page), color = Color.White, fontSize = 18.sp, textAlign = TextAlign.Center, modifier = Modifier.weight(1f))
                    Spacer(Modifier.width(52.dp))
                }
                Column(Modifier.weight(1f).fillMaxWidth().verticalScroll(rememberScrollState()).padding(horizontal = 14.dp, vertical = 12.dp)) {
                    if (page == "styles" || page == "lists" || page == "indent" || page == "smart") {
                        ParaPages(page, a, para, spacing, typo) { page = "" }
                    } else if (page == "hi") {
                        Row(
                            Modifier.fillMaxWidth().height(48.dp).border(1.dp, if (hiNone) TpAcc else TpLine, RoundedCornerShape(3.dp))
                                .clickable { hiNone = true; a.onHighlight(null) }.padding(horizontal = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            NoFillIcon()
                            Spacer(Modifier.width(12.dp))
                            Text("No Fill", color = TpAcc, fontSize = 17.sp, modifier = Modifier.weight(1f))
                            if (hiNone) Text("✓", color = TpAcc, fontSize = 20.sp)
                        }
                        Spacer(Modifier.height(18.dp))
                        HiGrid.chunked(5).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { hiNone = false; a.onHighlight(Color(c).toArgb()) } }
                            }
                        }
                    } else {
                        GridColors.chunked(6).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { a.onColor(Color(c).toArgb()) } }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        Text("Standard Colors", color = TpGrey, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        StdColors.chunked(6).forEach { r ->
                            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                                r.forEach { c -> BigDot(c) { a.onColor(Color(c).toArgb()) } }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun BigDot(c: Long, onClick: () -> Unit) {
    Box(Modifier.size(50.dp).background(Color(c), CircleShape).clickable { onClick() })
}

@Composable
private fun NoFillIcon() {
    Canvas(Modifier.size(26.dp)) {
        val w = 1.6.dp.toPx()
        drawCircle(TpIcon, radius = size.width / 2f - w, style = androidx.compose.ui.graphics.drawscope.Stroke(w))
        drawLine(TpIcon, Offset(size.width * 0.2f, size.height * 0.8f), Offset(size.width * 0.8f, size.height * 0.2f), w)
    }
}

@Composable
private fun ItemList(items: List<Pair<String, () -> Unit>>) {
    Column(Modifier.fillMaxWidth()) {
        items.forEach { (label, act) ->
            Text(label, color = Color.White, fontSize = 17.sp, modifier = Modifier.fillMaxWidth().clickable { act() }.padding(horizontal = 20.dp, vertical = 16.dp))
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0xFF2E2E2E)))
        }
    }
}

@Composable
private fun HomeTab(
    a: FormatActions, sizeNow: Int, fontLabel: String, bold: Boolean, italic: Boolean, under: Boolean,
    curColor: Color, spacing: Float, justify: Boolean, rtl: Boolean, alignSel: Int, setAlign: (Int) -> Unit,
    setPage: (String) -> Unit, menu: String, setMenu: (String) -> Unit,
    para: ParaState, autoNum: Boolean,
    caps: Int, sup: Boolean, sub: Boolean, columns: Int
) {
    Column(Modifier.fillMaxWidth().padding(14.dp)) {
        Row(Modifier.fillMaxWidth().height(172.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(0.8f)) {
                TpCardBox(Modifier.fillMaxSize(), { setMenu("size") }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Size", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(8.dp))
                        Text("$sizeNow", color = TpAcc, fontSize = 26.sp)
                    }
                }
                DropdownMenu(expanded = menu == "size", onDismissRequest = { setMenu("") }) {
                    SizeList.forEach { z ->
                        DropdownMenuItem(text = { Text(if (z == sizeNow) "✓ $z" else "$z", color = Color.White) }, onClick = { setMenu(""); a.onSize(z) })
                    }
                }
            }
            Column(Modifier.weight(2.2f), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Box(Modifier.fillMaxWidth().weight(1f)) {
                    TpCardBox(Modifier.fillMaxSize(), { setMenu("font") }) {
                        Text(fontLabel, color = Color.White, fontSize = 20.sp, maxLines = 1)
                    }
                    DropdownMenu(expanded = menu == "font", onDismissRequest = { setMenu("") }) {
                        FontMenuItems(onPick = { l, f -> setMenu(""); a.onFont(l, f) }, onAdd = { setMenu(""); a.onAddFont() })
                    }
                }
                TpCardBox(Modifier.fillMaxWidth().weight(1f)) {
                    Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        StyleBtn("B", bold, FontWeight.Normal, FontStyle.Normal, TextDecoration.None) { a.onBold() }
                        StyleBtn("I", italic, FontWeight.Normal, FontStyle.Italic, TextDecoration.None) { a.onItalic() }
                        StyleBtn("U", under, FontWeight.Normal, FontStyle.Normal, TextDecoration.Underline) { a.onUnder() }
                        StyleBtn("S", false, FontWeight.Normal, FontStyle.Normal, TextDecoration.LineThrough) { a.onStrike() }
                    }
                }
            }
        }
        Spacer(Modifier.height(16.dp))
        Text("Text Color", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth().height(76.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            TpCardBox(Modifier.weight(1f).fillMaxSize()) {
                Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    listOf(0xFF3A3A46, 0xFFC00000, 0xFFFFC000, 0xFF92D050, 0xFF00B0F0).forEach { c ->
                        TpDot(c, curColor == Color(c)) { a.onColor(Color(c).toArgb()) }
                    }
                    Text("···", color = TpIcon, fontSize = 22.sp, modifier = Modifier.clickable { setPage("color") }.padding(4.dp))
                }
            }
            Box(
                Modifier.width(110.dp).fillMaxSize().border(1.dp, TpAcc, RoundedCornerShape(12.dp)).clickable { a.onColor(null) },
                contentAlignment = Alignment.Center
            ) { Text("Automatic", color = TpAcc, fontSize = 16.sp) }
        }
        Spacer(Modifier.height(16.dp))
        Text("Highlight", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        TpCardBox(Modifier.fillMaxWidth().height(76.dp)) {
            Row(Modifier.fillMaxSize().padding(horizontal = 12.dp), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                listOf(0xFFFFFF00, 0xFF00FF00, 0xFF00FFFF, 0xFFFF00FF, 0xFFFF0000).forEach { c ->
                    TpDot(c, false) { a.onHighlight(Color(c).toArgb()) }
                }
                Box(Modifier.size(34.dp).clickable { a.onHighlight(null) }, contentAlignment = Alignment.Center) { NoFillIcon() }
                Text("···", color = TpIcon, fontSize = 22.sp, modifier = Modifier.clickable { setPage("hi") }.padding(4.dp))
            }
        }
        Spacer(Modifier.height(16.dp))
        Row(Modifier.fillMaxWidth().height(94.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.weight(1f)) {
                TpCardBox(Modifier.fillMaxSize(), { setMenu("sp") }) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Multiple", color = Color.White, fontSize = 16.sp)
                        Spacer(Modifier.height(6.dp))
                        Text(String.format(java.util.Locale.US, "%.1f", spacing), color = TpAcc, fontSize = 24.sp)
                    }
                }
                DropdownMenu(expanded = menu == "sp", onDismissRequest = { setMenu("") }) {
                    SpacingList.forEach { v ->
                        DropdownMenuItem(
                            text = { Text(String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.'), color = Color.White) },
                            onClick = { setMenu(""); a.onSpacing(v) }
                        )
                    }
                }
            }
            TpCardBox(Modifier.weight(2.2f).fillMaxSize()) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    TpLines(0, alignSel == 0) { setAlign(0); a.onAlign(0) }
                    TpLines(1, alignSel == 1) { setAlign(1); a.onAlign(1) }
                    TpLines(2, alignSel == 2) { setAlign(2); a.onAlign(2) }
                    TpLines(3, justify) { a.onJustify() }
                    TpLines(4, rtl) { a.onRtl() }
                }
            }
        }
        Spacer(Modifier.height(20.dp))
        Text("Style", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        StyleRow(a, para.style, setPage)
        Spacer(Modifier.height(16.dp))
        Text("Bullets & Numbers", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        ListsCard(a, para, setPage)
        Spacer(Modifier.height(12.dp))
        LevelCard(a, para)
        Spacer(Modifier.height(12.dp))
        AutoNumRow(a, autoNum)
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            OutlineBtn("Indents & Spacing", Modifier.weight(1f)) { setPage("indent") }
            OutlineBtn("Smart Typography", Modifier.weight(1f)) { setPage("smart") }
        }
        Spacer(Modifier.height(22.dp))
        Text("Columns", color = TpGrey, fontSize = 16.sp)
        Spacer(Modifier.height(8.dp))
        ColumnsCard(columns) { a.onColumns(it) }
        Spacer(Modifier.height(14.dp))
        Row(Modifier.fillMaxWidth().height(64.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            TpCardBox(Modifier.weight(1f).fillMaxSize()) {
                Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                    ScriptBtn(true, sup) { a.onScript(true) }
                    Box(Modifier.width(1.dp).height(30.dp).background(TpLine))
                    ScriptBtn(false, sub) { a.onScript(false) }
                }
            }
            TpCardBox(Modifier.weight(1.7f).fillMaxSize()) {
                Row(Modifier.fillMaxSize(), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.weight(1f).fillMaxSize().clickable { a.onCaps(false) }, contentAlignment = Alignment.Center) {
                        Text("Small Caps", color = if (caps == 2) TpAcc else Color.White, fontSize = 17.sp)
                    }
                    Box(Modifier.width(1.dp).height(30.dp).background(TpLine))
                    Box(Modifier.weight(1f).fillMaxSize().clickable { a.onCaps(true) }, contentAlignment = Alignment.Center) {
                        Text("All Caps", color = if (caps == 1) TpAcc else Color.White, fontSize = 17.sp)
                    }
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }
}

/** T with a small 2 above (superscript) or below (subscript). */
@Composable
private fun ScriptBtn(up: Boolean, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(64.dp, 52.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(8.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            buildAnnotatedString {
                append("T")
                withStyle(SpanStyle(fontSize = 15.sp, baselineShift = if (up) BaselineShift.Superscript else BaselineShift.Subscript)) { append("2") }
            },
            color = if (on) TpAcc else TpIcon, fontSize = 28.sp
        )
    }
}

/** Little page picture of a column preset (text lines inside 1-3 columns). */
@Composable
private fun ColIcon(kind: Int, color: Color) {
    Canvas(Modifier.size(30.dp, 26.dp)) {
        val w = 1.7.dp.toPx()
        val fr: List<Pair<Float, Float>> = when (kind) {
            1 -> listOf(0f to 0.46f, 0.54f to 1f)
            2 -> listOf(0f to 0.30f, 0.35f to 0.65f, 0.70f to 1f)
            3 -> listOf(0f to 0.30f, 0.38f to 1f)
            4 -> listOf(0f to 0.62f, 0.70f to 1f)
            else -> listOf(0f to 1f)
        }
        for ((a, b) in fr) {
            for (i in 0 until 5) {
                val y = size.height * (0.06f + 0.22f * i)
                val bEnd = if (i == 4) a + (b - a) * 0.6f else b
                drawLine(color, Offset(size.width * a, y), Offset(size.width * bEnd, y), w)
            }
        }
    }
}

/** "Columns": One, Two, Three, Left, Right (the chosen one is blue). */
@Composable
private fun ColumnsCard(sel: Int, onPick: (Int) -> Unit) {
    val names = listOf("One", "Two", "Three", "Left", "Right")
    TpCardBox(Modifier.fillMaxWidth().height(78.dp)) {
        Row(Modifier.fillMaxSize().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            for (i in 0 until 5) {
                Column(
                    Modifier.weight(1f).fillMaxHeight().clickable { onPick(i) },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
                ) {
                    ColIcon(i, if (sel == i) TpAcc else TpIcon)
                    Spacer(Modifier.height(6.dp))
                    Text(names[i], color = if (sel == i) TpAcc else Color.White, fontSize = 14.sp, maxLines = 1)
                }
            }
        }
    }
}

@Composable
private fun StyleBtn(label: String, on: Boolean, w: FontWeight, st: FontStyle, deco: TextDecoration, onClick: () -> Unit) {
    Box(
        Modifier.size(52.dp, 44.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(8.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) {
        Text(
            label, color = if (on) TpAcc else TpIcon, fontSize = 26.sp, fontWeight = if (label == "B") FontWeight.Medium else w,
            fontStyle = st, textDecoration = deco
        )
    }
}

private const val CM = 28.3465f

private fun pageTitle(p: String): String = when (p) {
    "hi" -> "Highlight"
    "styles" -> "Styles"
    "lists" -> "Bullets & Numbers"
    "indent" -> "Indents & Spacing"
    "smart" -> "Smart Typography"
    else -> "Text Color"
}

private fun cmText(pt: Float): String = String.format(java.util.Locale.US, "%.2f cm", pt / CM)
private fun ptText(pt: Float): String = String.format(java.util.Locale.US, "%.0f pt", pt)

@Composable
private fun StyleRow(a: FormatActions, cur: Int, setPage: (String) -> Unit) {
    val names = listOf("Normal", "Heading 1", "Heading 2", "Heading 3")
    val samples = listOf("AaBbCc", "AaBb", "AaBbC", "AaBbC")
    val sizes = listOf(13, 22, 18, 15)
    Row(Modifier.fillMaxWidth().height(76.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        names.forEachIndexed { i, n ->
            val on = cur == i
            Column(
                Modifier.weight(1f).fillMaxHeight().background(TpCard, RoundedCornerShape(12.dp))
                    .border(if (on) 2.dp else 1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(12.dp))
                    .clickable { a.onStyle(i) }
            ) {
                Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                    Text(samples[i], color = Color.White, fontSize = sizes[i].sp, fontWeight = if (i == 0) FontWeight.Normal else FontWeight.Bold, maxLines = 1)
                }
                Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
                Box(Modifier.fillMaxWidth().height(26.dp), contentAlignment = Alignment.Center) {
                    Text(n, color = if (on) TpAcc else TpGrey, fontSize = 11.sp, maxLines = 1)
                }
            }
        }
        Box(
            Modifier.width(44.dp).fillMaxHeight().background(TpCard, RoundedCornerShape(12.dp))
                .border(1.dp, TpLine, RoundedCornerShape(12.dp)).clickable { setPage("styles") },
            contentAlignment = Alignment.Center
        ) { Text("···", color = TpIcon, fontSize = 22.sp) }
    }
}

@Composable
private fun ListGlyph(kind: Int, color: Color) {
    if (kind == 4) {
        Canvas(Modifier.size(24.dp)) {
            val w = 1.6.dp.toPx()
            drawRect(color, topLeft = Offset(w, w), size = androidx.compose.ui.geometry.Size(size.width - 2 * w, size.height - 2 * w), style = androidx.compose.ui.graphics.drawscope.Stroke(w))
            drawLine(color, Offset(0f, size.height), Offset(size.width, 0f), w)
        }
        return
    }
    val nums = listOf("1", "1.1", "1.1.1")
    Column(Modifier.size(26.dp), verticalArrangement = Arrangement.SpaceBetween) {
        for (i in 0 until 3) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.width(if (kind == 3) 14.dp else 9.dp), contentAlignment = Alignment.CenterStart) {
                    when (kind) {
                        0 -> Box(Modifier.size(4.dp).background(color, CircleShape))
                        1 -> Box(Modifier.size(6.dp, 1.5.dp).background(color))
                        2 -> Text("${i + 1}", color = color, fontSize = 7.sp)
                        else -> Text(nums[i], color = color, fontSize = 6.sp, maxLines = 1)
                    }
                }
                Box(Modifier.weight(1f).height(1.5.dp).background(color))
            }
        }
    }
}

@Composable
private fun ListBtn(kind: Int, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp, 40.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(6.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { ListGlyph(kind, if (on) TpAcc else TpIcon) }
}

@Composable
private fun ListsCard(a: FormatActions, para: ParaState, setPage: (String) -> Unit) {
    TpCardBox(Modifier.fillMaxWidth().height(64.dp)) {
        Row(Modifier.fillMaxSize().padding(horizontal = 8.dp), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            ListBtn(0, para.listKind == 100) { a.onBullet(0) }
            ListBtn(1, para.listKind == 103) { a.onBullet(3) }
            ListBtn(2, para.listKind == 200 + ListFmt.N_DEC) { a.onNumber(ListFmt.N_DEC) }
            ListBtn(3, para.listKind == 200 + ListFmt.N_MULTI) { a.onNumber(ListFmt.N_MULTI) }
            ListBtn(4, false) { a.onNoList() }
            Box(Modifier.size(40.dp).clickable { setPage("lists") }, contentAlignment = Alignment.Center) {
                Text("···", color = TpIcon, fontSize = 22.sp)
            }
        }
    }
}

@Composable
private fun ActCell(label: String, enabled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.fillMaxHeight().clickable(enabled = enabled) { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = if (enabled) Color.White else Color(0xFF666666), fontSize = 17.sp)
    }
}

@Composable
private fun LevelCard(a: FormatActions, para: ParaState) {
    TpCardBox(Modifier.fillMaxWidth()) {
        Column(Modifier.fillMaxWidth()) {
            Row(Modifier.fillMaxWidth().height(54.dp)) {
                ActCell("Increase", para.level < 8, Modifier.weight(1f)) { a.onIndent(1) }
                Box(Modifier.width(1.dp).fillMaxHeight().background(TpLine))
                ActCell("Decrease", para.canDec, Modifier.weight(1f)) { a.onIndent(-1) }
            }
            Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
            Row(Modifier.fillMaxWidth().height(54.dp)) {
                ActCell("Restart", para.numbered, Modifier.weight(1f)) { a.onRestart() }
                Box(Modifier.width(1.dp).fillMaxHeight().background(TpLine))
                ActCell("Continue", para.numbered, Modifier.weight(1f)) { a.onContinue() }
            }
        }
    }
}

@Composable
private fun SwitchBox(on: Boolean, onChange: (Boolean) -> Unit) {
    Switch(
        checked = on, onCheckedChange = { onChange(it) },
        colors = SwitchDefaults.colors(
            checkedThumbColor = Color.White, checkedTrackColor = TpAcc,
            uncheckedThumbColor = Color.White, uncheckedTrackColor = Color(0xFF555555), uncheckedBorderColor = Color(0xFF555555)
        )
    )
}

@Composable
private fun AutoNumRow(a: FormatActions, on: Boolean) {
    Row(Modifier.fillMaxWidth().height(56.dp).clickable { a.onAutoNum(!on) }.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        ListGlyph(2, TpIcon)
        Spacer(Modifier.width(16.dp))
        Text("Auto Numbering", color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
        SwitchBox(on) { a.onAutoNum(it) }
    }
}

@Composable
private fun OutlineBtn(label: String, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(54.dp).border(1.dp, TpLine, RoundedCornerShape(12.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 16.sp, maxLines = 1) }
}

@Composable
private fun StepBtn(label: String, onClick: () -> Unit) {
    Box(Modifier.size(40.dp).border(1.dp, TpLine, CircleShape).clickable { onClick() }, contentAlignment = Alignment.Center) {
        Text(label, color = TpIcon, fontSize = 22.sp)
    }
}

@Composable
private fun StepRow(label: String, value: String, onMinus: () -> Unit, onPlus: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 16.sp, modifier = Modifier.weight(1f))
        StepBtn("−", onMinus)
        Text(value, color = TpAcc, fontSize = 17.sp, textAlign = TextAlign.Center, modifier = Modifier.width(88.dp))
        StepBtn("+", onPlus)
    }
}

@Composable
private fun ChipBtn(label: String, on: Boolean, modifier: Modifier, onClick: () -> Unit) {
    Box(
        modifier.height(42.dp).background(if (on) Color(0xFF111111) else Color.Transparent, RoundedCornerShape(10.dp))
            .border(1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(10.dp)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, color = if (on) TpAcc else TpIcon, fontSize = 15.sp, maxLines = 1) }
}

@Composable
private fun SwitchRow(label: String, sample: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().height(58.dp).clickable { onChange(!on) }.padding(horizontal = 14.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(label, color = Color.White, fontSize = 16.sp)
            Text(sample, color = TpGrey, fontSize = 13.sp)
        }
        SwitchBox(on, onChange)
    }
}

@Composable
private fun SectionLabel(t: String) {
    Spacer(Modifier.height(14.dp))
    Text(t, color = TpGrey, fontSize = 16.sp)
    Spacer(Modifier.height(8.dp))
}

@Composable
private fun ParaPages(page: String, a: FormatActions, para: ParaState, spacing: Float, typo: TypoCfg, back: () -> Unit) {
    Column(Modifier.fillMaxWidth()) {
        when (page) {
            "styles" -> {
                listOf(Triple("Title", 4, 26), Triple("Subtitle", 5, 19), Triple("Quote", 6, 16)).forEach { (name, id, sz) ->
                    val on = para.style == id
                    Row(
                        Modifier.fillMaxWidth().padding(vertical = 5.dp).height(62.dp).background(TpCard, RoundedCornerShape(12.dp))
                            .border(if (on) 2.dp else 1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(12.dp))
                            .clickable { a.onStyle(id); back() }.padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            name, color = Color.White, fontSize = sz.sp,
                            fontWeight = if (id == 4) FontWeight.Bold else FontWeight.Normal,
                            fontStyle = if (id == 6) FontStyle.Italic else FontStyle.Normal
                        )
                    }
                }
            }
            "lists" -> {
                Text("Bullets", color = TpGrey, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                ListFmt.BULLETS.withIndex().toList().chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { iv ->
                            val on = para.listKind == 100 + iv.index
                            Box(
                                Modifier.weight(1f).height(54.dp).background(TpCard, RoundedCornerShape(12.dp))
                                    .border(if (on) 2.dp else 1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(12.dp))
                                    .clickable { a.onBullet(iv.index); back() },
                                contentAlignment = Alignment.Center
                            ) { Text(iv.value, color = Color.White, fontSize = 22.sp) }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                SectionLabel("Numbering")
                val nums = listOf(
                    Pair("1.", ListFmt.N_DEC), Pair("1)", ListFmt.N_DECP), Pair("(1)", ListFmt.N_PAREN), Pair("1.1.", ListFmt.N_MULTI),
                    Pair("a.", ListFmt.N_ALPHA), Pair("A.", ListFmt.N_ALPHA_U), Pair("i.", ListFmt.N_ROMAN), Pair("I.", ListFmt.N_ROMAN_U),
                    Pair("\u06F1\u06D4", ListFmt.N_URDU)
                )
                nums.chunked(4).forEach { row ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { p ->
                            val on = para.listKind == 200 + p.second
                            Box(
                                Modifier.weight(1f).height(54.dp).background(TpCard, RoundedCornerShape(12.dp))
                                    .border(if (on) 2.dp else 1.dp, if (on) TpAcc else TpLine, RoundedCornerShape(12.dp))
                                    .clickable { a.onNumber(p.second); back() },
                                contentAlignment = Alignment.Center
                            ) { Text(p.first, color = Color.White, fontSize = 20.sp) }
                        }
                        repeat(4 - row.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
                Spacer(Modifier.height(10.dp))
                OutlineBtn("No list", Modifier.fillMaxWidth()) { a.onNoList(); back() }
            }
            "indent" -> {
                val left = para.left
                val fr = para.firstRel
                val mode = if (fr > 0.5f) 1 else if (fr < -0.5f) 2 else 0
                val amt = kotlin.math.abs(fr)
                Text("Indent", color = TpGrey, fontSize = 16.sp)
                Spacer(Modifier.height(8.dp))
                TpCardBox(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        StepRow(
                            "Left indent", cmText(left),
                            { a.onParaFmt((left - CM * 0.5f).coerceAtLeast(0f), fr, para.before, para.after) },
                            { a.onParaFmt(left + CM * 0.5f, fr, para.before, para.after) }
                        )
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            ChipBtn("None", mode == 0, Modifier.weight(1f)) { a.onParaFmt(left, 0f, para.before, para.after) }
                            ChipBtn("First line", mode == 1, Modifier.weight(1f)) { a.onParaFmt(left, maxOf(amt, CM * 0.5f), para.before, para.after) }
                            ChipBtn("Hanging", mode == 2, Modifier.weight(1f)) { a.onParaFmt(left, -maxOf(amt, CM * 0.5f), para.before, para.after) }
                        }
                        StepRow(
                            "By", cmText(amt),
                            { val nb = (amt - CM * 0.25f).coerceAtLeast(0f); a.onParaFmt(left, if (mode == 2) -nb else nb, para.before, para.after) },
                            { val nb = amt + CM * 0.25f; a.onParaFmt(left, if (mode == 2) -nb else nb, para.before, para.after) }
                        )
                    }
                }
                SectionLabel("Spacing")
                TpCardBox(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        StepRow(
                            "Before paragraph", ptText(para.before),
                            { a.onParaFmt(left, fr, (para.before - 2f).coerceAtLeast(0f), para.after) },
                            { a.onParaFmt(left, fr, (para.before + 2f).coerceAtMost(72f), para.after) }
                        )
                        StepRow(
                            "After paragraph", ptText(para.after),
                            { a.onParaFmt(left, fr, para.before, (para.after - 2f).coerceAtLeast(0f)) },
                            { a.onParaFmt(left, fr, para.before, (para.after + 2f).coerceAtMost(72f)) }
                        )
                        Text("Line spacing", color = Color.White, fontSize = 16.sp, modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp))
                        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(1.0f, 1.15f, 1.5f, 2.0f).forEach { v ->
                                ChipBtn(String.format(java.util.Locale.US, "%.2f", v).trimEnd('0').trimEnd('.'), kotlin.math.abs(spacing - v) < 0.01f, Modifier.weight(1f)) { a.onSpacing(v) }
                            }
                        }
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlineBtn("Reset indent & spacing", Modifier.fillMaxWidth()) { a.onParaReset() }
            }
            else -> {
                Text("Turn an option on to fix text while you type. \"Apply now\" fixes the selected text, or the whole document when nothing is selected.", color = TpGrey, fontSize = 14.sp)
                Spacer(Modifier.height(10.dp))
                TpCardBox(Modifier.fillMaxWidth()) {
                    Column(Modifier.fillMaxWidth()) {
                        SwitchRow("Smart quotes", "\" \"  →  \u201C \u201D", typo.quotes) { a.onTypo(0, it) }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
                        SwitchRow("Dashes", "--  →  \u2013      ---  →  \u2014", typo.dashes) { a.onTypo(1, it) }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
                        SwitchRow("Ellipsis", "...  →  \u2026", typo.ellipsis) { a.onTypo(2, it) }
                        Box(Modifier.fillMaxWidth().height(1.dp).background(TpLine))
                        SwitchRow("Urdu punctuation", "?  ,  ;  →  \u061F  \u060C  \u061B", typo.urdu) { a.onTypo(3, it) }
                    }
                }
                Spacer(Modifier.height(14.dp))
                OutlineBtn("Apply now", Modifier.fillMaxWidth()) { a.onTypoApply() }
            }
        }
    }
}
