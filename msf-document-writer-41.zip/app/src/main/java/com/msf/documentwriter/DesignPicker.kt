package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Small (down-sampled) previews of the page designs, so 24 full bitmaps are not held in memory. */
object DesignThumbs {
    private val cache = HashMap<Int, Bitmap?>()

    fun get(c: Context, id: Int): Bitmap? {
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            val s = PageDesigns.spec(id)!!
            val o = BitmapFactory.Options().apply { inSampleSize = 4 }
            if (CustomDesigns.isCustom(id)) BitmapFactory.decodeFile(s.asset, o)
            else c.applicationContext.assets.open(s.asset).use { BitmapFactory.decodeStream(it, null, o) }
        } catch (e: Throwable) { null }
        cache[id] = b
        return b
    }

    fun forget(id: Int) { cache.remove(id) }
}

/** The "Page Design" gallery of the New Document screen, as a dialog for the Blank Page editor. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun DesignPickerDialog(current: Int, addMode: Boolean, onPick: (Int) -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var askDelete by remember { mutableStateOf(-1) }
    val customs = remember(tick) { CustomDesigns.list() }
    val items: List<Triple<Int, String, String>> =
        (if (addMode) emptyList() else listOf(Triple(0, "Plain page", "سادہ صفحہ"))) +
            customs.map { Triple(it.id, it.en, it.ur) } +
            PageDesigns.all.map { Triple(it.id, it.en, it.ur) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                if (addMode) "Add design page\nڈیزائن والا صفحہ شامل کریں" else "Page Design\nپیج ڈیزائن منتخب کریں",
                fontSize = 18.sp, fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                GalleryDesignButton(false) { onPick(it) }
                items.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        row.forEach { (id, en, ur) ->
                            val sel = id == current && !addMode
                            Column(
                                Modifier.weight(1f)
                                    .background(if (sel) Color(0xFFDCEBFF) else Color(0xFFF7F9FD), RoundedCornerShape(14.dp))
                                    .border(if (sel) 2.dp else 1.dp, if (sel) Color(0xFF0B4DB8) else Color(0xFFD5E0F2), RoundedCornerShape(14.dp))
                                    .combinedClickable(onClick = { onPick(id) }, onLongClick = { if (CustomDesigns.isCustom(id)) askDelete = id })
                                    .padding(8.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                val tb = if (id != 0) remember(id) { DesignThumbs.get(ctx, id) } else null
                                if (tb != null) Image(
                                    bitmap = tb.asImageBitmap(), contentDescription = null, contentScale = ContentScale.Fit,
                                    modifier = Modifier.fillMaxWidth().aspectRatio(0.72f)
                                ) else Box(Modifier.fillMaxWidth().aspectRatio(0.72f).background(Color.White).border(1.dp, Color(0xFFBBC7DA)))
                                Spacer(Modifier.height(6.dp))
                                Text(en, fontSize = 13.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center, color = Color(0xFF10264F))
                                Text(ur, fontSize = 12.sp, textAlign = TextAlign.Center, color = Color(0xFF3A4A66))
                            }
                        }
                        if (row.size < 2) Spacer(Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } }
    )
    if (askDelete >= 0) AlertDialog(
        onDismissRequest = { askDelete = -1 },
        title = { Text("Delete this design? / یہ ڈیزائن مٹائیں؟") },
        text = { Text("صرف آپ کا اپنا شامل کیا ہوا ڈیزائن مٹے گا۔\nOnly your own design is removed from the list.") },
        confirmButton = { TextButton(onClick = { CustomDesigns.remove(ctx, askDelete); askDelete = -1; tick++ }) { Text("Delete", color = Color(0xFFD32F2F)) } },
        dismissButton = { TextButton(onClick = { askDelete = -1 }) { Text("Cancel") } }
    )
}

/** Asks how wide the text margins should be for a design chosen from the gallery. */
@Composable
fun DesignMarginDialog(onPick: (Int) -> Unit, onCancel: () -> Unit) {
    AlertDialog(
        onDismissRequest = onCancel,
        title = { Text("Text margin / تحریر کا حاشیہ", fontSize = 18.sp, fontWeight = FontWeight.Bold) },
        text = { Text("ڈیزائن کے کناروں سے تحریر کتنی دور رہے؟\nHow far from the edge should the text stay?") },
        confirmButton = {
            Column(horizontalAlignment = Alignment.End) {
                TextButton(onClick = { onPick(0) }) { Text("Small / چھوٹا") }
                TextButton(onClick = { onPick(1) }) { Text("Medium / درمیانہ") }
                TextButton(onClick = { onPick(2) }) { Text("Large / بڑا (frame / فریم)") }
            }
        },
        dismissButton = { TextButton(onClick = onCancel) { Text("Cancel") } }
    )
}

/** "Choose from Gallery / File Manager": picks a picture, asks the text margin, makes it a design and reports its id. */
@Composable
fun GalleryDesignButton(tile: Boolean, onNew: (Int) -> Unit) {
    val ctx = LocalContext.current
    var pending by remember { mutableStateOf<android.net.Uri?>(null) }
    val picker = androidx.activity.compose.rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.GetContent()) { u ->
        if (u != null) pending = u
    }
    val open = { safe(ctx) { picker.launch("image/*") } }
    if (tile) {
        Column(
            Modifier.width(104.dp).background(Color(0xFFE8F5E9), RoundedCornerShape(12.dp))
                .border(1.5.dp, Color(0xFF2E7D32), RoundedCornerShape(12.dp))
                .clickable { open() }.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.width(70.dp).height(100.dp), contentAlignment = Alignment.Center) {
                Text("＋", fontSize = 40.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
            }
            Spacer(Modifier.height(4.dp))
            Text("Gallery / Files", fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1)
            Text("اپنا ڈیزائن", fontSize = 11.sp, maxLines = 1)
        }
    } else {
        Row(
            Modifier.fillMaxWidth().background(Color(0xFFE8F5E9), RoundedCornerShape(14.dp))
                .border(1.5.dp, Color(0xFF2E7D32), RoundedCornerShape(14.dp))
                .clickable { open() }.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("＋", fontSize = 26.sp, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
            Spacer(Modifier.width(12.dp))
            Column {
                Text("Choose from Gallery / File Manager", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1B5E20))
                Text("گیلری یا فائل مینیجر سے اپنا ڈیزائن منتخب کریں", fontSize = 12.sp, color = Color(0xFF1B5E20))
            }
        }
    }
    if (pending != null) DesignMarginDialog(
        onPick = { size ->
            val u = pending
            pending = null
            val sp = if (u != null) CustomDesigns.add(ctx, u, size) else null
            if (sp == null) toast(ctx, "یہ تصویر ڈیزائن نہیں بن سکی / Could not use this picture") else onNew(sp.id)
        },
        onCancel = { pending = null }
    )
}
