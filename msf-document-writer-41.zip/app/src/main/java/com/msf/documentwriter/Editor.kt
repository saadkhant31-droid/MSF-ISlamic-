@file:OptIn(ExperimentalMaterial3Api::class)

package com.msf.documentwriter

import android.graphics.Typeface
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.TextWatcher
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalView
import android.content.Intent
import android.graphics.Rect
import android.view.ViewTreeObserver
import kotlinx.coroutines.launch
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import android.content.Context
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import androidx.compose.foundation.BorderStroke
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

class SelEditText(c: Context) : EditText(c) {
    var onSel: (() -> Unit)? = null
    /** Last real (non-empty) selection. Menus and pop-ups (font, size, colour) steal focus and Android then collapses
     *  the selection, so the format buttons fall back to this range. It is dropped when the user taps the text or types. */
    var keepA = -1
    var keepB = -1
    private var touching = false

    override fun onSelectionChanged(selStart: Int, selEnd: Int) {
        super.onSelectionChanged(selStart, selEnd)
        if (selStart >= 0 && selEnd >= 0) {
            if (selStart != selEnd) { keepA = minOf(selStart, selEnd); keepB = maxOf(selStart, selEnd) }
            else if (touching) { keepA = -1; keepB = -1 }
        }
        onSel?.invoke()
    }

    override fun onTextChanged(text: CharSequence?, start: Int, lengthBefore: Int, lengthAfter: Int) {
        super.onTextChanged(text, start, lengthBefore, lengthAfter)
        keepA = -1; keepB = -1
    }

    /** Set while the page shows text columns (see [ColumnMap]); null = one normal column. */
    var colMap: ColumnMap? = null

    override fun onTouchEvent(event: MotionEvent): Boolean {
        val cm = colMap
        if (cm != null) {
            val m = MotionEvent.obtain(event)
            try {
                cm.mapTouch(m, paddingLeft, paddingTop)
                return touchInner(m)
            } finally { m.recycle() }
        }
        return touchInner(event)
    }

    private fun touchInner(event: MotionEvent): Boolean {
        if (event.actionMasked == MotionEvent.ACTION_DOWN) touching = true
        val r = super.onTouchEvent(event)
        if (event.actionMasked == MotionEvent.ACTION_UP || event.actionMasked == MotionEvent.ACTION_CANCEL) touching = false
        return r
    }

    /** With columns every piece of the text column is drawn at its own place on the page. */
    override fun onDraw(canvas: android.graphics.Canvas) {
        val cm = colMap
        if (cm == null) { super.onDraw(canvas); return }
        val padL = paddingLeft
        val padT = paddingTop
        for (i in 0 until cm.count) {
            val h = cm.bots[i] - cm.tops[i]
            if (h <= 0) continue
            val sx = cm.x(i)
            val sy = cm.y(i)
            canvas.save()
            canvas.clipRect(sx - 6f, sy, sx + cm.colW + 6f, sy + h)
            canvas.translate(sx - padL, sy - cm.tops[i] - padT)
            super.onDraw(canvas)
            canvas.restore()
        }
    }

    // the caret blink asks to redraw the caret's place in the text layout; with columns that place is elsewhere on screen
    @Suppress("OVERRIDE_DEPRECATION")
    override fun invalidate(l: Int, t: Int, r: Int, b: Int) {
        if (colMap != null) super.invalidate() else super.invalidate(l, t, r, b)
    }

    // keeps the page scrolled to the caret: the caret's rectangle is in text-layout coordinates, the page shows it elsewhere
    override fun requestRectangleOnScreen(rectangle: Rect, immediate: Boolean): Boolean {
        val cm = colMap
        if (cm != null && cm.count > 0) {
            val i = cm.chunkAt((rectangle.top - paddingTop).toFloat())
            val r = Rect(rectangle)
            r.offset((cm.x(i) - paddingLeft).toInt(), (cm.y(i) - cm.tops[i] - paddingTop).toInt())
            return super.requestRectangleOnScreen(r, immediate)
        }
        return super.requestRectangleOnScreen(rectangle, immediate)
    }
}

/** The selection to format: the current one, or the last real one when a menu/pop-up collapsed it (it is restored on screen). */
fun selRange(et: EditText): Pair<Int, Int> {
    var a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
    var b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
    if (a == b && et is SelEditText) {
        val ka = et.keepA
        val kb = et.keepB
        if (ka >= 0 && ka < kb && kb <= et.text.length) {
            a = ka; b = kb
            et.setSelection(a, b)
        }
    }
    return Pair(a, b)
}

class EditorHolder {
    var sheets: PageSheets? = null
    var et: EditText? = null
    var main: EditText? = null
    var tr: EditText? = null
}

const val BISMILLAH = "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ"

val TextColors: List<Int?> = listOf(
    0xFFD32F2F.toInt(), 0xFF000000.toInt(), 0xFF1565C0.toInt(), 0xFF2E7D32.toInt(), 0xFFEF6C00.toInt(),
    0xFF6A1B9A.toInt(), 0xFF00796B.toInt(), 0xFF5D4037.toInt(), 0xFF616161.toInt(), 0xFFC2185B.toInt()
)
val HiColors: List<Int?> = listOf(
    0xFFFFF176.toInt(), 0xFFA5D6A7.toInt(), 0xFF80DEEA.toInt(), 0xFFF48FB1.toInt(), 0xFFFFCC80.toInt(), 0xFFE0E0E0.toInt(), null
)
@Composable
fun ColumnScope.FontMenuItems(onPick: (String, String) -> Unit, onAdd: () -> Unit) {
    Fonts.all().forEach { (l, fam) -> DropdownMenuItem(text = { Text(l) }, onClick = { onPick(l, fam) }) }
    Divider()
    DropdownMenuItem(
        text = { Text("＋ Add Font / فونٹ شامل کریں", fontWeight = FontWeight.Bold, color = Color(0xFF1E5CD6)) },
        onClick = onAdd
    )
}
/** Runs an action that opens a system screen (picker etc.); never lets a failure close the app. */
fun safe(c: Context, block: () -> Unit) {
    try { block() } catch (e: Throwable) { toast(c, "یہ آپشن کھل نہیں سکا / Could not open this option") }
}
val SizeList = listOf(10, 12, 14, 16, 18, 20, 24, 28, 32, 40, 48, 60, 72)

fun defaultFontLabel(): String = Fonts.all().firstOrNull { it.second == Doc.font }?.first ?: "Default"

val Fatiha = Template(
    "Al-Fatiha", "سورۃ الفاتحہ", "Quran_Surah_Fatiha",
    "بِسْمِ اللَّهِ الرَّحْمَٰنِ الرَّحِيمِ\nالْحَمْدُ لِلَّهِ رَبِّ الْعَالَمِينَ\nالرَّحْمَٰنِ الرَّحِيمِ\nمَالِكِ يَوْمِ الدِّينِ\nإِيَّاكَ نَعْبُدُ وَإِيَّاكَ نَسْتَعِينُ\nاهْدِنَا الصِّرَاطَ الْمُسْتَقِيمَ\nصِرَاطَ الَّذِينَ أَنْعَمْتَ عَلَيْهِمْ غَيْرِ الْمَغْضُوبِ عَلَيْهِمْ وَلَا الضَّالِّينَ",
    true, Icons.Filled.MenuBook, Color(0xFF0F766E),
    "اللہ کے نام سے جو بڑا مہربان، نہایت رحم کرنے والا ہے۔\nہر طرح کی تعریف اللہ ہی کے لیے ہے، جو تمام جہانوں کا پروردگار ہے۔\nجو بڑا مہربان، نہایت رحم کرنے والا ہے۔\nبدلے کے دن کا مالک ہے۔\nہم تیری ہی عبادت کرتے ہیں اور تجھ سے ہی مدد مانگتے ہیں۔\nہمیں سیدھا راستہ دکھا۔\nان لوگوں کا راستہ جن پر تو نے انعام کیا، نہ کہ جن پر تیرا غضب ہوا اور نہ گمراہوں کا۔"
)

fun makeEditor(
    c: Context, init: CharSequence, hintText: String, size: Int, font: String?,
    onChange: () -> Unit, onFocus: (EditText) -> Unit, onSel: () -> Unit
): SelEditText {
    val et = SelEditText(c)
    et.background = null
    et.gravity = Gravity.TOP
    et.setPadding(20, 16, 20, 16)
    et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    et.setTextSize(TypedValue.COMPLEX_UNIT_DIP, size.toFloat())
    et.setTextColor(android.graphics.Color.BLACK)
    et.hint = hintText
    if (font != null) et.typeface = Fonts.typeface(font)
    et.setText(init, TextView.BufferType.EDITABLE)
    PageBreaks.decorate(et.text)
    et.setSelection(et.text.length)
    var sig = PageBreaks.signature(et.text)
    et.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            onChange()
            if (s != null) {
                val g = PageBreaks.signature(s)
                if (g != sig) { sig = g; PageBreaks.decorate(s) }
            }
        }
    })
    et.setOnFocusChangeListener { v, f -> if (f) onFocus(v as EditText) }
    et.onSel = onSel
    return et
}

@Composable
fun ColorMenu(expanded: Boolean, onDismiss: () -> Unit, colors: List<Int?>, onPick: (Int?) -> Unit) {
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            colors.chunked(5).forEach { row ->
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { c ->
                        Box(
                            Modifier.size(34.dp).clip(CircleShape).background(if (c != null) Color(c) else Color.White)
                                .border(1.dp, Color.Gray, CircleShape).clickable { onPick(c); onDismiss() },
                            contentAlignment = Alignment.Center
                        ) { if (c == null) Text("✕", fontSize = 14.sp) }
                    }
                }
            }
        }
    }
}

@Composable
fun ToolBtn(
    icon: ImageVector, label: String, modifier: Modifier = Modifier, active: Boolean = false,
    tint: Color = Blue, labelSize: Int = 10, onClick: () -> Unit
) {
    Column(
        modifier.clip(RoundedCornerShape(10.dp))
            .background(if (active) Color(0xFFD6E6FF) else Color.Transparent)
            .clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, null, tint = tint, modifier = Modifier.size(24.dp))
        Text(label, fontSize = labelSize.sp, maxLines = 1, softWrap = false, color = Color(0xFF0A2A66))
    }
}

@Composable
fun VDiv() {
    Box(Modifier.width(1.dp).height(34.dp).background(Color(0xFFE3EAF6)))
}

@Composable
fun PickerCard(
    title: String, icon: ImageVector, modifier: Modifier, onClick: () -> Unit,
    menu: @Composable () -> Unit, value: @Composable () -> Unit
) {
    Column(
        modifier.clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp)).padding(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(Blue), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = Color.White, modifier = Modifier.size(15.dp))
            }
            Spacer(Modifier.width(4.dp))
            Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
        }
        Spacer(Modifier.height(4.dp))
        Row(
            Modifier.fillMaxWidth().clip(RoundedCornerShape(8.dp)).border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(8.dp))
                .clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 5.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.weight(1f)) { value() }
            Icon(Icons.Filled.ArrowDropDown, null, modifier = Modifier.size(18.dp))
        }
        Box { menu() }
    }
}

@Composable
fun StyleBtn(t: String, active: Boolean, modifier: Modifier, b: Boolean, i: Boolean, u: Boolean, onClick: () -> Unit) {
    Box(
        modifier.height(30.dp).clip(RoundedCornerShape(6.dp))
            .background(if (active) Blue else Color.White)
            .border(1.dp, if (active) Blue else Color(0xFFD5E0F2), RoundedCornerShape(6.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Text(
            t, fontSize = 15.sp, color = if (active) Color.White else Color(0xFF0A2A66),
            fontWeight = if (b) FontWeight.ExtraBold else FontWeight.Normal,
            fontStyle = if (i) FontStyle.Italic else FontStyle.Normal,
            textDecoration = if (u) TextDecoration.Underline else null
        )
    }
}

@Composable
fun LangSegment(lang: Int, onPick: (Int) -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp))
    ) {
        listOf(Triple("Urdu", "اردو", "ا"), Triple("Arabic", "عربی", "ع")).forEachIndexed { i, t ->
            val sel = lang == i
            Row(
                Modifier.background(if (sel) Blue else Color.Transparent).clickable { onPick(i) }
                    .padding(horizontal = 8.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(24.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (sel) Color.White else if (i == 0) Blue else Color(0xFF16A34A)),
                    contentAlignment = Alignment.Center
                ) { Text(t.third, color = if (sel) Blue else Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp) }
                Spacer(Modifier.width(4.dp))
                Column {
                    Text(t.first, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = if (sel) Color.White else Color(0xFF0A2A66))
                    Text(t.second, fontSize = 10.sp, color = if (sel) Color.White else Color.DarkGray)
                }
            }
        }
    }
}

@Composable
fun MiniChip(label: String, icon: ImageVector, trailing: Boolean = false, onClick: () -> Unit) {
    Row(
        Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp))
            .clickable(onClick = onClick).padding(horizontal = 9.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(18.dp))
        Spacer(Modifier.width(3.dp))
        Text(label, fontSize = 12.sp, color = Color(0xFF0A2A66), maxLines = 1)
        if (trailing) Icon(Icons.Filled.ArrowDropDown, null, modifier = Modifier.size(16.dp))
    }
}

@Composable
fun UrduBanner() {
    Card(
        Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))
    ) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(62.dp)) {
                Box(
                    Modifier.align(Alignment.TopStart).size(38.dp).clip(RoundedCornerShape(10.dp)).background(Color(0xFF16A34A)),
                    contentAlignment = Alignment.Center
                ) { Text("ع", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                Box(
                    Modifier.align(Alignment.BottomEnd).size(38.dp).clip(RoundedCornerShape(10.dp)).background(Blue),
                    contentAlignment = Alignment.Center
                ) { Text("ا", color = Color.White, fontSize = 24.sp, fontWeight = FontWeight.Bold) }
            }
            Spacer(Modifier.width(8.dp))
            Column(Modifier.weight(1f)) {
                Text("Urdu & Arabic Writing", fontWeight = FontWeight.ExtraBold, fontSize = 17.sp, color = Color(0xFF0A2A66), maxLines = 1)
                Text("اردو اور عربی میں لکھیں", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color(0xFF0A2A66))
                Text("آپ آسانی سے اردو اور عربی زبان میں خوبصورت تحریر لکھ سکتے ہیں۔", fontSize = 10.sp, color = Color.DarkGray, maxLines = 2)
            }
            Spacer(Modifier.width(6.dp))
            Box(
                Modifier.size(64.dp, 70.dp).clip(RoundedCornerShape(10.dp))
                    .background(Brush.verticalGradient(listOf(Color(0xFF1B6B4A), Color(0xFF0B3D2B)))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Filled.MenuBook, null, tint = Color(0xFFE8C766), modifier = Modifier.size(40.dp)) }
        }
    }
}

@Composable
fun OrnatePanel(
    modifier: Modifier, header: String, headerBg: Color, headerColor: Color, accent: Color,
    onHeader: () -> Unit, content: @Composable () -> Unit
) {
    Box(
        modifier.clip(RoundedCornerShape(12.dp)).background(Color.White)
            .border(1.5.dp, accent.copy(alpha = 0.75f), RoundedCornerShape(12.dp))
    ) {
        Column(Modifier.fillMaxSize().padding(8.dp)) {
            Box(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(headerBg)
                    .clickable(onClick = onHeader).padding(vertical = 6.dp),
                contentAlignment = Alignment.Center
            ) { Text(header, color = headerColor, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1) }
            Spacer(Modifier.height(6.dp))
            Box(Modifier.weight(1f).fillMaxWidth()) { content() }
        }
        Box(Modifier.align(Alignment.TopStart).padding(3.dp).size(7.dp).rotate(45f).background(accent))
        Box(Modifier.align(Alignment.TopEnd).padding(3.dp).size(7.dp).rotate(45f).background(accent))
        Box(Modifier.align(Alignment.BottomStart).padding(3.dp).size(7.dp).rotate(45f).background(accent))
        Box(Modifier.align(Alignment.BottomEnd).padding(3.dp).size(7.dp).rotate(45f).background(accent))
    }
}

@Composable
fun RichEditorScreen(nav: NavController, mode: String) {
    val ctx = LocalContext.current
    val urdu = mode == "urdu"
    val holder = remember { EditorHolder() }
    var version by remember { mutableIntStateOf(0) }
    var dirty by remember { mutableStateOf(Doc.dirty) }
    var rtl by remember { mutableStateOf(Doc.rtl || urdu) }
    var justify by remember { mutableStateOf(Doc.justify) }
    var fontLabel by remember { mutableStateOf(defaultFontLabel()) }
    var sizeNow by remember { mutableIntStateOf(Doc.baseSize) }
    var lang by remember { mutableIntStateOf(Doc.lang) }
    var curColor by remember { mutableStateOf(Color.Black) }
    var stBold by remember { mutableStateOf(false) }
    var stItalic by remember { mutableStateOf(false) }
    var stUnder by remember { mutableStateOf(false) }
    var alignNow by remember { mutableIntStateOf(if (urdu) -1 else 0) }
    var menu by remember { mutableStateOf("") }
    var showTpl by remember { mutableStateOf(false) }
    var showExit by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var showDesign by remember { mutableStateOf(false) }
    var addMode by remember { mutableStateOf(false) }
    var designList by remember { mutableStateOf(Doc.pageDesigns) }
    var showTable by remember { mutableStateOf(false) }
    var tRows by remember { mutableIntStateOf(3) }
    var tCols by remember { mutableIntStateOf(3) }
    var tHeader by remember { mutableStateOf(true) }
    var tStyle by remember { mutableIntStateOf(0) }
    var numbers by remember { mutableStateOf(Doc.pageNumbers) }
    var pn by remember { mutableStateOf(Doc.pn) }
    var showPn by remember { mutableStateOf(false) }
    var design by remember { mutableIntStateOf(Doc.pageDesign) }
    var cursorTick by remember { mutableIntStateOf(0) }
    // keyboard open? (the window is resized by the keyboard, so compare the visible frame with the full screen)
    val rootView = LocalView.current
    var imeOpen by remember { mutableStateOf(false) }
    DisposableEffect(rootView) {
        val l = ViewTreeObserver.OnGlobalLayoutListener {
            val r = Rect()
            rootView.getWindowVisibleDisplayFrame(r)
            val full = rootView.rootView.height
            imeOpen = full > 0 && (full - r.bottom) > full * 0.15f
        }
        rootView.viewTreeObserver.addOnGlobalLayoutListener(l)
        onDispose { rootView.viewTreeObserver.removeOnGlobalLayoutListener(l) }
    }
    val imgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            Doc.image = u; dirty = true
            toast(ctx, "تصویر PDF/Image محفوظ کرنے پر شامل ہو گی / Image is added when saving as PDF or Image")
        }
    }

    fun refreshState() {
        val et = holder.et ?: return
        val e = et.text
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val from = if (a == b) maxOf(a - 1, 0) else a
        val styles = e.getSpans(from, b, StyleSpan::class.java).filter { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        stBold = styles.any { (it.style and Typeface.BOLD) != 0 }
        stItalic = styles.any { (it.style and Typeface.ITALIC) != 0 }
        stUnder = e.getSpans(from, b, UnderlineSpan::class.java).any { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        val sz = e.getSpans(from, b, AbsoluteSizeSpan::class.java).lastOrNull()
        sizeNow = sz?.size ?: Doc.baseSize
        val col = e.getSpans(from, b, ForegroundColorSpan::class.java).lastOrNull()
        curColor = if (col != null) Color(col.foregroundColor) else Color.Black
        val fam = e.getSpans(from, b, TypefaceSpan::class.java).lastOrNull()?.family
        fontLabel = Fonts.all().firstOrNull { it.second == fam }?.first ?: defaultFontLabel()
    }
    fun sync() {
        holder.main?.let { Doc.text = cleanCopy(it.text) }
        Doc.pageStarts = holder.sheets?.breakStarts ?: emptyList()
        holder.tr?.let { Doc.trans = SpannableStringBuilder(it.text) }
        Doc.rtl = rtl; Doc.justify = justify; Doc.dirty = dirty; Doc.lang = lang; Doc.pageNumbers = numbers; Doc.pn = pn
    }
    fun touch() { dirty = true; version++; refreshState() }
    fun fmt(block: (Editable, Int, Int) -> Unit) {
        val et = holder.et ?: return
        val sel = selRange(et)
        if (holder.sheets != null && sel.first == sel.second) {
            toast(ctx, "پہلے متن منتخب کریں / Select some text first")
            return
        }
        val (s, e) = Rich.range(et)
        if (s >= e) { toast(ctx, "پہلے متن لکھیں / Write some text first"); return }
        block(et.text, s, e)
        touch()
    }
    /** Font menu choice: selected text gets the font; with no selection the whole document uses it (also for new typing). */
    fun chooseFont(label: String, fam: String) {
        fontLabel = label
        val et = holder.et ?: holder.main ?: return
        val (a, b) = selRange(et)
        if (a != b) {
            Rich.font(et.text, a, b, fam)
        } else if (holder.sheets != null && et.text.isNotEmpty()) {
            // page editor: with no selection only the text typed next gets the font
            Rich.pendingFont(et.text, a, fam)
        } else {
            Doc.font = fam
            val main = holder.main
            if (main != null) {
                main.typeface = Fonts.typeface(fam)
                val t = main.text
                for (sp in t.getSpans(0, t.length, TypefaceSpan::class.java)) t.removeSpan(sp)
            }
            if (holder.tr == null) et.typeface = Fonts.typeface(fam)
        }
        touch()
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            var name: String? = null
            try {
                ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { cur -> if (cur.moveToFirst()) name = cur.getString(0) }
            } catch (e: Exception) { }
            if (name == null) name = u.lastPathSegment
            val label = Fonts.add(ctx, u, name)
            if (label == null) toast(ctx, "یہ فونٹ شامل نہیں ہو سکا (.ttf یا .otf چاہیے) / Could not add font (.ttf or .otf needed)")
            else {
                toast(ctx, "فونٹ شامل ہو گیا / Font added: $label")
                chooseFont(label, label)
            }
        }
    }
    fun para(block: (EditText) -> Unit) { holder.et?.let { block(it); touch() } }
    fun setLang(i: Int) {
        lang = i
        val f = if (i == 0) "Noto Nastaliq Urdu" else "Noto Naskh Arabic"
        Doc.font = f
        holder.main?.typeface = Fonts.typeface(f)
        holder.tr?.typeface = Fonts.typeface("Noto Nastaliq Urdu")
        fontLabel = defaultFontLabel()
        rtl = true
        touch()
    }
    fun setSize(sz: Int) {
        sizeNow = sz
        val et = holder.et ?: return
        if (et.text.isEmpty()) {
            Doc.baseSize = sz
            if (holder.sheets != null) holder.sheets?.setBase(sz) else holder.main?.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sz.toFloat())
            holder.tr?.setTextSize(TypedValue.COMPLEX_UNIT_DIP, sz.toFloat())
            touch()
        } else fmt { e, s, en -> Rich.size(e, s, en, sz) }
    }
    fun quick(k: DocKind): File? = try {
        sync()
        Doc.saveTo(ctx, k, Doc.name.ifBlank { "Document" }).also { dirty = false; Doc.dirty = false }
    } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed"); null }
    fun shareNow() {
        quick(if (Doc.kind == DocKind.IMAGE) DocKind.WORD else Doc.kind)?.let { Actions.share(ctx, it) }
    }
    fun insertTemplate(t: Template) {
        val main = holder.main ?: return
        val tr = holder.tr
        if (tr != null && t.trans.isNotEmpty()) {
            main.text.insert(main.selectionStart.coerceAtLeast(0), t.body)
            tr.text.insert(tr.selectionStart.coerceAtLeast(0), t.trans)
        } else {
            val extra = if (t.trans.isNotEmpty()) t.body + "\n\n" + t.trans else t.body
            main.text.insert(main.selectionStart.coerceAtLeast(0), extra)
        }
        if (t.rtl) rtl = true
        touch()
    }
    fun applyDir(et: EditText) {
        et.textDirection = if (rtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_FIRST_STRONG_LTR
        if (Build.VERSION.SDK_INT >= 26) {
            et.justificationMode = if (justify) Layout.JUSTIFICATION_MODE_INTER_WORD else Layout.JUSTIFICATION_MODE_NONE
        }
    }

    fun newPage() {
        val et = holder.et ?: holder.main ?: return
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val np = PageBreaks.insertAt(et.text, pos)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
        toast(ctx, "نیا صفحہ شامل ہو گیا / New page added")
    }
    fun blankPage() {
        val et = holder.et ?: holder.main ?: return
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val np = PageBreaks.insertBlank(et.text, pos)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
        toast(ctx, "خالی صفحہ شامل ہو گیا / Blank page added")
    }
    fun insertTable() {
        val et = holder.et ?: holder.main ?: return
        val pos = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val np = Tables.insert(et.text, pos, tRows, tCols, tHeader, tStyle)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
        toast(ctx, "ٹیبل شامل ہو گیا، | کے درمیان خانوں میں لکھیں / Table added: type between the | bars")
    }
    fun setDesign(id: Int) {
        sync()
        design = id
        Doc.pageDesign = id
        Doc.pageDesigns = emptyList(); designList = emptyList()
        dirty = true; Doc.dirty = true
        version++
    }

    /** "+": a new page after all the text, with its own design (pages can have different designs). */
    fun addDesignPage(id: Int) {
        val et = holder.et ?: holder.main
        val sh = holder.sheets
        if (et == null || sh == null || design == 0) { setDesign(id); return }
        val pagesNow = sh.contentPages.coerceAtLeast(1)
        val ends = et.text.toString().trimEnd(' ', '\n').endsWith(PAGE_BREAK)
        val target = if (ends) pagesNow - 1 else pagesNow
        val list = ArrayList<Int>(if (designList.isEmpty()) listOf(design) else designList)
        while (list.size < target) list.add(list.lastOrNull() ?: design)
        while (list.size > target) list.removeAt(list.size - 1)
        list.add(id)
        if (!ends) PageBreaks.insertAt(et.text, et.text.length)
        et.setSelection(et.text.length)
        et.requestFocus()
        designList = list
        Doc.pageDesigns = list
        Doc.pageDesign = list[0]
        design = list[0]
        touch()
        toast(ctx, "نیا ڈیزائن والا صفحہ شامل ہو گیا / Design page added")
    }

    DisposableEffect(Unit) { onDispose { sync() } }
    LaunchedEffect(Unit) {
        if (urdu && Doc.font == null) setLang(Doc.lang)
        if (Doc.pickImage) { Doc.pickImage = false; safe(ctx) { imgPicker.launch("image/*") } }
    }
    LaunchedEffect(version) {
        val key = when (Doc.kind) { DocKind.WORD -> "docx"; DocKind.TEXT -> "txt"; else -> null }
        if (version > 0 && key != null && Prefs.autoSave(ctx) && Doc.saved[key] != null) {
            delay(2500)
            sync()
            try { Doc.saveTo(ctx, Doc.kind, Doc.name); dirty = false; Doc.dirty = false } catch (_: Exception) {}
        }
    }
    BackHandler(enabled = dirty) { showExit = true }

    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader(
                sub = if (Doc.name.isBlank()) "آسان طریقے سے اپنی دستاویزات بنائیں" else Doc.name,
                onBack = { if (dirty) showExit = true else nav.popBackStack() }
            ) {
                if (urdu) {
                    IconButton(onClick = { shareNow() }) { Icon(Icons.Filled.Share, null, tint = Color.White) }
                } else {
                    Column(
                        Modifier.clip(RoundedCornerShape(8.dp)).clickable { sync(); nav.navigate("save") }.padding(horizontal = 8.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Icon(Icons.Filled.Save, null, tint = Color.White)
                        Text("Save", color = Color.White, fontSize = 11.sp)
                    }
                }
                Box {
                    IconButton(onClick = { menu = "more" }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
                    DropdownMenu(expanded = menu == "more", onDismissRequest = { menu = "" }) {
                        DropdownMenuItem(text = { Text("Add image / تصویر شامل کریں") }, onClick = { menu = ""; safe(ctx) { imgPicker.launch("image/*") } })
                        DropdownMenuItem(text = { Text((if (rtl) "✓ " else "") + "Right-to-left / دائیں سے بائیں") }, onClick = { menu = ""; rtl = !rtl; touch() })
                        DropdownMenuItem(text = { Text("New page / نیا صفحہ") }, onClick = { menu = ""; newPage() })
                        DropdownMenuItem(text = { Text("Blank page / خالی صفحہ") }, onClick = { menu = ""; blankPage() })
                        DropdownMenuItem(text = { Text("Insert table / ٹیبل") }, onClick = { menu = ""; showTable = true })
                        DropdownMenuItem(text = { Text((if (numbers) "✓ " else "") + "Page numbers / صفحہ نمبر") }, onClick = { menu = ""; numbers = !numbers; touch() })
                        DropdownMenuItem(text = { Text("Page number… / صفحہ نمبر کی ترتیب") }, onClick = { menu = ""; showPn = true })
                        DropdownMenuItem(text = { Text("Page design / پیج ڈیزائن") }, onClick = { menu = ""; addMode = false; showDesign = true })
                        DropdownMenuItem(text = { Text("+ Add design page / ڈیزائن والا صفحہ شامل کریں") }, onClick = { menu = ""; addMode = true; showDesign = true })
                        DropdownMenuItem(text = { Text("Insert template / ٹیمپلیٹ") }, onClick = { menu = ""; showTpl = true })
                        DropdownMenuItem(text = { Text("Save as… / محفوظ کریں") }, onClick = { menu = ""; sync(); nav.navigate("save") })
                        DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menu = ""; shareNow() })
                        DropdownMenuItem(text = { Text("Clear all / سب مٹائیں", color = Color(0xFFD32F2F)) }, onClick = { menu = ""; showClear = true })
                    }
                }
            }
        },
        bottomBar = {
            if (!imeOpen) BottomBar(
                listOf(
                    Nav(Icons.Filled.Home, "Home") { goHome(nav) },
                    Nav(Icons.Filled.Folder, "My Documents") { nav.navigate("docs/browse") },
                    Nav(Icons.Filled.Add, "New") { nav.navigate("new") },
                    if (urdu) Nav(Icons.Filled.Translate, "Urdu & Arabic") {}
                    else Nav(Icons.Filled.Palette, "Text Formatting") {
                        if (mode == "edit") {
                            sync()
                            nav.navigate("format") { popUpTo("editor") { inclusive = true } }
                        }
                    },
                    Nav(Icons.Filled.Settings, "Settings") { nav.navigate("settings") }
                ),
                if (mode == "edit") -1 else 3, center = 2
            )
        }
    ) { pad ->
        Column(Modifier.padding(pad).fillMaxSize().padding(horizontal = 10.dp, vertical = 6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            // ───── top panel
            if (urdu) {
                UrduBanner()
                Row(
                    Modifier.horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
                ) {
                    LangSegment(lang) { setLang(it) }
                    Box {
                        MiniChip("Font", Icons.Filled.TextFields) { menu = "font" }
                        DropdownMenu(expanded = menu == "font", onDismissRequest = { menu = "" }) {
                            FontMenuItems(
                                onPick = { l, fam -> menu = ""; chooseFont(l, fam) },
                                onAdd = { menu = ""; safe(ctx) { fontPicker.launch("*/*") } }
                            )
                        }
                    }
                    Box {
                        MiniChip("Style", Icons.Filled.Palette) { menu = "style" }
                        DropdownMenu(expanded = menu == "style", onDismissRequest = { menu = "" }) {
                            DropdownMenuItem(text = { Text("Normal / عام") }, onClick = { menu = ""; para { Rich.heading(it, 0) } })
                            DropdownMenuItem(text = { Text("Heading 1 / عنوان") }, onClick = { menu = ""; para { Rich.heading(it, 1) } })
                            DropdownMenuItem(text = { Text("Heading 2 / ذیلی عنوان") }, onClick = { menu = ""; para { Rich.heading(it, 2) } })
                        }
                    }
                    Box {
                        MiniChip("Size", Icons.Filled.FormatSize, trailing = true) { menu = "size" }
                        DropdownMenu(expanded = menu == "size", onDismissRequest = { menu = "" }) {
                            SizeList.forEach { z -> DropdownMenuItem(text = { Text(if (z == sizeNow) "✓ $z" else "$z") }, onClick = { menu = ""; setSize(z) }) }
                        }
                    }
                }
            } else {
                if (!imeOpen) Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                    Row(Modifier.padding(horizontal = 6.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { if (dirty) showExit = true else nav.popBackStack() }, modifier = Modifier.size(34.dp)) {
                            Icon(Icons.Filled.ArrowBack, null, tint = Color(0xFF0A2A66))
                        }
                        Column(Modifier.weight(1f)) {
                            Text(if (mode == "format") "Text Formatting" else "Edit Document", fontWeight = FontWeight.ExtraBold, fontSize = 18.sp, color = Color(0xFF0A2A66), maxLines = 1)
                            Text("Font, Size, Color, Style and More", fontSize = 11.sp, color = Color.DarkGray, maxLines = 2)
                        }
                        Row(
                            Modifier.clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = 0.7f)).padding(5.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(34.dp).clip(RoundedCornerShape(8.dp)).background(Blue), contentAlignment = Alignment.Center) {
                                Text("T", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                            }
                            Spacer(Modifier.width(5.dp))
                            Column {
                                Text("Text Formatting", fontSize = 10.sp, fontWeight = FontWeight.Bold, maxLines = 1)
                                Text("ٹیکسٹ فارمیٹنگ", fontSize = 11.sp, maxLines = 1)
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    PickerCard("Font", Icons.Filled.TextFields, Modifier.weight(1.3f), { menu = "font" }, {
                        DropdownMenu(expanded = menu == "font", onDismissRequest = { menu = "" }) {
                            FontMenuItems(
                                onPick = { l, fam -> menu = ""; chooseFont(l, fam) },
                                onAdd = { menu = ""; safe(ctx) { fontPicker.launch("*/*") } }
                            )
                        }
                    }) { Text(fontLabel, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis) }
                    PickerCard("Size", Icons.Filled.FormatSize, Modifier.weight(0.85f), { menu = "size" }, {
                        DropdownMenu(expanded = menu == "size", onDismissRequest = { menu = "" }) {
                            SizeList.forEach { z -> DropdownMenuItem(text = { Text(if (z == sizeNow) "✓ $z" else "$z") }, onClick = { menu = ""; setSize(z) }) }
                        }
                    }) { Text("$sizeNow", fontSize = 13.sp) }
                    Column(
                        Modifier.weight(1.2f).clip(RoundedCornerShape(12.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp)).padding(6.dp)
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(22.dp).clip(RoundedCornerShape(6.dp)).background(Blue), contentAlignment = Alignment.Center) {
                                Text("B", color = Color.White, fontWeight = FontWeight.ExtraBold, fontSize = 13.sp)
                            }
                            Spacer(Modifier.width(4.dp))
                            Text("Style", fontWeight = FontWeight.Bold, fontSize = 12.sp, maxLines = 1)
                        }
                        Spacer(Modifier.height(4.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                            StyleBtn("B", stBold, Modifier.weight(1f), true, false, false) { fmt { e, s, en -> Rich.bold(e, s, en) } }
                            StyleBtn("I", stItalic, Modifier.weight(1f), false, true, false) { fmt { e, s, en -> Rich.italic(e, s, en) } }
                            StyleBtn("U", stUnder, Modifier.weight(1f), false, false, true) { fmt { e, s, en -> Rich.underline(e, s, en) } }
                        }
                    }
                    PickerCard("Color", Icons.Filled.FormatColorText, Modifier.weight(0.85f), { menu = "tc" }, {
                        ColorMenu(menu == "tc", { menu = "" }, TextColors) { c -> fmt { e, s, en -> Rich.color(e, s, en, c) }; curColor = if (c != null) Color(c) else Color.Black }
                    }) { Box(Modifier.size(20.dp).clip(CircleShape).background(curColor)) }
                }
            }
            // ───── toolbar
            Row(
                Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                    .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp)).padding(horizontal = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (urdu) {
                    ToolBtn(Icons.Filled.FormatBold, "Bold", Modifier.weight(0.8f), stBold, labelSize = 8) { fmt { e, s, en -> Rich.bold(e, s, en) } }
                    ToolBtn(Icons.Filled.FormatItalic, "Italic", Modifier.weight(0.8f), stItalic, labelSize = 8) { fmt { e, s, en -> Rich.italic(e, s, en) } }
                    ToolBtn(Icons.Filled.FormatUnderlined, "Underline", Modifier.weight(1.1f), stUnder, labelSize = 8) { fmt { e, s, en -> Rich.underline(e, s, en) } }
                    ToolBtn(Icons.Filled.FormatAlignLeft, "Align Left", Modifier.weight(1.3f), alignNow == 0, labelSize = 8) { alignNow = 0; para { Rich.align(it, 0) } }
                    ToolBtn(Icons.Filled.FormatAlignCenter, "Center", Modifier.weight(1.1f), alignNow == 1, labelSize = 8) { alignNow = 1; para { Rich.align(it, 1) } }
                    ToolBtn(Icons.Filled.FormatAlignRight, "Align Right", Modifier.weight(1.35f), alignNow == 2, labelSize = 8) { alignNow = 2; para { Rich.align(it, 2) } }
                    Box(Modifier.weight(1.25f)) {
                        ToolBtn(Icons.Filled.FormatColorText, "Text Color", Modifier.fillMaxWidth(), tint = Color(0xFFD32F2F), labelSize = 8) { menu = "tc2" }
                        ColorMenu(menu == "tc2", { menu = "" }, TextColors) { c -> fmt { e, s, en -> Rich.color(e, s, en, c) }; if (c != null) curColor = Color(c) }
                    }
                    Box(Modifier.weight(1.3f)) {
                        ToolBtn(Icons.Filled.FormatColorFill, "Background", Modifier.fillMaxWidth(), tint = Color(0xFFF59E0B), labelSize = 8) { menu = "hi" }
                        ColorMenu(menu == "hi", { menu = "" }, HiColors) { c -> fmt { e, s, en -> Rich.highlight(e, s, en, c) } }
                    }
                    Box(Modifier.weight(0.9f)) {
                        ToolBtn(Icons.Filled.MoreHoriz, "More", Modifier.fillMaxWidth(), labelSize = 8) { menu = "tools" }
                        DropdownMenu(expanded = menu == "tools", onDismissRequest = { menu = "" }) {
                            DropdownMenuItem(text = { Text("Strikethrough") }, onClick = { menu = ""; fmt { e, s, en -> Rich.strike(e, s, en) } })
                            DropdownMenuItem(text = { Text("Clear Format") }, onClick = { menu = ""; fmt { e, s, en -> Rich.clearFormat(e, s, en) } })
                            DropdownMenuItem(text = { Text("Bullets") }, onClick = { menu = ""; para { Rich.list(it, false) } })
                            DropdownMenuItem(text = { Text("Numbering") }, onClick = { menu = ""; para { Rich.list(it, true) } })
                            DropdownMenuItem(text = { Text((if (justify) "✓ " else "") + "Justify") }, onClick = { menu = ""; justify = !justify; touch() })
                            DropdownMenuItem(text = { Text((if (rtl) "✓ " else "") + "Right-to-left") }, onClick = { menu = ""; rtl = !rtl; touch() })
                        }
                    }
                } else {
                    ToolBtn(Icons.Filled.FormatBold, "Bold", Modifier.weight(1f), stBold, labelSize = 9) { fmt { e, s, en -> Rich.bold(e, s, en) } }
                    VDiv()
                    ToolBtn(Icons.Filled.FormatItalic, "Italic", Modifier.weight(1f), stItalic, labelSize = 9) { fmt { e, s, en -> Rich.italic(e, s, en) } }
                    VDiv()
                    ToolBtn(Icons.Filled.FormatUnderlined, "Underline", Modifier.weight(1.1f), stUnder, labelSize = 9) { fmt { e, s, en -> Rich.underline(e, s, en) } }
                    VDiv()
                    ToolBtn(Icons.Filled.FormatStrikethrough, "Strikethrough", Modifier.weight(1.4f), labelSize = 9) { fmt { e, s, en -> Rich.strike(e, s, en) } }
                    VDiv()
                    Box(Modifier.weight(1.1f)) {
                        ToolBtn(Icons.Filled.FormatColorText, "Text Color", Modifier.fillMaxWidth(), tint = Color(0xFFD32F2F), labelSize = 9) { menu = "tc2" }
                        ColorMenu(menu == "tc2", { menu = "" }, TextColors) { c -> fmt { e, s, en -> Rich.color(e, s, en, c) }; if (c != null) curColor = Color(c) }
                    }
                    VDiv()
                    Box(Modifier.weight(1.05f)) {
                        ToolBtn(Icons.Filled.Highlight, "Highlight", Modifier.fillMaxWidth(), tint = Color(0xFFF59E0B), labelSize = 9) { menu = "hi" }
                        ColorMenu(menu == "hi", { menu = "" }, HiColors) { c -> fmt { e, s, en -> Rich.highlight(e, s, en, c) } }
                    }
                    VDiv()
                    ToolBtn(Icons.Filled.FormatClear, "Clear Format", Modifier.weight(1.3f), labelSize = 9) { fmt { e, s, en -> Rich.clearFormat(e, s, en) } }
                }
            }
            // ───── editor
            if (urdu) {
                Column(
                    Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp)).padding(6.dp)
                ) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        Button(
                            onClick = { showClear = true }, modifier = Modifier.height(32.dp),
                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Blue)
                        ) { Icon(Icons.Filled.Delete, null, modifier = Modifier.size(16.dp)); Spacer(Modifier.width(4.dp)); Text("Clear", fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(4.dp))
                    Row(Modifier.fillMaxWidth().weight(1f), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        OrnatePanel(
                            Modifier.weight(1f).fillMaxHeight(), BISMILLAH, Color(0xFFDDF3E4), Color(0xFF166534), Color(0xFF16A34A),
                            onHeader = {
                                val m = holder.main
                                if (m != null) {
                                    if (!m.text.toString().startsWith(BISMILLAH)) { m.text.insert(0, BISMILLAH + "\n"); touch() }
                                    m.requestFocus()
                                }
                            }
                        ) {
                            AndroidView(
                                factory = { c ->
                                    makeEditor(
                                        c, Doc.text, "یہاں لکھیں / Start writing…", Doc.baseSize, Doc.font,
                                        { touch() }, { holder.et = it; refreshState() }, { refreshState() }
                                    ).also { holder.main = it; if (holder.et == null) holder.et = it }
                                },
                                update = { et -> applyDir(et) },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                        OrnatePanel(
                            Modifier.weight(1f).fillMaxHeight(), "اردو ترجمہ", Color(0xFFE3EEFF), Blue, Blue,
                            onHeader = { holder.tr?.requestFocus() }
                        ) {
                            AndroidView(
                                factory = { c ->
                                    makeEditor(
                                        c, Doc.trans, "اردو ترجمہ یہاں لکھیں", Doc.baseSize, "Noto Nastaliq Urdu",
                                        { touch() }, { holder.et = it; refreshState() }, { refreshState() }
                                    ).also { holder.tr = it }
                                },
                                update = { et -> applyDir(et) },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                }
            } else {
                val dSpec = PageDesigns.spec(design)
                val dBmp = if (dSpec != null) PageDesigns.bitmap(ctx, design) else null
                if (dSpec != null && dBmp != null) {
                    // Designed pages: real A4 sheets one under the other (like the Blank Page editor);
                    // when a page is full the text continues on a new sheet with the same design.
                    Box(Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp))) {
                    AndroidView(
                        factory = { c ->
                            val sv = ScrollView(c)
                            sv.setBackgroundColor(0xFFEDEDED.toInt())
                            sv.isFillViewport = false
                            val sheets = PageSheets(c)
                            sheets.baseSize = Doc.baseSize
                            sheets.numbers = numbers
                            sheets.pn = pn
                            sheets.setPaper(Doc.paper, Doc.landscape)
                            sheets.bmpOf = { id -> PageDesigns.bitmap(ctx, id) }
                            sheets.setDesign(dBmp, dSpec)
                            sheets.setDesigns(designList)
                            val et = makeBlankEditor(
                                c,
                                onChange = { touch() },
                                onSel = { refreshState() },
                                schedule = { holder.sheets?.schedule() }
                            )
                            sheets.et = et
                            holder.et = et
                            holder.main = et
                            holder.sheets = sheets
                            sheets.addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                            sv.addView(sheets, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                            sv
                        },
                        update = { _ ->
                            holder.et?.let { applyDir(it) }
                            holder.sheets?.let { it.numbers = numbers; it.pn = pn; it.setDesign(dBmp, dSpec); it.setDesigns(designList); it.invalidate() }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    FloatingActionButton(
                        onClick = { addMode = true; showDesign = true },
                        modifier = Modifier.align(Alignment.BottomEnd).padding(14.dp).size(50.dp),
                        containerColor = Blue, contentColor = Color.White
                    ) { Icon(Icons.Filled.Add, "Add design page") }
                    }
                } else {
                    Box(
                        Modifier.fillMaxWidth().weight(1f).clip(RoundedCornerShape(12.dp)).background(if (design != 0) Color(0xFFE9EEF7) else Color.White)
                            .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp))
                    ) {
                        AndroidView(
                            factory = { c ->
                                makeEditor(
                                    c, Doc.text, "یہاں لکھیں / Start writing…", Doc.baseSize, Doc.font,
                                    { touch() }, { holder.et = it; refreshState() }, { refreshState() }
                                ).also { holder.main = it; holder.et = it; holder.sheets = null }
                            },
                            update = { et -> applyDir(et) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
            // ───── bottom tools
            if (urdu) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(
                        onClick = { showTpl = true }, modifier = Modifier.weight(1.6f).height(44.dp), contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDCEBFF), contentColor = Blue)
                    ) {
                        Icon(Icons.Filled.Description, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp))
                        Text("Insert Template", fontSize = 11.sp, maxLines = 1, fontWeight = FontWeight.Bold)
                    }
                    Button(
                        onClick = { sync(); nav.navigate("save") }, modifier = Modifier.weight(1f).height(44.dp), contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Blue)
                    ) { Icon(Icons.Filled.Save, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Save", fontSize = 12.sp) }
                    Button(
                        onClick = { shareNow() }, modifier = Modifier.weight(1f).height(44.dp), contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF16A34A))
                    ) { Icon(Icons.Filled.Share, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Share", fontSize = 12.sp) }
                    Button(
                        onClick = { quick(DocKind.PDF)?.let { toast(ctx, "PDF بن گئی / PDF created"); Actions.open(ctx, it) } },
                        modifier = Modifier.weight(1f).height(44.dp), contentPadding = PaddingValues(4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935))
                    ) { Icon(Icons.Filled.PictureAsPdf, null, modifier = Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("PDF", fontSize = 12.sp) }
                }
            } else {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(Color.White)
                        .border(1.dp, Color(0xFFD5E0F2), RoundedCornerShape(12.dp)).padding(horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.weight(1.15f)) {
                        ToolBtn(Icons.Filled.Subject, "Paragraph", Modifier.fillMaxWidth(), labelSize = 9) { menu = "para" }
                        DropdownMenu(expanded = menu == "para", onDismissRequest = { menu = "" }) {
                            DropdownMenuItem(text = { Text("Normal / عام") }, onClick = { menu = ""; para { Rich.heading(it, 0) } })
                            DropdownMenuItem(text = { Text("Heading 1 / عنوان") }, onClick = { menu = ""; para { Rich.heading(it, 1) } })
                            DropdownMenuItem(text = { Text("Heading 2 / ذیلی عنوان") }, onClick = { menu = ""; para { Rich.heading(it, 2) } })
                        }
                    }
                    ToolBtn(Icons.Filled.FormatAlignLeft, "Align Left", Modifier.weight(1.15f), alignNow == 0, labelSize = 9) { alignNow = 0; para { Rich.align(it, 0) } }
                    ToolBtn(Icons.Filled.FormatAlignCenter, "Center", Modifier.weight(1f), alignNow == 1, labelSize = 9) { alignNow = 1; para { Rich.align(it, 1) } }
                    ToolBtn(Icons.Filled.FormatAlignRight, "Align Right", Modifier.weight(1.2f), alignNow == 2, labelSize = 9) { alignNow = 2; para { Rich.align(it, 2) } }
                    ToolBtn(Icons.Filled.FormatAlignJustify, "Justify", Modifier.weight(1f), justify, labelSize = 9) { justify = !justify; touch() }
                    VDiv()
                    ToolBtn(Icons.Filled.FormatListBulleted, "Bullets", Modifier.weight(1f), labelSize = 9) { para { Rich.list(it, false) } }
                    ToolBtn(Icons.Filled.FormatListNumbered, "Numbering", Modifier.weight(1.2f), labelSize = 9) { para { Rich.list(it, true) } }
                }
            }
        }
    }
    if (showPn) PageNumberDialog(
        pn,
        onOk = { c -> pn = c; Doc.pn = c; numbers = true; Doc.pageNumbers = true; showPn = false; touch() },
        onCancel = { showPn = false }
    )
    if (showTable) TablePickerDialog(
        tRows, tCols, tHeader, tStyle,
        onCancel = { showTable = false },
        onOk = { r, c, h, st -> tRows = r; tCols = c; tHeader = h; tStyle = st; showTable = false; insertTable() }
    )
    if (showDesign) DesignPickerDialog(
        current = design, addMode = addMode,
        onPick = { id -> showDesign = false; val add = addMode; addMode = false; if (add) addDesignPage(id) else setDesign(id) },
        onDismiss = { showDesign = false; addMode = false }
    )
    if (showTpl) AlertDialog(
        onDismissRequest = { showTpl = false },
        title = { Text("Insert Template / ٹیمپلیٹ") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                (listOf(Fatiha) + Templates).forEach { t ->
                    TextButton(onClick = { showTpl = false; insertTemplate(t) }, modifier = Modifier.fillMaxWidth()) {
                        Icon(t.icon, null, tint = t.color)
                        Spacer(Modifier.width(10.dp))
                        Text("${t.en}  —  ${t.ur}", modifier = Modifier.weight(1f))
                    }
                }
            }
        },
        confirmButton = {}, dismissButton = { TextButton(onClick = { showTpl = false }) { Text("Cancel") } }
    )
    if (showClear) AlertDialog(
        onDismissRequest = { showClear = false },
        title = { Text("Clear all? / سب مٹائیں؟") },
        text = { Text("تمام متن ہٹا دیا جائے گا۔ / All text will be removed.") },
        confirmButton = {
            TextButton(onClick = {
                showClear = false
                holder.main?.text?.clear()
                holder.tr?.text?.clear()
                touch()
            }) { Text("Clear", color = Color(0xFFD32F2F)) }
        },
        dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
    )
    if (showExit) AlertDialog(
        onDismissRequest = { showExit = false },
        title = { Text("Save? / محفوظ کریں؟") },
        text = { Text("آپ کی تبدیلیاں محفوظ نہیں ہوئیں۔ / You have unsaved changes.") },
        confirmButton = { TextButton(onClick = { showExit = false; sync(); nav.navigate("save") }) { Text("Save") } },
        dismissButton = {
            Row {
                TextButton(onClick = { showExit = false; dirty = false; Doc.dirty = false; nav.popBackStack() }) { Text("Discard", color = Color(0xFFD32F2F)) }
                TextButton(onClick = { showExit = false }) { Text("Cancel") }
            }
        }
    )
}

// ───────────────────────── SAVE SCREEN ─────────────────────────
@Composable
fun InfoRow(icon: ImageVector, text: String, color: Color = Color(0xFF0A2A66)) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = Blue, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(8.dp))
        Text(text, fontSize = 13.sp, color = color, maxLines = 1)
    }
}

@Composable
fun SaveScreen(nav: NavController) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(Doc.name.ifBlank { if (Doc.rtl) "Urdu_Document" else "Document" }) }
    var kind by remember { mutableStateOf(if (Doc.kind == DocKind.IMAGE) DocKind.WORD else Doc.kind) }
    var cloud by remember { mutableStateOf(false) }
    var saveWhere by remember { mutableStateOf(PublicSave.where(ctx)) }
    val treeL = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u ->
        if (u != null) {
            try {
                ctx.contentResolver.takePersistableUriPermission(u, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                PublicSave.setTree(ctx, u)
                saveWhere = PublicSave.where(ctx)
            } catch (_: Exception) { toast(ctx, "یہ فولڈر استعمال نہیں ہو سکا / Could not use this folder") }
        }
    }
    var lastFile by remember { mutableStateOf<File?>(null) }
    var sizeText by remember { mutableStateOf("…") }
    var menuOpen by remember { mutableStateOf(false) }
    val preview = remember { Render.page(Doc.combined(), Doc.baseSize, Doc.font, Doc.rtl, Doc.justify, PageDesigns.bitmap(ctx, Doc.pageDesign), PageDesigns.spec(Doc.pageDesign), Doc.pageNumbers, Doc.paper, Doc.landscape, Doc.mar, Doc.pn).asImageBitmap() }
    val nowText = remember { fmtDate(System.currentTimeMillis()) }
    LaunchedEffect(kind) {
        val k = kind
        sizeText = "…"
        sizeText = withContext(Dispatchers.IO) {
            try {
                val t = File(ctx.cacheDir, "size_probe.tmp")
                Doc.write(ctx, k, t)
                val l = t.length()
                t.delete()
                fmtSize(l)
            } catch (e: Exception) { "—" }
        }
    }
    val mime = when (kind) {
        DocKind.WORD -> "application/vnd.openxmlformats-officedocument.wordprocessingml.document"
        DocKind.PDF -> "application/pdf"
        DocKind.TEXT -> "text/plain"
        DocKind.IMAGE -> "image/jpeg"
    }
    val cloudL = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument(mime)) { u ->
        val f = lastFile
        if (u != null && f != null) {
            try {
                ctx.contentResolver.openOutputStream(u)?.use { o -> f.inputStream().use { it.copyTo(o) } }
                toast(ctx, "کاپی محفوظ ہو گئی / Copy saved")
            } catch (_: Exception) { toast(ctx, "کاپی محفوظ نہیں ہوئی / Copy failed") }
        }
        nav.popBackStack()
    }
    fun doSave(): File? = try {
        val f = Doc.saveTo(ctx, kind, name)
        if (kind == DocKind.WORD || kind == DocKind.TEXT) Doc.kind = kind
        Doc.dirty = false
        Prefs.add(ctx, "edited", f.name)
        lastFile = f
        f
    } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed"); null }
    fun saveAndClose(share: Boolean) {
        val f = doSave() ?: return
        toast(ctx, "محفوظ ہو گیا / Saved: ${f.name}\n${PublicSave.note(ctx)}")
        if (share) Actions.share(ctx, f)
        if (cloud) cloudL.launch(f.name) else if (!share) nav.popBackStack()
    }
    fun previewDoc() {
        try {
            val t = File(ctx.cacheDir, "preview.pdf")
            Doc.write(ctx, DocKind.PDF, t)
            Actions.open(ctx, t)
        } catch (_: Exception) { toast(ctx, "Preview failed") }
    }
    val ext = Doc.extOf(kind)
    val types = listOf(
        TileData("Word", "(.docx)", Color(0xFF1E5CD6), Color(0xFFE8F0FF), letter = "W", selected = kind == DocKind.WORD) { kind = DocKind.WORD },
        TileData("PDF", "(.pdf)", Color(0xFFE53935), Color(0xFFFFEEEE), icon = Icons.Filled.PictureAsPdf, selected = kind == DocKind.PDF) { kind = DocKind.PDF },
        TileData("TXT", "(.txt)", Color(0xFF16A34A), Color(0xFFE3F8EC), letter = "T", selected = kind == DocKind.TEXT) { kind = DocKind.TEXT },
        TileData("Image", "(.jpg)", Color(0xFF7C4DFF), Color(0xFFEFE9FF), icon = Icons.Filled.Image, selected = kind == DocKind.IMAGE) { kind = DocKind.IMAGE }
    )
    Scaffold(
        containerColor = Bg,
        topBar = {
            AppHeader("آسان طریقے سے اپنی دستاویزات محفوظ کریں", onBack = { nav.popBackStack() }) {
                Column(
                    Modifier.clip(RoundedCornerShape(8.dp)).clickable { saveAndClose(false) }.padding(horizontal = 8.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) { Icon(Icons.Filled.Save, null, tint = Color.White); Text("Save", color = Color.White, fontSize = 11.sp) }
                Box {
                    IconButton(onClick = { menuOpen = true }) { Icon(Icons.Filled.MoreVert, null, tint = Color.White) }
                    DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                        DropdownMenuItem(text = { Text("Preview / پری ویو") }, onClick = { menuOpen = false; previewDoc() })
                        DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menuOpen = false; saveAndClose(true) })
                        DropdownMenuItem(text = { Text("My Documents / میری فائلیں") }, onClick = { menuOpen = false; nav.navigate("docs/browse") })
                        DropdownMenuItem(text = { Text("Back / واپس") }, onClick = { menuOpen = false; nav.popBackStack() })
                    }
                }
            }
        }
    ) { pad ->
        Column(Modifier.padding(pad).verticalScroll(rememberScrollState()).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFDCEBFF))) {
                Row(Modifier.padding(12.dp)) {
                    Image(
                        preview, null,
                        Modifier.width(112.dp).height(150.dp).clip(RoundedCornerShape(8.dp)).background(Color.White)
                            .border(1.dp, Color(0xFFBFD3F2), RoundedCornerShape(8.dp)),
                        contentScale = ContentScale.Crop
                    )
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                        Text(if (Doc.rtl) "Urdu & Arabic Document" else "Document", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF0A2A66))
                        Text(
                            "✓ Ready to Save", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold,
                            modifier = Modifier.background(Color(0xFF16A34A), RoundedCornerShape(8.dp)).padding(horizontal = 8.dp, vertical = 2.dp)
                        )
                        InfoRow(Icons.Filled.Description, "$name.$ext")
                        InfoRow(Icons.Filled.CalendarMonth, nowText)
                        InfoRow(Icons.Filled.InsertDriveFile, sizeText)
                        InfoRow(Icons.Filled.Folder, saveWhere)
                        Row(
                            Modifier.align(Alignment.End).clip(RoundedCornerShape(20.dp)).background(Color(0xFFD6E6FF))
                                .clickable { previewDoc() }.padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Filled.Visibility, null, tint = Blue, modifier = Modifier.size(20.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("Preview", color = Blue, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
            Text("File Name", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF0A2A66))
            OutlinedTextField(
                value = name, onValueChange = { name = it }, singleLine = true,
                modifier = Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(12.dp)), shape = RoundedCornerShape(12.dp),
                leadingIcon = { Icon(Icons.Filled.Description, null, tint = Blue) },
                trailingIcon = { Row(verticalAlignment = Alignment.CenterVertically) { Text(".$ext", color = Color.Gray); IconButton(onClick = { name = "" }) { Icon(Icons.Filled.Close, null) } } }
            )
            Text("Save As", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF0A2A66))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                types.forEach { t -> Tile(t, Modifier.weight(1f).height(104.dp)) }
            }
            Text("Save Location", fontWeight = FontWeight.ExtraBold, fontSize = 16.sp, color = Color(0xFF0A2A66))
            Card(
                onClick = { nav.navigate("docs/browse") }, modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFD5E0F2))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Folder, null, tint = Blue, modifier = Modifier.size(36.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("My Documents", fontWeight = FontWeight.Bold)
                        Text(Store.dir(ctx).absolutePath, fontSize = 11.sp, color = Color.Gray)
                    }
                    Icon(Icons.Filled.ChevronRight, null)
                }
            }
            Card(
                Modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = Color.White), border = BorderStroke(1.dp, Color(0xFFD5E0F2))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Security, null, tint = Blue, modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Also Save to Cloud", fontWeight = FontWeight.Bold)
                        Text("Keep your files safe online (Google Drive / any folder)", fontSize = 12.sp, color = Color.Gray)
                    }
                    Switch(checked = cloud, onCheckedChange = { cloud = it })
                }
            }
            Card(
                Modifier.fillMaxWidth().clickable { treeL.launch(null) }, shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1D6))
            ) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Filled.Folder, null, tint = Color(0xFFF59E0B), modifier = Modifier.size(32.dp))
                    Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Save Folder / محفوظ کرنے کا فولڈر", fontWeight = FontWeight.Bold)
                        Text(saveWhere, fontSize = 12.sp, color = Color.Gray)
                    }
                    Text("Change", color = Blue, fontWeight = FontWeight.Bold)
                }
            }
            Button(
                onClick = { saveAndClose(false) }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Blue)
            ) { Icon(Icons.Filled.Save, null); Spacer(Modifier.width(8.dp)); Text("Save Document", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
            OutlinedButton(
                onClick = { saveAndClose(true) }, modifier = Modifier.fillMaxWidth().height(56.dp), shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.5.dp, Blue)
            ) {
                Icon(Icons.Filled.Share, null); Spacer(Modifier.width(8.dp)); Text("Share Document", fontWeight = FontWeight.Bold, fontSize = 17.sp)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
