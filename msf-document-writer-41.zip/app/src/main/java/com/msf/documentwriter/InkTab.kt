package com.msf.documentwriter

import android.content.Context
import android.graphics.Canvas as ACanvas
import android.graphics.Paint as APaint
import android.graphics.Path as APath
import android.view.MotionEvent
import android.view.View
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.TouchApp
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** One pen / highlighter stroke. Points are kept as fractions of the page, so they follow the page size and go into the PDF. */
class InkStroke(val page: Int, val pts: FloatArray, val color: Int, val width: Float, val hi: Boolean)

object InkStore {
    val strokes = ArrayList<InkStroke>()
    var on = false
    var finger = true
    var tool = 0                 // 0 pencil, 1 highlighter, 2 eraser
    var color = 0xFF000000.toInt()
    var widthIdx = 0
    var view: View? = null

    val colors = intArrayOf(0xFFFF9800.toInt(), 0xFFFF0000.toInt(), 0xFFFFEB00.toInt(), 0xFF2979FF.toInt(), 0xFF000000.toInt())
    private val widths = floatArrayOf(0.0022f, 0.0045f, 0.008f, 0.0125f)   // fraction of the page width
    fun width(): Float = widths[widthIdx.coerceIn(0, 3)] * (if (tool == 1) 4f else 1f)

    fun clear() { strokes.clear(); refresh() }
    fun refresh() { view?.invalidate() }

    private val p = APaint(APaint.ANTI_ALIAS_FLAG).apply { style = APaint.Style.STROKE; strokeJoin = APaint.Join.ROUND }

    /** Draws the strokes. [only] >= 0: just that page, with the page's top-left at (0,0) (PDF). Otherwise all pages stacked with [gap]. */
    fun draw(c: ACanvas, w: Float, h: Float, gap: Float, only: Int = -1, extra: InkStroke? = null) {
        val all = if (extra != null) strokes + extra else strokes
        for (s in all) {
            if (only >= 0 && s.page != only) continue
            val oy = if (only >= 0) 0f else s.page * (h + gap)
            p.color = s.color
            p.alpha = if (s.hi) 90 else 255
            p.strokeWidth = s.width * w
            p.strokeCap = if (s.hi) APaint.Cap.SQUARE else APaint.Cap.ROUND
            val path = APath()
            val n = s.pts.size / 2
            if (n == 0) continue
            path.moveTo(s.pts[0] * w, oy + s.pts[1] * h)
            if (n == 1) path.lineTo(s.pts[0] * w + 0.1f, oy + s.pts[1] * h)
            for (i in 1 until n) path.lineTo(s.pts[2 * i] * w, oy + s.pts[2 * i + 1] * h)
            c.drawPath(path, p)
        }
    }
}

/** Transparent layer over the pages: draws the ink and, when ink is on, takes the pen / finger touches. */
class InkView(c: Context, private val sh: PageSheets) : View(c) {
    private val gap = Math.max(4, Math.round(6 * resources.displayMetrics.density)).toFloat()
    private var cur: ArrayList<Float>? = null
    private var curPage = 0

    init { InkStore.view = this }

    private fun ph(): Float = width.toFloat() * sh.pageH / sh.pageW

    override fun onDraw(canvas: ACanvas) {
        val w = width.toFloat()
        if (w <= 0f) return
        val live = cur?.let { if (InkStore.tool == 2 || it.isEmpty()) null else InkStroke(curPage, it.toFloatArray(), InkStore.color, InkStore.width(), InkStore.tool == 1) }
        InkStore.draw(canvas, w, ph(), gap, -1, live)
    }

    private fun erase(x: Float, y: Float) {
        val w = width.toFloat(); val h = ph()
        val r = 0.03f * w
        val it = InkStore.strokes.iterator()
        var hit = false
        while (it.hasNext()) {
            val s = it.next()
            val oy = s.page * (h + gap)
            var near = false
            var i = 0
            while (i + 1 < s.pts.size) {
                val dx = s.pts[i] * w - x; val dy = oy + s.pts[i + 1] * h - y
                if (dx * dx + dy * dy < r * r) { near = true; break }
                i += 2
            }
            if (near) { it.remove(); hit = true }
        }
        if (hit) { Doc.dirty = true; invalidate() }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (!InkStore.on) return false
        val finger = e.getToolType(0) == MotionEvent.TOOL_TYPE_FINGER
        if (cur == null && finger && !InkStore.finger && InkStore.tool != 2 && e.actionMasked == MotionEvent.ACTION_DOWN) return false
        val w = width.toFloat()
        if (w <= 0f) return false
        val h = ph()
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                if (InkStore.tool == 2) { cur = ArrayList(); erase(e.x, e.y); return true }
                curPage = (e.y / (h + gap)).toInt().coerceIn(0, Math.max(0, sh.pages - 1))
                val l = ArrayList<Float>()
                l.add((e.x / w).coerceIn(0f, 1f)); l.add(((e.y - curPage * (h + gap)) / h).coerceIn(0f, 1f))
                cur = l
                invalidate()
                return true
            }
            MotionEvent.ACTION_MOVE -> {
                val l = cur ?: return false
                if (InkStore.tool == 2) { erase(e.x, e.y); return true }
                for (i in 0 until e.historySize) { l.add((e.getHistoricalX(i) / w).coerceIn(0f, 1f)); l.add(((e.getHistoricalY(i) - curPage * (h + gap)) / h).coerceIn(0f, 1f)) }
                l.add((e.x / w).coerceIn(0f, 1f)); l.add(((e.y - curPage * (h + gap)) / h).coerceIn(0f, 1f))
                invalidate()
                return true
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val l = cur
                cur = null
                if (l != null && InkStore.tool != 2 && l.size >= 2) {
                    InkStore.strokes.add(InkStroke(curPage, l.toFloatArray(), InkStore.color, InkStore.width(), InkStore.tool == 1))
                    Doc.dirty = true
                }
                invalidate()
                return true
            }
        }
        return true
    }

    override fun onDetachedFromWindow() {
        super.onDetachedFromWindow()
        if (InkStore.view === this) InkStore.view = null
    }
}

@Composable
private fun ToolIcon(kind: Int) {
    Canvas(Modifier.size(width = 34.dp, height = 62.dp)) {
        val w = size.width; val h = size.height
        fun rect(color: Color, l: Float, t: Float, r: Float, b: Float) = drawRect(color, Offset(l, t), androidx.compose.ui.geometry.Size(r - l, b - t))
        when (kind) {
            0 -> {
                val tip = Path().apply { moveTo(w * 0.5f, 0f); lineTo(w * 0.15f, h * 0.35f); lineTo(w * 0.85f, h * 0.35f); close() }
                drawPath(tip, Color(0xFF8E8E8E))
                rect(Color(0xFFB5683A), w * 0.15f, h * 0.35f, w * 0.85f, h)
                rect(Color(0xFF8A4B27), w * 0.5f, h * 0.35f, w * 0.85f, h)
            }
            1 -> {
                rect(Color(0xFFE8E8E8), w * 0.2f, 0f, w * 0.8f, h * 0.25f)
                rect(Color(0xFFFFD600), w * 0.1f, h * 0.25f, w * 0.9f, h)
            }
            else -> {
                rect(Color(0xFFF2F2F2), w * 0.05f, h * 0.1f, w * 0.95f, h * 0.4f)
                rect(Color(0xFF26A69A), w * 0.05f, h * 0.4f, w * 0.95f, h)
            }
        }
    }
}

@Composable
fun PenPanel() {
    var tick by remember { mutableIntStateOf(0) }
    tick.let { }
    fun upd() { tick++; InkStore.refresh() }
    Column(Modifier.fillMaxWidth()) {
        SwitchRow(Icons.Outlined.Edit, if (InkStore.on) "Turn Ink Off / قلم بند کریں" else "Turn Ink On / قلم چالو کریں", InkStore.on) { InkStore.on = it; upd() }
        Box(Modifier.fillMaxWidth().padding(start = 20.dp).height(1.dp).background(Color(0xFF2E2E2E)))
        SwitchRow(Icons.Outlined.TouchApp, "Use Finger / انگلی سے لکھیں", InkStore.finger) { InkStore.finger = it; upd() }
        Band()
        Box(Modifier.padding(14.dp).fillMaxWidth().border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp)).padding(vertical = 14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.Bottom) {
                for (k in 0..2) {
                    Column(Modifier.clickable { InkStore.tool = k; if (k == 1 && InkStore.color == 0xFF000000.toInt()) InkStore.color = InkStore.colors[2]; upd() }, horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (InkStore.tool == k) "✓" else " ", color = Color(0xFFBBBBBB), fontSize = 16.sp)
                        ToolIcon(k)
                    }
                }
            }
        }
        Band()
        Box(Modifier.padding(14.dp).fillMaxWidth().border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp)).padding(vertical = 18.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                InkStore.colors.forEach { c ->
                    Box(Modifier.size(38.dp).background(Color(c), CircleShape).clickable { InkStore.color = c; if (InkStore.tool == 2) InkStore.tool = 0; upd() }, contentAlignment = Alignment.Center) {
                        if (InkStore.color == c) Text("✓", color = if (c == 0xFF000000.toInt()) Color.White else Color.Black, fontSize = 18.sp)
                    }
                }
            }
        }
        Band()
        Box(Modifier.padding(14.dp).fillMaxWidth().border(1.dp, Color(0xFF444444), RoundedCornerShape(12.dp)).padding(vertical = 20.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                for (i in 0..3) {
                    Column(Modifier.clickable { InkStore.widthIdx = i; upd() }.padding(horizontal = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(if (InkStore.widthIdx == i) "✓" else " ", color = Color(0xFF4A8BEF), fontSize = 14.sp)
                        Box(Modifier.width(62.dp).height((1 + i).dp).background(if (InkStore.widthIdx == i) Color(0xFF4A8BEF) else Color(0xFF8E8E8E)))
                    }
                }
            }
        }
        Band()
        val ctx = androidx.compose.ui.platform.LocalContext.current
        Text(
            "Clear all ink / سارا قلم مٹائیں", color = Color(0xFFEF5350), fontSize = 18.sp,
            modifier = Modifier.fillMaxWidth().clickable { InkStore.clear(); Doc.dirty = true; toast(ctx, "مٹ گیا / Cleared") }.padding(horizontal = 20.dp, vertical = 16.dp)
        )
        Text(
            "قلم کی لکھائی PDF اور Image میں آتی ہے، Word میں نہیں۔\nInk is saved in PDF / Image, not in Word. Turn ink off to scroll and type.",
            color = Color(0xFF8E8E8E), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 20.dp, vertical = 8.dp)
        )
        Spacer(Modifier.height(24.dp))
    }
}
