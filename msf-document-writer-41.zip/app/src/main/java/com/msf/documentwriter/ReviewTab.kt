package com.msf.documentwriter

import android.text.Editable
import android.text.Spannable
import android.text.TextWatcher
import android.text.style.BackgroundColorSpan
import android.widget.EditText
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CheckCircleOutline
import androidx.compose.material.icons.outlined.CancelPresentation
import androidx.compose.material.icons.outlined.Description
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.Share
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.Spellcheck
import androidx.compose.material.icons.outlined.StickyNote2
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Marks text written while "Revise Mode" is on. */
class ReviseSpan

object Review {
    var showComments = false
    var showChanges = false
    var revise = false
    var spell = true
    private var watcher: ReviseWatcher? = null
    private var watched: EditText? = null
    private const val RED = 0xFFD32F2F.toInt()
    private val NOTE = Regex("【تبصرہ[^】]*】")

    class ReviseWatcher : TextWatcher {
        private var s0 = 0
        private var c0 = 0
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { s0 = start; c0 = count }
        override fun afterTextChanged(e: Editable?) {
            if (e == null || c0 <= 0) return
            val a = s0.coerceIn(0, e.length)
            val b = (s0 + c0).coerceIn(a, e.length)
            c0 = 0
            if (b > a) {
                e.setSpan(ReviseSpan(), a, b, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE)
                if (Review.showChanges) Rich.color(e, a, b, 0xFFD32F2F.toInt())
            }
        }
    }

    fun applyRevise(on: Boolean) {
        revise = on
        val et = InsertBridge.et
        try { watched?.removeTextChangedListener(watcher) } catch (_: Throwable) {}
        watcher = null; watched = null
        if (on && et != null) { watcher = ReviseWatcher(); watched = et; et.addTextChangedListener(watcher) }
    }

    fun ranges(): List<IntRange> {
        val e = InsertBridge.et?.text ?: return emptyList()
        return e.getSpans(0, e.length, ReviseSpan::class.java).mapNotNull {
            val a = e.getSpanStart(it); val b = e.getSpanEnd(it)
            if (a in 0 until b) a until b else null
        }.sortedBy { it.first }
    }

    fun applyShowChanges(on: Boolean) {
        showChanges = on
        val e = InsertBridge.et?.text ?: return
        for (r in ranges()) Rich.color(e, r.first, r.last + 1, if (on) RED else null)
        InsertBridge.et?.invalidate()
    }

    fun accept() {
        val e = InsertBridge.et?.text ?: return
        for (sp in e.getSpans(0, e.length, ReviseSpan::class.java)) e.removeSpan(sp)
        Doc.dirty = true
    }

    fun reject(): Int {
        val e = InsertBridge.et?.text ?: return 0
        val rs = ranges()
        for (r in rs.reversed()) if (r.last + 1 <= e.length) e.delete(r.first, r.last + 1)
        for (sp in e.getSpans(0, e.length, ReviseSpan::class.java)) e.removeSpan(sp)
        Doc.dirty = true
        return rs.size
    }

    /** Comment notes: (range, text). */
    fun notes(): List<Pair<IntRange, String>> {
        val s = InsertBridge.et?.text?.toString() ?: return emptyList()
        return NOTE.findAll(s).map { Pair(it.range, it.value) }.toList()
    }

    fun applyShowComments(on: Boolean) {
        showComments = on
        val e = InsertBridge.et?.text ?: return
        for ((r, _) in notes()) Rich.highlight(e, r.first, r.last + 1, if (on) 0xFFFFF59D.toInt() else null)
        InsertBridge.et?.invalidate()
    }

    fun removeNotes(): Int {
        val e = InsertBridge.et?.text ?: return 0
        val n = notes()
        for ((r, _) in n.reversed()) e.delete(r.first, r.last + 1)
        Doc.dirty = true
        return n.size
    }

    fun applySpell(on: Boolean) {
        spell = on
        val et = InsertBridge.et ?: return
        val flag = android.text.InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        val cur = et.inputType
        et.inputType = if (on) cur and flag.inv() else cur or flag
    }

    fun userName(c: android.content.Context): String = Prefs.str(c, "user_name", "")

    /** Text of every highlighted passage, one per line. */
    fun highlights(): List<String> {
        val e = InsertBridge.et?.text ?: return emptyList()
        val out = ArrayList<String>()
        for (sp in e.getSpans(0, e.length, BackgroundColorSpan::class.java).sortedBy { e.getSpanStart(it) }) {
            val a = e.getSpanStart(sp); val b = e.getSpanEnd(sp)
            if (a < 0 || b <= a) continue
            val t = e.subSequence(a, b).toString().trim()
            if (t.isNotEmpty() && !t.startsWith("【تبصرہ")) out.add(t)
        }
        return out
    }
}

@Composable
private fun ActRow(icon: ImageVector, label: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 20.dp, vertical = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, label, tint = Color(0xFFD0D0D0), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(20.dp))
        Text(label, color = Color.White, fontSize = 18.sp, modifier = Modifier.weight(1f))
    }
    Box(Modifier.fillMaxWidth().padding(start = 68.dp).height(1.dp).background(Color(0xFF2E2E2E)))
}

@Composable
fun ReviewPanel() {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    tick.let { }
    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            BigAction(Icons.Outlined.Share, "Export Text Highlights", true, Modifier.weight(1f)) {
                val h = Review.highlights()
                if (h.isEmpty()) toast(ctx, "کوئی ہائی لائٹ نہیں ملی / No highlighted text found")
                else {
                    try {
                        val f = java.io.File(ctx.cacheDir, "highlights.txt")
                        f.writeText(h.joinToString("\n\n"))
                        Actions.share(ctx, f)
                    } catch (_: Throwable) { toast(ctx, "برآمد نہیں ہو سکا / Could not export") }
                }
            }
            BigAction(Icons.Outlined.CancelPresentation, "Remove All Comments", Review.notes().isNotEmpty(), Modifier.weight(1f)) {
                val n = Review.removeNotes(); toast(ctx, "$n تبصرے ہٹ گئے / comments removed"); tick++
            }
        }
        Band()
        SwitchRow(Icons.Outlined.StickyNote2, "Show Comments", Review.showComments) { on ->
            Review.applyShowComments(on); tick++
            if (on) { if (Review.notes().isEmpty()) toast(ctx, "کوئی تبصرہ نہیں / No comments yet") else dlg = "list" }
        }
        SwitchRow(Icons.Outlined.Description, "Show Changes", Review.showChanges) { Review.applyShowChanges(it); tick++ }
        ActRow(Icons.Outlined.FormatListBulleted, "Comments and Revisions List") { dlg = "list" }
        SwitchRow(Icons.Outlined.Edit, "Enter Revise Mode", Review.revise) {
            Review.applyRevise(it)
            if (it) toast(ctx, "اب جو لکھیں گے اس پر نشان لگے گا / Text you type now is marked as a change")
            tick++
        }
        ActRow(Icons.Outlined.CheckCircleOutline, "Accept All Changes") { Review.accept(); toast(ctx, "تبدیلیاں قبول / Changes accepted"); tick++ }
        ActRow(Icons.Outlined.CancelPresentation, "Reject All Changes") { val n = Review.reject(); toast(ctx, "$n تبدیلیاں رد / changes rejected"); tick++ }
        ActRow(Icons.Outlined.Person, "Modify User Name" + Review.userName(ctx).let { if (it.isBlank()) "" else "  ($it)" }) { dlg = "name" }
        Band()
        SwitchRow(Icons.Outlined.Spellcheck, "Spell Check", Review.spell) { Review.applySpell(it); tick++ }
        Spacer(Modifier.height(24.dp))
    }
    when (dlg) {
        "name" -> {
            var n by remember { mutableStateOf(Review.userName(ctx)) }
            AlertDialog(
                onDismissRequest = { dlg = "" },
                title = { Text("User Name / یوزر کا نام") },
                text = { OutlinedTextField(value = n, onValueChange = { n = it }, singleLine = true, label = { Text("Name / نام") }) },
                confirmButton = { TextButton(onClick = { Prefs.setStr(ctx, "user_name", n.trim()); dlg = ""; tick++ }) { Text("OK") } },
                dismissButton = { TextButton(onClick = { dlg = "" }) { Text("Cancel") } }
            )
        }
        "list" -> RevisionList { dlg = ""; tick++ }
    }
}

@Composable
private fun RevisionList(onClose: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    tick.let { }
    val et = InsertBridge.et
    val notes = Review.notes()
    val changes = Review.ranges()
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Comments & Revisions / تبصرے اور تبدیلیاں") },
        text = {
            if (notes.isEmpty() && changes.isEmpty()) Text("کچھ نہیں ملا۔\nNothing yet.")
            else Column(Modifier.verticalScroll(rememberScrollState())) {
                notes.forEach { (r, t) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("💬 " + t.trim('【', '】'), fontSize = 15.sp, maxLines = 3, modifier = Modifier.weight(1f).clickable { ViewOps.scrollTo(r.first); onClose() }.padding(vertical = 10.dp))
                        TextButton(onClick = { et?.text?.delete(r.first, r.last + 1); Doc.dirty = true; tick++ }) { Text("✕", color = Color(0xFFD32F2F)) }
                    }
                }
                changes.forEach { r ->
                    val t = et?.text?.subSequence(r.first, (r.last + 1).coerceAtMost(et.text.length))?.toString()?.take(80) ?: ""
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("✎ $t", fontSize = 15.sp, maxLines = 3, modifier = Modifier.weight(1f).clickable { ViewOps.scrollTo(r.first); onClose() }.padding(vertical = 10.dp))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
