package com.msf.documentwriter

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.ContextWrapper
import android.content.pm.ActivityInfo
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.graphics.Paint as APaint
import android.text.style.AbsoluteSizeSpan
import android.view.View
import android.widget.EditText
import android.widget.ScrollView
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Bookmarks
import androidx.compose.material.icons.outlined.BookmarkAdd
import androidx.compose.material.icons.outlined.ContentCopy
import androidx.compose.material.icons.outlined.ContentCut
import androidx.compose.material.icons.outlined.ContentPaste
import androidx.compose.material.icons.outlined.Dashboard
import androidx.compose.material.icons.outlined.FormatListBulleted
import androidx.compose.material.icons.outlined.Info
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Search
import androidx.compose.material.icons.outlined.Visibility
import androidx.compose.material.icons.outlined.WbSunny
import androidx.compose.material.icons.outlined.Bedtime
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** Reading settings of the View tab: page colour, night mode, eye protection, screen always on. */
object ViewFx {
    var bg: Int = 0xFFFFFFFF.toInt()
    var night = false
    var eye = false
    var keepOn = false

    fun apply(v: View?) {
        if (v == null) return
        try {
            v.keepScreenOn = keepOn
            val white = bg == 0xFFFFFFFF.toInt()
            if (white && !night && !eye) { v.setLayerType(View.LAYER_TYPE_NONE, null); return }
            val m = ColorMatrix()
            m.setScale(((bg shr 16) and 255) / 255f, ((bg shr 8) and 255) / 255f, (bg and 255) / 255f, 1f)
            if (eye) m.postConcat(ColorMatrix(floatArrayOf(1f, 0f, 0f, 0f, 0f, 0f, 0.92f, 0f, 0f, 0f, 0f, 0f, 0.7f, 0f, 0f, 0f, 0f, 0f, 1f, 0f)))
            if (night) m.postConcat(ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)))
            v.setLayerType(View.LAYER_TYPE_HARDWARE, APaint().apply { colorFilter = ColorMatrixColorFilter(m) })
        } catch (_: Throwable) {}
    }

    fun scroll(): View? {
        var v: View? = InsertBridge.et
        while (v != null && v !is ScrollView) v = v.parent as? View
        return v
    }

    fun refresh() { apply(scroll()) }
}

class Bookmark(val name: String, val pos: Int)

object BookmarkStore {
    val list = ArrayList<Bookmark>()
    fun clear() = list.clear()
}

object ViewOps {
    fun cursor(): Int { val et = InsertBridge.et ?: return 0; return InsertOps.pos(et) }

    fun scrollTo(off: Int) {
        val et = InsertBridge.et ?: return
        val len = et.text.length
        val o = off.coerceIn(0, len)
        et.requestFocus()
        et.setSelection(o)
        val l = et.layout ?: return
        var y = et.paddingTop + l.getLineTop(l.getLineForOffset(o))
        var v: View = et
        while (v !is ScrollView) {
            y += v.top
            v = (v.parent as? View) ?: return
        }
        (v as ScrollView).smoothScrollTo(0, (y - 140).coerceAtLeast(0))
    }

    fun pageCount(): Int = ((InsertBridge.et?.parent as? PageSheets)?.breakStarts?.size ?: 0) + 1

    fun pageStart(n: Int): Int {
        val et = InsertBridge.et ?: return 0
        val sh = et.parent as? PageSheets ?: return 0
        return if (n <= 1) 0 else (sh.breakStarts.getOrNull(n - 2) ?: et.text.length)
    }

    fun snippet(at: Int, n: Int = 34): String {
        val et = InsertBridge.et ?: return ""
        val t = et.text.toString()
        var a = at.coerceIn(0, t.length)
        while (a < t.length && (t[a].isWhitespace() || t[a] == PAGE_BREAK)) a++
        var e = a
        while (e < t.length && t[e] != '\n' && t[e] != PAGE_BREAK && e - a < n) e++
        return t.substring(a, e)
    }

    fun addBookmark(): String {
        val p = cursor()
        val sn = snippet(p, 30)
        val name = if (sn.isBlank()) "Bookmark ${BookmarkStore.list.size + 1}" else sn
        BookmarkStore.list.add(Bookmark(name, p))
        return name
    }

    fun gotoBookmark(b: Bookmark) {
        val et = InsertBridge.et ?: return
        val t = et.text.toString()
        var p = b.pos.coerceIn(0, t.length)
        if (!t.regionMatches(p, b.name, 0, b.name.length) && !b.name.startsWith("Bookmark ")) {
            val i = t.indexOf(b.name)
            if (i >= 0) p = i
        }
        scrollTo(p)
    }

    /** (offset, title) of the lines that look like headings. */
    fun headings(): List<Pair<Int, String>> {
        val et = InsertBridge.et ?: return emptyList()
        val t = et.text
        val s = t.toString()
        val out = ArrayList<Pair<Int, String>>()
        var ps = 0
        while (ps <= s.length) {
            val nl = s.indexOf('\n', ps)
            val pe = if (nl < 0) s.length else nl
            val line = s.substring(ps, pe).trim()
            if (line.isNotEmpty() && line.length <= 90 && line[0] != PAGE_BREAK) {
                var big = line.startsWith("#")
                if (!big && pe > ps) {
                    for (sp in t.getSpans(ps, pe, AbsoluteSizeSpan::class.java)) {
                        if (t.getSpanStart(sp) <= ps + 1 && sp.size > Doc.baseSize + 1) { big = true; break }
                    }
                }
                if (big) out.add(Pair(ps, line.trimStart('#', ' ')))
            }
            if (nl < 0) break
            ps = nl + 1
        }
        return out
    }

    fun hasSelection(): Boolean { val et = InsertBridge.et ?: return false; return et.selectionStart != et.selectionEnd }
    fun menu(id: Int) { InsertBridge.et?.onTextContextMenuItem(id); Doc.dirty = true }

    fun activity(c: Context): Activity? {
        var x: Context? = c
        while (x is ContextWrapper) { if (x is Activity) return x; x = x.baseContext }
        return null
    }
}

@Composable
fun SectionTitle(t: String) {
    Text(t, color = Color(0xFF8E8E8E), fontSize = 15.sp, modifier = Modifier.padding(start = 20.dp, top = 16.dp, bottom = 10.dp))
}

@Composable
fun Band() { Box(Modifier.fillMaxWidth().height(10.dp).background(Color(0xFF181818))) }

@Composable
fun BigAction(icon: ImageVector, label: String, enabled: Boolean = true, modifier: Modifier, onClick: () -> Unit) {
    val col = if (enabled) Color.White else Color(0xFF555555)
    Column(
        modifier.clickable(enabled = enabled) { onClick() }.padding(vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, label, tint = col, modifier = Modifier.size(28.dp))
        Spacer(Modifier.height(8.dp))
        Text(label, color = col, fontSize = 14.sp)
    }
}

@Composable
fun SwitchRow(icon: ImageVector, label: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().clickable { onChange(!on) }.padding(horizontal = 20.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, label, tint = Color(0xFFD0D0D0), modifier = Modifier.size(28.dp))
        Spacer(Modifier.width(20.dp))
        Text(label, color = Color.White, fontSize = 19.sp, modifier = Modifier.weight(1f))
        Switch(checked = on, onCheckedChange = onChange)
    }
}

private val MoreBg = listOf(
    0xFFFFFFFF, 0xFFF5F0DC, 0xFFE8F5E9, 0xFFFCE4EC, 0xFFEDE7F6, 0xFFFFF9C4, 0xFFD7CCC8, 0xFFB0BEC5, 0xFFCFD8DC, 0xFFC8E6C9
)

/** The View tab: Find & Replace, Word Count, reading settings, page colour, clipboard, bookmarks, page list, Lock Screen, page settings. */
@Composable
fun ViewPanel(items: List<Pair<String, () -> Unit>>) {
    val ctx = LocalContext.current
    var tick by remember { mutableIntStateOf(0) }
    var dlg by remember { mutableStateOf("") }
    var lock by remember { mutableStateOf(false) }
    tick.let { }
    val hasSel = ViewOps.hasSelection()

    Column(Modifier.fillMaxWidth()) {
        Row(Modifier.fillMaxWidth()) {
            BigAction(Icons.Outlined.Search, "Find & Replace", modifier = Modifier.weight(1f)) { dlg = "find" }
            BigAction(Icons.Outlined.Info, "Word Count", modifier = Modifier.weight(1f)) { dlg = "count" }
        }
        Band()
        SectionTitle("Reading Settings")
        SwitchRow(Icons.Outlined.WbSunny, "Screen Always On", ViewFx.keepOn) { ViewFx.keepOn = it; ViewFx.refresh(); tick++ }
        SwitchRow(Icons.Outlined.Bedtime, "Night Mode", ViewFx.night) { ViewFx.night = it; ViewFx.refresh(); tick++ }
        SwitchRow(Icons.Outlined.Visibility, "Eye Protection Mode", ViewFx.eye) { ViewFx.eye = it; ViewFx.refresh(); tick++ }
        Band()
        SectionTitle("Page Background")
        Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            listOf(0xFFFFFFFF, 0xFF808080, 0xFF99CCFF, 0xFFFFCC99).forEach { c ->
                val sel = ViewFx.bg == c.toInt()
                Box(
                    Modifier.weight(1f).height(52.dp).background(Color(c), RoundedCornerShape(6.dp))
                        .border(if (sel) 2.dp else 0.dp, if (sel) Color(0xFF4A8BEF) else Color.Transparent, RoundedCornerShape(6.dp))
                        .clickable { ViewFx.bg = c.toInt(); ViewFx.refresh(); tick++ },
                    contentAlignment = Alignment.Center
                ) { if (sel) Text("✓", color = Color(0xFF333333), fontSize = 18.sp) }
            }
            Box(
                Modifier.weight(1f).height(52.dp).border(1.dp, Color(0xFF555555), RoundedCornerShape(6.dp)).clickable { dlg = "bg" },
                contentAlignment = Alignment.Center
            ) { Text("•••", color = Color(0xFFAAAAAA), fontSize = 18.sp) }
        }
        Spacer(Modifier.height(14.dp))
        Band()
        Row(Modifier.fillMaxWidth()) {
            BigAction(Icons.Outlined.ContentCopy, "Copy", hasSel, Modifier.weight(1f)) { ViewOps.menu(android.R.id.copy); tick++ }
            BigAction(Icons.Outlined.ContentPaste, "Paste", true, Modifier.weight(1f)) {
                val cm = ctx.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                if (cm.hasPrimaryClip()) { ViewOps.menu(android.R.id.paste); tick++ } else toast(ctx, "کلپ بورڈ خالی ہے / Clipboard is empty")
            }
            BigAction(Icons.Outlined.ContentCut, "Cut", hasSel, Modifier.weight(1f)) { ViewOps.menu(android.R.id.cut); tick++ }
        }
        Band()
        Row(Modifier.fillMaxWidth()) {
            BigAction(Icons.Outlined.BookmarkAdd, "Add Bookmark", true, Modifier.weight(1f)) {
                val n = ViewOps.addBookmark(); toast(ctx, "بُک مارک شامل ہو گیا / Bookmark added: $n"); tick++
            }
            BigAction(Icons.Outlined.Bookmarks, "All Bookmarks", BookmarkStore.list.isNotEmpty(), Modifier.weight(1f)) { dlg = "bookmarks" }
            BigAction(Icons.Outlined.Dashboard, "Thumbnail", true, Modifier.weight(1f)) { dlg = "pages" }
            BigAction(Icons.Outlined.FormatListBulleted, "Content", true, Modifier.weight(1f)) { dlg = "content" }
        }
        Band()
        SwitchRow(Icons.Outlined.Lock, "Lock Screen", lock) { on ->
            lock = on
            ViewOps.activity(ctx)?.requestedOrientation = if (on) ActivityInfo.SCREEN_ORIENTATION_LOCKED else ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED
        }
        Band()
        SectionTitle("View")
        items.forEach { (label, act) ->
            Text(label, color = Color.White, fontSize = 18.sp, modifier = Modifier.fillMaxWidth().clickable { act() }.padding(horizontal = 20.dp, vertical = 16.dp))
            Box(Modifier.fillMaxWidth().padding(start = 20.dp).height(1.dp).background(Color(0xFF2E2E2E)))
        }
        Spacer(Modifier.height(24.dp))
    }

    when (dlg) {
        "find" -> FindReplaceDialog { dlg = "" }
        "count" -> WordCountDialog { dlg = "" }
        "bg" -> AlertDialog(
            onDismissRequest = { dlg = "" },
            title = { Text("Page Background / صفحے کا رنگ") },
            text = {
                Column {
                    MoreBg.chunked(5).forEach { r ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            r.forEach { c ->
                                Box(
                                    Modifier.weight(1f).height(44.dp).background(Color(c), RoundedCornerShape(6.dp))
                                        .border(1.dp, Color(0xFF888888), RoundedCornerShape(6.dp))
                                        .clickable { ViewFx.bg = c.toInt(); ViewFx.refresh(); dlg = "" }
                                )
                            }
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { dlg = "" }) { Text("Close") } }
        )
        "bookmarks" -> BookmarksDialog { dlg = "" }
        "pages" -> PageListDialog { dlg = "" }
        "content" -> ContentDialog { dlg = "" }
    }
}

@Composable
private fun PickList(title: String, empty: String, rows: List<Pair<String, () -> Unit>>, onClose: () -> Unit, extra: (@Composable (Int) -> Unit)? = null) {
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text(title) },
        text = {
            if (rows.isEmpty()) Text(empty)
            else Column(Modifier.verticalScroll(rememberScrollState())) {
                rows.forEachIndexed { i, (label, act) ->
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            label, fontSize = 16.sp, maxLines = 2,
                            modifier = Modifier.weight(1f).clickable { act(); onClose() }.padding(vertical = 12.dp)
                        )
                        extra?.invoke(i)
                    }
                    Box(Modifier.fillMaxWidth().height(1.dp).background(Color(0x33888888)))
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}

@Composable
private fun BookmarksDialog(onClose: () -> Unit) {
    var tick by remember { mutableIntStateOf(0) }
    tick.let { }
    val rows = BookmarkStore.list.map { b -> Pair(b.name, { ViewOps.gotoBookmark(b) }) }
    PickList("All Bookmarks / بُک مارکس", "کوئی بُک مارک نہیں / No bookmarks", rows, onClose) { i ->
        TextButton(onClick = { BookmarkStore.list.removeAt(i); tick++; if (BookmarkStore.list.isEmpty()) onClose() }) { Text("✕", color = Color(0xFFD32F2F)) }
    }
}

@Composable
private fun PageListDialog(onClose: () -> Unit) {
    val n = ViewOps.pageCount()
    val rows = (1..n).map { p ->
        val sn = ViewOps.snippet(ViewOps.pageStart(p), 40)
        Pair("Page $p   " + if (sn.isBlank()) "—" else sn, { ViewOps.scrollTo(ViewOps.pageStart(p)) })
    }
    PickList("Pages / صفحات", "—", rows, onClose)
}

@Composable
private fun ContentDialog(onClose: () -> Unit) {
    val h = ViewOps.headings()
    val rows = h.map { (off, t) -> Pair(t, { ViewOps.scrollTo(off) }) }
    PickList("Content / فہرست", "کوئی عنوان نہیں ملا۔ عنوان کو بڑے سائز میں یا # کے ساتھ لکھیں۔\nNo headings found. Write headings in a bigger size or start them with #.", rows, onClose)
}

@Composable
private fun WordCountDialog(onClose: () -> Unit) {
    val t = InsertBridge.et?.text?.toString()?.replace(PAGE_BREAK.toString(), "") ?: ""
    val words = t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }
    val noSp = t.count { !it.isWhitespace() }
    val paras = t.split('\n').count { it.isNotBlank() }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Word Count / الفاظ کی گنتی") },
        text = {
            Column {
                listOf(
                    "Words / الفاظ" to words, "Characters / حروف" to t.length, "Characters (no spaces)" to noSp,
                    "Paragraphs / پیراگراف" to paras, "Pages / صفحات" to ViewOps.pageCount()
                ).forEach { (k, v) ->
                    Row(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                        Text(k, modifier = Modifier.weight(1f)); Text("$v", color = Color(0xFF4A8BEF))
                    }
                }
            }
        },
        confirmButton = { TextButton(onClick = onClose) { Text("OK") } }
    )
}

@Composable
private fun FindReplaceDialog(onClose: () -> Unit) {
    val ctx = LocalContext.current
    var find by remember { mutableStateOf("") }
    var repl by remember { mutableStateOf("") }
    var info by remember { mutableStateOf("") }
    fun next(): Boolean {
        val et = InsertBridge.et ?: return false
        if (find.isEmpty()) return false
        val s = et.text.toString()
        var i = s.indexOf(find, maxOf(et.selectionStart, et.selectionEnd), ignoreCase = true)
        if (i < 0) i = s.indexOf(find, 0, ignoreCase = true)
        if (i < 0) { info = "نہیں ملا / Not found"; return false }
        ViewOps.scrollTo(i)
        et.setSelection(i, i + find.length)
        info = ""
        return true
    }
    AlertDialog(
        onDismissRequest = onClose,
        title = { Text("Find & Replace / تلاش اور تبدیلی") },
        text = {
            Column {
                OutlinedTextField(value = find, onValueChange = { find = it; info = "" }, label = { Text("Find / تلاش") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(8.dp))
                OutlinedTextField(value = repl, onValueChange = { repl = it }, label = { Text("Replace with / بدلیں") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                if (info.isNotEmpty()) Text(info, color = Color(0xFFD32F2F), fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = {
            Column(horizontalAlignment = Alignment.End) {
                Row {
                    TextButton(onClick = { next() }) { Text("Find next") }
                    TextButton(onClick = {
                        val et = InsertBridge.et
                        if (et != null && find.isNotEmpty()) {
                            val a = minOf(et.selectionStart, et.selectionEnd); val b = maxOf(et.selectionStart, et.selectionEnd)
                            if (b - a == find.length && et.text.substring(a, b).equals(find, ignoreCase = true)) {
                                et.text.replace(a, b, repl); Doc.dirty = true
                                et.setSelection((a + repl.length).coerceAtMost(et.text.length))
                            }
                            next()
                        }
                    }) { Text("Replace") }
                }
                TextButton(onClick = {
                    val et = InsertBridge.et
                    if (et != null && find.isNotEmpty()) {
                        val s = et.text.toString()
                        val hits = ArrayList<Int>()
                        var i = s.indexOf(find, 0, ignoreCase = true)
                        while (i >= 0) { hits.add(i); i = s.indexOf(find, i + find.length, ignoreCase = true) }
                        for (k in hits.indices.reversed()) et.text.replace(hits[k], hits[k] + find.length, repl)
                        if (hits.isNotEmpty()) Doc.dirty = true
                        toast(ctx, "${hits.size} تبدیلیاں / replaced")
                    }
                }) { Text("Replace all / سب بدلیں") }
            }
        },
        dismissButton = { TextButton(onClick = onClose) { Text("Close") } }
    )
}
