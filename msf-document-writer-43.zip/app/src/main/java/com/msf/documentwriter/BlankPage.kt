package com.msf.documentwriter

import android.app.Activity
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Typeface
import android.os.Build
import android.text.Editable
import android.text.InputType
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.TextWatcher
import android.text.style.AbsoluteSizeSpan
import android.text.style.ForegroundColorSpan
import android.text.style.LineHeightSpan
import android.text.style.ReplacementSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.text.style.UpdateLayout
import android.util.TypedValue
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Close
import androidx.compose.material.icons.outlined.CropFree
import androidx.compose.material.icons.outlined.FormatAlignLeft
import androidx.compose.material.icons.outlined.GridView
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Keyboard
import androidx.compose.material.icons.outlined.Redo
import androidx.compose.material.icons.outlined.Save
import androidx.compose.material.icons.outlined.Undo
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.navigation.NavController
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

private val BarDark = Color(0xFF151515)
private val BarGrey = Color(0xFF2B2B2B)
private val IconGrey = Color(0xFFBDBDBD)

/** Small paper (A5, A6) gets narrower margins so the writing area stays usable. */
private fun blankMargin(paper: Int): Float = if (Paper.get(paper).wPt < 450) 40f else 72f

/** The page-break character is shown as nothing: the next page itself is the visual cue. */
class PageMarkSpan : ReplacementSpan() {
    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = 0
    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {}
}

/**
 * Pushes the line that starts at this span's first character down by [d] pixels, so that the text jumps over
 * the bottom margin, the gap and the top margin of the next page sheet.
 */
class PagePushSpan(val d: Int, private val mult: Float) : LineHeightSpan, UpdateLayout {
    override fun chooseHeight(text: CharSequence, start: Int, end: Int, spanstartv: Int, lineHeight: Int, fm: Paint.FontMetricsInt) {
        if (text is Spanned && text.getSpanStart(this) == start) {
            // the editor multiplies the line height by [mult] afterwards, so ask for d / mult here
            val e = (d / mult).roundToInt()
            fm.ascent -= e
            fm.top -= e
        }
    }
}

/** Re-draws the invisible page-break markers and table-row backgrounds of the Blank Page editor. */
fun decorateBlank(e: Editable) {
    for (s in e.getSpans(0, e.length, PageBreakSpan::class.java)) e.removeSpan(s)
    for (s in e.getSpans(0, e.length, PageMarkSpan::class.java)) e.removeSpan(s)
    for (s in e.getSpans(0, e.length, TableRowSpan::class.java)) e.removeSpan(s)
    val str = e.toString()
    for (i in str.indices) {
        if (str[i] == PAGE_BREAK) e.setSpan(PageMarkSpan(), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }
    var ps = 0
    val deco = TableDeco(e)
    while (ps <= str.length) {
        val nl = str.indexOf('\n', ps)
        val pe = if (nl < 0) str.length else nl
        deco.line(ps, pe, str.substring(ps, pe))
        if (nl < 0) break
        ps = nl + 1
    }
}

fun cleanCopy(src: CharSequence): SpannableStringBuilder {
    val b = SpannableStringBuilder(src)
    for (s in b.getSpans(0, b.length, PagePushSpan::class.java)) b.removeSpan(s)
    for (s in b.getSpans(0, b.length, PageMarkSpan::class.java)) b.removeSpan(s)
    for (s in b.getSpans(0, b.length, PipeSpan::class.java)) b.removeSpan(s)
    for (s in b.getSpans(0, b.length, SepSpan::class.java)) b.removeSpan(s)
    return b
}

private fun countChars(t: CharSequence): Int {
    var n = 0
    for (ch in t) if (!ch.isWhitespace() && ch != PAGE_BREAK) n++
    return n
}

/**
 * The paper: a column of white page sheets (with corner marks at the margins) and the editor on top of them.
 * Text size and margins are scaled so that one point of the PDF is [pgScale] pixels here; text that would run into the
 * bottom margin is pushed to the next sheet, so what you see is the page layout of the PDF / Word file.
 */
class PageSheets(c: Context) : FrameLayout(c) {
    var pageW = 612
    var pageH = 792
    var mar = Mar.all(72f)
    var numbers = true
    var pn = PageNumCfg()
    var border = false
    var baseSize = 16
    var pages = 2
        private set
    var contentPages = 1
        private set
    var pgScale = 1f
        private set(v) { field = v; ParaScale.px = v }
    var onState: (() -> Unit)? = null
    lateinit var et: SelEditText
    var landscape = false
        private set
    private var bg: android.graphics.Bitmap? = null
    private var spec: PageDesigns.Spec? = null
    private val bmpP = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    /** Different design per page: design id of page i (0 = plain); empty = the same [bg] on every page. */
    private var designIds: List<Int> = emptyList()
    var bmpOf: (Int) -> android.graphics.Bitmap? = { null }
    private var fx = 0f
    private var ft = 0f
    private var fb = 0f

    private fun recomputeFractions() {
        val specs = listOfNotNull(spec) + designIds.mapNotNull { PageDesigns.spec(it) }
        fx = specs.maxOfOrNull { it.mx } ?: 0f
        ft = specs.maxOfOrNull { it.mt } ?: 0f
        fb = specs.maxOfOrNull { it.mb } ?: 0f
    }

    fun setDesigns(list: List<Int>) {
        if (list == designIds) return
        designIds = list
        recomputeFractions()
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    private val density = resources.displayMetrics.density
    private val gapPx = max(4, (6 * density).roundToInt())
    private val sheet = Paint()
    private val markP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val numP = Paint(Paint.ANTI_ALIAS_FLAG)
    private val endP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0x88E53935.toInt(); style = Paint.Style.STROKE; strokeWidth = 1.2f; pathEffect = android.graphics.DashPathEffect(floatArrayOf(14f, 10f), 0f) }
    private val frameP = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = android.graphics.Color.BLACK; style = Paint.Style.STROKE; strokeWidth = 1.5f }
    private val endT = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xAAE53935.toInt(); textAlign = Paint.Align.CENTER }
    private var pending = false
    private var extraPasses = 0
    /** Character offsets where a new page starts (after the last measuring). */
    var breakStarts: List<Int> = emptyList()
    private var lastW = 0
    /** Text columns preset (see [Cols]) and whether the first column is on the right (right-to-left documents). */
    var colMode = 0
        private set
    private var rtlCols = false
    private var gridPasses = 0
    /** The table handles drawn over the page (set by the screen). */
    var overlay: View? = null

    private fun nCols(): Int = Cols.count(colMode)
    private fun colGap(): Float = 18f * pgScale
    private fun colWidthFor(w: Int): Float =
        if (nCols() > 1) ((w - mlPx() - mrPx() - (nCols() - 1) * colGap()) / nCols()).coerceAtLeast(20f) else w - mlPx() - mrPx()
    private fun padRightFor(w: Int): Int =
        if (nCols() > 1) (w - mlPx() - colWidthFor(w)).roundToInt().coerceAtLeast(0) else mrPx().roundToInt()

    fun setColumns(mode: Int, rtl: Boolean) {
        if (mode == colMode && rtl == rtlCols) return
        colMode = mode
        rtlCols = rtl
        if (nCols() <= 1) et.colMap = null
        if (width > 0) applyScale(width)
        extraPasses = 0
        requestLayout()
        invalidate()
        schedule()
    }

    init {
        setBackgroundColor(0xFFEDEDED.toInt())
        sheet.color = android.graphics.Color.WHITE
        markP.color = 0xFFBDBDBD.toInt()
        markP.style = Paint.Style.STROKE
        markP.strokeWidth = max(1f, 1.2f * density)
        numP.color = 0xFF333333.toInt()
        numP.textAlign = Paint.Align.CENTER
    }

    private fun pageHpx(): Int = (pageH * pgScale).roundToInt()

    private fun designOn(): Boolean = bg != null && spec != null && !landscape
    private fun mlPx(): Float = if (designOn()) fx * pageW * pgScale else mar.l * pgScale
    private fun mrPx(): Float = if (designOn()) fx * pageW * pgScale else mar.r * pgScale
    private fun mtPx(): Float = if (designOn()) ft * pageHpx() else mar.t * pgScale
    private fun mbPx(): Float = if (designOn()) fb * pageHpx() else mar.b * pgScale

    /** A page border design: every sheet shows it and the text stays inside its frame (null = plain white sheets). */
    fun setDesign(b: android.graphics.Bitmap?, s: PageDesigns.Spec?) {
        if (b === bg && s === spec) return
        bg = b
        spec = s
        recomputeFractions()
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    fun setPaper(p: Int, land: Boolean) {
        val d = Paper.pt(p, land)
        val landChanged = landscape != land
        landscape = land
        if (d.first == pageW && d.second == pageH && !landChanged) return
        pageW = d.first
        pageH = d.second
        if (width > 0) { pgScale = width.toFloat() / pageW; applyScale(width) }
        requestLayout()
        invalidate()
        schedule()
    }

    fun setMargins(m: Mar) {
        if (m == mar) return
        mar = m
        if (width > 0) applyScale(width)
        requestLayout()
        invalidate()
        schedule()
    }

    fun setBase(sz: Int) {
        baseSize = sz
        if (pgScale > 0f) et.setTextSize(TypedValue.COMPLEX_UNIT_PX, baseSize * pgScale)
        schedule()
    }

    private fun applyScale(w: Int) {
        if (w <= 0) return
        pgScale = w.toFloat() / pageW
        et.setPadding(mlPx().roundToInt(), mtPx().roundToInt(), padRightFor(w), mbPx().roundToInt())
        et.paint.density = pgScale
        et.setTextSize(TypedValue.COMPLEX_UNIT_PX, baseSize * pgScale)
        lastW = w
    }

    override fun onMeasure(widthMeasureSpec: Int, heightMeasureSpec: Int) {
        val w = MeasureSpec.getSize(widthMeasureSpec)
        pgScale = if (w > 0) w.toFloat() / pageW else 1f
        val total = pages * pageHpx() + (pages - 1) * gapPx
        setMeasuredDimension(w, total)
        val cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY)
        val ch = MeasureSpec.makeMeasureSpec(total, MeasureSpec.EXACTLY)
        for (i in 0 until childCount) {
            val child = getChildAt(i)
            if (nCols() > 1 && child === et) {
                // the one tall text column is drawn in pieces; its view must be as tall as the whole column
                val need = (et.layout?.height ?: 0) + et.paddingTop + et.paddingBottom
                child.measure(cw, MeasureSpec.makeMeasureSpec(max(total, need), MeasureSpec.EXACTLY))
            } else child.measure(cw, ch)
        }
    }

    override fun onSizeChanged(w: Int, h: Int, oldw: Int, oldh: Int) {
        super.onSizeChanged(w, h, oldw, oldh)
        if (w != lastW) { applyScale(w); schedule() }
    }

    override fun dispatchDraw(canvas: Canvas) {
        val w = width.toFloat()
        val ph = pageHpx().toFloat()
        val design = designOn()
        val len = max(8f * density, 0.024f * w)
        numP.textSize = 11f * pgScale
        for (i in 0 until pages) {
            val top = i * (ph + gapPx)
            val bottom = top + ph
            if (design) {
                val pb = if (designIds.isEmpty()) bg else designIds[min(i, designIds.size - 1)].let { if (it == 0) null else bmpOf(it) }
                if (pb != null) canvas.drawBitmap(pb, null, android.graphics.RectF(0f, top, w, bottom), bmpP)
                else canvas.drawRect(0f, top, w, bottom, sheet)
            } else {
                canvas.drawRect(0f, top, w, bottom, sheet)
                val l = mar.l * pgScale
                val r = w - mar.r * pgScale
                val t = top + mar.t * pgScale
                val b = bottom - mar.b * pgScale
                // top-left, top-right, bottom-left, bottom-right corner marks (outside the text area)
                canvas.drawLine(l, t - len, l, t, markP); canvas.drawLine(l - len, t, l, t, markP)
                canvas.drawLine(r, t - len, r, t, markP); canvas.drawLine(r, t, r + len, t, markP)
                canvas.drawLine(l, b, l, b + len, markP); canvas.drawLine(l - len, b, l, b, markP)
                canvas.drawLine(r, b, r, b + len, markP); canvas.drawLine(r, b, r + len, b, markP)
            }
            if (nCols() > 1 && i < contentPages) {
                val cwid = colWidthFor(width)
                val rule = Paint(Paint.ANTI_ALIAS_FLAG)
                rule.color = 0xFFE2E2E2.toInt()
                rule.strokeWidth = max(1f, density)
                for (k in 1 until nCols()) {
                    val rx = mlPx() + k * (cwid + colGap()) - colGap() / 2f
                    canvas.drawLine(rx, top + mtPx(), rx, bottom - mbPx(), rule)
                }
            }
            if (border && i < contentPages) {
                val inset = min(min(mlPx(), mrPx()), min(mtPx(), mbPx())) * 0.55f
                canvas.drawRect(inset, top + inset, w - inset, bottom - inset, frameP)
            }
            if (i < contentPages) {
                // clear "page ends here" line at the bottom of the text area
                val ey = bottom - mbPx()
                canvas.drawLine(mlPx(), ey, w - mrPx(), ey, endP)
                endT.textSize = 9f * density
                canvas.drawText("صفحہ ${i + 1} ختم / Page ${i + 1} end", w / 2f, ey - 3f * density, endT)
            }
            if (numbers && i < contentPages) {
                val nx: Float
                when (pn.align) {
                    0 -> { numP.textAlign = Paint.Align.LEFT; nx = mlPx() }
                    2 -> { numP.textAlign = Paint.Align.RIGHT; nx = w - mrPx() }
                    else -> { numP.textAlign = Paint.Align.CENTER; nx = w / 2f }
                }
                val ny = if (pn.loc == 0) top + max(mtPx() - 24f * pgScale, 16f * pgScale) else bottom - mbPx() + 24f * pgScale
                canvas.drawText(PageNum.label(i + 1, pn, border), nx, ny, numP)
            }
        }
        super.dispatchDraw(canvas)
    }

    fun schedule() {
        if (pending) return
        pending = true
        post { pending = false; repaginate() }
    }

    fun currentPage(): Int {
        val lay = et.layout ?: return 1
        val off = et.selectionStart.coerceIn(0, et.text.length)
        val cm = et.colMap
        if (cm != null && cm.count > 0) {
            val ci = cm.chunkAt(lay.getLineTop(lay.getLineForOffset(off)).toFloat())
            return (ci / cm.n).coerceIn(0, pages - 1) + 1
        }
        val y = et.paddingTop + lay.getLineTop(lay.getLineForOffset(off))
        return (y / (pageHpx() + gapPx)).coerceIn(0, pages - 1) + 1
    }

    private fun gridNow() {
        try {
            if (TableGrid.fit(et)) { if (gridPasses < 6) { gridPasses++; schedule() } } else gridPasses = 0
        } catch (e: Throwable) { }
        overlay?.invalidate()
    }

    private fun repaginateColumns() {
        val lay = et.layout
        if (lay == null || width <= 0 || pgScale <= 0f) return
        try {
            val ed = et.text
            val str = ed.toString()
            val len = str.length
            val n = nCols()
            // the page pushes of the one-column mode are not used with columns
            val olds = ed.getSpans(0, len, PagePushSpan::class.java)
            if (olds.isNotEmpty()) {
                for (sp in olds) ed.removeSpan(sp)
                if (extraPasses < 8) { extraPasses++; schedule(); return }
            }
            val ph = pageHpx()
            val room = ph - mtPx() - mbPx()
            val tops = ArrayList<Int>()
            val bots = ArrayList<Int>()
            var used = 0f
            var curTop = 0
            var curBot = 0
            var open = false
            var force = false
            for (i in 0 until lay.lineCount) {
                val st = lay.getLineStart(i)
                val en = lay.getLineEnd(i)
                val top = lay.getLineTop(i)
                val bot = lay.getLineBottom(i)
                val nat = max(1, bot - top).toFloat()
                val seg = str.substring(min(st, len), min(en, len))
                val isBreakLine = seg.length <= 3 && seg.contains(PAGE_BREAK) && seg.all { it == PAGE_BREAK || it == '\n' || it == ' ' }
                if (force) {
                    // a forced page break: the rest of this page stays empty
                    if (open) { tops.add(curTop); bots.add(curBot); open = false }
                    while (tops.size % n != 0) { tops.add(top); bots.add(top) }
                    used = 0f
                    force = false
                } else if (open && !isBreakLine && used + nat > room) {
                    tops.add(curTop); bots.add(curBot); open = false; used = 0f
                }
                if (!open) { open = true; curTop = top }
                curBot = bot
                used += nat
                if (isBreakLine) force = true
            }
            if (open) { tops.add(curTop); bots.add(curBot) }
            if (tops.isEmpty()) { tops.add(0); bots.add(0) }
            val pg = (tops.size + n - 1) / n + (if (force) 1 else 0)
            et.colMap = ColumnMap(
                n, colWidthFor(width), colGap(), mlPx(), mtPx(), ph, gapPx, rtlCols,
                tops.toIntArray(), bots.toIntArray()
            )
            breakStarts = emptyList()
            contentPages = pg
            val np = max(2, contentPages)
            if (np != pages) { pages = np; requestLayout() }
            val total = pages * ph + (pages - 1) * gapPx
            val need = lay.height + et.paddingTop + et.paddingBottom
            if (et.height != max(total, need)) requestLayout()
            et.invalidate()
            invalidate()
            onState?.invoke()
            gridNow()
        } catch (e: Throwable) {
            // never let the page preview crash the editor
        }
    }

    private fun repaginate() {
        val lay = et.layout
        if (lay == null || width <= 0 || pgScale <= 0f) return
        if (nCols() > 1) { repaginateColumns(); return }
        if (et.colMap != null) { et.colMap = null; et.invalidate(); requestLayout() }
        try {
            val ed = et.text
            val str = ed.toString()
            val len = str.length
            val ph = pageHpx()
            val room = ph - mtPx() - mbPx()
            val oldSpans = ed.getSpans(0, len, PagePushSpan::class.java)
            val old = HashMap<Int, Int>()
            for (sp in oldSpans) old[ed.getSpanStart(sp)] = sp.d
            val want = LinkedHashMap<Int, Int>()
            var used = 0f
            var pg = 0
            var force = false
            for (i in 0 until lay.lineCount) {
                val st = lay.getLineStart(i)
                val en = lay.getLineEnd(i)
                val nat = max(1, lay.getLineBottom(i) - lay.getLineTop(i) - (old[st] ?: 0)).toFloat()
                val seg = str.substring(min(st, len), min(en, len))
                // a line that holds only the (invisible) page-break mark never needs a page of its own: if it did not fit
                // it used to be pushed to a new sheet and the forced break then pushed the next line to yet another sheet,
                // which left an empty extra page
                val isBreakLine = seg.length <= 3 && seg.contains(PAGE_BREAK) && seg.all { it == PAGE_BREAK || it == '\n' || it == ' ' }
                if (force || (!isBreakLine && used > 0f && used + nat > room)) {
                    val d = (ph + gapPx - used).roundToInt()
                    if (st < len && d > 0 && d <= ph + gapPx) want[st] = d
                    used = 0f
                    pg++
                    force = false
                }
                used += nat
                if (isBreakLine) force = true
            }
            breakStarts = want.keys.toList()
            var same = want.size == oldSpans.size
            if (same) {
                for ((k, v) in want) {
                    val o = old[k]
                    if (o == null || abs(o - v) > 2) { same = false; break }
                }
            }
            if (!same) {
                for (sp in oldSpans) ed.removeSpan(sp)
                for ((k, v) in want) ed.setSpan(PagePushSpan(v, 1.25f * Doc.lineSpacing), k, k + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                // the pushes change the layout: measure once more (a few times at most) so the page breaks settle
                if (extraPasses < 8) { extraPasses++; schedule() }
            } else extraPasses = 0
            contentPages = pg + 1 + (if (force) 1 else 0)
            val np = max(2, contentPages)
            if (np != pages) { pages = np; requestLayout() }
            invalidate()
            onState?.invoke()
            gridNow()
        } catch (e: Throwable) {
            // never let the page preview crash the editor
        }
    }
}

class BlankHolder {
    var et: SelEditText? = null
    var sheets: PageSheets? = null
    var overlay: TableOverlay? = null
}

fun makeBlankEditor(c: Context, onChange: () -> Unit, onSel: () -> Unit, schedule: () -> Unit): SelEditText {
    val et = SelEditText(c)
    et.background = null
    et.gravity = Gravity.TOP
    et.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
    et.setTextColor(android.graphics.Color.BLACK)
    et.setLineSpacing(0f, 1.25f * Doc.lineSpacing)
    et.paintFlags = et.paintFlags or Paint.LINEAR_TEXT_FLAG or Paint.SUBPIXEL_TEXT_FLAG
    et.isVerticalScrollBarEnabled = false
    et.overScrollMode = View.OVER_SCROLL_NEVER
    if (Doc.font != null) et.typeface = Fonts.typeface(Doc.font)
    et.setText(Doc.text, TextView.BufferType.EDITABLE)
    try { TableGuard.free { TableGuard.repairAll(et.text) } } catch (_: Throwable) { }
    et.filters = et.filters + TableFilter(et)
    decorateBlank(et.text)
    var sig = PageBreaks.signature(et.text)
    et.addTextChangedListener(object : TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, a: Int) {}
        override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
        override fun afterTextChanged(s: Editable?) {
            if (s != null) {
                val g = PageBreaks.signature(s)
                if (g != sig) { sig = g; decorateBlank(s) }
            }
            onChange()
            schedule()
        }
    })
    et.onSel = onSel
    return et
}

private fun applyBlankDir(et: EditText, rtl: Boolean, justify: Boolean) {
    et.textDirection = if (rtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_FIRST_STRONG_LTR
    if (Build.VERSION.SDK_INT >= 26) {
        et.justificationMode = if (justify) Layout.JUSTIFICATION_MODE_INTER_WORD else Layout.JUSTIFICATION_MODE_NONE
    }
}

@Composable
private fun BarBtn(icon: ImageVector, desc: String, tint: Color = IconGrey, onClick: () -> Unit) {
    IconButton(onClick = onClick, modifier = Modifier.size(49.dp)) {
        Icon(icon, desc, tint = tint, modifier = Modifier.size(26.dp))
    }
}

/** Small line-drawn icons of the floating paragraph bar (bullets, numbers, indents, alignment). */
@Composable
private fun ParaIcon(kind: String, tint: Color = Color.White) {
    Canvas(Modifier.size(24.dp)) {
        val w = size.width
        val h = size.height
        val sw = 2.2f * density
        fun line(x1: Float, x2: Float, y: Float) = drawLine(tint, Offset(x1 * w, y * h), Offset(x2 * w, y * h), strokeWidth = sw, cap = StrokeCap.Round)
        when (kind) {
            "bullets" -> for (y in listOf(0.25f, 0.5f, 0.75f)) { drawCircle(tint, 1.8f * density, Offset(0.12f * w, y * h)); line(0.3f, 0.92f, y) }
            "numbers" -> for ((i, y) in listOf(0.25f, 0.5f, 0.75f).withIndex()) { line(0.1f, 0.2f, y - 0.07f + 0.0f * i); line(0.3f, 0.92f, y) }
            "indent+" -> {
                line(0.1f, 0.92f, 0.2f); line(0.45f, 0.92f, 0.4f); line(0.45f, 0.92f, 0.6f); line(0.1f, 0.92f, 0.8f)
                drawLine(tint, Offset(0.1f * w, 0.4f * h), Offset(0.3f * w, 0.5f * h), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, Offset(0.1f * w, 0.6f * h), Offset(0.3f * w, 0.5f * h), strokeWidth = sw, cap = StrokeCap.Round)
            }
            "indent-" -> {
                line(0.1f, 0.92f, 0.2f); line(0.45f, 0.92f, 0.4f); line(0.45f, 0.92f, 0.6f); line(0.1f, 0.92f, 0.8f)
                drawLine(tint, Offset(0.3f * w, 0.4f * h), Offset(0.1f * w, 0.5f * h), strokeWidth = sw, cap = StrokeCap.Round)
                drawLine(tint, Offset(0.3f * w, 0.6f * h), Offset(0.1f * w, 0.5f * h), strokeWidth = sw, cap = StrokeCap.Round)
            }
            "left" -> { line(0.1f, 0.9f, 0.22f); line(0.1f, 0.6f, 0.42f); line(0.1f, 0.9f, 0.62f); line(0.1f, 0.6f, 0.82f) }
            "center" -> { line(0.1f, 0.9f, 0.22f); line(0.25f, 0.75f, 0.42f); line(0.1f, 0.9f, 0.62f); line(0.25f, 0.75f, 0.82f) }
        }
    }
}

@Composable
private fun PanelChip(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).background(if (on) Color(0xFF4A4A4A) else Color.Transparent, RoundedCornerShape(8.dp)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { Text(label, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold) }
}

@Composable
fun BlankPageScreen(nav: NavController) {
    val ctx = LocalContext.current
    val act = ctx as? Activity
    val holder = remember { BlankHolder() }

    var paper by remember { mutableIntStateOf(Doc.paper) }
    var land by remember { mutableStateOf(Doc.landscape) }
    var rtl by remember { mutableStateOf(Doc.rtl) }
    var justify by remember { mutableStateOf(Doc.justify) }
    var numbers by remember { mutableStateOf(Doc.pageNumbers) }
    var dirty by remember { mutableStateOf(Doc.dirty) }
    var border by remember { mutableStateOf(Doc.pageBorder) }
    var chars by remember { mutableIntStateOf(0) }
    var curPage by remember { mutableIntStateOf(1) }
    var menu by remember { mutableStateOf("") }
    var paraBar by remember { mutableStateOf(false) }
    var panel by remember { mutableStateOf(false) }
    var spacing by remember { mutableStateOf(Doc.lineSpacing) }
    var showSetup by remember { mutableStateOf(false) }
    var showPn by remember { mutableStateOf(false) }
    var customMar by remember { mutableStateOf(if (Doc.marCustom) Doc.mar else null) }
    var pn by remember { mutableStateOf(Doc.pn) }
    var showExit by remember { mutableStateOf(false) }
    var showTable by remember { mutableStateOf(false) }
    var showClear by remember { mutableStateOf(false) }
    var tRows by remember { mutableIntStateOf(3) }
    var tCols by remember { mutableIntStateOf(3) }
    var tHeader by remember { mutableStateOf(true) }
    var tStyle by remember { mutableIntStateOf(0) }
    var redoOn by remember { mutableStateOf(false) }
    var showTabs by remember { mutableStateOf(false) }
    var stBold by remember { mutableStateOf(false) }
    var stItalic by remember { mutableStateOf(false) }
    var stUnder by remember { mutableStateOf(false) }
    var sizeNow by remember { mutableIntStateOf(Doc.baseSize) }
    var fontLabel by remember { mutableStateOf(defaultFontLabel()) }
    var curColor by remember { mutableStateOf(Color.Black) }
    var paraNow by remember { mutableStateOf(ParaState()) }
    var autoNum by remember { mutableStateOf(Prefs.bool(ctx, "autonum", true)) }
    var typoCfg by remember { mutableStateOf(TypoCfg.load(ctx)) }
    var columns by remember { mutableIntStateOf(Doc.columns) }
    var stSup by remember { mutableStateOf(false) }
    var stSub by remember { mutableStateOf(false) }
    var capsNow by remember { mutableIntStateOf(0) }
    var showTblProps by remember { mutableStateOf(false) }
    var tblNow by remember { mutableStateOf<TblInfo?>(null) }
    var tblLockRows by remember { mutableStateOf<Set<Int>>(emptySet()) }
    var tblLockCols by remember { mutableStateOf<Set<Int>>(emptySet()) }
    // the design lives in Doc, so it is still there when this screen is opened again (after Save, Done ...)
    var design by remember { mutableIntStateOf(Doc.pageDesign) }
    var designList by remember { mutableStateOf<List<Int>>(Doc.pageDesigns) }
    var showDesign by remember { mutableStateOf(false) }
    var designAdd by remember { mutableStateOf(false) }

    fun effMar(): Mar = customMar ?: Mar.all(blankMargin(paper))
    fun openSetup() {
        val et = holder.et
        if (et != null) (ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
        showSetup = true
    }

    SideEffect { act?.window?.statusBarColor = BarDark.toArgb(); act?.window?.navigationBarColor = BarGrey.toArgb() }
    DisposableEffect(Unit) {
        onDispose {
            act?.window?.statusBarColor = Blue.toArgb()
            act?.window?.navigationBarColor = Blue.toArgb()
        }
    }

    fun refresh() {
        val et = holder.et ?: return
        val e = et.text
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        if (b > e.length) return
        val from = if (a == b) maxOf(a - 1, 0) else a
        stBold = e.getSpans(from, b, StyleSpan::class.java).any { (it.style and Typeface.BOLD) != 0 && (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        stItalic = e.getSpans(from, b, StyleSpan::class.java).any { (it.style and Typeface.ITALIC) != 0 && (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        stUnder = e.getSpans(from, b, UnderlineSpan::class.java).any { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }
        sizeNow = e.getSpans(from, b, AbsoluteSizeSpan::class.java).lastOrNull()?.size ?: Doc.baseSize
        val col = e.getSpans(from, b, ForegroundColorSpan::class.java).lastOrNull()
        curColor = if (col != null) Color(col.foregroundColor) else Color.Black
        val fam = e.getSpans(from, b, TypefaceSpan::class.java).lastOrNull()?.family
        fontLabel = Fonts.all().firstOrNull { it.second == fam }?.first ?: defaultFontLabel()
        holder.sheets?.let { curPage = it.currentPage() }
        try { paraNow = Para.stateAt(e, a, Doc.baseSize) } catch (_: Throwable) {}
        try {
            stSup = Rich.hasScript(e, a, b, true)
            stSub = Rich.hasScript(e, a, b, false)
            capsNow = Caps.kindAt(e, from, b)
        } catch (_: Throwable) {}
        try {
            val ti = TableOps.info(e, a)
            tblNow = ti
            if (ti != null) {
                val lk = TableLocks.get(e, a)
                tblLockRows = lk.rows
                tblLockCols = lk.cols
            }
        } catch (_: Throwable) { tblNow = null }
        holder.overlay?.invalidate()
    }
    fun sync() {
        val et = holder.et ?: return
        Doc.text = cleanCopy(et.text)
        Doc.pageStarts = holder.sheets?.breakStarts ?: emptyList()
        Doc.rtl = rtl; Doc.justify = justify; Doc.dirty = dirty; Doc.pageNumbers = numbers; Doc.pageBorder = border
        Doc.paper = paper; Doc.landscape = land; Doc.mar = effMar(); Doc.marCustom = customMar != null; Doc.pn = pn; Doc.pageDesign = design; Doc.pageDesigns = designList; Doc.columns = columns
    }
    fun touch() { dirty = true; Doc.dirty = true; refresh(); holder.sheets?.schedule() }
    fun pickDesign(id: Int) {
        design = id
        designList = emptyList()
        Doc.pageDesign = id; Doc.pageDesigns = emptyList()
        if (land && id != 0) toast(ctx, "ڈیزائن صرف سیدھے (Portrait) صفحے پر لگتا ہے / Designs work on Portrait pages only")
        touch()
    }
    /** A new page after all the text, with its own design (pages can have different designs). */
    fun addDesignPage(id: Int) {
        val et = holder.et
        val sh = holder.sheets
        if (et == null || sh == null || design == 0) { pickDesign(id); return }
        val pagesNow = sh.contentPages.coerceAtLeast(1)
        val ends = et.text.toString().trimEnd(' ', '\n').endsWith(PAGE_BREAK)
        val target = if (ends) pagesNow - 1 else pagesNow
        val list = ArrayList<Int>(if (designList.isEmpty()) listOf(design) else designList)
        while (list.size < target) list.add(list.lastOrNull() ?: design)
        while (list.size > target) list.removeAt(list.size - 1)
        list.add(id)
        if (!ends) PageBreaks.insertAt(et.text, et.text.length)
        et.setSelection(et.text.length)
        et.requestFocus()
        designList = list
        Doc.pageDesigns = list
        Doc.pageDesign = list[0]
        design = list[0]
        touch()
        toast(ctx, "نیا ڈیزائن والا صفحہ شامل ہو گیا / Design page added")
    }
    fun paraOp(block: (Editable, Int, Int) -> Unit) {
        val et = holder.et ?: return
        val (a, b) = selRange(et)
        try { block(et.text, a, b) } catch (_: Throwable) { toast(ctx, "یہ تبدیلی نہیں ہو سکی / Could not apply") }
        touch()
    }
    fun fmt(pending: ((Editable, Int) -> Unit)? = null, block: (Editable, Int, Int) -> Unit) {
        val et = holder.et ?: return
        val (a, b) = selRange(et)
        if (a == b) {
            // no selection: only the text typed from here on gets the format, the rest of the page stays as it is
            if (pending != null) { pending(et.text, a); touch() }
            else toast(ctx, "پہلے متن منتخب کریں / Select some text first")
            return
        }
        block(et.text, a, b)
        touch()
    }
    fun chooseFont(label: String, fam: String) {
        fontLabel = label
        val et = holder.et ?: return
        val (a, b) = selRange(et)
        if (a != b) {
            Rich.font(et.text, a, b, fam)
        } else if (et.text.isEmpty()) {
            Doc.font = fam
            et.typeface = Fonts.typeface(fam)
        } else {
            // cursor only: the new font is used for what is typed next; the text already written keeps its own fonts
            Rich.pendingFont(et.text, a, fam)
        }
        holder.sheets?.schedule()
        touch()
    }
    fun setSize(sz: Int) {
        sizeNow = sz
        val et = holder.et ?: return
        if (et.text.isEmpty()) {
            Doc.baseSize = sz
            holder.sheets?.setBase(sz)
            touch()
        } else fmt({ e, p -> Rich.pendingSize(e, p, sz) }) { e, s, en -> Rich.size(e, s, en, sz) }
    }
    fun quickSave(): java.io.File? {
        sync()
        return try {
            val f = Doc.saveTo(ctx, if (Doc.kind == DocKind.IMAGE) DocKind.WORD else Doc.kind, Doc.name.ifBlank { "Document" })
            dirty = false; Doc.dirty = false
            f
        } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed"); null }
    }
    fun pageBreakAction(blank: Boolean) {
        val et = holder.et ?: return
        val pos0 = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val pos = TableOps.tableRange(et.text, pos0.coerceAtMost(et.text.length))?.second ?: pos0
        val np = TableGuard.free { if (blank) PageBreaks.insertBlank(et.text, pos) else PageBreaks.insertAt(et.text, pos) }
        decorateBlank(et.text)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
    }
    fun insertTable() {
        val et = holder.et ?: return
        val pos0 = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        // a new table never goes inside another table: it is put right after it
        val pos = TableOps.tableRange(et.text, pos0.coerceAtMost(et.text.length))?.second ?: pos0
        val np = TableGuard.free { Tables.insert(et.text, pos, tRows, tCols, tHeader, tStyle) }
        decorateBlank(et.text)
        et.setSelection(np.coerceIn(0, et.text.length))
        touch()
        toast(ctx, "ٹیبل شامل ہو گیا / Table added")
    }
    fun toggleKeyboard() {
        val et = holder.et ?: return
        val imm = ctx.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        val vis = ViewCompat.getRootWindowInsets(et)?.isVisible(WindowInsetsCompat.Type.ime()) == true
        if (vis) imm.hideSoftInputFromWindow(et.windowToken, 0)
        else { et.requestFocus(); imm.showSoftInput(et, InputMethodManager.SHOW_IMPLICIT) }
    }

    // ───── table handles (A B C / 1 2 3 / + / menu) drawn on the page
    fun withTable(block: (SelEditText, Int, TblInfo) -> Unit) {
        val et = holder.et ?: return
        try { TableGuard.free { TableGuard.repairAll(et.text) } } catch (_: Throwable) { }
        val pos = maxOf(et.selectionStart, 0).coerceAtMost(et.text.length)
        val inf = TableOps.info(et.text, pos) ?: return
        try { TableGuard.free { block(et, pos, inf) } } catch (_: Throwable) { toast(ctx, "یہ تبدیلی نہیں ہو سکی / Could not apply") }
    }
    fun tblDone(et: SelEditText, np: Int?) {
        decorateBlank(et.text)
        if (np != null) et.setSelection(np.coerceIn(0, et.text.length))
        touch()
    }
    val tableActions = TableActions(
        onCol = { c -> withTable { et, pos, inf -> et.setSelection(TableOps.cellPos(et.text, pos, inf.row, c).coerceIn(0, et.text.length)); refresh() } },
        onRow = { r -> withTable { et, pos, inf -> et.setSelection(TableOps.cellPos(et.text, pos, r, inf.col).coerceIn(0, et.text.length)); refresh() } },
        onAddCol = { withTable { et, pos, _ -> tblDone(et, TableOps.addCol(et.text, pos, true)) } },
        onAddRow = { withTable { et, pos, _ -> tblDone(et, TableOps.addRow(et.text, pos, true)) } },
        onSelect = {
            withTable { et, pos, inf ->
                val r = TableOps.cellRange(et.text, pos, inf.row, inf.col)
                if (r != null) { et.requestFocus(); et.setSelection(r.first, r.second); refresh() }
            }
        },
        onSelectAll = {
            withTable { et, pos, _ ->
                val r = TableOps.tableRange(et.text, pos)
                if (r != null) { et.requestFocus(); et.setSelection(r.first, r.second); refresh() }
            }
        },
        onProps = { withTable { _, _, _ -> showTblProps = true } },
        onRowAbove = { withTable { et, pos, _ -> tblDone(et, TableOps.addRow(et.text, pos, false)) } },
        onColLeft = { withTable { et, pos, _ -> tblDone(et, TableOps.addCol(et.text, pos, false)) } },
        onDelRow = {
            withTable { et, pos, inf ->
                if (!TableOps.deleteRow(et.text, pos)) toast(ctx, if (TableLocks.get(et.text, pos).rows.contains(inf.row)) "یہ قطار لاک ہے، پہلے کھولیں / Row is locked, unlock it first" else "آخری قطار نہیں مٹ سکتی / The last row cannot be deleted")
                tblDone(et, null)
            }
        },
        onDelCol = {
            withTable { et, pos, inf ->
                if (!TableOps.deleteCol(et.text, pos)) toast(ctx, if (TableLocks.get(et.text, pos).cols.contains(inf.col)) "یہ کالم لاک ہے، پہلے کھولیں / Column is locked, unlock it first" else "آخری کالم نہیں مٹ سکتا / The last column cannot be deleted")
                tblDone(et, null)
            }
        },
        onDelTable = {
            withTable { et, pos, _ ->
                if (TableLocks.get(et.text, pos).any) toast(ctx, "ٹیبل میں لاک ہے، پہلے کھولیں / The table has locks, unlock them first")
                else tblDone(et, TableOps.deleteTable(et.text, pos))
            }
        },
        onColMove = { visual ->
            withTable { et, pos, inf ->
                // in a right-to-left document the first column is on the right, so "left" means later in the text row
                val dir = if (rtl) -visual else visual
                val lk = TableLocks.get(et.text, pos)
                val other = inf.col + dir
                if (lk.cols.contains(inf.col) || lk.cols.contains(other)) {
                    toast(ctx, "لاک والا کالم نہیں ہلتا / A locked column can not be moved")
                } else {
                    val np = TableOps.moveCol(et.text, pos, dir)
                    if (np == null) toast(ctx, "کالم مزید نہیں ہل سکتا / The column cannot move further") else tblDone(et, np)
                }
            }
        },
        onRowMove = { dir ->
            withTable { et, pos, inf ->
                val lk = TableLocks.get(et.text, pos)
                val other = inf.row + dir
                if (lk.rows.contains(inf.row) || lk.rows.contains(other)) {
                    toast(ctx, "لاک والی قطار نہیں ہلتی / A locked row can not be moved")
                } else if (inf.header && (inf.row == 0 || other == 0)) {
                    toast(ctx, "عنوان والی قطار نہیں ہلتی / The header row can not be moved")
                } else {
                    val np = TableOps.moveRow(et.text, pos, dir)
                    if (np == null) toast(ctx, "قطار مزید نہیں ہل سکتی / The row cannot move further") else tblDone(et, np)
                }
            }
        },
        onLockRow = {
            withTable { et, pos, inf ->
                val lk = TableLocks.get(et.text, pos)
                val rs = if (lk.rows.contains(inf.row)) lk.rows - inf.row else lk.rows + inf.row
                TableLocks.set(et.text, pos, rs, lk.cols)
                toast(ctx, if (rs.contains(inf.row)) "قطار ${inf.row + 1} لاک ہو گئی / Row ${inf.row + 1} locked" else "قطار ${inf.row + 1} کھل گئی / Row ${inf.row + 1} unlocked")
                tblDone(et, null)
            }
        },
        onLockCol = {
            withTable { et, pos, inf ->
                val lk = TableLocks.get(et.text, pos)
                val cs = if (lk.cols.contains(inf.col)) lk.cols - inf.col else lk.cols + inf.col
                TableLocks.set(et.text, pos, lk.rows, cs)
                toast(ctx, if (cs.contains(inf.col)) "کالم ${tableColName(inf.col)} لاک ہو گیا / Column ${tableColName(inf.col)} locked" else "کالم ${tableColName(inf.col)} کھل گیا / Column ${tableColName(inf.col)} unlocked")
                tblDone(et, null)
            }
        }
    )

    val imgPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            Doc.image = u; dirty = true; Doc.dirty = true
            toast(ctx, "تصویر PDF/Image محفوظ کرنے پر شامل ہو گی / Image is added when saving as PDF or Image")
        }
    }
    val fontPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u ->
        if (u != null) {
            var name: String? = null
            try {
                ctx.contentResolver.query(u, arrayOf(android.provider.OpenableColumns.DISPLAY_NAME), null, null, null)
                    ?.use { cur -> if (cur.moveToFirst()) name = cur.getString(0) }
            } catch (e: Exception) { }
            if (name == null) name = u.lastPathSegment
            val label = Fonts.add(ctx, u, name)
            if (label == null) toast(ctx, "یہ فونٹ شامل نہیں ہو سکا (.ttf یا .otf چاہیے) / Could not add font (.ttf or .otf needed)")
            else { toast(ctx, "فونٹ شامل ہو گیا / Font added: $label"); chooseFont(label, label) }
        }
    }

    DisposableEffect(Unit) { onDispose { ParaScale.px = 1f; sync() } }
    LaunchedEffect(Unit) { delay(150); holder.sheets?.schedule(); refresh() }
    BackHandler(enabled = dirty) { showExit = true }

    Box(Modifier.fillMaxSize()) {
    Column(Modifier.fillMaxSize().background(BarDark)) {
        // ───── top bar
        Row(Modifier.fillMaxWidth().height(56.dp).background(BarDark), verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Done", color = Color(0xFFE6E6E6), fontSize = 17.sp,
                modifier = Modifier.clickable { sync(); nav.navigate("save") }.padding(horizontal = 16.dp, vertical = 14.dp)
            )
            BarBtn(Icons.Outlined.Save, "Save") { val f = quickSave(); if (f != null) toast(ctx, "محفوظ ہو گیا / Saved: ${f.name}") }
            BarBtn(Icons.Outlined.Undo, "Undo") { TableGuard.free { holder.et?.onTextContextMenuItem(android.R.id.undo) }; redoOn = true }
            BarBtn(Icons.Outlined.Redo, "Redo", if (redoOn) IconGrey else Color(0xFF6A6A6A)) { TableGuard.free { holder.et?.onTextContextMenuItem(android.R.id.redo) } }
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(34.dp).border(1.5.dp, IconGrey, RoundedCornerShape(3.dp)).clickable { showPn = true },
                contentAlignment = Alignment.Center
            ) { Text("$curPage", color = IconGrey, fontSize = 15.sp) }
            BarBtn(Icons.Outlined.Close, "Close") { if (dirty) showExit = true else nav.popBackStack() }
        }

        // ───── page canvas
        Box(Modifier.weight(1f).fillMaxWidth()) {
            AndroidView(
                factory = { c ->
                    val sv = ScrollView(c)
                    sv.setBackgroundColor(0xFFEDEDED.toInt())
                    sv.isFillViewport = false
                    val sheets = PageSheets(c)
                    sheets.baseSize = Doc.baseSize
                    sheets.mar = effMar()
                    sheets.pn = pn
                    sheets.numbers = numbers
                    sheets.setPaper(paper, land)
                    val et = makeBlankEditor(
                        c,
                        onChange = { dirty = true; Doc.dirty = true; redoOn = false; chars = countChars(holder.et?.text ?: ""); refresh() },
                        onSel = { refresh() },
                        schedule = { holder.sheets?.schedule() }
                    )
                    et.addTextChangedListener(EditHelper(et, { autoNum }, { typoCfg }))
                    sheets.et = et
                    holder.et = et
                    InsertBridge.et = et
                    holder.sheets = sheets
                    sheets.onState = { curPage = sheets.currentPage(); chars = countChars(et.text) }
                    sheets.addView(et, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    val ov = TableOverlay(c, et)
                    ov.act = tableActions
                    ov.onResized = { sheets.schedule(); dirty = true; Doc.dirty = true }
                    sheets.addView(ov, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    sheets.overlay = ov
                    sheets.addView(InkView(c, sheets), FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
                    holder.overlay = ov
                    TableGrid.rtl = rtl
                    sheets.setColumns(columns, rtl)
                    sv.addView(sheets, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                    ViewFx.apply(sv)
                    sv
                },
                update = { _ ->
                    holder.et?.let { applyBlankDir(it, rtl, justify) }
                    TableGrid.rtl = rtl
                    holder.sheets?.let {
                        it.bmpOf = { id -> PageDesigns.bitmap(ctx, id) }
                        it.setDesign(if (design != 0) PageDesigns.bitmap(ctx, design) else null, PageDesigns.spec(design))
                        it.setDesigns(designList)
                        it.setColumns(columns, rtl)
                        it.numbers = numbers
                        it.pn = pn
                        it.border = border
                        it.setMargins(effMar())
                        it.setPaper(paper, land)
                        it.invalidate()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
            Box(
                Modifier.align(Alignment.BottomStart).padding(start = 14.dp, bottom = 12.dp)
                    .background(Color(0xFFF2F2F2), RoundedCornerShape(4.dp)).padding(horizontal = 10.dp, vertical = 5.dp)
            ) { Text("Full text: $chars", color = Color(0xFF9A9A9A), fontSize = 14.sp) }
        }

        // ───── table buttons: move column / row, lock row / column (only while the cursor is in a table)
        val tn = tblNow
        if (!panel && tn != null) TableToolsBar(tn, tblLockRows, tblLockCols, tableActions)

        // ───── text format sheet (Aa): Home / File / Insert / View
        if (panel) {
            val acts = FormatActions(
                onSize = { z -> setSize(z) },
                onFont = { l, f -> chooseFont(l, f) },
                onAddFont = { safe(ctx) { fontPicker.launch("*/*") } },
                onBold = { fmt({ e, p -> Rich.pendingStyle(e, p, Typeface.BOLD) }) { e, s, en -> Rich.bold(e, s, en) } },
                onItalic = { fmt({ e, p -> Rich.pendingStyle(e, p, Typeface.ITALIC) }) { e, s, en -> Rich.italic(e, s, en) } },
                onUnder = { fmt({ e, p -> Rich.pendingUnderline(e, p) }) { e, s, en -> Rich.underline(e, s, en) } },
                onStrike = { fmt({ e, p -> Rich.pendingStrike(e, p) }) { e, s, en -> Rich.strike(e, s, en) } },
                onColor = { c -> fmt({ e, p -> Rich.pendingColor(e, p, c) }) { e, s, en -> Rich.color(e, s, en, c) } },
                onHighlight = { c -> fmt(null) { e, s, en -> Rich.highlight(e, s, en, c) } },
                onSpacing = { v ->
                    spacing = v
                    Doc.lineSpacing = v
                    holder.et?.let { et ->
                        et.setLineSpacing(0f, 1.25f * v)
                        for (sp in et.text.getSpans(0, et.text.length, PagePushSpan::class.java)) et.text.removeSpan(sp)
                    }
                    touch()
                },
                onAlign = { m -> holder.et?.let { Rich.align(it, m); touch() } },
                onJustify = { justify = !justify; touch() },
                onRtl = { rtl = !rtl; touch() },
                onClose = { panel = false },
                onKeyboard = { toggleKeyboard() },
                onStyle = { id -> paraOp { e, a, b -> StyleFmt.applyAny(e, a, b, id, Doc.baseSize) } },
                onBullet = { i -> paraOp { e, a, b -> ListFmt.setBullet(e, a, b, i) } },
                onNumber = { st -> paraOp { e, a, b -> ListFmt.setNumbered(e, a, b, st) } },
                onNoList = { paraOp { e, a, b -> ListFmt.clearList(e, a, b) } },
                onIndent = { d -> paraOp { e, a, b -> ListFmt.changeLevel(e, a, b, d) } },
                onRestart = { paraOp { e, a, b -> if (!ListFmt.mark(e, a, b, true)) toast(ctx, "نمبر والی لائن پر کرسر رکھیں / Put the cursor in a numbered item") } },
                onContinue = { paraOp { e, a, b -> if (!ListFmt.mark(e, a, b, false)) toast(ctx, "نمبر والی لائن پر کرسر رکھیں / Put the cursor in a numbered item") } },
                onAutoNum = { v -> autoNum = v; Prefs.setBool(ctx, "autonum", v) },
                onParaFmt = { left, fr, before, after ->
                    paraOp { e, a, b ->
                        for ((s, en) in Para.paragraphs(e, a, b)) {
                            Para.setIndent(e, s, en, (left + fr).coerceAtLeast(0f), left)
                            Para.setSpace(e, s, en, before, after)
                        }
                    }
                },
                onParaReset = {
                    paraOp { e, a, b ->
                        for ((s, en) in Para.paragraphs(e, a, b)) {
                            Para.setIndent(e, s, en, 0f, 0f)
                            Para.setSpace(e, s, en, 0f, 0f)
                        }
                    }
                },
                onTypo = { k, v ->
                    typoCfg = when (k) {
                        0 -> typoCfg.copy(quotes = v)
                        1 -> typoCfg.copy(dashes = v)
                        2 -> typoCfg.copy(ellipsis = v)
                        else -> typoCfg.copy(urdu = v)
                    }
                    typoCfg.save(ctx)
                },
                onTypoApply = {
                    if (!typoCfg.any()) toast(ctx, "پہلے کوئی آپشن آن کریں / Turn an option on first")
                    else paraOp { e, a, b ->
                        val n = Typo.fix(e, a, b, typoCfg)
                        toast(ctx, if (n == 0) "کوئی تبدیلی نہیں ملی / Nothing to change" else "$n تبدیلیاں / changes")
                    }
                },
                onScript = { up -> fmt({ e, p -> Rich.pendingScript(e, p, up) }) { e, s, en -> Rich.script(e, s, en, up) } },
                onCaps = { all ->
                    fmt(null) { e, s, en ->
                        try { if (all) Caps.toggleAll(e, s, en) else Caps.toggleSmall(e, s, en) }
                        catch (_: Throwable) { toast(ctx, "یہ تبدیلی نہیں ہو سکی / Could not apply") }
                    }
                },
                onColumns = { m ->
                    columns = m
                    Doc.columns = m
                    holder.sheets?.setColumns(m, rtl)
                    touch()
                }
            )
            FormatSheet(
                acts, sizeNow, fontLabel, stBold, stItalic, stUnder, curColor, spacing, justify, rtl, paraNow, autoNum, typoCfg,
                capsNow, stSup, stSub, columns,
                file = FileActions(
                    onSave = { val f = quickSave(); if (f != null) toast(ctx, "محفوظ ہو گیا / Saved: ${f.name}\n${PublicSave.note(ctx)}") },
                    onSaveAs = { sync(); nav.navigate("save") },
                    onExportPdf = {
                        sync()
                        try {
                            val f = Doc.saveTo(ctx, DocKind.PDF, Doc.name.ifBlank { "Document" })
                            toast(ctx, "PDF بن گئی / PDF created\n${PublicSave.note(ctx)}")
                            Actions.open(ctx, f)
                        } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed") }
                    },
                    savedFile = { quickSave() },
                    makePdf = {
                        sync()
                        try {
                            val t = java.io.File(ctx.cacheDir, "file_tab_tmp.pdf")
                            Doc.write(ctx, DocKind.PDF, t)
                            t
                        } catch (e: Throwable) { null }
                    },
                    docName = { Doc.name.ifBlank { "Document" } },
                    textStats = {
                        val t = holder.et?.text?.toString() ?: ""
                        Pair(t.trim().split(Regex("\\s+")).count { it.isNotEmpty() }, t.length)
                    },
                    paperName = { Paper.get(paper).name + if (land) " (Landscape)" else "" },
                    pageNow = curPage
                ),
                insert = listOf(
                    "New page / نیا صفحہ" to { pageBreakAction(false) },
                    "Blank page / خالی صفحہ" to { pageBreakAction(true) },
                    "Insert table / ٹیبل" to { showTable = true },
                    "Image / تصویر" to { safe(ctx) { imgPicker.launch("image/*") } },
                    "Page number… / صفحہ نمبر" to { showPn = true }
                ),
                view = listOf(
                    "Page setup / پیج سیٹ اپ  (" + Paper.get(paper).name + ")" to { panel = false; openSetup() },
                    (if (design != 0) "✓ " else "") + "Page design / پیج ڈیزائن" to { designAdd = false; showDesign = true },
                    "+ Add design page / ڈیزائن والا صفحہ" to { designAdd = true; showDesign = true },
                    (if (numbers) "✓ " else "") + "Show page numbers / صفحہ نمبر" to { numbers = !numbers; touch() },
                    (if (border) "✓ " else "") + "Page border / صفحے کے گرد لکیر" to { border = !border; touch() },
                    (if (rtl) "✓ " else "") + "Right-to-left / دائیں سے بائیں" to { rtl = !rtl; touch() },
                    (if (justify) "✓ " else "") + "Justify / برابر" to { justify = !justify; touch() }
                ),
                modifier = Modifier.fillMaxWidth().height(440.dp)
            )
        }

        // ───── floating paragraph bar (bullets, numbering, indents, align, more)
        if (!panel && paraBar) Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            Row(
                Modifier.background(Color(0xFF303030), RoundedCornerShape(14.dp)).padding(horizontal = 6.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                val items = listOf<Pair<String, () -> Unit>>(
                    "bullets" to { paraOp { e, a, b -> ListFmt.setBullet(e, a, b, 0) } },
                    "numbers" to { paraOp { e, a, b -> ListFmt.setNumbered(e, a, b, 0) } },
                    "indent+" to { paraOp { e, a, b -> ListFmt.changeLevel(e, a, b, 1) } },
                    "indent-" to { paraOp { e, a, b -> ListFmt.changeLevel(e, a, b, -1) } },
                    "left" to { holder.et?.let { Rich.align(it, 0); touch() }; Unit },
                    "center" to { holder.et?.let { Rich.align(it, 1); touch() }; Unit }
                )
                for ((k, run) in items) {
                    Box(Modifier.size(44.dp).clickable(onClick = run), contentAlignment = Alignment.Center) { ParaIcon(k) }
                }
                Box {
                    Box(Modifier.size(44.dp).clickable { menu = "align" }, contentAlignment = Alignment.Center) {
                        Text("•••", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // ───── bottom toolbar
        if (!panel) Row(Modifier.fillMaxWidth().height(54.dp).background(BarGrey), verticalAlignment = Alignment.CenterVertically) {
            Spacer(Modifier.width(8.dp))
            Box {
                BarBtn(Icons.Outlined.GridView, "File Tabs") { showTabs = true }
                DropdownMenu(expanded = menu == "tools", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("Page setup / پیج سیٹ اپ  (" + Paper.get(paper).name + ")") }, onClick = { menu = ""; openSetup() })
                    DropdownMenuItem(text = { Text("Page number… / صفحہ نمبر کی ترتیب") }, onClick = { menu = ""; showPn = true })
                    DropdownMenuItem(text = { Text((if (numbers) "✓ " else "") + "Show page numbers / صفحہ نمبر") }, onClick = { menu = ""; numbers = !numbers; touch() })
                    DropdownMenuItem(text = { Text((if (border) "✓ " else "") + "Page border / صفحے کے گرد لکیر") }, onClick = { menu = ""; border = !border; touch() })
                    DropdownMenuItem(text = { Text((if (design != 0) "✓ " else "") + "Page design / پیج ڈیزائن") }, onClick = { menu = ""; designAdd = false; showDesign = true })
                    DropdownMenuItem(text = { Text("+ Add design page / ڈیزائن والا صفحہ") }, onClick = { menu = ""; designAdd = true; showDesign = true })
                    DropdownMenuItem(text = { Text((if (rtl) "✓ " else "") + "Right-to-left / دائیں سے بائیں") }, onClick = { menu = ""; rtl = !rtl; touch() })
                    DropdownMenuItem(text = { Text((if (justify) "✓ " else "") + "Justify / برابر") }, onClick = { menu = ""; justify = !justify; touch() })
                    DropdownMenuItem(text = { Text("Insert table / ٹیبل") }, onClick = { menu = ""; showTable = true })
                    DropdownMenuItem(text = { Text("Save as PDF / پی ڈی ایف") }, onClick = {
                        menu = ""
                        sync()
                        try {
                            val f = Doc.saveTo(ctx, DocKind.PDF, Doc.name.ifBlank { "Document" })
                            toast(ctx, "PDF بن گئی / PDF created\n${PublicSave.note(ctx)}")
                            Actions.open(ctx, f)
                        } catch (e: Exception) { toast(ctx, "محفوظ نہیں ہو سکا / Save failed") }
                    })
                    DropdownMenuItem(text = { Text("Save as… / محفوظ کریں") }, onClick = { menu = ""; sync(); nav.navigate("save") })
                    DropdownMenuItem(text = { Text("Share / شیئر کریں") }, onClick = { menu = ""; quickSave()?.let { Actions.share(ctx, it) } })
                    DropdownMenuItem(text = { Text("Clear all / سب مٹائیں", color = Color(0xFFD32F2F)) }, onClick = { menu = ""; showClear = true })
                }
            }
            Box(Modifier.width(1.dp).height(26.dp).background(Color(0xFF444444)))
            Spacer(Modifier.width(8.dp))
            BarBtn(Icons.Outlined.CropFree, "Page setup") { openSetup() }
            Box(Modifier.size(49.dp).clickable { panel = !panel }, contentAlignment = Alignment.Center) {
                Text(
                    buildAnnotatedString {
                        withStyle(SpanStyle(fontSize = 24.sp)) { append("A") }
                        withStyle(SpanStyle(fontSize = 16.sp)) { append("a") }
                    },
                    color = if (panel) Color.White else IconGrey
                )
            }
            Box {
                BarBtn(Icons.Outlined.FormatAlignLeft, "Align", if (paraBar) Color(0xFF64B5F6) else IconGrey) { paraBar = !paraBar }
                DropdownMenu(expanded = menu == "align", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("Left / بائیں") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 0); touch() } })
                    DropdownMenuItem(text = { Text("Center / درمیان") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 1); touch() } })
                    DropdownMenuItem(text = { Text("Right / دائیں") }, onClick = { menu = ""; holder.et?.let { Rich.align(it, 2); touch() } })
                    DropdownMenuItem(text = { Text((if (justify) "✓ " else "") + "Justify / برابر") }, onClick = { menu = ""; justify = !justify; touch() })
                }
            }
            BarBtn(Icons.Outlined.Image, "Image") { safe(ctx) { imgPicker.launch("image/*") } }
            Box {
                BarBtn(Icons.Outlined.Add, "Insert") { menu = "plus" }
                DropdownMenu(expanded = menu == "plus", onDismissRequest = { menu = "" }) {
                    DropdownMenuItem(text = { Text("New page / نیا صفحہ") }, onClick = { menu = ""; pageBreakAction(false) })
                    DropdownMenuItem(text = { Text("Blank page / خالی صفحہ") }, onClick = { menu = ""; pageBreakAction(true) })
                    DropdownMenuItem(text = { Text("Design page / ڈیزائن والا صفحہ") }, onClick = { menu = ""; designAdd = (design != 0); showDesign = true })
                    DropdownMenuItem(text = { Text("Insert table / ٹیبل") }, onClick = { menu = ""; showTable = true })
                }
            }
            Spacer(Modifier.weight(1f))
            BarBtn(Icons.Outlined.Keyboard, "Keyboard") { toggleKeyboard() }
            Spacer(Modifier.width(6.dp))
        }
    }

    if (showTabs) FileTabsOverlay(
        Doc.name.ifBlank { "Document" }.let { if (it.contains('.')) it else "$it.docx" },
        onDismiss = { showTabs = false },
        onHome = { if (dirty) showExit = true else nav.navigate("home") { popUpTo("home") } },
        onNew = { if (dirty) showExit = true else nav.navigate("new") },
        onTools = { menu = "tools" }
    )

    if (showSetup) PageSetupScreen(
        paper, land, effMar(),
        onPaper = { p, l -> paper = p; land = l; Doc.paper = p; Doc.landscape = l; dirty = true; Doc.dirty = true },
        onMar = { m -> customMar = m; dirty = true; Doc.dirty = true },
        onBack = { showSetup = false; holder.sheets?.schedule() }
    )
    }

    if (showDesign) DesignPickerDialog(
        current = design, addMode = designAdd,
        onPick = { id -> showDesign = false; val add = designAdd; designAdd = false; panel = false; if (add) addDesignPage(id) else pickDesign(id) },
        onDismiss = { showDesign = false; designAdd = false }
    )
    if (showPn) PageNumberDialog(
        pn,
        onOk = { c -> pn = c; Doc.pn = c; numbers = true; Doc.pageNumbers = true; showPn = false; touch() },
        onCancel = { showPn = false }
    )
    if (showExit) AlertDialog(
        onDismissRequest = { showExit = false },
        title = { Text("Save changes? / تبدیلیاں محفوظ کریں؟") },
        text = { Text("آپ نے دستاویز میں تبدیلی کی ہے۔\nYou have unsaved changes.") },
        confirmButton = { TextButton(onClick = { showExit = false; sync(); nav.navigate("save") }) { Text("Save / محفوظ") } },
        dismissButton = {
            Row {
                TextButton(onClick = { showExit = false }) { Text("Cancel") }
                TextButton(onClick = { showExit = false; dirty = false; Doc.dirty = false; nav.popBackStack() }) { Text("Discard", color = Color(0xFFD32F2F)) }
            }
        }
    )
    if (showClear) AlertDialog(
        onDismissRequest = { showClear = false },
        title = { Text("Clear all / سب مٹائیں") },
        text = { Text("پوری دستاویز مٹا دی جائے گی۔\nThe whole document will be cleared.") },
        confirmButton = { TextButton(onClick = { showClear = false; TableGuard.free { holder.et?.text?.clear() }; touch() }) { Text("Clear", color = Color(0xFFD32F2F)) } },
        dismissButton = { TextButton(onClick = { showClear = false }) { Text("Cancel") } }
    )
    if (showTblProps) {
        val tet = holder.et
        val tpos = if (tet == null) 0 else maxOf(tet.selectionStart, 0).coerceAtMost(tet.text.length)
        val tinf = if (tet == null) null else TableOps.info(tet.text, tpos)
        if (tet == null || tinf == null) showTblProps = false
        else TablePropsDialog(
            tinf,
            onHeader = { on -> TableGuard.free { TableOps.setHeader(tet.text, tpos, on) }; tblDone(tet, null) },
            onStyle = { st -> TableGuard.free { TableOps.setStyle(tet.text, tpos, st) }; tblDone(tet, null) },
            onClose = { showTblProps = false }
        )
    }
    if (showTable) TablePickerDialog(
        tRows, tCols, tHeader, tStyle,
        onCancel = { showTable = false },
        onOk = { r, c, h, st -> tRows = r; tCols = c; tHeader = h; tStyle = st; showTable = false; insertTable() }
    )
}
