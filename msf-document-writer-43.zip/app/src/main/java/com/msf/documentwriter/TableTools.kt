package com.msf.documentwriter

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowDownward
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.ArrowUpward
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.LockOpen
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val TtBg = Color(0xFF1B1B1B)
private val TtBtn = Color(0xFF2C2C2C)
private val TtAcc = Color(0xFF64B5F6)
private val TtLock = Color(0xFFFF9800)

@Composable
private fun TtButton(icon: ImageVector, ur: String, en: String, tint: Color, fill: Color, onClick: () -> Unit) {
    Column(
        Modifier.width(78.dp).clip(RoundedCornerShape(10.dp)).background(fill).clickable(onClick = onClick).padding(vertical = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(icon, en, tint = tint, modifier = Modifier.size(22.dp))
        Text(ur, color = Color.White, fontSize = 12.sp, maxLines = 1, textAlign = TextAlign.Center)
        Text(en, color = Color(0xFF9AA0A6), fontSize = 9.sp, maxLines = 1, textAlign = TextAlign.Center)
    }
}

@Composable
private fun TtDivider() {
    Box(Modifier.width(1.dp).height(40.dp).background(Color(0xFF3A3A3A)))
}

/**
 * Buttons shown under the page while the cursor is inside a table: move the current column left / right, move the current
 * row up / down, and lock / unlock the current row or column (a locked row or column can not be edited, moved or deleted).
 */
@Composable
fun TableToolsBar(info: TblInfo, lockRows: Set<Int>, lockCols: Set<Int>, a: TableActions, modifier: Modifier = Modifier) {
    val rowLocked = lockRows.contains(info.row)
    val colLocked = lockCols.contains(info.col)
    Column(modifier.fillMaxWidth().background(TtBg)) {
        Text(
            "ٹیبل  •  قطار ${info.row + 1}  •  کالم ${tableColName(info.col)}   (Row ${info.row + 1}, Column ${tableColName(info.col)})",
            color = Color(0xFF9AA0A6), fontSize = 11.sp, maxLines = 1,
            modifier = Modifier.padding(start = 12.dp, top = 5.dp, end = 12.dp)
        )
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 8.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically
        ) {
            TtButton(Icons.Filled.ArrowBack, "کالم بائیں", "Column left", TtAcc, TtBtn) { a.onColMove(-1) }
            TtButton(Icons.Filled.ArrowForward, "کالم دائیں", "Column right", TtAcc, TtBtn) { a.onColMove(1) }
            TtDivider()
            TtButton(Icons.Filled.ArrowUpward, "قطار اوپر", "Row up", TtAcc, TtBtn) { a.onRowMove(-1) }
            TtButton(Icons.Filled.ArrowDownward, "قطار نیچے", "Row down", TtAcc, TtBtn) { a.onRowMove(1) }
            TtDivider()
            TtButton(
                if (rowLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                if (rowLocked) "قطار کھولیں" else "قطار لاک", if (rowLocked) "Unlock row" else "Lock row",
                if (rowLocked) TtLock else Color.White, if (rowLocked) Color(0xFF3A2A12) else TtBtn
            ) { a.onLockRow() }
            TtButton(
                if (colLocked) Icons.Filled.Lock else Icons.Filled.LockOpen,
                if (colLocked) "کالم کھولیں" else "کالم لاک", if (colLocked) "Unlock column" else "Lock column",
                if (colLocked) TtLock else Color.White, if (colLocked) Color(0xFF3A2A12) else TtBtn
            ) { a.onLockCol() }
        }
    }
}
