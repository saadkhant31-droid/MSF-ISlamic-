package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import android.text.SpannableStringBuilder
import java.io.File
import java.io.FileInputStream

/** The document currently open in the editor (shared by editor, save and settings screens). */
object Doc {
    var text = SpannableStringBuilder()
    var trans = SpannableStringBuilder()
    var name = ""
    var kind = DocKind.WORD
    var rtl = false
    var justify = false
    var baseSize = 16
    var font: String? = null
    var image: Uri? = null
    var pickImage = false
    var dirty = false
    var lang = 0
    val saved = mutableMapOf<String, File>()

    fun new(c: Context, kind: DocKind, title: String = "", body: String = "", rtl: Boolean = false) {
        text = SpannableStringBuilder(body); trans = SpannableStringBuilder(); name = title; this.kind = kind; this.rtl = rtl
        justify = false; baseSize = Prefs.fontSize(c); font = null; image = null
        pickImage = false; dirty = false; lang = 0; saved.clear()
    }

    fun edit(c: Context, f: File) {
        new(c, kindOf(f.name) ?: DocKind.TEXT)
        name = f.nameWithoutExtension
        saved[f.extension.lowercase()] = f
        try {
            if (f.extension.lowercase() == "docx") {
                val r = FileInputStream(f).use { RichDocx.parse(it) }
                text = r.text; baseSize = r.size; rtl = r.rtl; justify = r.justify; font = r.font
            } else text = SpannableStringBuilder(f.readText())
        } catch (_: Exception) {}
    }

    /** Main text, plus the Urdu translation panel (if used) appended after it. */
    fun combined(): CharSequence {
        if (trans.isEmpty()) return text
        val b = SpannableStringBuilder(text)
        if (b.isNotEmpty()) b.append("\n\n")
        b.append("اردو ترجمہ\n")
        b.append(trans)
        return b
    }

    fun extOf(k: DocKind) = when (k) {
        DocKind.WORD -> "docx"; DocKind.PDF -> "pdf"; DocKind.TEXT -> "txt"; DocKind.IMAGE -> "jpg"
    }

    fun write(c: Context, k: DocKind, target: File) {
        val t: CharSequence = combined()
        when (k) {
            DocKind.WORD -> RichDocx.write(target, t, baseSize, rtl, justify, font, Prefs.paper(c), Prefs.landscape(c))
            DocKind.PDF -> {
                val b = PdfBuilder(Prefs.paper(c), Prefs.landscape(c))
                image?.let { u -> decodeBitmap(c, u, 1600)?.let { b.image(it) } }
                b.rich(t, baseSize, font, rtl, justify)
                b.finish(target)
            }
            DocKind.TEXT -> target.writeText(t.toString())
            DocKind.IMAGE -> Render.toJpeg(t, baseSize, font, rtl, justify, image?.let { decodeBitmap(c, it, 1600) }, target)
        }
    }

    fun saveTo(c: Context, k: DocKind, base: String): File {
        val ext = extOf(k)
        val clean = base.trim().ifEmpty { "Document" }.replace(Regex("[\\\\/:*?\"<>|]"), "_")
        val old = saved[ext]
        val target = if (old != null && old.nameWithoutExtension == clean) old else Store.uniqueFile(c, clean, ext)
        write(c, k, target)
        if (old != null && old != target) old.delete()
        saved[ext] = target
        name = target.nameWithoutExtension
        return target
    }
}
