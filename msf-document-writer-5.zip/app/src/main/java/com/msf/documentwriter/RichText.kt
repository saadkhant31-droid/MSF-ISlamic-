package com.msf.documentwriter

import android.graphics.Typeface
import android.text.Editable
import android.text.Layout
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.AbsoluteSizeSpan
import android.text.style.AlignmentSpan
import android.text.style.BackgroundColorSpan
import android.text.style.CharacterStyle
import android.text.style.ForegroundColorSpan
import android.text.style.StrikethroughSpan
import android.text.style.StyleSpan
import android.text.style.TypefaceSpan
import android.text.style.UnderlineSpan
import android.widget.EditText
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/** Selection based formatting helpers for the editor's EditText. */
object Rich {
    fun range(et: EditText): Pair<Int, Int> {
        val str = et.text.toString()
        var s = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var en = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        if (s == en) {
            s = str.lastIndexOf('\n', s - 1) + 1
            val nl = str.indexOf('\n', en)
            en = if (nl < 0) str.length else nl
        }
        return Pair(s, en)
    }

    private fun <T : Any> spans(e: Editable, s: Int, en: Int, cls: Class<T>): List<T> =
        e.getSpans(s, en, cls).filter { (e.getSpanFlags(it) and Spanned.SPAN_COMPOSING) == 0 }

    private fun <T : Any> clear(e: Editable, s: Int, en: Int, cls: Class<T>, copy: (T) -> T, test: (T) -> Boolean = { true }) {
        for (sp in spans(e, s, en, cls)) {
            if (!test(sp)) continue
            val ss = e.getSpanStart(sp)
            val se = e.getSpanEnd(sp)
            val fl = e.getSpanFlags(sp)
            e.removeSpan(sp)
            if (ss < s) e.setSpan(copy(sp), ss, s, fl)
            if (se > en) e.setSpan(copy(sp), en, se, fl)
        }
    }

    private fun covered(e: Editable, s: Int, en: Int, list: List<Any>): Boolean {
        var pos = s
        val iv = list.map { Pair(maxOf(e.getSpanStart(it), s), minOf(e.getSpanEnd(it), en)) }.sortedBy { it.first }
        for ((a, b) in iv) {
            if (a > pos) return false
            if (b > pos) pos = b
            if (pos >= en) return true
        }
        return pos >= en
    }

    private fun toggleStyle(e: Editable, s: Int, en: Int, st: Int) {
        val has = covered(e, s, en, spans(e, s, en, StyleSpan::class.java).filter { it.style == st })
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == st }
        if (!has) e.setSpan(StyleSpan(st), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun bold(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.BOLD)
    fun italic(e: Editable, s: Int, en: Int) = toggleStyle(e, s, en, Typeface.ITALIC)

    fun underline(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, UnderlineSpan::class.java))
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        if (!has) e.setSpan(UnderlineSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun strike(e: Editable, s: Int, en: Int) {
        val has = covered(e, s, en, spans(e, s, en, StrikethroughSpan::class.java))
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        if (!has) e.setSpan(StrikethroughSpan(), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun color(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        if (c != null) e.setSpan(ForegroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun highlight(e: Editable, s: Int, en: Int, c: Int?) {
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        if (c != null) e.setSpan(BackgroundColorSpan(c), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun size(e: Editable, s: Int, en: Int, pt: Int) {
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        e.setSpan(AbsoluteSizeSpan(pt, true), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun font(e: Editable, s: Int, en: Int, family: String) {
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
        e.setSpan(FontSpan(family), s, en, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
    }

    fun clearFormat(e: Editable, s: Int, en: Int) {
        clear(e, s, en, StyleSpan::class.java, { StyleSpan(it.style) })
        clear(e, s, en, UnderlineSpan::class.java, { UnderlineSpan() })
        clear(e, s, en, StrikethroughSpan::class.java, { StrikethroughSpan() })
        clear(e, s, en, ForegroundColorSpan::class.java, { ForegroundColorSpan(it.foregroundColor) })
        clear(e, s, en, BackgroundColorSpan::class.java, { BackgroundColorSpan(it.backgroundColor) })
        clear(e, s, en, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
        clear(e, s, en, TypefaceSpan::class.java, { FontSpan(it.family ?: "sans-serif") })
    }

    /** Paragraph ranges (start, end-without-newline) touched by the selection/cursor. */
    fun paragraphs(et: EditText): List<Pair<Int, Int>> {
        val str = et.text.toString()
        val a = minOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        val b = maxOf(et.selectionStart, et.selectionEnd).coerceAtLeast(0)
        var ps = str.lastIndexOf('\n', a - 1) + 1
        val res = mutableListOf<Pair<Int, Int>>()
        while (true) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            res.add(Pair(ps, pe))
            if (nl < 0 || nl >= b) break
            ps = nl + 1
        }
        return res
    }

    /** mode: 0 left, 1 centre, 2 right (visual). */
    fun align(et: EditText, mode: Int) {
        val e = et.text
        for ((ps, pe) in paragraphs(et)) {
            val end = if (pe < e.length) pe + 1 else pe
            for (sp in e.getSpans(ps, end, AlignmentSpan.Standard::class.java)) e.removeSpan(sp)
            val lay = et.layout
            val dir = if (lay != null && e.isNotEmpty()) lay.getParagraphDirection(lay.getLineForOffset(minOf(ps, e.length))) else 1
            val ltr = dir == Layout.DIR_LEFT_TO_RIGHT
            val al = when (mode) {
                1 -> Layout.Alignment.ALIGN_CENTER
                2 -> if (ltr) Layout.Alignment.ALIGN_OPPOSITE else Layout.Alignment.ALIGN_NORMAL
                else -> if (ltr) Layout.Alignment.ALIGN_NORMAL else Layout.Alignment.ALIGN_OPPOSITE
            }
            e.setSpan(AlignmentSpan.Standard(al), ps, end, Spanned.SPAN_PARAGRAPH)
        }
    }

    fun list(et: EditText, numbered: Boolean) {
        val e = et.text
        val ps = paragraphs(et)
        val bullet = Regex("^• ")
        val num = Regex("^\\d+\\. ")
        val rx = if (numbered) num else bullet
        val all = ps.all { (a, b) -> rx.containsMatchIn(e.subSequence(a, b)) }
        for (i in ps.indices.reversed()) {
            val (a, b) = ps[i]
            val line = e.subSequence(a, b).toString()
            val old = (bullet.find(line) ?: num.find(line))?.value
            if (all) {
                e.delete(a, a + (old?.length ?: 0))
            } else {
                if (old != null) e.delete(a, a + old.length)
                e.insert(a, if (numbered) "${i + 1}. " else "• ")
            }
        }
    }

    fun heading(et: EditText, level: Int) {
        val e = et.text
        for ((a, b) in paragraphs(et).reversed()) {
            if (b <= a) continue
            clear(e, a, b, AbsoluteSizeSpan::class.java, { AbsoluteSizeSpan(it.size, it.dip) })
            clear(e, a, b, StyleSpan::class.java, { StyleSpan(it.style) }) { it.style == Typeface.BOLD }
            if (level > 0) {
                e.setSpan(AbsoluteSizeSpan(if (level == 1) 28 else 22, true), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                e.setSpan(StyleSpan(Typeface.BOLD), a, b, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            }
        }
    }
}

data class RichDoc(val text: SpannableStringBuilder, val size: Int, val rtl: Boolean, val justify: Boolean, val font: String?)

object RichDocx {
    private val DOT = RegexOption.DOT_MATCHES_ALL
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun unesc(s: String) =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")
    private fun rtlChar(ch: Char): Boolean {
        val d = Character.getDirectionality(ch)
        return d == Character.DIRECTIONALITY_RIGHT_TO_LEFT || d == Character.DIRECTIONALITY_RIGHT_TO_LEFT_ARABIC
    }
    private fun hasRtl(s: String) = s.any { rtlChar(it) }
    private fun firstStrongRtl(s: String): Boolean {
        for (ch in s) {
            val d = Character.getDirectionality(ch)
            if (d == Character.DIRECTIONALITY_LEFT_TO_RIGHT) return false
            if (rtlChar(ch)) return true
        }
        return false
    }
    private fun hex(c: Int) = String.format("%06X", c and 0xFFFFFF)

    private fun paragraph(sp: Spanned, str: String, ps: Int, pe: Int, base: Int, docRtl: Boolean, justify: Boolean, font: String?): String {
        val bidi = docRtl || firstStrongRtl(str.substring(ps, pe))
        val al = if (pe > ps) sp.getSpans(ps, pe, AlignmentSpan::class.java).firstOrNull()?.alignment else null
        val jc = when {
            al == Layout.Alignment.ALIGN_CENTER -> "<w:jc w:val=\"center\"/>"
            al == Layout.Alignment.ALIGN_OPPOSITE -> "<w:jc w:val=\"right\"/>"
            justify -> "<w:jc w:val=\"both\"/>"
            else -> ""
        }
        val ppr = "<w:pPr>" + (if (bidi) "<w:bidi/>" else "") + jc + "</w:pPr>"
        if (pe <= ps) return "<w:p>$ppr</w:p>"
        val cuts = sortedSetOf(ps, pe)
        for (s in sp.getSpans(ps, pe, CharacterStyle::class.java)) {
            cuts.add(maxOf(ps, sp.getSpanStart(s)))
            cuts.add(minOf(pe, sp.getSpanEnd(s)))
        }
        val cl = cuts.toList()
        val runs = StringBuilder()
        for (i in 0 until cl.size - 1) {
            val a = cl[i]
            val b = cl[i + 1]
            if (b <= a) continue
            var bold = false; var ital = false; var und = false; var strike = false
            var color: Int? = null; var bg: Int? = null; var size = base; var fam = font
            for (s in sp.getSpans(a, b, CharacterStyle::class.java)) {
                if ((sp.getSpanFlags(s) and Spanned.SPAN_COMPOSING) != 0) continue
                when (s) {
                    is StyleSpan -> { if ((s.style and Typeface.BOLD) != 0) bold = true; if ((s.style and Typeface.ITALIC) != 0) ital = true }
                    is UnderlineSpan -> und = true
                    is StrikethroughSpan -> strike = true
                    is ForegroundColorSpan -> color = s.foregroundColor
                    is BackgroundColorSpan -> bg = s.backgroundColor
                    is AbsoluteSizeSpan -> size = s.size
                    is TypefaceSpan -> fam = s.family ?: fam
                    else -> {}
                }
            }
            val txt = str.substring(a, b)
            var rpr = ""
            if (fam != null) rpr += "<w:rFonts w:ascii=\"${esc(fam)}\" w:hAnsi=\"${esc(fam)}\" w:cs=\"${esc(fam)}\"/>"
            if (bold) rpr += "<w:b/><w:bCs/>"
            if (ital) rpr += "<w:i/><w:iCs/>"
            if (strike) rpr += "<w:strike/>"
            if (color != null) rpr += "<w:color w:val=\"${hex(color)}\"/>"
            rpr += "<w:sz w:val=\"${size * 2}\"/><w:szCs w:val=\"${size * 2}\"/>"
            if (und) rpr += "<w:u w:val=\"single\"/>"
            if (bg != null) rpr += "<w:shd w:val=\"clear\" w:color=\"auto\" w:fill=\"${hex(bg)}\"/>"
            if (bidi || hasRtl(txt)) rpr += "<w:rtl/>"
            val t = esc(txt).replace("\t", "</w:t><w:tab/><w:t xml:space=\"preserve\">")
            runs.append("<w:r><w:rPr>$rpr</w:rPr><w:t xml:space=\"preserve\">$t</w:t></w:r>")
        }
        return "<w:p>$ppr$runs</w:p>"
    }

    fun write(f: File, t: CharSequence, base: Int, docRtl: Boolean, justify: Boolean, font: String?, paper: Int, land: Boolean) {
        val sp = SpannableStringBuilder(t)
        val str = sp.toString()
        val body = StringBuilder()
        var ps = 0
        while (true) {
            val nl = str.indexOf('\n', ps)
            val pe = if (nl < 0) str.length else nl
            body.append(paragraph(sp, str, ps, pe, base, docRtl, justify, font))
            if (nl < 0) break
            ps = nl + 1
        }
        var w = 11906
        var h = 16838
        when (paper) { 1 -> { w = 12240; h = 15840 }; 2 -> { w = 12240; h = 20160 } }
        if (land) { val x = w; w = h; h = x }
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$body" +
            "<w:sectPr><w:pgSz w:w=\"$w\" w:h=\"$h\"${if (land) " w:orient=\"landscape\"" else ""}/>" +
            "<w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        ZipOutputStream(FileOutputStream(f)).use { z ->
            fun put(name: String, text: String) { z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry() }
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("word/document.xml", doc)
        }
    }

    private fun highlightColor(n: String): Int? = when (n.lowercase()) {
        "yellow" -> 0xFFFFFF00.toInt(); "green" -> 0xFF00FF00.toInt(); "cyan" -> 0xFF00FFFF.toInt()
        "magenta" -> 0xFFFF00FF.toInt(); "red" -> 0xFFFF0000.toInt(); "blue" -> 0xFF0000FF.toInt()
        "lightgray" -> 0xFFD3D3D3.toInt(); else -> null
    }

    fun parse(input: InputStream): RichDoc {
        val xml = Docx.zipTexts(input) { it == "word/document.xml" }["word/document.xml"] ?: ""
        val out = SpannableStringBuilder()
        var base = -1
        var anyRtl = false
        var justify = false
        var font: String? = null
        val token = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>", DOT)
        val paras = Regex("<w:p[ >].*?</w:p>|<w:p/>", DOT).findAll(xml).toList()
        for ((pi, p) in paras.withIndex()) {
            val px = p.value
            val ps = out.length
            if (px.contains("<w:bidi")) anyRtl = true
            val jc = Regex("<w:jc w:val=\"(\\w+)\"").find(px)?.groupValues?.get(1)
            for (r in Regex("<w:r[ >].*?</w:r>", DOT).findAll(px)) {
                val rx = r.value
                val rpr = Regex("<w:rPr>(.*?)</w:rPr>", DOT).find(rx)?.groupValues?.get(1) ?: ""
                val text = token.findAll(rx).joinToString("") {
                    when {
                        it.value.startsWith("<w:tab") -> "\t"
                        it.value.startsWith("<w:br") -> "\n"
                        else -> unesc(it.groupValues[1])
                    }
                }
                val rs = out.length
                out.append(text)
                val re = out.length
                if (re <= rs) continue
                val x = Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                if (rpr.contains("<w:b/>") || Regex("<w:b w:val=\"(1|true|on)\"").containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.BOLD), rs, re, x)
                if (rpr.contains("<w:i/>") || Regex("<w:i w:val=\"(1|true|on)\"").containsMatchIn(rpr)) out.setSpan(StyleSpan(Typeface.ITALIC), rs, re, x)
                if (rpr.contains("<w:u/>") || Regex("<w:u w:val=\"(?!none)\\w+\"").containsMatchIn(rpr)) out.setSpan(UnderlineSpan(), rs, re, x)
                if (rpr.contains("<w:strike/>")) out.setSpan(StrikethroughSpan(), rs, re, x)
                Regex("<w:color w:val=\"([0-9A-Fa-f]{6})\"").find(rpr)?.let {
                    out.setSpan(ForegroundColorSpan(0xFF000000.toInt() or it.groupValues[1].toInt(16)), rs, re, x)
                }
                val fill = Regex("<w:shd [^>]*w:fill=\"([0-9A-Fa-f]{6})\"").find(rpr)?.groupValues?.get(1)
                val hl = Regex("<w:highlight w:val=\"(\\w+)\"").find(rpr)?.groupValues?.get(1)
                if (fill != null) out.setSpan(BackgroundColorSpan(0xFF000000.toInt() or fill.toInt(16)), rs, re, x)
                else if (hl != null) highlightColor(hl)?.let { out.setSpan(BackgroundColorSpan(it), rs, re, x) }
                val sz = Regex("<w:sz w:val=\"(\\d+)\"").find(rpr)?.groupValues?.get(1)?.toIntOrNull()?.div(2)
                if (sz != null) {
                    if (base < 0) base = sz
                    if (sz != base) out.setSpan(AbsoluteSizeSpan(sz, true), rs, re, x)
                }
                val fam = Regex("<w:rFonts [^>]*?w:(?:ascii|cs)=\"([^\"]+)\"").find(rpr)?.groupValues?.get(1)
                if (fam != null) {
                    if (font == null) font = fam
                    else if (fam != font) out.setSpan(FontSpan(fam), rs, re, x)
                }
            }
            if (pi < paras.size - 1) out.append("\n")
            val al = when (jc) {
                "center" -> Layout.Alignment.ALIGN_CENTER
                "right", "end" -> Layout.Alignment.ALIGN_OPPOSITE
                else -> null
            }
            if (jc == "both") justify = true
            if (al != null) out.setSpan(AlignmentSpan.Standard(al), ps, out.length, Spanned.SPAN_PARAGRAPH)
        }
        return RichDoc(out, if (base < 0) 11 else base, anyRtl, justify, font)
    }
}
