# MSF Document Writer (Android)

Kotlin + Jetpack Compose. Create / edit / share / print Word (.docx), PDF and Text documents with rich formatting, Urdu & Arabic (RTL) writing, search, PDF Maker, backup & restore.

## Screens
Home · Print (new) · New Document · Text Formatting · Urdu & Arabic Writing · Save Document · My Documents · Word Documents · Search · PDF Maker · Settings · Privacy · Terms · About

## Build
- **Android Studio**: open this folder, sync Gradle, Run.
- **GitHub**: push; Actions → *Build APK* produces a debug APK artifact.

## Notes
- Documents are stored privately in the app (no INTERNET permission). "Cloud" = copy saved through the system file picker (Drive etc.).
- Set your real support e-mail in `Settings.kt` (`SUPPORT_EMAIL`).
- Fonts use system fonts; `Noto Nastaliq Urdu` / `Noto Naskh Arabic` appear only if the device has them (otherwise default Arabic-script font is used).
- Legacy .doc/.xls/.ppt are not supported in PDF Maker.

## Update
- Text Formatting, Urdu & Arabic Writing and Save Document screens redesigned to match the new mock-ups.
- Urdu & Arabic: two ornate panels (Arabic text + Urdu translation); tap the Bismillah pill to insert it; Insert Template adds Surah Al-Fatiha with its Urdu translation. The translation is saved with the document.
- Style (B/I/U), size, colour and font indicators now follow the cursor/selection.

## Update 2 (mock-up redesign)
- New **Print** screen: page preview with pager, Printer / Copies / Paper Size / Orientation / Color Mode / Print Quality, Print button, and Quick Actions (Save as PDF, Share, Preview, Advanced Settings: margins & two-sided).
- Common bottom bar on all main screens: Home - My Documents - New - Print - Settings.
- Header now has a 3-dot menu (Home and shortcuts). Document rows and Search filter chips (with counts) match the mock-ups.
- Import files moved to the My Documents 3-dot menu.

## Update 3 (Profile and Privacy & Security)
- **Profile** screen: photo (tap to change), name/email, stats (Total Documents, Created Today, Files Viewed, Bookmarks), Edit Profile, Privacy & Security, Notifications (opens the phone's notification settings), Appearance (theme), About App, Log Out.
- **Privacy & Security** screen: App Lock (phone PIN/pattern/fingerprint at app start), Fingerprint Authentication, Change PIN/Pattern (opens phone security settings), Hide Sensitive Files, Data Encryption (information), Backup & Restore, Privacy Policy, Clear Private Data.
- New dependency: androidx.biometric:biometric:1.1.0 (the app still has no INTERNET permission).

## Update 4 (crash fix)
- Fixed: the app closed when tapping **Add Font** or any option in the 3-dot menu (Add image etc.). Cause: `biometric:1.1.0` pulled in an old `fragment` library that rejects Activity Result API request codes ("Can only use lower 16 bits for requestCode"). Added `androidx.fragment:fragment-ktx:1.6.2`. This also fixes every other picker (Save as, Import, Backup/Restore, profile photo).
- Picker launches in the editor are now wrapped in `safe { }` so a failure shows a message instead of closing the app.
- Version bumped to 1.0.1 (versionCode 2).

## Update 5 (pages)
- New **page designs** (assets/pages): Golden Border and Islamic Frame. Pick them in *New Document → Page Design*, or in the editor via ⋮ → *Page design*.
- New **New page / نیا صفحہ** (⋮ menu) inserts a page break (a line holding U+000C, drawn as a "New page" label). Text also flows to a new page automatically in PDF/Word/Image output.
- PDF, Word (.docx, border as a header background image) and Image exports draw the design on every page and respect page breaks. Portrait only (the border is ignored in landscape).
- The editor shows the chosen design as an A4 sheet when a design is selected.

## Update 6 (fonts)
- Choosing or adding a font with no text selected now sets the font for the whole document (and for new typing). Before, it did nothing on an empty document.
- Added fonts: file type is detected from the file header when the picker hides the name; re-adding a font replaces the old copy.
