package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.text.Editable
import android.text.Spanned
import android.text.style.ReplacementSpan

/** Page border designs (assets/pages) and the "new page" marker used inside the text. */
object PageDesigns {
    /** mx / mt / mb = text margins as a fraction of the page width / height, chosen to stay inside the border. */
    class Spec(val id: Int, val en: String, val ur: String, val asset: String, val mx: Float, val mt: Float, val mb: Float)

    val all: List<Spec> = listOf(
        Spec(1, "Golden Border", "سنہری بارڈر", "pages/page_design_1.jpg", 0.105f, 0.125f, 0.125f),
        Spec(2, "Islamic Frame", "اسلامی فریم", "pages/page_design_2.jpg", 0.105f, 0.150f, 0.150f)
    )

    /** Width / height of the page sheet (A4). */
    const val RATIO = 0.7071f

    fun spec(id: Int): Spec? = all.firstOrNull { it.id == id }

    private val cache = HashMap<Int, Bitmap?>()

    fun bitmap(c: Context, id: Int): Bitmap? {
        val s = spec(id) ?: return null
        if (cache.containsKey(id)) return cache[id]
        val b = try {
            c.applicationContext.assets.open(s.asset).use { BitmapFactory.decodeStream(it) }
        } catch (e: Throwable) { null }
        cache[id] = b
        return b
    }

    fun bytes(c: Context, id: Int): ByteArray? {
        val s = spec(id) ?: return null
        return try { c.applicationContext.assets.open(s.asset).use { it.readBytes() } } catch (e: Throwable) { null }
    }
}

/** Page break character (form feed). It sits alone on its own line and is drawn as a small "New page" label. */
const val PAGE_BREAK = '\u000C'

class PageBreakSpan : ReplacementSpan() {
    private val w = 300

    override fun getSize(paint: Paint, text: CharSequence?, start: Int, end: Int, fm: Paint.FontMetricsInt?): Int = w

    override fun draw(canvas: Canvas, text: CharSequence?, start: Int, end: Int, x: Float, top: Int, y: Int, bottom: Int, paint: Paint) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.color = 0xFFDCEBFF.toInt()
        canvas.drawRoundRect(RectF(x, top + 3f, x + w, bottom - 3f), 14f, 14f, p)
        p.color = 0xFF0B4DB8.toInt()
        p.textSize = paint.textSize * 0.75f
        p.textAlign = Paint.Align.CENTER
        canvas.drawText("— نیا صفحہ / New page —", x + w / 2f, y.toFloat(), p)
    }
}

object PageBreaks {
    /** Makes sure every page-break character in [e] carries the drawing span (needed after loading a file). */
    fun decorate(e: Editable) {
        for (s in e.getSpans(0, e.length, PageBreakSpan::class.java)) e.removeSpan(s)
        for (i in 0 until e.length) {
            if (e[i] == PAGE_BREAK) e.setSpan(PageBreakSpan(), i, i + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        }
    }

    fun insertAt(e: Editable, pos: Int): Int {
        val p = pos.coerceIn(0, e.length)
        e.insert(p, "\n$PAGE_BREAK\n")
        decorate(e)
        return p + 3
    }
}
