package com.msf.documentwriter

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object Docx {
    private val DOT = RegexOption.DOT_MATCHES_ALL
    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    private fun unesc(s: String) =
        s.replace("&lt;", "<").replace("&gt;", ">").replace("&quot;", "\"").replace("&apos;", "'").replace("&amp;", "&")

    fun write(f: File, body: String, fmt: Fmt) {
        val jc = when (fmt.align) {
            1 -> "<w:jc w:val=\"center\"/>"
            2 -> "<w:jc w:val=\"right\"/>"
            else -> ""
        }
        val rpr = (if (fmt.bold) "<w:b/><w:bCs/>" else "") + (if (fmt.italic) "<w:i/><w:iCs/>" else "") +
            "<w:sz w:val=\"${fmt.size * 2}\"/><w:szCs w:val=\"${fmt.size * 2}\"/>" + (if (fmt.rtl) "<w:rtl/>" else "")
        val ppr = "<w:pPr>" + (if (fmt.rtl) "<w:bidi/>" else "") + jc + "</w:pPr>"
        val paras = body.replace("\r", "").split("\n").joinToString("") {
            "<w:p>$ppr<w:r><w:rPr>$rpr</w:rPr><w:t xml:space=\"preserve\">${esc(it)}</w:t></w:r></w:p>"
        }
        val doc = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<w:document xmlns:w=\"http://schemas.openxmlformats.org/wordprocessingml/2006/main\"><w:body>$paras" +
            "<w:sectPr><w:pgSz w:w=\"11906\" w:h=\"16838\"/><w:pgMar w:top=\"1440\" w:right=\"1440\" w:bottom=\"1440\" w:left=\"1440\" w:header=\"708\" w:footer=\"708\" w:gutter=\"0\"/></w:sectPr></w:body></w:document>"
        val types = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Types xmlns=\"http://schemas.openxmlformats.org/package/2006/content-types\">" +
            "<Default Extension=\"rels\" ContentType=\"application/vnd.openxmlformats-package.relationships+xml\"/>" +
            "<Default Extension=\"xml\" ContentType=\"application/xml\"/>" +
            "<Override PartName=\"/word/document.xml\" ContentType=\"application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml\"/></Types>"
        val rels = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>" +
            "<Relationships xmlns=\"http://schemas.openxmlformats.org/package/2006/relationships\">" +
            "<Relationship Id=\"rId1\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument\" Target=\"word/document.xml\"/></Relationships>"
        ZipOutputStream(FileOutputStream(f)).use { z ->
            fun put(name: String, text: String) {
                z.putNextEntry(ZipEntry(name)); z.write(text.toByteArray(Charsets.UTF_8)); z.closeEntry()
            }
            put("[Content_Types].xml", types)
            put("_rels/.rels", rels)
            put("word/document.xml", doc)
        }
    }

    fun zipTexts(input: InputStream, want: (String) -> Boolean): Map<String, String> {
        val out = linkedMapOf<String, String>()
        ZipInputStream(input).use { z ->
            var e = z.nextEntry
            while (e != null) {
                if (want(e.name)) out[e.name] = z.readBytes().toString(Charsets.UTF_8)
                e = z.nextEntry
            }
        }
        return out
    }

    fun parse(input: InputStream): Pair<String, Fmt> {
        val xml = zipTexts(input) { it == "word/document.xml" }["word/document.xml"] ?: ""
        val token = Regex("<w:t(?: [^>]*)?>(.*?)</w:t>|<w:tab/>|<w:br/>", DOT)
        val body = Regex("<w:p[ >].*?</w:p>", DOT).findAll(xml).joinToString("\n") { p ->
            token.findAll(p.value).joinToString("") {
                when {
                    it.value.startsWith("<w:tab") -> "\t"
                    it.value.startsWith("<w:br") -> "\n"
                    else -> unesc(it.groupValues[1])
                }
            }
        }
        val size = Regex("<w:sz w:val=\"(\\d+)\"").find(xml)?.groupValues?.get(1)?.toIntOrNull()?.div(2) ?: 14
        val align = when {
            xml.contains("w:jc w:val=\"center\"") -> 1
            xml.contains("w:jc w:val=\"right\"") || xml.contains("w:jc w:val=\"end\"") -> 2
            else -> 0
        }
        return Pair(body, Fmt(size = size, bold = xml.contains("<w:b/>"), italic = xml.contains("<w:i/>"), align = align, rtl = xml.contains("<w:bidi")))
    }

    private fun num(s: String) = Regex("\\d+").find(s.substringAfterLast('/'))?.value?.toIntOrNull() ?: 0

    fun xlsxText(input: InputStream): String {
        val m = zipTexts(input) { it == "xl/sharedStrings.xml" || (it.startsWith("xl/worksheets/sheet") && it.endsWith(".xml")) }
        val shared = Regex("<si>(.*?)</si>", DOT).findAll(m["xl/sharedStrings.xml"] ?: "").map { si ->
            Regex("<t[^>]*>(.*?)</t>", DOT).findAll(si.groupValues[1]).joinToString("") { unesc(it.groupValues[1]) }
        }.toList()
        val sb = StringBuilder()
        m.filterKeys { it != "xl/sharedStrings.xml" }.entries.sortedBy { num(it.key) }.forEachIndexed { idx, sheet ->
            if (idx > 0) sb.append("\n\n")
            sb.append("--- Sheet ${idx + 1} ---\n")
            Regex("<row[ >].*?</row>", DOT).findAll(sheet.value).forEach { row ->
                val cells = Regex("<c\\b([^>]*?)(?:/>|>(.*?)</c>)", DOT).findAll(row.value).map { c ->
                    val attrs = c.groupValues[1]
                    val inner = c.groupValues[2]
                    when {
                        attrs.contains("t=\"s\"") ->
                            Regex("<v>(.*?)</v>").find(inner)?.groupValues?.get(1)?.toIntOrNull()?.let { shared.getOrNull(it) } ?: ""
                        attrs.contains("t=\"inlineStr\"") ->
                            Regex("<t[^>]*>(.*?)</t>", DOT).findAll(inner).joinToString("") { unesc(it.groupValues[1]) }
                        else -> unesc(Regex("<v>(.*?)</v>").find(inner)?.groupValues?.get(1) ?: "")
                    }
                }.toList()
                sb.append(cells.joinToString("  |  ")).append("\n")
            }
        }
        return sb.toString()
    }

    fun pptxSlides(input: InputStream): List<String> =
        zipTexts(input) { it.startsWith("ppt/slides/slide") && it.endsWith(".xml") }
            .entries.sortedBy { num(it.key) }.map { e ->
                e.value.split("</a:p>").map { p ->
                    Regex("<a:t>(.*?)</a:t>", DOT).findAll(p).joinToString("") { unesc(it.groupValues[1]) }
                }.filter { it.isNotBlank() }.joinToString("\n")
            }
}

object Converter {
    private fun stripRtf(s: String): String {
        var t = s.replace(Regex("\\\\u(-?\\d+)\\??")) { String(Character.toChars(it.groupValues[1].toInt() and 0xFFFF)) }
        t = t.replace(Regex("\\\\par(?![a-z])"), "\n")
            .replace(Regex("\\\\'[0-9a-fA-F]{2}"), "")
            .replace(Regex("\\\\[a-zA-Z]+-?\\d* ?"), "")
            .replace(Regex("[{}]"), "")
        return t.trim()
    }

    /** Adds the content of the file to the PDF. Returns false if the format is not supported. */
    fun append(c: Context, u: Uri, name: String, pdf: PdfBuilder): Boolean {
        val ext = name.substringAfterLast('.', "").lowercase()
        val open = { c.contentResolver.openInputStream(u) ?: throw java.io.IOException("open failed") }
        pdf.startNewPage()
        when (ext) {
            "txt" -> pdf.text(open().use { it.readBytes().toString(Charsets.UTF_8) }, Fmt(size = 14))
            "rtf" -> pdf.text(stripRtf(open().use { it.readBytes().toString(Charsets.UTF_8) }), Fmt(size = 14))
            "docx" -> { val r = open().use { RichDocx.parse(it) }; pdf.rich(r.text, r.size, r.font, r.rtl, r.justify) }
            "xlsx" -> pdf.text(open().use { Docx.xlsxText(it) }, Fmt(size = 10))
            "pptx" -> Docx.pptxSlides(open()).forEach { pdf.startNewPage(); pdf.text(it, Fmt(size = 18)) }
            "jpg", "jpeg", "png", "bmp", "webp" -> {
                val bmp = decodeBitmap(c, u, 1600) ?: return false
                pdf.image(bmp)
            }
            else -> return false
        }
        return true
    }

    fun toTempPdf(c: Context, f: File, paper: Int = Prefs.paper(c), landscape: Boolean = Prefs.landscape(c)): File? = try {
        val out = File(c.cacheDir, f.nameWithoutExtension + ".pdf")
        val d = if (f.extension.lowercase() == "docx" && !landscape) RichDocx.designOf(f) else 0
        val b = PdfBuilder(paper, landscape, if (d != 0) PageDesigns.bitmap(c, d) else null, PageDesigns.spec(d), f.extension.lowercase() == "docx" && RichDocx.hasNumbers(f))
        if (append(c, Uri.fromFile(f), f.name, b)) { b.finish(out); out } else { b.discard(); null }
    } catch (e: Exception) { null }
}
