package com.msf.documentwriter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import android.net.Uri
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.StyleSpan
import android.os.Build
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import java.io.File
import java.io.FileOutputStream

fun decodeBitmap(c: Context, u: Uri, max: Int): Bitmap? = try {
    val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    c.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it, null, o) }
    var s = 1
    while (o.outWidth / s > max || o.outHeight / s > max) s *= 2
    c.contentResolver.openInputStream(u)?.use {
        BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
    }
} catch (e: Exception) { null }

object Render {
    fun layout(t: CharSequence, base: Float, font: String?, rtl: Boolean, justify: Boolean, width: Int, density: Float): StaticLayout {
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG)
        tp.textSize = base * density
        tp.density = density
        tp.color = Color.BLACK
        if (font != null) tp.typeface = Fonts.typeface(font)
        val b = StaticLayout.Builder.obtain(t, 0, t.length, tp, width)
            .setAlignment(Layout.Alignment.ALIGN_NORMAL)
            .setTextDirection(if (rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR)
            .setLineSpacing(0f, 1.25f)
        if (justify && Build.VERSION.SDK_INT >= 26) b.setJustificationMode(Layout.JUSTIFICATION_MODE_INTER_WORD)
        return b.build()
    }

    /** First page preview (A4 @ 595x842). */
    fun page(t: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, bg: Bitmap? = null, spec: PageDesigns.Spec? = null, numbers: Boolean = false): Bitmap {
        val bmp = Bitmap.createBitmap(595, 842, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        if (bg != null) c.drawBitmap(bg, null, RectF(0f, 0f, 595f, 842f), Paint(Paint.FILTER_BITMAP_FLAG))
        val mx = if (spec != null && bg != null) 595f * spec.mx else 40f
        val mt = if (spec != null && bg != null) 842f * spec.mt else 40f
        val mb = if (spec != null && bg != null) 842f * spec.mb else 40f
        val cut = t.indexOf(PAGE_BREAK)
        val first = if (cut >= 0) t.subSequence(0, cut) else t
        val lay = layout(first, base.toFloat(), font, rtl, justify, (595f - 2 * mx).toInt(), 1f)
        c.save()
        c.translate(mx, mt)
        c.clipRect(0f, 0f, 595f - 2 * mx, 842f - mt - mb)
        lay.draw(c)
        c.restore()
        if (numbers) {
            val np = TextPaint(Paint.ANTI_ALIAS_FLAG)
            np.textSize = 11f; np.color = 0xFF333333.toInt(); np.textAlign = Paint.Align.CENTER
            c.drawText("1", 595f / 2f, 842f - mb + 24f, np)
        }
        return bmp
    }

    /** Renders every page of a PDF (max 8) one below the other into a single JPEG. */
    fun pdfToJpeg(pdf: File, out: File, width: Int = 1000, maxPages: Int = 8) {
        val pfd = ParcelFileDescriptor.open(pdf, ParcelFileDescriptor.MODE_READ_ONLY)
        val r = PdfRenderer(pfd)
        try {
            val n = minOf(r.pageCount, maxPages).coerceAtLeast(1)
            val p0 = r.openPage(0)
            val h = (width.toFloat() * p0.height / p0.width).toInt()
            p0.close()
            val all = Bitmap.createBitmap(width, h * n, Bitmap.Config.ARGB_8888)
            val ac = Canvas(all)
            ac.drawColor(Color.WHITE)
            val one = Bitmap.createBitmap(width, h, Bitmap.Config.ARGB_8888)
            for (i in 0 until n) {
                one.eraseColor(Color.WHITE)
                val pg = r.openPage(i)
                pg.render(one, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                pg.close()
                ac.drawBitmap(one, 0f, (i * h).toFloat(), null)
            }
            one.recycle()
            FileOutputStream(out).use { all.compress(Bitmap.CompressFormat.JPEG, 92, it) }
            all.recycle()
        } finally { r.close(); pfd.close() }
    }

    fun toJpeg(t: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean, image: Bitmap?, out: File) {
        val scale = 2f
        val w = 1190
        val m = 80
        val lay = layout(t, base.toFloat(), font, rtl, justify, w - 2 * m, scale)
        val imgW = w - 2 * m
        val imgH = if (image != null) (image.height * (imgW.toFloat() / image.width)).toInt().coerceAtMost(1400) + 30 else 0
        val h = maxOf(1684, lay.height + imgH + 2 * m).coerceAtMost(16000)
        val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        c.drawColor(Color.WHITE)
        var y = m.toFloat()
        if (image != null) {
            c.drawBitmap(image, null, RectF(m.toFloat(), y, (m + imgW).toFloat(), y + imgH - 30), Paint(Paint.FILTER_BITMAP_FLAG))
            y += imgH
        }
        c.translate(m.toFloat(), y)
        lay.draw(c)
        FileOutputStream(out).use { bmp.compress(Bitmap.CompressFormat.JPEG, 92, it) }
    }
}

class PdfBuilder(paper: Int = 0, landscape: Boolean = false, private val bg: Bitmap? = null, spec: PageDesigns.Spec? = null, private val numbers: Boolean = false) {
    private val doc = PdfDocument()
    private var page: PdfDocument.Page? = null
    private var n = 0
    private var y = 0f
    private var pending = false
    private val W: Int
    private val H: Int
    private val mx: Float
    private val mt: Float
    private val mb: Float

    init {
        val (w, h) = when (paper) { 1 -> Pair(612, 792); 2 -> Pair(612, 1008); else -> Pair(595, 842) }
        if (landscape) { W = h; H = w } else { W = w; H = h }
        val useBg = bg != null && spec != null && !landscape
        mx = if (useBg) W * spec!!.mx else 40f
        mt = if (useBg) H * spec!!.mt else 40f
        mb = if (useBg) H * spec!!.mb else 40f
    }

    fun startNewPage() { pending = true }

    private fun closePage() {
        val pg = page ?: return
        if (numbers) {
            val p = TextPaint(Paint.ANTI_ALIAS_FLAG)
            p.textSize = 11f
            p.color = 0xFF333333.toInt()
            p.textAlign = Paint.Align.CENTER
            pg.canvas.drawText(n.toString(), W / 2f, H - mb + 24f, p)
        }
        doc.finishPage(pg)
    }

    private fun newPage() {
        closePage()
        n++
        page = doc.startPage(PdfDocument.PageInfo.Builder(W, H, n).create())
        if (bg != null && mx > 40f) page!!.canvas.drawBitmap(bg, null, RectF(0f, 0f, W.toFloat(), H.toFloat()), Paint(Paint.FILTER_BITMAP_FLAG))
        y = mt
        pending = false
    }

    private fun ensure() { if (page == null || pending) newPage() }

    private fun drawLayout(lay: StaticLayout, w: Int) {
        for (i in 0 until lay.lineCount) {
            val top = lay.getLineTop(i)
            val bot = lay.getLineBottom(i)
            if (y + (bot - top) > H - mb) newPage()
            val c = page!!.canvas
            c.save()
            c.translate(mx, y - top)
            c.clipRect(0f, top.toFloat(), w.toFloat(), bot.toFloat())
            lay.draw(c)
            c.restore()
            y += (bot - top)
        }
    }

    /** Rich (spanned) text. Spans such as bold, colour, size, alignment are honoured; page breaks and |tables| are handled. */
    fun rich(t: CharSequence, base: Int, font: String?, rtl: Boolean, justify: Boolean) {
        ensure()
        val w = (W - 2 * mx).toInt()
        val s = t.toString()
        var start = 0
        while (true) {
            val i = s.indexOf(PAGE_BREAK, start)
            val end = if (i < 0) s.length else i
            for (blk in Tables.split(s, start, end)) {
                when (blk) {
                    is TextBlock -> drawLayout(Render.layout(t.subSequence(blk.a, blk.b), base.toFloat(), font, rtl, justify, w, 1f), w)
                    is TableBlock -> drawTable(t, blk, base, font, rtl, w)
                }
            }
            if (i < 0) break
            newPage()
            start = i + 1
            if (start < s.length && s[start] == '\n') start++
        }
    }

    private fun drawTable(t: CharSequence, tb: TableBlock, base: Int, font: String?, rtl: Boolean, w: Int) {
        val cols = tb.rows.maxOf { it.size }.coerceAtLeast(1)
        val colW = w / cols.toFloat()
        val pad = 4f
        val border = Paint(Paint.ANTI_ALIAS_FLAG)
        border.color = Color.BLACK
        border.style = Paint.Style.STROKE
        border.strokeWidth = 0.8f
        val shade = Paint()
        shade.color = 0xFFE8EEF7.toInt()
        shade.style = Paint.Style.FILL
        for ((ri, row) in tb.rows.withIndex()) {
            val head = tb.header && ri == 0
            val lays = ArrayList<StaticLayout>()
            for (ci in 0 until cols) {
                val cell = row.getOrNull(ci)
                val txt: CharSequence = if (cell == null || cell.second <= cell.first) "" else t.subSequence(cell.first, cell.second)
                val shown: CharSequence = if (head && txt.isNotEmpty()) {
                    val sb = SpannableStringBuilder(txt)
                    sb.setSpan(StyleSpan(Typeface.BOLD), 0, sb.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
                    sb
                } else txt
                lays.add(Render.layout(shown, base.toFloat(), font, rtl, false, (colW - 2 * pad).toInt().coerceAtLeast(10), 1f))
            }
            var rowH = 0f
            for (l in lays) rowH = maxOf(rowH, l.height.toFloat())
            rowH += 2 * pad
            if (y + rowH > H - mb) newPage()
            val c = page!!.canvas
            for (ci in 0 until cols) {
                val x = mx + (if (rtl) (cols - 1 - ci) * colW else ci * colW)
                val r = RectF(x, y, x + colW, y + rowH)
                if (head) c.drawRect(r, shade)
                c.drawRect(r, border)
                c.save()
                c.translate(x + pad, y + pad)
                c.clipRect(0f, 0f, colW - 2 * pad, rowH - 2 * pad)
                lays[ci].draw(c)
                c.restore()
            }
            y += rowH
        }
        y += 8f
    }

    fun text(t: String, f: Fmt) {
        ensure()
        val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
            textSize = f.size.toFloat()
            color = Color.BLACK
            typeface = Typeface.create(
                Typeface.DEFAULT,
                when { f.bold && f.italic -> Typeface.BOLD_ITALIC; f.bold -> Typeface.BOLD; f.italic -> Typeface.ITALIC; else -> Typeface.NORMAL }
            )
        }
        val w = (W - 2 * mx).toInt()
        val al = when (f.align) {
            1 -> Layout.Alignment.ALIGN_CENTER
            2 -> Layout.Alignment.ALIGN_OPPOSITE
            else -> Layout.Alignment.ALIGN_NORMAL
        }
        val dir = if (f.rtl) TextDirectionHeuristics.RTL else TextDirectionHeuristics.FIRSTSTRONG_LTR
        for (para in t.replace("\r", "").split("\n")) {
            val lay = StaticLayout.Builder.obtain(para, 0, para.length, tp, w)
                .setAlignment(al).setTextDirection(dir).setLineSpacing(0f, 1.25f).build()
            drawLayout(lay, w)
        }
    }

    fun image(b: Bitmap) {
        ensure()
        val s = minOf((W - 2 * mx) / b.width, (H - mt - mb) / b.height)
        val h = b.height * s
        if (y + h > H - mb) newPage()
        page!!.canvas.drawBitmap(b, null, RectF(mx, y, mx + b.width * s, y + h), Paint(Paint.FILTER_BITMAP_FLAG))
        y += h + 12f
    }

    fun finish(out: File) {
        if (page == null) newPage()
        closePage()
        page = null
        FileOutputStream(out).use { doc.writeTo(it) }
        doc.close()
    }

    fun discard() { try { doc.close() } catch (_: Exception) {} }
}
